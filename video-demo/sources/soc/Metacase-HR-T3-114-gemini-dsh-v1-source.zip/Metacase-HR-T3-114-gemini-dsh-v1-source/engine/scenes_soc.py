"""Centre-panel scenes for the HR-T3-114 replay of the gemini-3.8-flash x DeepSeek Harness run.

Every figure drawn here is stated in the approved page copy or in the run record
(data/hr.json, the judge's per-criterion verdicts). No row of the task's input files is drawn.
"""
from __future__ import annotations

import gfx as G
import ui as U
from scenes import cue, after
from scenes_x import frame, check_frame, verdict, IX0, IX1

W = IX1 - IX0


def _card(cv, x, y, w, h, a, col=None, k=0.0, fill=(13, 18, 26)):
    col = col or G.EDGE
    G.rrect(cv, x, y, w, h, 12, fill=G.mix(fill, col, 0.06 * k), fa=0.96, stroke=G.mix(G.EDGE, col, 0.35 + 0.65 * k), sw=1.4, a=a)


# ============================================================================ TASK chapter
def draw_hubs(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, d.get("title", "The setting"), d.get("sub", ""), title_c=G.BRAND)
    hubs = [("SYN-HUB-01", False), ("SYN-HUB-02", False), ("SYN-HUB-03", False), ("SYN-HUB-04", True)]
    cw = (W - 3 * 20) / 4
    for j, (hid, deferred) in enumerate(hubs):
        x = IX0 + j * (cw + 20)
        at = cue(sh, "d") if deferred else 0.25 + j * 0.3
        k = a * G.ease(G.seg(t, at, at + 0.5))
        col = G.BRAND if deferred else G.SANDBOX
        G.rrect(cv, x, 330, cw, 230, 14, fill=G.mix((13, 18, 26), col, 0.08), stroke=col, sw=1.6, a=k)
        cx_ = x + cw / 2
        G.poly(cv, [(cx_ - 46, 400), (cx_, 368), (cx_ + 46, 400)], col, a=k * 0.9)
        G.rrect(cv, cx_ - 40, 400, 80, 52, 3, fill=G.mix(G.PANEL, col, 0.35), a=k)
        G.rrect(cv, cx_ - 14, 422, 28, 30, 2, fill=G.mix(G.PANEL, col, 0.7), a=k)
        G.text(cv, hid, cx_, 470, size=17, c=G.FG, weight=600, kind="mono", a=k, align="center")
        G.text(cv, "deferred" if deferred else "trained · 6 weeks", cx_, 500, size=15, c=col, kind="mono", a=k, align="center")
        if deferred:
            G.text(cv, "same-period reference", cx_, 524, size=13.5, c=G.DIM, kind="mono", a=k, align="center")
    k2 = a * after(sh, t, "d", 0.6, 0.6)
    y = 600
    G.rrect(cv, IX0, y, W, 120, 12, fill=(13, 18, 26), fa=0.96, stroke=G.EDGE, sw=1.3, a=k2)
    G.text(cv, "Did the training change how supervisors handle incidents,", IX0 + 22, y + 22, size=19, c=G.FG, a=k2)
    G.text(cv, "or did opportunity, equipment and weather move the numbers?", IX0 + 22, y + 52, size=19, c=G.FG, a=k2)
    G.text(cv, "all entities and data in this task are synthetic", IX0 + 22, y + 86, size=13.5, c=G.DIM, kind="mono", a=k2)


PACKAGES = [("SYN-WP-A", "Training preparation and delivery", "244,800", "delivery items"),
            ("SYN-WP-B", "Evidence of retention and on-the-job transfer", "367,200", "4 equal evidence units"),
            ("SYN-WP-C", "Operational validation and close-out", "204,000", "2 equal validation units")]


def draw_claim(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, d.get("title", "The decision"), d.get("sub", ""), title_c=G.BRAND)
    cw = (W - 2 * 20) / 3
    for j, (wid, en, amt, unit) in enumerate(PACKAGES):
        x = IX0 + j * (cw + 20)
        at = cue(sh, "wp") + j * 0.25
        k = a * G.ease(G.seg(t, at, at + 0.45))
        G.rrect(cv, x, 330, cw, 250, 14, fill=(13, 18, 26), fa=0.96, stroke=G.EDGE, sw=1.4, a=k)
        G.text(cv, wid, x + 18, 348, size=18, c=G.MODEL, weight=700, kind="mono", a=k)
        G.text(cv, en, x + 18, 382, size=17, c=G.FG, weight=600, a=k, width=cw - 36, maxlines=2)
        G.text(cv, f"¥ {amt}", x + 18, 462, size=26, c=G.FG, weight=600, a=k)
        G.text(cv, unit, x + 18, 502, size=13.5, c=G.DIM, kind="mono", a=k)
        cx_ = x + 18
        for lab in ("accept", "retain", "defer"):
            w = U.pill(cv, lab + "?", cx_, 534, G.BRAND, a=k, size=13)
            cx_ += w + 8
    ks = a * after(sh, t, "sum", 0.5)
    y = 612
    G.rrect(cv, IX0, y, W, 112, 12, fill=G.mix(G.PANEL, G.WARN, 0.06), stroke=G.mix(G.EDGE, G.WARN, 0.8), sw=1.4, a=ks)
    G.text(cv, "¥ 816,000 claimed in total", IX0 + 22, y + 18, size=24, c=G.FG, weight=600, a=ks)
    G.text(cv, "Provider's stage claim: all three accepted, citing “materials uploaded” — the provider's own rating",
           IX0 + 22, y + 64, size=15, c=G.WARN, a=ks, maxlines=1, width=870)


UNSETTLED = [
    ("supervisor_scope_shift_roster.csv", "84 names · one in the wrong role", "listed in error", "a"),
    ("attendance_makeup_waivers.csv", "3 supervisors · 360 minutes each, no sign-out", "pending verification", "b"),
    ("scenario_test_answers_3_points.csv", "2 supervisors · a practice attempt before the delayed test", "practice · void", "c"),
    ("field_behaviour_coding.xlsx", "18 of 1,145 observations · observers disagree", "pending review", "d"),
    ("evidence_completeness_checklist.xlsx", "one chiller repair · end recorded a day apart", "open", "e"),
]


def draw_unsettled(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, d.get("title", "The evidence"), d.get("sub", ""), title_c=G.BRAND)
    y0, rh = 322, 66
    for j, (fn, what, status, at) in enumerate(UNSETTLED):
        k = a * after(sh, t, at, 0.4)
        if k <= 0.01:
            continue
        y = y0 + j * rh
        hi = G.fade_io(t, cue(sh, at), cue(sh, at) + 1.6, 0.3)
        _card(cv, IX0, y, W, rh - 10, k, G.WARN, hi)
        kind = fn.rsplit(".", 1)[1]
        G.icon_file(cv, IX0 + 14, y + 8, kind, a=k, w=28, h=38)
        G.text(cv, fn, IX0 + 54, y + 8, size=13, c=G.DIM, kind="mono", a=k, maxlines=1, width=560)
        G.text(cv, what, IX0 + 54, y + 27, size=17, c=G.FG, a=k, maxlines=1, width=600)
        U.pill(cv, status, IX1 - 16, y + 15, G.WARN, a=k, size=14, align="right")
    kf = a * after(sh, t, "e", 0.5, 0.2)
    y = y0 + len(UNSETTLED) * rh + 6
    G.rrect(cv, IX0, y, 760, 62, 12, fill=G.mix(G.PANEL, G.BRAND, 0.08), stroke=G.BRAND, sw=1.4, a=kf)
    G.text(cv, "Every status must be kept as it stands.", IX0 + 20, y + 19, size=18, c=G.FG, weight=600, a=kf)


THRESHOLDS = [
    ("SYN-WP-A", "Training preparation and delivery", "a",
     [("Training units delivered", "delivery verified"),
      ("Effective learning time", "≥ 85% of 1,620 min, met by ≥ 90% of supervisors")]),
    ("SYN-WP-B", "Retention and on-the-job transfer", "b",
     [("Delayed-test coverage", "≥ 90% · formal attempts only"),
      ("Behaviour attainment", "≥ 75% of supervisors with ≥ 2 verified incidents")]),
    ("SYN-WP-C", "Operational validation and close-out", "c",
     [("Operational validation", "net improvement > 0 on ≥ 2 core metrics"),
      ("Close-out", "usable index · no high-risk open item marked closed")]),
]


def draw_thresholds(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, d.get("title", "The contract"), d.get("sub", ""), title_c=G.BRAND)
    cw = (W - 2 * 20) / 3
    for j, (wid, name, at, rules) in enumerate(THRESHOLDS):
        x = IX0 + j * (cw + 20)
        k = a * G.ease(G.seg(t, 0.2 + j * 0.25, 0.65 + j * 0.25))
        hi = G.fade_io(t, cue(sh, at), cue(sh, at) + 2.2, 0.3)
        G.text(cv, wid, x, 322, size=18, c=G.MODEL, weight=700, kind="mono", a=k)
        G.text(cv, name, x, 350, size=14.5, c=G.DIM, a=k, maxlines=1, width=cw)
        for r, (lab, thr) in enumerate(rules):
            y = 386 + r * 138
            _card(cv, x, y, cw, 124, k, G.BRAND, hi)
            G.text(cv, f"THRESHOLD {r + 1}", x + 16, y + 14, size=12, c=G.BRAND, kind="mono", weight=600, a=k, ls=1.4)
            G.text(cv, lab, x + 16, y + 36, size=18, c=G.FG, weight=600, a=k, maxlines=1, width=cw - 32)
            G.text(cv, thr, x + 16, y + 66, size=14, c=(190, 198, 210), kind="mono", a=k, width=cw - 32, maxlines=2, lh=1.35)
    kf = a * after(sh, t, "a", 0.5)
    G.text(cv, "“uploaded” is not “reviewed”  ·  a unit whose key source is pending does not pass", IX0, 676, size=15,
           c=G.WARN, kind="mono", a=kf, maxlines=1, width=780)


# ============================================================================ behaviour measures (AGENT and CHECK)
MEASURES = [("mean of all reviewed items ≥ 3.0", 73, "100%"),
            ("mean of the last round ≥ 3.0", 67, "91.8%"),
            ("all five ratings ≥ 3 in the last round", 53, "72.6%")]


def draw_measures(cv, sh, t, a, ctx):
    d = sh.d
    if d.get("check"):
        check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    else:
        frame(cv, a, d.get("title", "One threshold, three measures"), d.get("sub", ""), d.get("rq", ""),
              accent=G.MODEL, accent_a=0.3, title_c=G.MODEL)
    k0 = a * after(sh, t, "m", 0.4)
    bx0, bx1 = IX0 + 360, IX1 - 180
    X = lambda v: bx0 + (bx1 - bx0) * v / 73.0
    y0, rh = 336, 78
    cues = d.get("row_cues", ("a", "b", "c"))
    tags = {r: (txt, col, at) for r, txt, col, at in d.get("tags", [])}
    for j, (lab, n, pct) in enumerate(MEASURES):
        y = y0 + j * rh
        k = a * after(sh, t, cues[j], 0.45)
        below = n / 73.0 < 0.75
        col = G.FAIL if below else G.SANDBOX
        G.text(cv, lab, IX0, y + 8, size=16, c=G.FG, a=k0, width=350, maxlines=1)
        G.rrect(cv, bx0, y + 6, bx1 - bx0, 30, 6, fill=(22, 28, 38), a=k0)
        grow = G.ease(G.seg(t, cue(sh, cues[j]), cue(sh, cues[j]) + 0.7))
        G.rrect(cv, bx0, y + 6, (X(n) - bx0) * grow, 30, 6, fill=G.mix(G.PANEL, col, 0.75), a=k)
        G.text(cv, f"{n} / 73", bx1 + 14, y + 2, size=20, c=G.FG, weight=600, kind="mono", a=k)
        G.text(cv, pct, bx1 + 14, y + 28, size=13.5, c=col, kind="mono", a=k)
        if j in tags:
            txt, tcol, at = tags[j]
            kt = a * after(sh, t, at, 0.4)
            U.pill(cv, txt, IX0, y + 40, G.ROLE.get(tcol, G.BRAND), a=kt, size=13)
    # contract threshold at 75%
    tx = X(73 * 0.75)
    G.line(cv, [(tx, y0 - 8), (tx, y0 + 3 * rh - 16)], G.WARN, sw=1.6, a=k0, dash=(6, 5))
    G.text(cv, "contract threshold 75%", tx, y0 + 3 * rh - 12, size=13, c=G.WARN, kind="mono", a=k0, align="center")
    yb = y0 + 3 * rh + 22
    if d.get("verdict"):
        cid, title, result, col, at = d["verdict"]
        verdict(cv, a, IX0, yb, cid, title, result, col, after(sh, t, at, 0.5))
        if d.get("note"):
            kn = a * after(sh, t, d.get("note_at", at), 0.5)
            G.text(cv, d["note"], IX0, yb + 86, size=15, c=G.DIM, kind="mono", a=kn, maxlines=1, width=780)
    elif d.get("note"):
        kn = a * after(sh, t, d.get("note_at", "pick"), 0.5)
        G.rrect(cv, IX0, yb, 780, 62, 12, fill=G.mix(G.PANEL, G.MODEL, 0.08), stroke=G.MODEL, sw=1.4, a=kn)
        G.text(cv, d["note"], IX0 + 20, yb + 19, size=17, c=G.FG, a=kn, maxlines=1, width=740)


# ============================================================================ CHECK chapter
ACCEPTED = [("SYN-WP-A", "conditional acceptance", "three sign-outs pending", "¥ 220,320", "for approval", "¥ 24,480", "retained", "a"),
            ("SYN-WP-B", "partial · 3 of 4 units", "behaviour unit deferred", "¥ 275,400", "for approval", "¥ 91,800", "deferred", "b"),
            ("SYN-WP-C", "partial · 1 of 2 units", "close-out unit deferred", "¥ 102,000", "for approval", "¥ 102,000", "deferred", "c")]


def draw_accept(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    cw = (W - 2 * 20) / 3
    ka = after(sh, t, "amt", 0.5)
    for j, (wid, status, why, v1, l1, v2, l2, at) in enumerate(ACCEPTED):
        x = IX0 + j * (cw + 20)
        k = a * after(sh, t, at, 0.45)
        hi = G.fade_io(t, cue(sh, at), cue(sh, at) + 1.4, 0.3)
        _card(cv, x, 326, cw, 250, k, G.PASS, max(hi, 0.4 * ka))
        G.text(cv, wid, x + 18, 342, size=18, c=G.MODEL, weight=700, kind="mono", a=k)
        G.text(cv, status, x + 18, 374, size=19, c=G.PASS, weight=600, a=k, maxlines=1, width=cw - 36)
        G.text(cv, why, x + 18, 404, size=13.5, c=G.DIM, kind="mono", a=k, maxlines=1, width=cw - 36)
        G.line(cv, [(x + 18, 436), (x + cw - 18, 436)], (32, 40, 54), sw=1, a=k)
        kk = k * (0.45 + 0.55 * ka)
        G.text(cv, v1, x + 18, 450, size=24, c=G.FG, weight=600, a=kk)
        G.text(cv, l1, x + cw - 18, 458, size=13, c=G.DIM, kind="mono", a=kk, align="right")
        G.text(cv, v2, x + 18, 500, size=24, c=G.FG, weight=600, a=kk)
        G.text(cv, l2, x + cw - 18, 508, size=13, c=G.DIM, kind="mono", a=kk, align="right")
    verdict(cv, a, IX0, 602, "R20–R25", "Status and amounts of all three packages · 40 of 40 points", "met", "pass",
            after(sh, t, "ok", 0.5, 0.3))
    G.text(cv, "recommendations only · approval stays with the authorised body", IX0, 690, size=14, c=G.DIM, kind="mono",
           a=a * ka, maxlines=1, width=780)


SHEETS = ["Index & definitions", "Sample & master ledger", "Attendance & hours", "Retention & tests",
          "Opportunity & behaviour", "Coaching & actions", "Operations & DiD", "Disruptions & attribution",
          "Evidence gaps", "Packages & amounts"]


def draw_byhub(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    k1 = after(sh, t, "pool", 0.5)
    k2 = after(sh, t, "idx", 0.5)
    w = (W - 30) / 2
    G.kicker(cv, "WORKBOOK · THREE TRAINED HUBS, POOLED", IX0, 318, c=G.WARN, a=a * k1, size=13)
    G.rrect(cv, IX0, 342, w, 118, 12, fill=(13, 18, 26), stroke=G.WARN, sw=1.4, a=a * k1)
    for j, (lab, val) in enumerate((("response-SLA rate", "+4.33 pp"), ("isolation completeness", "+5.53 pp"))):
        G.text(cv, lab, IX0 + 18, 362 + j * 44, size=16, c=G.FG, a=a * k1)
        G.text(cv, val, IX0 + w - 18, 358 + j * 44, size=21, c=G.WARN, weight=600, kind="mono", a=a * k1, align="right")
    x2 = IX0 + w + 30
    G.kicker(cv, "RUBRIC · EACH HUB NET OF SYN-HUB-04", x2, 318, c=G.SCORER, a=a * k1, size=13)
    G.rrect(cv, x2, 342, w, 118, 12, fill=(13, 18, 26), stroke=G.SCORER, sw=1.4, a=a * k1)
    for j, (hub, val) in enumerate((("SYN-HUB-01", "+6.5 pp"), ("SYN-HUB-02", "+4.5 pp"), ("SYN-HUB-03", "+2.0 pp"))):
        G.text(cv, hub, x2 + 18, 354 + j * 33, size=15, c=G.FG, kind="mono", a=a * k1)
        G.text(cv, "response-SLA rate", x2 + 150, 355 + j * 33, size=13.5, c=G.DIM, kind="mono", a=a * k1)
        G.text(cv, val, x2 + w - 18, 351 + j * 33, size=19, c=G.SCORER, weight=600, kind="mono", a=a * k1, align="right")
    verdict(cv, a, IX0, 474, "R14–16", "Each trained hub's net change shown directly · 3 criteria", "not met", "fail", k1)
    y = 558
    G.text(cv, "10 sheets in the workbook", IX0, y, size=14, c=G.DIM, kind="mono", a=a * k1)
    x, yy = IX0, y + 24
    for nm in SHEETS + ["Source index"]:
        tw, _ = G.measure(nm, 13, 500)
        if x + tw + 18 > IX1:
            x, yy = IX0, yy + 34
        if nm == "Source index":
            G.rrect(cv, x, yy, tw + 18, 28, 7, stroke=G.FAIL, sw=1.4, a=a * k2, dash=(5, 4))
            G.text(cv, nm, x + 9, yy + 5, size=13, c=G.FAIL, a=a * k2)
        else:
            G.rrect(cv, x, yy, tw + 18, 28, 7, fill=(18, 23, 32), stroke=G.EDGE, sw=1.1, a=a * k1)
            G.text(cv, nm, x + 9, yy + 5, size=13, c=G.FG, a=a * k1)
        x += tw + 26
    verdict(cv, a, IX0, 656, "R1 · R19", "A source index with key chains", "not met", "fail", k2)


CLAIMS = [("R13", "Coaching and behaviour: a descriptive association", "r"),
          ("R17", "Attribution with its limits stated", "b"),
          ("R26", "A complete closure plan", "p")]


def draw_claims(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    kq = after(sh, t, "q", 0.5)
    G.kicker(cv, "DECISION MEMO · AS SUBMITTED", IX0, 322, c=G.WARN, a=a * kq, size=13)
    G.rrect(cv, IX0, 348, W, 104, 12, fill=G.mix((13, 18, 26), G.WARN, 0.05), stroke=G.WARN, sw=1.5, a=a * kq)
    G.text(cv, "the data “irrefutably prove” the training's independent value", IX0 + 22, 366, size=24, c=G.WHITE, weight=600,
           a=a * kq, maxlines=1, width=W - 44)
    G.text(cv, "the memo's wording, rendered in English · cited in the judge's reasoning for R13", IX0 + 22, 412, size=13.5, c=G.DIM, kind="mono", a=a * kq)
    for j, (cid, title, at) in enumerate(CLAIMS):
        verdict(cv, a, IX0, 478 + j * 84, cid, title, "not met", "fail", after(sh, t, "r", 0.45, j * 0.3))


# ============================================================================ RESULT chapter
HELD = ["Scope, attendance, tests, strata · 13 criteria", "Pending and void records kept as they stand",
        "Status and amounts of all three packages", "No penalty triggered · data-use rule kept"]
FAILED = ["A measure at odds with the rubric · R11", "Net change pooled, not by hub · R14–R16",
          "Attribution and its limits · R13, R17", "Source index and closure plan · R1, R19, R26"]


def draw_lessons(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, d.get("title", "What the record shows"), d.get("sub", ""))
    w = (W - 30) / 2
    for j, (head, rows, col, at) in enumerate((("WHAT HELD", HELD, G.PASS, "a"), ("WHAT FAILED", FAILED, G.FAIL, "b"))):
        x = IX0 + j * (w + 30)
        k = a * after(sh, t, at, 0.5)
        G.kicker(cv, head, x, 322, c=col, a=k, size=13.5)
        G.rrect(cv, x, 348, w, 250, 12, fill=G.mix((13, 18, 26), col, 0.05), fa=0.96, stroke=G.mix(G.EDGE, col, 0.8), sw=1.4, a=k)
        for r, ln in enumerate(rows):
            kr = a * G.ease(G.seg(t, cue(sh, at) + 0.25 + r * 0.22, cue(sh, at) + 0.65 + r * 0.22))
            yy = 368 + r * 56
            if col == G.PASS:
                G.icon_check(cv, x + 28, yy + 12, col, a=kr, s=7, sw=2.4)
            else:
                G.icon_cross(cv, x + 28, yy + 12, col, a=kr, s=6, sw=2.4)
            G.text(cv, ln, x + 50, yy, size=16, c=G.FG, a=kr, width=w - 68, maxlines=2, lh=1.25)
    kc = a * after(sh, t, "c", 0.5)
    G.rrect(cv, IX0, 622, 780, 66, 12, fill=G.mix(G.PANEL, G.BRAND, 0.08), stroke=G.BRAND, sw=1.4, a=kc)
    G.text(cv, "These losses are not arithmetic. A script's self-check would not find them.", IX0 + 20, 643, size=17,
           c=G.FG, a=kc, maxlines=1, width=740)


SCENES = {
    "hubs": draw_hubs, "claim": draw_claim, "unsettled": draw_unsettled, "thresholds": draw_thresholds,
    "measures": draw_measures, "accept": draw_accept, "byhub": draw_byhub, "claims": draw_claims,
    "lessons": draw_lessons,
}
