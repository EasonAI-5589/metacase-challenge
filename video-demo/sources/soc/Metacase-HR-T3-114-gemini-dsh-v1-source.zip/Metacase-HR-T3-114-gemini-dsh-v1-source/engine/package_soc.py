"""Package the HR-T3-114 replay of the gemini-3.8-flash x DeepSeek Harness run (soc v1).

usage: python engine/package_soc.py
Requires the full build/hr/hr.mp4, its render receipt and font-selection sidecar.

This is a new storyboard for a new run, so there is no earlier edition to compare with
(unlike engine/package.py). The provenance states where each kind of figure comes from
and what was checked.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import compose  # noqa: E402
import rundata  # noqa: E402
from package import (CHAPTERS, FFMPEG, probe, read_json, relative,  # noqa: E402
                     run_checked, runtime_versions, sha, write_json)
from timeline import FPS  # noqa: E402

RUN = "hr"
VERSION = "hr-t3-114-gemini-dsh-v1"
NAME, DOC = "hr-t3-114-gemini-dsh-replay", "soc"
POSTER = ("s12", "pick", 1.2)  # the three measures, with the adopted one marked
README = "README-soc-v1.md"


def _portable_fonts(source_path):
    """Font selections without workstation paths; macOS records some faces as a family description, not a file."""
    record = read_json(source_path)
    for face in record["fonts"].values():
        source = face["source"]
        if os.path.isfile(source):
            face["font_file_sha256"] = sha(source)
            try:
                face["source"] = relative(source)
                face["source_base"] = "editable source root"
            except ValueError:
                face["source"] = f"system-fonts/{os.path.basename(source)}"
                face["source_base"] = "operating-system font directory; font not redistributed"
        else:
            face["source"] = " / ".join(os.path.basename(part.strip()) for part in source.split(" / "))
            face["source_base"] = "operating-system font, selected by family name; not redistributed"
    return record


def main():
    ctx = compose.Ctx(RUN)
    tl = ctx.tl
    build = os.path.join(ROOT, "build", RUN)
    source_mp4 = os.path.join(build, f"{RUN}.mp4")
    source_fonts = os.path.join(build, f"{RUN}.font-selection.json")
    source_receipt = os.path.join(build, f"{RUN}.render-receipt.json")
    for required in (source_mp4, source_fonts, source_receipt):
        if not os.path.isfile(required):
            raise FileNotFoundError(f"Full render artifact is missing: {required}")
    receipt = read_json(source_receipt)
    if receipt["output_sha256"] != sha(source_mp4):
        raise RuntimeError("Full video does not match its render receipt")
    for path, expected in receipt["inputs"]["source_sha256"].items():
        if sha(Path(ROOT, path)) != expected:
            raise RuntimeError(f"Rendered input changed before packaging: {path}")
    fonts = read_json(source_fonts)["fonts"]
    if set(receipt["inputs"]["font_sha256"]) != set(n for n, f in fonts.items() if os.path.isfile(f["source"])):
        raise RuntimeError("Font selections do not match the render receipt")
    from render import verify_video
    verify_video(source_mp4, tl.nframes)

    src_files = sorted(Path(ROOT, "engine").glob("*.py"))
    src_files += [Path(ROOT, "story", "hr.py"), Path(ROOT, "story", "hr_en.py"), Path(ROOT, "story", "fin_en.py"),
                  Path(ROOT, "data", "hr.json"), Path(ROOT, "data", "hr.requests.jsonl"),
                  Path(ROOT, README), Path(ROOT, "requirements-render.txt"),
                  Path(ROOT, "robot", "sprite.html"), Path(ROOT, "robot", "render_sprites.mjs"),
                  Path(ROOT, "robot", "sprites", "sprites.json"), Path(ROOT, "fonts", "SpaceMono-400.ttf")]
    src_files += sorted(Path(ROOT, "brand").glob("*"))
    src_files += sorted(p for p in Path(ROOT, "reconstruction").glob("*") if p.is_file())
    source_hashes = {relative(f): sha(f) for f in src_files}

    from check_guide import audit
    qa = audit(RUN)
    qa["source_snapshot_sha256"] = source_hashes
    qa["source_snapshot_phase"] = "packaging"
    qa_path = os.path.join(build, "guide-geometry-qa.json")
    write_json(qa_path, qa)
    if not qa["passed"]:
        raise RuntimeError(f"Guide geometry audit failed; inspect {relative(qa_path)}")

    out_v = os.path.join(ROOT, "deliver", "assets", "video")
    out_d = os.path.join(ROOT, "deliver", "docs", "video", DOC)
    os.makedirs(out_v, exist_ok=True)
    os.makedirs(out_d, exist_ok=True)
    mp4 = os.path.join(out_v, f"{NAME}.mp4")
    shutil.copyfile(source_mp4, mp4)
    sh = next(s for s in tl.shots if s.id == POSTER[0])
    png = os.path.join(build, "poster.png")
    compose.render_still(ctx, sh.start + sh.cue(POSTER[1]) + POSTER[2], png)
    poster = os.path.join(out_v, f"{NAME}-poster.jpg")
    run_checked([FFMPEG, "-v", "error", "-y", "-i", png, "-q:v", "2", poster])
    shutil.copyfile(os.path.join(build, "captions.en.srt"), os.path.join(out_d, "captions.en.srt"))
    shutil.copyfile(qa_path, os.path.join(out_d, "guide-geometry-qa.json"))
    shutil.copyfile(source_receipt, os.path.join(out_d, "render-receipt.json"))
    write_json(os.path.join(out_d, "font-selection.json"), _portable_fonts(source_fonts))
    shutil.copyfile(os.path.join(ROOT, README), os.path.join(out_d, "README.md"))
    for extra in ("cjk-onscreen.json", "text-timing.json"):
        if os.path.isfile(os.path.join(build, extra)):
            shutil.copyfile(os.path.join(build, extra), os.path.join(out_d, extra))

    run_data = rundata.load(RUN)
    data_path, log_path = rundata.SOURCES[RUN]
    p = probe(mp4)
    hr_en = __import__("story.hr_en", fromlist=["GLOSSARY"])
    nclips = len(tl.shots)
    prov = {
        "version": VERSION,
        "task_id": ctx.conf["task_id"],
        "run": "pilot-20261114-or__A40__dsh__google-gemini-3-8-flash",
        "status": "draft for review; narration and on-screen text follow the approved page copy",
        "model": "gemini-3.8-flash (google/gemini-3.8-flash through OpenRouter)",
        "harness": run_data.agent["harness"], "runner": run_data.agent["runner"],
        "judge": "RewardKit, one session per criterion, on a model other than the agent's (not named in the video)",
        "recorded_agent_seconds": run_data.duration,
        "model_requests": len(run_data.requests), "tool_calls": len(run_data.tool_steps),
        "reward": run_data.result["reward"],
        "duration_seconds": round(float(p["format"]["duration"]), 3),
        "frames": tl.nframes, "fps": f"{FPS}/1", "resolution": [1920, 1080],
        "streams": p["streams"],
        "voice": "en-US-AriaNeural, rate +12% (edge-tts), the voice and rate of the site's finance and HR videos",
        "audio_is_synthetic": True,
        "audio_processing": "per-shot neural TTS clips placed on the shot timeline, loudnorm I=-16.5 LUFS, AAC 48 kHz mono",
        "burned_captions": ["en"],
        "renderer": "offline Skia (skia-python) frame renderer; no browser, no CDP; H.264 High via libx264",
        "runtime": runtime_versions(),
        "guide_character": {
            "character": "the homepage robot (mc-kit.js robot(0xf7f5f0, 0x8ff6ff)) holding the arena's DeepSeek Harness "
                         "weapon (Kenney blaster-q.glb, CC0; arena-models.js maps it to DeepSeek Harness)",
            "renderer": "robot/sprite.html (three.js, homepage lights) -> 362 transparent sprites, -90..+90 degrees aim in "
                        "1-degree steps, eyes open and mid-blink (robot/make_sprites.sh)",
            "sprites_index": {"path": "robot/sprites/sprites.json", "sha256": sha(os.path.join(ROOT, "robot", "sprites", "sprites.json"))},
            "pointer": "a sight laser from the muzzle to the cue target; hidden in the parked pose",
            "routes_and_cues": f"{len(ctx.guide.events)} cues (engine/guide_targets.py, shots s00–s30)",
        },
        "english_only": {
            "captions": "English only",
            "on_screen_text": "written in English; the 17 input file names and the two deliverable names are shown by English "
                              "names via story/hr_en.py GLOSSARY; numbers, codes and amounts unchanged",
            "glossary": [{"zh": zh, "en": en} for zh, en in hr_en.GLOSSARY],
            "check": "reconstruction/cjk_scan.py drew every 5th frame and lists strings with Chinese characters that reach "
                     "the screen (cjk-onscreen.json)",
        },
        "brand": {
            "mark_and_wordmark": "Metacase mark (.lg-anim timing) and the site's 'Global Metacase Challenge' wordmark",
            "institutions": "NTU, HKU, SUFE and Tsinghua crests as on the homepage hero; 'Hosted by NTU GIFTS with HKU, SUFE and Tsinghua PBCSF'",
            "site": "easonai-5589.github.io/metacase-challenge",
            "attribution": "brand/ATTRIBUTION.txt",
        },
        "figures": {
            "from_the_run_record": "requests, tool calls, step times, exit codes, token counts, file-opening order, deliverable "
                                   "sizes and sheet counts, the 34 criterion verdicts and the reward (data/hr.json, built by "
                                   "reconstruction/build_soc_data.py from the trial's replay record)",
            "from_the_approved_copy": "the setting, the five unsettled items, the six thresholds, the amounts, the three "
                                      "behaviour measures, pooled and by-hub net changes, and the readings of R11, R13, R14–R17, "
                                      "R19–R26 (网页文案-经济与社科.md, sections 5 and 7)",
            "editorial": ["the nine run phases in the left panel are a reading of the recorded steps; the agent wrote no plan",
                          "is_error / exit_code come from the '[exit code: N]' line the harness appends to a failed command",
                          "document lines on the s09 card and the memo wording on the s26 card are English renderings of Chinese text"],
            "not_shown": ["rows of the task's input files", "model thinking text", "any other run or model"],
        },
        "validation": {
            "geometry_report": f"docs/video/{DOC}/guide-geometry-qa.json",
            "text_timing": f"docs/video/{DOC}/text-timing.json",
            "font_selection": f"docs/video/{DOC}/font-selection.json",
            "render_receipt": f"docs/video/{DOC}/render-receipt.json",
            "render_input_fingerprint": receipt["input_fingerprint"],
            "geometry_passed": qa["passed"],
            "frames_checked": qa["frames_checked"],
            "cue_boundaries_checked": qa["cues_checked"],
            "video_checks": "Full render frame count, frame rate and dimensions verified with ffprobe before packaging.",
            "review_scope": "Automated geometry, text and timing checks plus review of preview stills of every shot; "
                            "these records do not claim full human viewing or listening.",
        },
        "chapters": [{"name": CHAPTERS[i], "start_seconds": round(a_, 3), "end_seconds": round(b_, 3)}
                     for i, (a_, b_) in enumerate(tl.chapters)],
        "shots": [{"id": s.id, "chapter": CHAPTERS[s.ch], "kind": s.kind, "start_seconds": round(s.start, 3),
                   "end_seconds": round(s.end, 3), "narration_en": s.en, "trace_seconds": s.d.get("trace")}
                  for s in tl.shots],
        "files": {
            f"assets/video/{NAME}.mp4": {"bytes": os.path.getsize(mp4), "sha256": sha(mp4)},
            f"assets/video/{NAME}-poster.jpg": {"bytes": os.path.getsize(poster), "sha256": sha(poster)},
            **{f"docs/video/{DOC}/{fn}": {"bytes": os.path.getsize(os.path.join(out_d, fn)), "sha256": sha(os.path.join(out_d, fn))}
               for fn in sorted(os.listdir(out_d)) if fn != "provenance.json"},
        },
        "sources": {
            "run_export": {"path": relative(data_path), "sha256": sha(data_path),
                           "note": "derived from the trial's replay record; free text removed"},
            "request_metadata": {"path": relative(log_path), "sha256": sha(log_path), "note": "timestamps, usage and tool names only"},
            "voice_cache_index": {"path": f"build/{RUN}/voice.json", "sha256": sha(os.path.join(build, "voice.json"))},
        },
        "editable_source": {
            "directory": ".",
            "files_sha256": source_hashes,
            "requirements": "requirements-render.txt",
            "instructions": README,
            "rebuild": [f"python -X utf8 engine/render.py {RUN} --workers 2",
                        "python -X utf8 engine/package_soc.py"],
            "offline": f"Uses the {nclips} cached narration MP3 clips and build/hr/voice.json; voice.py is needed only after a narration change.",
        },
        "boundaries": [
            "Editorial replay of one recorded pilot run; no new agent run, no re-scoring.",
            "All entities and data of the task are synthetic. The reward is one pilot run's rubric score, not accuracy or a ranking.",
            "This task has six penalty criteria and no red lines.",
            "DeepSeek Harness and bash run inside the task's Docker container; the model is reached through an API.",
            "The rubric and tests are absent during the agent run; Harbor copies tests into the same container afterwards.",
            "Judge sessions are separate per criterion; scores never feed back into the recorded agent run.",
        ],
    }
    if source_hashes != {relative(f): sha(f) for f in src_files}:
        raise RuntimeError("Editable source changed during packaging; run packaging again after edits finish")
    write_json(os.path.join(out_d, "provenance.json"), prov)
    print(json.dumps({"mp4": mp4, "duration": prov["duration_seconds"],
                      "sha256": prov["files"][f"assets/video/{NAME}.mp4"]["sha256"], "poster": poster}, indent=1))


if __name__ == "__main__":
    main()
