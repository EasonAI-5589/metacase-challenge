#!/bin/bash
# Re-render the guide robot holding the DeepSeek Harness weapon (blaster-q.glb, as on the site's arena).
# Serves the folder that holds both the site worktree and this project on 127.0.0.1, then stops its own server.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PARENT="$(cd "$HERE/../../.." && pwd)"          # .../metacase (contains _wt-metacase-three-fields and _video-work-20261114)
PORT="${PORT:-4193}"
cd "$PARENT"
python3 -m http.server "$PORT" --bind 127.0.0.1 >/dev/null 2>&1 &
SRV=$!
sleep 1.5
cd "$HERE"
node render_sprites.mjs --base "http://127.0.0.1:$PORT" --out "$HERE/sprites-dsh" --angles -90:90:1 --size 400
RC=$?
kill "$SRV" 2>/dev/null
echo "render_sprites exit=$RC"
ls "$HERE/sprites-dsh" | wc -l
