"""Reading-time check for text that appears late in a shot.

Rule (project feedback on earlier videos): a text must stay fully visible for at least
0.3 s + words / 4. For each late-appearing block below, `left` is the time from its cue to
the end of the shot (the next shot's cross-fade adds about 0.3 s more, not counted here).
usage: python reconstruction/text_timing.py  -> prints a table and writes build/hr/text-timing.json
"""
import json, os, sys
SRC = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
os.chdir(SRC); sys.path[:0] = [os.path.join(SRC, "engine"), SRC]
import compose

LATE = [
    ("s04", ("e", 0.2), "Every status must be kept as it stands."),
    ("s05", "c", "(column C is lit; all three columns are on screen from 0.2 s)"),
    ("s08", "n", "/app/output 0 / 2 files"),
    ("s09", "use", "Learning data: for evaluation, coaching and acceptance. Not for discipline, reassignment, pay cuts or dismissal."),
    ("s10", "att", "LEARNING TIME 82 / 83 threshold 1,377 of 1,620 min one supervisor at 1,170 3 x 360 pending min held out"),
    ("s11", ("s", 2.4), "DATA-USE RULE No opportunity is not no ability not recorded as zero not judged as failing"),
    ("s12", "pick", "The workbook reports the second. adopted in the workbook"),
    ("s13", "pool", "three trained hubs, pooled net: +4.33 pp"),
    ("s14", "save", "OBSERVATION step 132 10 sheets listed read back at +837.3 s"),
    ("s15", "ok", "OBSERVATION step 145 Replacement successful. Sections 1–7 finished. SUCCESS: memorandum saved"),
    ("s16", "ls", "ls -la /app/output/ workbook 71,379 bytes memo 62,787 bytes"),
    ("s18", "turn", "NameError IndexError"),
    ("s20", "score", "RewardKit judge sessions run as root no channel back to the finished agent run"),
    ("s22", "nf", "agent run ended scores never reach the agent"),
    ("s23", "amt", "recommendations only approval stays with the authorised body"),
    ("s24", "b", "both exceed 75% the decision on package B is unaffected"),
    ("s25", "idx", "Source index R1 R19 A source index with key chains not met"),
    ("s26", ("r", 0.6), "R26 A complete closure plan not met"),
    ("s27", "pen", "Penalties 6 none triggered"),
    ("s28", "pilot", "One pilot run on a synthetic task not accuracy, not a ranking. no penalty applied this task has no red lines"),
    ("s29", "c", "These losses are not arithmetic. A script's self-check would not find them."),
    ("s30", "site", "easonai-5589.github.io/metacase-challenge Scenarios contributed by Shanghai University of Finance and Economics"),
]
ctx = compose.Ctx("hr")
sh = {s.id: s for s in ctx.tl.shots}
rows, bad = [], 0
for sid, c, txt in LATE:
    s = sh[sid]
    left = s.dur - s.cue(c)
    words = len([w for w in txt.split() if not w.startswith("(")]) if not txt.startswith("(") else 0
    need = 0.3 + words / 4
    ok = left + 1e-6 >= need
    bad += not ok
    rows.append(dict(shot=sid, cue=str(c), words=words, left_s=round(left, 2), need_s=round(need, 2), ok=ok))
    print(f"{sid} cue {str(c):12} words {words:2d} left {left:5.2f} need {need:5.2f} {'OK' if ok else 'SHORT'}")
print("duration", round(ctx.tl.duration, 3), "frames", ctx.tl.nframes, "shots", len(ctx.tl.shots), "short", bad)
json.dump(dict(rule="visible >= 0.3 s + words / 4", duration_s=round(ctx.tl.duration, 3), rows=rows),
          open(os.path.join(SRC, "build", "hr", "text-timing.json"), "w"), indent=1)
