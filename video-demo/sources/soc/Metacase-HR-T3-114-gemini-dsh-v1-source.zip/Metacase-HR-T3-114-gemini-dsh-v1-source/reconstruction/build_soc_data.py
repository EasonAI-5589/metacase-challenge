"""Build data/hr.json and data/hr.requests.jsonl for the gemini-3.8-flash x DeepSeek Harness run.

Source: the replay record made by metacase-harbor's scripts/replay_record.py from the trial's own
files (run.json + requests.jsonl). The record's free text is dropped here: no model thinking, no
command text and no tool output are copied, because tool output quotes rows of the task's
restricted input files. What is kept per step: its index, start and end time, tool name, the
agent's own one-line label, the input file names that appear in the command, and whether the
tool result ended with a non-zero exit code.

Two things are added and marked as editorial in the output:
  - is_error / exit_code: read from the "[exit code: N]" line that DeepSeek Harness appends to a
    failed command's result (the harness itself records no error flag);
  - phases: nine phases of the run, placed on the trace by time, drawn in the left panel. They are
    a reading of the recorded steps, not a plan written by the agent (this run wrote none).

usage: python reconstruction/build_soc_data.py <replay dir>
"""
from __future__ import annotations

import json
import os
import re
import sys

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SRC = sys.argv[1]

# (start s, label) — boundaries are the start times of recorded steps
PHASES = [
    (8.6, "Read the four documents"),
    (24.8, "Inspect workbooks and ledgers"),
    (40.5, "Scope, attendance, tests"),
    (142.9, "Opportunity, behaviour, coaching"),
    (227.2, "Operations and disruptions"),
    (288.2, "Contract rules and open items"),
    (423.9, "Build the workbook"),
    (867.7, "Build the memo"),
    (1099.2, "Read both files back"),
]
END = 1109.8

with open(os.path.join(SRC, "run.json"), encoding="utf-8") as f:
    src = json.load(f)

steps = []
for s in src["agent"]["steps"]:
    if s["kind"] != "tool":
        continue
    result = s.get("result") or ""
    m = re.search(r"\[exit code: (\d+)\]\s*$", result)
    code = int(m.group(1)) if m else 0
    steps.append({
        "i": s["i"], "t_s": s["t_s"], "end_s": s["end_s"], "tool": s["tool"],
        "label": re.sub(r"SYN-PER-\d+( and SYN-PER-\d+)*", "named supervisors", s["label"]),
        "files": s.get("files") or [],
        "exit_code": code, "is_error": code != 0,
    })


def todos_at(T):
    out = []
    for j, (t0, lab) in enumerate(PHASES):
        t1 = PHASES[j + 1][0] if j + 1 < len(PHASES) else END
        st = "completed" if T >= t1 else ("in_progress" if T >= t0 else "pending")
        out.append({"text": lab, "status": st})
    return out


for t0 in [p[0] for p in PHASES] + [END]:
    s = next(x for x in steps if abs(x["t_s"] - t0) < 0.051)
    s["todos"] = todos_at(t0)

agent = {k: src["agent"][k] for k in ("harness", "runner", "provider", "requested_model", "session", "tool_calls",
                                      "files_opened", "usage")}
agent["steps"] = [{"i": 0, "t_s": 0.0, "kind": "start"}] + steps
judging = {
    "judge": {k: src["judging"]["judge"][k] for k in ("harness", "mode", "configured_model")},
    "result": src["judging"]["result"],
    "criteria": [{k: c[k] for k in ("id", "group", "weight", "value", "raw")} | {"negate": c["id"] in
                 ("R27", "R28", "R29", "R30", "R31", "R32")} for c in src["judging"]["criteria"]],
}
pos = [c for c in judging["criteria"] if not c["negate"]]
judging["result"] = dict(judging["result"], positive_weight=sum(c["weight"] for c in pos),
                         passed_weight=sum(c["weight"] * c["value"] for c in pos),
                         penalty=sum(c["weight"] * (1 - c["value"]) for c in judging["criteria"] if c["negate"]))
deliv = []
for f in src["deliverables"]["files"]:
    d = {k: f[k] for k in f if k in ("name", "bytes", "sha256", "paragraphs", "tables", "characters")}
    if "sheets" in f:
        d["sheets"] = [{k: sh[k] for k in ("name", "rows", "cols", "formulas")} for sh in f["sheets"]]
    deliv.append(d)

out = {
    "schema": src["schema"],
    "partial": ["step text, command text and tool output are not copied (restricted task inputs)",
                "is_error / exit_code are read from the harness's '[exit code: N]' result line",
                "phases are an editorial reading of the trace; the agent wrote no plan"],
    "task": dict(src["task"], key="HR", domain_en="HR", fictional=True,
                 title_en="Cold-chain supervisor training: impact review and provider acceptance"),
    "materials": [{k: m[k] for k in ("name", "kind", "bytes", "opened_step")} for m in src["materials"]],
    "agent": agent,
    "deliverables": {"files": deliv},
    "judging": judging,
    "provenance": {
        "method": "Derived from the trial's replay record (metacase-harbor scripts/replay_record.py).",
        "trial": src["provenance"]["trial_name"], "job": src["provenance"]["job_name"],
        "record_generated_at": src["provenance"]["generated_at"],
        "phases": [{"start_s": t0, "label": lab} for t0, lab in PHASES],
    },
}
with open(os.path.join(ROOT, "data", "hr.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

# requests: timestamps, token usage and tool names only
n = 0
with open(os.path.join(SRC, "requests.jsonl"), encoding="utf-8") as fi, \
        open(os.path.join(ROOT, "data", "hr.requests.jsonl"), "w", encoding="utf-8") as fo:
    for line in fi:
        if not line.strip():
            continue
        r = json.loads(line)
        if r["type"] == "assistant":
            m = r["message"]
            r = {"type": "assistant", "timestamp": r["timestamp"],
                 "message": {"id": m["id"], "usage": m["usage"],
                             "content": [{"type": "tool_use", "name": c["name"]} for c in m.get("content", [])
                                         if c.get("type") == "tool_use"]}}
            n += 1
        fo.write(json.dumps(r, ensure_ascii=False) + "\n")
print("steps", len(steps), "errors", [(s["i"], s["t_s"]) for s in steps if s["is_error"]], "requests", n,
      "positive", judging["result"]["positive_weight"], "passed", judging["result"]["passed_weight"],
      "penalty", judging["result"]["penalty"])
