"""Render review stills: python reconstruction/stills_soc.py [frac,frac,...] [shot ids...] -> build/hr/stills/*.jpg (960x540)."""
import os, subprocess, sys
SRC = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
os.chdir(SRC); sys.path[:0] = [os.path.join(SRC, "engine"), SRC]
import compose
ctx = compose.Ctx("hr")
OUT = os.path.join(SRC, "build", "hr", "stills"); os.makedirs(OUT, exist_ok=True)
args = sys.argv[1:]
fracs = [float(x) for x in args[0].split(",")] if args and args[0][0].isdigit() else [0.93]
only = set(a for a in args if not a[0].isdigit())
for sh in ctx.tl.shots:
    if only and sh.id not in only:
        continue
    for f in fracs:
        png = os.path.join(OUT, f"{sh.id}_{int(f * 100):02d}.png")
        compose.render_still(ctx, sh.start + sh.dur * f, png)
        jpg = png[:-4] + ".jpg"
        subprocess.check_call(["ffmpeg", "-v", "error", "-y", "-i", png, "-vf", "scale=1280:720", "-q:v", "3", jpg])
        os.remove(png)
    print(sh.id, flush=True)
