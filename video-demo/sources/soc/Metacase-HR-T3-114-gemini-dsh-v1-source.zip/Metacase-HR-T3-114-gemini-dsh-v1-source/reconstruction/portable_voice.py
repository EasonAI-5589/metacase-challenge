"""Make build/hr/voice.json portable: store narration clip paths relative to the project root.

engine/voice.py writes absolute paths; engine/timeline.py accepts relative ones. Run once after voice.py.
"""
import json, os
ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
p = os.path.join(ROOT, "build", "hr", "voice.json")
v = json.load(open(p, encoding="utf-8"))
used = set()
for row in v:
    row["mp3"] = os.path.relpath(os.path.join(ROOT, row["mp3"]) if not os.path.isabs(row["mp3"]) else row["mp3"], ROOT).replace(os.sep, "/")
    used.add(os.path.basename(row["mp3"]))
json.dump(v, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
# drop cached clips of sentences that are no longer in the storyboard
vd = os.path.join(ROOT, "build", "hr", "voice")
gone = [f for f in os.listdir(vd) if f.endswith(".mp3") and f not in used]
for f in gone:
    os.remove(os.path.join(vd, f))
    j = os.path.join(vd, f[:-4] + ".json")
    if os.path.exists(j):
        os.remove(j)
print("clips", len(v), "removed stale", len(gone), "example", v[0]["mp3"])
