"""HR-T3-114 storyboard for the gemini-3.8-flash x DeepSeek Harness 0.2.2-rc.1 run (2026-11-14).

One narration cue per shot. Every figure comes from the approved page copy
(网页文案-经济与社科.md, sections 5 and 7) or from the run record behind data/hr.json:
the trial's trajectory, its two deliverables and the judge's per-criterion verdicts.
This video shows this one run only. The engine and its scene grammar come from the
site's Finance and HR v3 source projects (video-demo/sources/); no finding or figure of
an earlier run is reused.

say : narration sent to the voice; {key} marks the start of the next word and becomes a
      visual cue time. en : caption (defaults to say without markers).
trace: agent-run seconds swept by the header clock during the shot; tk pins trace times to cues.
"""
import scenes_soc

RUN = "hr"
SCENES = scenes_soc.SCENES

SHOTS = [
    # ------------------------------------------------------------------ 01 TASK
    dict(id="s00", ch=0, kind="open",
         say="One model, one harness, one acceptance review. {a}Follow how the agent works inside DeepSeek Harness, {b}and how its two files are checked.",
         st=("brand", "HR-T3-114 · social science · synthetic task · recorded pilot run")),
    dict(id="s01", ch=0, kind="hubs",
         say="A cold-chain operator has trained frontline supervisors at three hubs for six weeks. {d}A fourth hub, deferred, kept its records for the same weeks as the reference.",
         st=("brand", "all entities and data are synthetic")),
    dict(id="s02", ch=0, kind="claim",
         say="On June eighth, a joint meeting decides {wp}three work packages the provider has claimed, {sum}eight hundred sixteen thousand yuan in all. The provider rates all three as accepted.",
         en="On 8 June, a joint meeting decides three work packages the provider has claimed, 816,000 yuan in all. The provider rates all three as accepted.",
         st=("brand", "the provider's own rating: all three packages accepted")),
    dict(id="s03", ch=0, kind="io",
         say="{kinds}Seventeen files go in: eight ledgers, five workbooks and four documents. {out}A workbook that can be recomputed and a decision memo must come out.",
         en="17 files go in: eight ledgers, five workbooks and four documents. A workbook that can be recomputed and a decision memo must come out.",
         st=("sandbox", "/app/input_files · 17 read-only  →  /app/output")),
    dict(id="s04", ch=0, kind="unsettled",
         say="Five things in those files are not yet settled: {a}a name listed in the wrong role, {b}three missing sign-outs, {c}two practice attempts, {d}eighteen disputed observations, {e}and a repair recorded a day apart.",
         en="Five things in those files are not yet settled: a name listed in the wrong role, three missing sign-outs, two practice attempts, 18 disputed observations, and a repair recorded a day apart.",
         st=("brand", "evidence closes 31 May · every status must be kept as it stands")),
    dict(id="s05", ch=0, kind="thresholds",
         say="The contract sets two thresholds for each package: {a}delivery and learning time for A, {b}test coverage and behaviour for B, {c}operating results and close-out for C.",
         st=("brand", "settlement rules v1.1 · six thresholds")),
    dict(id="s06", ch=0, kind="sealed",
         say="The scoring rubric is not in the container. {lock}The agent works without seeing how it will be judged.",
         st=("scorer", "tests/ and solution/ absent during the agent run")),

    # ------------------------------------------------------------------ 02 AGENT
    dict(id="s07", ch=1, kind="loop_intro",
         say="DeepSeek Harness runs the loop. {m}The model chooses an action, {h}the harness turns it into a shell command, {s}the command runs inside the container, {o}and the result returns to the model.",
         st=("harness", "harness · dsh headless · cwd /app"), trace=(0.0, 8.6)),
    dict(id="s09", ch=1, kind="rules",
         say="{rd}It begins with the four documents. {rule}Two rules shape everything after: uploaded is not reviewed, {use}and personal learning data may serve evaluation, coaching and acceptance, never discipline.",
         st=("sandbox", "steps 4–6 · python-docx · four Word files"), trace=(18.2, 20.9)),
    dict(id="s10", ch=1, kind="scope",
         say="{sc}Scope first: eighty-four names, one a warehouse coordinator listed in error, so eighty-three. {att}Then learning time: eighty-two of eighty-three reach the threshold, and three people's pending minutes are held out.",
         en="Scope first: 84 names, one a warehouse coordinator listed in error, so 83. Then learning time: 82 of 83 reach the threshold, and three people's pending minutes are held out.",
         st=("sandbox", "steps 11–37 · roster and attendance events"), trace=(40.5, 109.8)),
    dict(id="s11", ch=1, kind="tests",
         say="{t}Practice attempts are dropped from the tests. Mean scores rise from fifty-nine to ninety-four, and hold at ninety after ten weeks. {s}With two verified incidents as the bar, seventy-three supervisors can be evaluated, eight lack opportunity, and two are restricted.",
         en="Practice attempts are dropped from the tests. Mean scores rise from 59 to 94, and hold at 90 after ten weeks. With two verified incidents as the bar, 73 supervisors can be evaluated, 8 lack opportunity, and 2 are restricted.",
         st=("sandbox", "steps 39–60 · tests, opportunity log, observations"), trace=(115.3, 182.3)),
    dict(id="s12", ch=1, kind="measures",
         say="{m}Behaviour attainment can be read three ways, and the agent computes all three: {a}seventy-three, {b}sixty-seven, {c}or fifty-three of seventy-three. {pick}It adopts the second.",
         en="Behaviour attainment can be read three ways, and the agent computes all three: 73, 67, or 53 of 73. It adopts the second.",
         st=("model", "step 62 · +191.2 s · all three measures in one command"), trace=(191.2, 206.3)),
    dict(id="s13", ch=1, kind="pooledrun",
         say="{ops}For operations, it nets the trained hubs against the deferred hub, {pool}but as one pooled figure: four point three three points on the response rate.",
         en="For operations, it nets the trained hubs against the deferred hub, but as one pooled figure: 4.33 points on the response rate.",
         st=("sandbox", "step 86 · +274.3 s · weekly hub metrics, baseline against observation"), trace=(227.2, 274.6)),
    dict(id="s08", ch=1, kind="montage",
         say="{rd}By now all seventeen files have been opened, {n}and the output folder is still empty.",
         en="By now all 17 files have been opened, and the output folder is still empty.",
         st=("sandbox", "all 17 inputs named in recorded commands by +261.6 s · /app/output empty at +423.9 s"), trace=(274.6, 423.9)),
    dict(id="s14", ch=1, kind="write",
         say="{gen}Then it starts to build. The workbook generator is written in three passes {save}and run: ten sheets.",
         st=("sandbox", "steps 111–132 · +452.0 → +837.6 s"), trace=(452.0, 837.6)),
    dict(id="s15", ch=1, kind="error",
         say="{err}The memo script stops on an index error: the first row of a table that has none. {fix}The agent finds the cause, rewrites the helper, {ok}and generates the memo again.",
         st=("fail", "step 142 · IndexError · fixed by step 145, 8.8 s later"), trace=(1072.2, 1091.5)),
    dict(id="s16", ch=1, kind="verify",
         say="{chk}It reads both files back: sheet count, dimensions, key figures. {f}Ten sheets, but only three cells hold formulas. {ls}The output folder holds exactly the two required files.",
         st=("sandbox", "steps 146–150 · the agent's last tool calls"), trace=(1091.5, 1155.2)),

    # ------------------------------------------------------------------ 03 HARNESS
    dict(id="s18", ch=2, kind="trace",
         say="Here is the whole run: eighty-six requests, {calls}eighty-five tool calls, all shell commands, about nineteen minutes. {turn}Reading and recomputing take the first seven minutes; building the two files takes the rest.",
         en="Here is the whole run: 86 requests, 85 tool calls, all shell commands, about 19 minutes. Reading and recomputing take the first seven minutes; building the two files takes the rest.",
         st=("harness", "agent run 1155.2 s · 167,495 output tokens · 2 non-zero exits"), trace=(1155.2, 1155.2)),
    dict(id="s19", ch=2, kind="context",
         say="{grow}Each result is added to the model's context. {end}By the last request, the prompt has grown from about five thousand to about two hundred eight thousand tokens.",
         en="Each result is added to the model's context. By the last request, the prompt has grown from about 5 thousand to about 208 thousand tokens.",
         st=("model", "prompt tokens per request · 5,126 → 207,989"), trace=(1155.2, 1155.2)),
    dict(id="s20", ch=2, kind="handoff",
         say="{stop}When the agent stops, {tests}Harbor copies the rubric into the same container. {score}Only then does scoring begin.",
         st=("scorer", "same container · tests/ copied in · judge runs as root"), trace=(1155.2, 1155.2)),

    # ------------------------------------------------------------------ 04 CHECK
    dict(id="s21", ch=3, kind="chapter",
         say="An independent check now takes over.",
         title="Independent check", sub="The two submitted files are scored, one criterion at a time.",
         st=("scorer", "RewardKit · one judge session per criterion")),
    dict(id="s22", ch=3, kind="judges",
         say="{rk}Reward Kit opens one judge session for each of thirty-four criteria. {jm}The judge is a different model from the agent, {nf}and nothing flows back to the agent.",
         en="RewardKit opens one judge session for each of 34 criteria. The judge is a different model from the agent, and nothing flows back to the agent.",
         st=("scorer", "28 criteria to earn + 6 penalties · no red lines")),
    dict(id="s23", ch=3, kind="accept",
         say="{ok}The acceptance decisions hold. {a}Package A is conditional, {b}B passes three of four units, {c}C one of two, {amt}and every amount matches.",
         st=("pass", "R20–R25 · met · 40 of 40 points")),
    dict(id="s24", ch=3, kind="measures",
         say="{m}The behaviour measure does not hold. The rubric counts all reviewed items: seventy-three of seventy-three. {r}The workbook reports sixty-seven. {b}Both clear the threshold, so package B stands.",
         en="The behaviour measure does not hold. The rubric counts all reviewed items: 73 of 73. The workbook reports 67. Both clear the threshold, so package B stands.",
         st=("fail", "R11 · not met · weight 3")),
    dict(id="s25", ch=3, kind="byhub",
         say="{pool}The workbook pools the three hubs. The rubric wants each one net of the deferred hub: six point five, four point five and two points. {idx}And the workbook has no source index.",
         en="The workbook pools the three hubs. The rubric wants each one net of the deferred hub: 6.5, 4.5 and 2.0 points. And the workbook has no source index.",
         st=("fail", "R14–R16 · not met   R1, R19 · not met")),
    dict(id="s26", ch=3, kind="claims",
         say="{q}The memo says the data irrefutably prove the training's value. {r}The rubric asks for a descriptive association, {b}limits on attribution, {p}and a complete closure plan.",
         st=("fail", "R13 · R17 · R26 · not met")),

    # ------------------------------------------------------------------ 05 RESULT
    dict(id="s27", ch=4, kind="tally",
         say="{pos}Of twenty-eight criteria to earn, nineteen are met and nine are not. {pen}None of the six penalties applies, and this task has no red lines.",
         en="Of 28 criteria to earn, 19 are met and 9 are not. None of the six penalties applies, and this task has no red lines.",
         st=("scorer", "positive weight 106 · earned 79 · penalty 0")),
    dict(id="s28", ch=4, kind="reward",
         say="{rw}The recorded reward is zero point seven four five: {w}seventy-nine points over one hundred six. {pilot}One pilot run on a synthetic task. Not accuracy, and not a ranking.",
         en="The recorded reward is 0.745: 79 points over 106. One pilot run on a synthetic task. Not accuracy, and not a ranking.",
         st=("scorer", "reward 0.745283 · verifier_error 0")),
    dict(id="s29", ch=4, kind="lessons",
         say="{a}What held: scope, statuses, amounts and the data-use rule. {b}What failed: a measure, a layout, and the limits of a claim. {c}None of these losses is arithmetic that a script would catch.",
         st=("brand", "each loss points to a named table or sentence")),
    dict(id="s30", ch=4, kind="outro",
         say="A professional task, an agent run, and an independent check. {site}Explore more on the Global Metacase Challenge site.",
         st=("brand", "easonai-5589.github.io/metacase-challenge")),
]

# ---------------------------------------------------------------------------- persistent panels
_PHASES = ["Read the four documents", "Inspect workbooks and ledgers", "Scope, attendance, tests",
           "Opportunity, behaviour, coaching", "Operations and disruptions", "Contract rules and open items",
           "Build the workbook", "Build the memo", "Read both files back"]

MODEL = "gemini-3.8-flash"
HARNESS = "DeepSeek Harness"

CONF = dict(
    task_id="HR-T3-114", domain="HR · synthetic", version="",
    title="Cold-chain supervisor training: impact review and provider acceptance",
    title_zh="冷链仓储一线主管异常处置训练成效与服务采购验收",
    role="Joint lead · learning effectiveness and procurement acceptance",
    meta="17 input files · Excel + Word · A2 / C4",
    chips=[("MODEL", MODEL), ("HARNESS", "DeepSeek Harness"),
           ("SANDBOX", "Docker · bash"), ("JUDGE", "a separate model")],
    total_tools=85, total_requests=86, inputs=17, plan_slots=9,
    plan_labels=[("Opportunity, behaviour, coaching", "Opportunity and behaviour")] + [(p, p) for p in _PHASES],
    plan_title="RUN PHASES · trace",
    plan_foot="read from the recorded steps · not a grade",
    plan_empty="the run has not started",
    tool_legend=[("bash", "sandbox"), ("non-zero exit", "fail")],
    loop_title="DeepSeek Harness · tool loop",
    container_label="Docker container · Harbor 0.24.0",
    container_tools="dsh · python3 · pandas · openpyxl",
    session_label="DeepSeek Harness · agent session",
    rewardkit_note="one session each",
    handoff_short=True,
    # (trace s, label, value, colour) — values the agent's own commands produced
    found=[
        (47.5, "scope", "84 → 83", "fg"),
        (100.2, "learning time", "82 / 83", "fg"),
        (134.2, "test means", "59 · 94 · 90", "fg"),
        (182.3, "strata", "73 · 8 · 2", "fg"),
        (191.7, "behaviour", "67 / 73", "model"),
        (274.6, "pooled net change", "+4.33 pp", "model"),
    ],
    files_opened_label="materials opened",
    # decorative labels in the opening particle cloud: codes and totals of this run
    particle_words=("¥", "%", "Δ", "WP-A", "R11", "Word", "Excel", "86", "85", "1155.2", "{ }"),
    xlsx="训练成效与验收决策工作簿.xlsx",
    docx="项目验收与整改决策备忘录.docx",
)


def outputs(T):
    """State of /app/output at trace time T (from the recorded tool results and the submitted files)."""
    out = []
    if T >= 832.8:
        meta, size = "written by the generator", ""
        if T >= 837.6:
            meta, size = "10 sheets", "71,379 B"
        out.append(dict(kind="xlsx", name=CONF["xlsx"], meta=meta, size=size, state="ok"))
    if T >= 1081.0:
        meta, size = "written after the fix", ""
        if T >= 1099.5:
            meta, size = "94 ¶ · 9 tables", "62,787 B"
        out.append(dict(kind="docx", name=CONF["docx"], meta=meta, size=size, state="ok"))
    return out


# ---------------------------------------------------------------------------- shot payloads (visuals)
PAY = {
    "s00": dict(pet=[(0.0, (720, 530)), ("a", (560, 622)), ("b", (640, 690))]),
    "s07": dict(as_="loop", accent="harness", phases=[dict(
        at=0.0, rq="", sub="Model → DeepSeek Harness → Docker → back to the model",
        stages=[MODEL, HARNESS, "bash · python3", "next request"],
        labels=["MODEL", "HARNESS", "DOCKER · BASH", "OBSERVATION"],
        beats=[("m", 0), ("h", 1), ("s", 2), ("o", 3)], route="o",
        cards=[dict(kick="MODEL · REMOTE API", title="Chooses the next action", role="model", at="m", hi=[("m", "h")],
                    lines=["Reads the task and every result so far", "Replies with text and one tool call", "Served through OpenRouter"]),
               dict(kick="HARNESS · IN THE CONTAINER", title="DeepSeek Harness runs the loop", role="harness", at="h", hi=[("h", "s")],
                    lines=["Dispatches each tool call", "In this run every call is bash", "Sends the result with the next request"]),
               dict(kick="SANDBOX · DOCKER", title="Work happens in /app", role="sandbox", at="s", hi=[("s", "o")],
                    lines=["python3 with pandas and openpyxl", "Reads /app/input_files (read-only)", "Writes /app/output"])],
        foot="Harbor runs:  dsh headless --json")],
        pet=[("m", "card0"), ("h", "card1"), ("s", "card2"), ("o", (803, 470))]),
    "s09": dict(as_="loop", tk=[("rd", 18.2), (("use", 3.0), 20.9)], phases=[dict(
        at=0.0, rq="REQUESTS 3–4 / 86", sub="Read the four Word files",
        stages=[MODEL, "bash", "python-docx", "text"],
        beats=[("rd", 0), (("rd", 0.5), 1), (("rd", 1.0), 2), ("rule", 3)], route=("use", 1.5),
        cards=[dict(kick="REQUEST · step 4", role="model", mono=True, size=13, at=0.0, maxl=2,
                    lines=["python3 -c: docx.Document()", "each paragraph and table of", "four .docx files", "→ /tmp/docx_summary.txt"]),
               dict(kick="OBSERVATION · steps 4–6 · rendered in English", role="brand", size=15.5, at="rule", span=2, gap=6, maxl=2,
                    hi=[("rule", "use"), ("use", 4.5)], cols=["warn", None, "model", "model"],
                    line_at=["rule", ("rule", 0.4), "use", ("use", 0.5)],
                    lines=["Provider's stage claim: “uploaded” does not equal “reviewed”.",
                           "Two review items the provider lists as closed are still open.",
                           "Learning data: for evaluation, coaching and acceptance.",
                           "Not for discipline, reassignment, pay cuts or dismissal."]),
               None],
        foot="+18.2 → +20.9 s")],
        pet=[("rd", "card0"), ("rule", "card1")]),
    "s10": dict(as_="loop", tk=[("sc", 40.5), (("sc", 3.5), 47.5), ("att", 66.1), (("att", 5.0), 109.8)], phases=[dict(
        at=0.0, rq="REQUESTS 7–23 / 86", sub="Scope first, then learning time",
        stages=[MODEL, "bash", "pandas", "counts"],
        beats=[("sc", 0), (("sc", 0.5), 1), (("sc", 1.0), 2), (("sc", 1.5), 3), ("att", 0), (("att", 0.5), 1), (("att", 1.0), 2), (("att", 1.5), 3)],
        cards=[dict(kick="STEPS 11–14 · ROSTER", role="model", mono=True, size=13.5, at="sc", maxl=2,
                    lines=["roster: 84 rows", "scope status not “included”: 3", "1 excluded", "2 observation-restricted"]),
               dict(kick="SCOPE", title="84 → 83", role="sandbox", at=("sc", 1.6), hi=[(("sc", 1.6), "att")],
                    lines=["one warehouse coordinator,", "listed in error", "out of every denominator"]),
               dict(kick="LEARNING TIME", title="82 / 83", role="sandbox", at="att", hi=[("att", 6.0)],
                    lines=["threshold 1,377 of 1,620 min", "one supervisor at 1,170", "3 × 360 pending min held out"])],
        foot="+40.5 → +109.8 s")],
        pet=[("sc", "card0"), (("sc", 1.7), "card1"), ("att", "card2")]),
    "s11": dict(as_="loop", tk=[("t", 115.3), (("t", 5.0), 134.2), ("s", 142.9), (("s", 5.5), 182.3)], phases=[dict(
        at=0.0, rq="REQUESTS 24–36 / 86", sub="Tests, then opportunity",
        stages=[MODEL, "bash", "pandas", "means · strata"],
        beats=[("t", 0), (("t", 0.5), 1), (("t", 1.0), 2), (("t", 1.5), 3), ("s", 0), (("s", 0.5), 1), (("s", 1.0), 2), (("s", 1.5), 3)],
        cards=[dict(kick="TESTS · FORMAL ATTEMPTS ONLY", title="59.06 → 94.07 → 90.27", role="sandbox", at=("t", 1.4), hi=[(("t", 1.4), "s")],
                    lines=["before · after · ten weeks later", "83 · 83 · 79 valid tests", "2 practice attempts, void: excluded"]),
               dict(kick="OPPORTUNITY", title="73 · 8 · 2", role="sandbox", at="s", hi=[("s", 6.5)],
                    lines=["≥ 2 verified incidents: evaluable", "8 lack opportunity", "2 restricted: leave or transfer"]),
               dict(kick="DATA-USE RULE", title="No opportunity is not no ability", role="brand", at=("s", 2.4),
                    lines=["not recorded as zero", "not judged as failing"])],
        foot="+115.3 → +182.3 s")],
        pet=[(("t", 1.5), "card0"), ("s", "card1"), (("s", 2.5), "card2")]),
    "s13": dict(as_="loop", tk=[("ops", 227.2), ("pool", 274.3), (("pool", 3.0), 274.6)], phases=[dict(
        at=0.0, rq="REQUEST 50 / 86", sub="Trained hubs against the deferred hub",
        stages=[MODEL, "bash", "pandas", "net change"],
        beats=[("ops", 0), (("ops", 0.5), 1), (("ops", 1.0), 2), ("pool", 3)], route=("pool", 2.6),
        cards=[dict(kick="REQUEST · step 86", role="model", mono=True, size=13.5, at="ops", maxl=2,
                    lines=["group by hub and period", "baseline → observation", "trained − deferred"]),
               dict(kick="OBSERVATION · step 86 · response-SLA rate", role="brand", mono=True, size=14, at=("ops", 1.5), span=2, gap=5, maxl=1,
                    hi=[("pool", 4.0)], cols=[None, None, None, None, "model"],
                    line_at=[("ops", 1.5), ("ops", 1.7), ("ops", 1.9), ("ops", 2.1), "pool"],
                    lines=["SYN-HUB-01   own change  +7.5 pp",
                           "SYN-HUB-02   own change  +5.5 pp",
                           "SYN-HUB-03   own change  +3.0 pp",
                           "SYN-HUB-04   own change  +1.0 pp   deferred",
                           "three trained hubs, pooled net:  +4.33 pp"]),
               None],
        foot="step 86 · +274.3 s")],
        pet=[("ops", "card0"), (("ops", 1.6), "card1"), ("pool", "found")]),
    "s14": dict(as_="loop", accent="model", tk=[("gen", 452.0), (("save", -0.2), 831.7), (("save", 1.2), 837.6)], phases=[dict(
        at=0.0, rq="REQUESTS 64–75 / 86", sub="Write the workbook generator, then run it",
        stages=[MODEL, "bash · heredoc", "openpyxl", "saved"],
        labels=["MODEL", "TOOL CALL", "CONTAINER · FILE", "OBSERVATION"],
        beats=[("gen", 0), (("gen", 1.2), 1), ("save", 2), (("save", 0.8), 3)], route=("save", 0.8),
        cards=[dict(kick="REQUESTS · bash", role="model", mono=True, size=13, at="gen", hi=[("gen", "save")], maxl=2,
                    lines=["cat << 'EOF' >", "  /tmp/build_full_workbook.py", "import openpyxl, pandas", "pass 1: sheets 1–3", "pass 2: 4–6 · pass 3: 7–10"]),
               dict(kick="THE GENERATOR WRITES", title="10 sheets", role="sandbox", at=("gen", 1.6), hi=[("save", 3.0)],
                    lines=["sample · attendance · tests", "opportunity · coaching · operations", "disruptions · gaps · packages"]),
               dict(kick="OBSERVATION · step 132", role="brand", mono=True, size=13.5, at="save", maxl=2,
                    lines=["10 sheets listed", "read back at +837.3 s"])],
        foot="steps 111–132 · the generator is rewritten several times before it runs whole")],
        pet=[("gen", "card0"), (("gen", 1.7), "card1"), ("save", "output")], hold=1.1),
    "s15": dict(as_="loop", accent="fail", fail_scope="phase", tk=[("err", 1072.2), ("fix", 1077.1), ("ok", 1081.0), (("ok", 1.6), 1091.5)], phases=[
        dict(at=0.0, rq="REQUEST 80 / 86", sub="The memo generator stops", fail="err",
             stages=[MODEL, "bash", "python-docx", "exit code 1"],
             beats=[("err", 0), (("err", 0.4), 1), (("err", 0.8), 2), (("err", 1.2), 3)],
             cards=[dict(kick="REQUEST · step 142", role="model", mono=True, size=13.5, at=0.0, maxl=2,
                         lines=["python3", "  /tmp/generate_doc_script.py"]),
                    dict(kick="OBSERVATION · step 142 · exit code 1", role="fail", mono=True, size=14, at=("err", 1.2), span=2, gap=5, maxl=1,
                         hi=[(("err", 1.2), "fix")], cols=[None, None, "fail"],
                         lines=["Traceback (most recent call last):", "    hdr_cells = tbl.rows[0].cells", "IndexError: list index out of range"]),
                    None],
             foot="step 142 · +1072.2 s"),
        dict(at="fix", rq="REQUESTS 81–82 / 86", sub="Find the cause, rewrite the helper, run again",
             stages=[MODEL, "bash", "python-docx", "saved"],
             beats=[("fix", 0), (("fix", 0.5), 1), (("fix", 1.0), 2), ("ok", 3)], route=("ok", 0.4),
             cards=[dict(kick="REQUEST · step 145", role="model", mono=True, size=13.5, at="fix", maxl=2,
                         lines=["if len(tbl.rows) == 0:", "    hdr_row = tbl.add_row()", "else:", "    hdr_row = tbl.rows[0]"]),
                    dict(kick="OBSERVATION · step 145", role="pass", mono=True, size=14, at="ok", span=2, gap=5, maxl=2,
                         hi=[("ok", 3.0)], cols=[None, None, "pass"],
                         lines=["Replacement successful.", "Sections 1–7 finished.", "SUCCESS: memorandum saved"]),
                    None],
             foot="+1077.1 → +1081.0 s")],
        pet=[("err", "card1"), ("fix", "card0"), ("ok", "card1"), (("ok", 1.7), "output")], hold=1.1),
    "s16": dict(as_="loop", tk=[("chk", 1099.2), ("f", 1099.5), ("ls", 1109.8), (("ls", 2.6), 1155.2)], phases=[dict(
        at=0.0, rq="REQUESTS 83–85 / 86", sub="Read both files back, then the output folder",
        stages=[MODEL, "bash", "openpyxl · docx · ls", "structure"],
        beats=[("chk", 0), (("chk", 0.5), 1), (("chk", 1.0), 2), (("chk", 1.5), 3)],
        cards=[dict(kick="OBSERVATION · step 148", role="brand", mono=True, size=13.5, at="chk", maxl=1,
                    lines=["Total sheets: 10", "rows and columns per sheet", "memo: 94 paragraphs · 9 tables", "7 section headings"]),
               dict(kick="WORKBOOK · AS SUBMITTED", title="3 formula cells", role="warn", at="f", hi=[("f", "ls")],
                    lines=["in 10 sheets", "every other figure is a typed value"]),
               dict(kick="OBSERVATION · step 150", role="sandbox", mono=True, size=12.5, at="ls", maxl=1,
                    hi=[("ls", 3.0)],
                    lines=["ls -la /app/output/", "训练成效与验收决策工作簿.xlsx", "  71,379 bytes",
                           "项目验收与整改决策备忘录.docx", "  62,787 bytes"])],
        foot="steps 146–150 · the folder holds exactly the two required files")],
        pet=[("chk", "card0"), ("f", "card1"), ("ls", "card2"), (("ls", 1.6), "output")]),
}

for _s in SHOTS:
    _p = PAY.get(_s["id"])
    if _p:
        _p = dict(_p)
        if "as_" in _p:
            _p["as"] = _p.pop("as_")
        _s.update(_p)

CONF.update(
    deliverables=[("xlsx", "Decision workbook"), ("docx", "Decision memo")],
    tests_lines=["rubric · 34 criteria", "reference outputs", "judge prompt"],
    outro_q="Professional tasks, judged against expert rubrics",
)

PAY2 = {
    "s01": dict(title="The setting", sub="Jichuan Cold-Chain Operations (fictional) · frontline supervisor training",
                pet=[(0.0, (592, 445)), ("d", (1311, 445))]),
    "s02": dict(title="The decision", sub="Joint acceptance meeting, 8 June · evidence closes 31 May",
                pet=[(0.0, (960, 380)), ("wp", (960, 455)), ("sum", (960, 668))]),
    "s03": dict(title="The environment", sub="Harbor builds one Docker container for this run",
                files_at="kinds", out_at="out", cols=9, tw=62,
                pet=[(0.0, (700, 380)), ("kinds", (760, 450)), ("out", (900, 620))]),
    "s04": dict(title="The evidence", sub="17 files, and five things not yet settled", hold=0.4,
                pet=[(0.0, (960, 351)), ("b", (960, 417)), ("c", (960, 483)), ("d", (960, 549)), ("e", (960, 615)),
                     (("e", 0.3), (882, 689))]),
    "s05": dict(title="The contract", sub="Two thresholds for each work package",
                pet=[(0.0, (648, 520)), ("b", (960, 520)), ("c", (1272, 520))]),
    "s06": dict(title="The environment", sub="What the agent can and cannot see",
                pet=[(0.0, (900, 836)), ("lock", (1310, 692))]),
    "s08": dict(rq="REQUESTS 1–63 / 86", sub="Seven minutes of reading and recomputing, nothing written yet", cols=9, tw=93, count_at="rd",
                pet=[("rd", (1300, 790)), ("n", "output")]),
    "s12": dict(title="One threshold, three measures", sub="Behaviour attainment among the 73 supervisors who can be evaluated",
                rq="REQUEST 37 / 86", tk=[("m", 191.2), ("pick", 206.3)],
                tags=[(1, "adopted in the workbook", "model", "pick")],
                note="The workbook reports the second.", note_at="pick", hold=0.9,
                pet=[("m", (1020, 360)), ("b", (1020, 438)), ("c", (1020, 516)), ("pick", (1020, 438))]),
    "s18": dict(title="The whole run", sub="86 requests · 85 tool calls · 1155.2 s",
                phases_=[(8.6, 423.9, "read and recompute"), (423.9, 867.7, "build the workbook"),
                         (867.7, 1099.2, "build the memo"), (1099.2, 1155.2, "")],
                marks=[(509.3, "NameError", "fail", "turn"), (1072.2, "IndexError", "fail", "turn")],
                counts=[("bash", 85, "sandbox"), ("non-zero exits", 2, "fail")],
                count_at="calls", foot="the wide gaps are single responses, each writing a whole script",
                pet=[(0.0, (960, 640)), ("calls", (594, 762)), ("turn", (1050, 560))]),
    "s19": dict(title="What the model sees", sub="Prompt tokens of each of the 86 requests",
                grow_at="grow", end_at="end", first_xy=(150, 598), vmax=230000, vgrid=(50000, 100000, 150000, 200000),
                note="Each request carries the conversation so far: the task, the model's earlier replies and every tool result.",
                foot="input + cached tokens of each request · from the harness's recorded steps",
                pet=[("grow", (1484, 425)), ("end", (1484, 425))]),
    "s20": dict(sub="Harbor ends the agent phase and starts scoring", hold=1.8,
                pet=[("stop", (712, 520)), ("tests", (1240, 640)), ("score", (1150, 806))]),
    "s21": dict(pet=[(0.0, (960, 594))]),
    "s22": dict(sub="One judge session per criterion", rk_at="rk", jm_at="jm", nf_at="nf", hold=0.3,
                grid_note="28 criteria to earn + 6 penalties · no red lines",
                judge_note="a different model from the agent · it reads /app/output",
                pet=[("rk", (900, 600)), ("jm", (800, 716)), ("nf", (700, 796))]),
    "s23": dict(sub="R20–R25 · status and amounts of the three packages", hold=0.8,
                pet=[("ok", (648, 451)), ("b", (960, 451)), ("c", (1272, 451)), ("amt", (960, 637))]),
    "s24": dict(check=True, sub="R11 · behaviour attainment", row_cues=("m", "r", "b"),
                tags=[(0, "the rubric's measure", "scorer", "m"), (1, "reported in the workbook", "warn", "r")],
                verdict=("R11", "Behaviour attainment of 73 of 73, on the mean of all reviewed items", "not met", "fail", "r"),
                note="both exceed 75% · the decision on package B is unaffected", note_at="b",
                pet=[("m", (1020, 360)), ("r", (1020, 438)), ("b", (960, 627))]),
    "s25": dict(sub="R14–R16 · hub comparisons   R1, R19 · source index", hold=0.8,
                pet=[("pool", (960, 414)), ("idx", (960, 650))]),
    "s26": dict(sub="R13 · R17 · R26 · claims, limits and closure", hold=0.8,
                pet=[("q", (960, 400)), ("r", (960, 513)), ("b", (960, 597)), ("p", (960, 681))]),
    "s27": dict(sub="34 criteria · each judged on its own",
                labels=[("Criteria to earn · 28", "pos", "19 met · 9 not met"),
                        ("Penalties · 6", "pen", "none triggered")],
                foot="pass-or-fail criteria · weights differ between criteria",
                pet=[("pos", (700, 412)), ("pen", (700, 565))]),
    "s28": dict(value="0.745", formula="79 / 106 = 0.745283",
                line1="gemini-3.8-flash  +  DeepSeek Harness 0.2.2-rc.1  ·  HR-T3-114",
                line2="86 model requests · 85 tool calls · 1155.2 s agent run",
                line3="one judge session per criterion · 34 sessions",
                note="One pilot run on a synthetic task — not accuracy, not a ranking.", hold=0.3,
                note2="no penalty applied · this task has no red lines",
                pet=[("rw", (560, 600)), ("pilot", (690, 712))]),
    "s29": dict(title="What the record shows", sub="One run, read criterion by criterion",
                pet=[("a", (723, 473)), ("b", (1196, 473)), ("c", (882, 655))]),
    "s30": dict(pet=[(0.0, (560, 600)), ("site", (690, 594))]),
}

for _s in SHOTS:
    if _s["id"] in PAY2:
        _s.update(PAY2[_s["id"]])

# Loop-layout shots; captions are English only.
for _s in SHOTS:
    _s.setdefault("zh", "")
    if _s["kind"] in ("loop_intro", "rules", "scope", "tests", "pooledrun", "write", "error", "verify", "finish"):
        _s.setdefault("as", "loop")


def _out(name, kind="xlsx"):
    def f(ctx, sh, t, st):
        import gfx as G
        st["out_hi"] = G.ease(G.seg(t, sh.cue(name), sh.cue(name) + 0.5))
        st["out_kind"] = kind
    return f


def _found(name, label):
    def f(ctx, sh, t, st):
        import gfx as G
        st["found_hi"] = G.fade_io(t, sh.cue(name), sh.dur, 0.4)
        st["found_label"] = label
    return f


def _s17(ctx, sh, t, st):
    import gfx as G
    st["ledger_hi"] = {"req": G.fade_io(t, sh.cue("tot"), sh.dur, 0.3)}


def _s15(ctx, sh, t, st):
    _out("ok", "docx")(ctx, sh, t, st)


STATE = {"s10": _found("sc", "scope"), "s11": _found("s", "strata"), "s12": _found("pick", "behaviour"),
         "s13": _found("pool", "pooled net change"), "s14": _out("save", "xlsx"), "s15": _s15,
         "s16": _out("ls", "docx")}
