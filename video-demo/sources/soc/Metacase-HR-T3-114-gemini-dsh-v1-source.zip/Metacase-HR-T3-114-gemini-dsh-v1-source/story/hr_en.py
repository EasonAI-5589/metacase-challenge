"""English display names for the Chinese file names that reach the screen in HR-T3-114.

The task's 17 input files and the agent's two deliverables have Chinese names. Every on-screen
string passes through ``english()`` (engine/gfx.py) before layout, so the file grid, the
"latest opened" list and the output panel show snake_case English names with the original
extension. Codes (SYN-HUB-01, SYN-WP-A, R11), numbers and amounts are never changed.
All other on-screen text of this video is written in English in story/hr.py and
engine/scenes_soc.py.
"""
from __future__ import annotations

from story.fin_en import _CJK, _PUNCT

# (Chinese original, English shown on screen). Longer phrases are applied first.
GLOSSARY = [
    # ---- input files (as named in /app/input_files) ----
    ("三时点情境测验答题明细.csv", "scenario_test_answers_3_points.csv"),
    ("中心周度运营指标.csv", "hub_weekly_operations.csv"),
    ("主管范围与轮班花名册.csv", "supervisor_scope_shift_roster.csv"),
    ("任务授权、伦理边界与决策权限.docx", "task_authority_ethics_decision_rights.docx"),
    ("到课、补训与豁免事件.csv", "attendance_makeup_waivers.csv"),
    ("历史基准与同期参照.xlsx", "historical_baseline_reference.xlsx"),
    ("学习数据最小使用规范.docx", "learning_data_minimum_use.docx"),
    ("带教约谈与行动承诺.csv", "coaching_talks_commitments.csv"),
    ("异常处置机会暴露日志.csv", "incident_opportunity_log.csv"),
    ("异常工单生命周期.csv", "incident_ticket_lifecycle.csv"),
    ("现场处置行为编码.xlsx", "field_behaviour_coding.xlsx"),
    ("训练单元和教学场次账.xlsx", "training_units_sessions.xlsx"),
    ("训练服务方阶段申请.docx", "provider_stage_claim.docx"),
    ("设备、气象和货型扰动.csv", "equipment_weather_cargo_disruptions.csv"),
    ("证据完整性复核清单.xlsx", "evidence_completeness_checklist.xlsx"),
    ("跨部门决策会纪要.docx", "cross_department_meeting_minutes.docx"),
    ("采购工作包与结算规则.xlsx", "procurement_work_packages_settlement.xlsx"),
    # ---- the agent's two deliverables ----
    ("项目验收与整改决策备忘录.docx", "project_acceptance_remediation_memo.docx"),
    ("训练成效与验收决策工作簿.xlsx", "training_impact_acceptance_workbook.xlsx"),
]

_ORDERED = sorted(GLOSSARY, key=lambda kv: len(kv[0]), reverse=True)


def english(s):
    """Return the on-screen English form of ``s`` (unchanged when it has no Chinese)."""
    if not s or not _CJK.search(s):
        return s
    for zh, en in _ORDERED:
        if zh in s:
            s = s.replace(zh, en)
    for zh, en in _PUNCT.items():
        s = s.replace(zh, en)
    return s


def untranslated(s):
    """Chinese characters that would still reach the screen."""
    return _CJK.findall(english(s) or "")
