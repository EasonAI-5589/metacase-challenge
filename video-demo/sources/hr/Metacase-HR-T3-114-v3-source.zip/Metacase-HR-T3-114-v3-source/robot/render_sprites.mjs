// Drive robot/sprite.html in headless Chrome and write one transparent PNG per aim angle,
// plus sprites.json with the projected muzzle, grip, feet and head points.
// usage: node robot/render_sprites.mjs --base http://127.0.0.1:4190 --out robot/sprites [--angles -90:90:3] [--size 640]
import { chromium } from 'playwright-core';
import fs from 'node:fs';
import path from 'node:path';

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, v, i, all) => {
  if (v.startsWith('--')) acc.push([v.slice(2), all[i + 1]]);
  return acc;
}, []));
const base = args.base || 'http://127.0.0.1:4190';
const out = args.out || 'robot/sprites';
const size = Number(args.size || 640);
const [a0, a1, step] = (args.angles || '-90:90:3').split(':').map(Number);
const list = args.list ? args.list.split(',').map(Number) : null;
const angles = list || Array.from({ length: Math.round((a1 - a0) / step) + 1 }, (_, i) => a0 + i * step);
const executablePath = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';

fs.mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ executablePath, headless: true, args: ['--use-angle=metal', '--enable-gpu', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: size, height: size }, deviceScaleFactor: 1 });
page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') console.log('[page]', m.text()); });
page.on('pageerror', e => console.log('[pageerror]', e.message));
await page.goto(`${base}/video-work/fin-v3/source/robot/sprite.html?size=${size}`);
await page.waitForFunction(() => window.ready === true, null, { timeout: 60000 });
const meta = [];
for (const eyesClosed of [false, true]) {
  for (const aim of angles) {
    const r = await page.evaluate(([a, c]) => window.renderAim(a, c), [aim, eyesClosed]);
    const name = `robot_${eyesClosed ? 'blink' : 'open'}_${aim < 0 ? 'm' : 'p'}${String(Math.abs(aim)).padStart(3, '0')}.png`;
    fs.writeFileSync(path.join(out, name), Buffer.from(r.png.split(',')[1], 'base64'));
    delete r.png;
    meta.push({ file: name, ...r });
  }
}
const bodyOnly = await page.evaluate(() => window.renderBody());
fs.writeFileSync(path.join(out, 'robot_body.png'), Buffer.from(bodyOnly.png.split(',')[1], 'base64'));
delete bodyOnly.png;
fs.writeFileSync(path.join(out, 'sprites.json'), JSON.stringify({ size, angles, body: { file: 'robot_body.png', ...bodyOnly }, sprites: meta }, null, 1));
console.log(`wrote ${meta.length} sprites to ${out}`);
await browser.close();
