"""Contact sheet of sprites on the video's panel colour, with muzzle/grip markers."""
import json, sys, skia
src, out = sys.argv[1], sys.argv[2]
meta = json.load(open(f"{src}/sprites.json"))
items = [s for s in meta["sprites"] if not s["eyesClosed"]] + [s for s in meta["sprites"] if s["eyesClosed"]][:2]
cell = 320
surf = skia.Surface(cell * len(items[:8]), cell)
cv = surf.getCanvas(); cv.clear(skia.Color(21, 26, 36))
for i, s in enumerate(items[:8]):
    img = skia.Image.open(f"{src}/{s['file']}")
    k = cell / s["size"]
    cv.drawImageRect(img, skia.Rect.MakeXYWH(i * cell, 0, cell, cell), skia.SamplingOptions(skia.CubicResampler.Mitchell()))
    for (x, y), c in ((s["muzzle"], skia.ColorRED), (s["grip"], skia.ColorGREEN), (s["feet"], skia.ColorYELLOW)):
        cv.drawCircle(i * cell + x * k, y * k, 4, skia.Paint(Color=c))
    p = skia.Paint(Color=skia.ColorWHITE)
    cv.drawString(f"{s['aim']}{' blink' if s['eyesClosed'] else ''}", i * cell + 8, 18, skia.Font(None, 14), p)
surf.makeImageSnapshot().save(out, skia.kPNG)
print(out)
