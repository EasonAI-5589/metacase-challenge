# SUFE Finance / HR narrated replays — relay edition

Offline Skia renderer and storyboards for FIN-T1-003 and HR-T3-114, matching the approved PR #27 replay.
Delivery record: `../handoffs/20261018-sufe-videos-claude/RELAY-DELIVERY.md`.

- `engine/` — fonts, drawing primitives (`gfx.py`), persistent UI (`ui.py`, `panels.py`), scenes (`scenes.py`,
  `scenes_x.py`), run facts from the export and session logs (`rundata.py`), timing and captions (`timeline.py`),
  voice (`voice.py`), parallel render (`render.py`), packaging (`package.py`), website install with backup (`integrate.py`)
- `story/fin.py`, `story/hr.py` — narration with word cues, captions, per-shot visual data
- `deliver/` — files installed into the website; `site-before-relay/` — what they replaced, with `manifest.json`
- `build/` — narration clips, segments, previews and logs (regenerable)

Rebuild one run: `.venv/bin/python engine/voice.py fin && .venv/bin/python engine/render.py fin && .venv/bin/python engine/package.py fin`.
Preview stills: `.venv/bin/python engine/compose.py fin f16:err`.
