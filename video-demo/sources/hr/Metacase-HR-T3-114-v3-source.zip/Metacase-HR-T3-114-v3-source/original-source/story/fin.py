"""FIN-T1-003 storyboard (one narration cue per shot).

say : narration sent to the voice; {key} marks the start of the next word and becomes a
      visual cue time. en : caption (defaults to say without markers). zh : caption.
trace: agent-run seconds swept by the header clock during the shot (None = before/after run).
Every request/step number refers to the recorded run (requests = 28 assistant message ids in
the Claude Code session log; steps = zero-based fin.json agent.steps indexes).
"""

RUN = "fin"

SHOTS = [
    # ------------------------------------------------------------------ 01 TASK
    dict(id="f00", ch=0, kind="open",
         say="One model, one harness, one month-end close. {a}Follow how the agent works inside Claude Code, {b}and how its files are checked.",
         zh="一个模型、一套 Harness、一次月末结账。看 Agent 如何在 Claude Code 里工作，交付物又如何被检验。",
         st=("brand", "FIN-T1-003 · finance · recorded pilot run")),
    dict(id="f01", ch=0, kind="task",
         say="The July books lock at six p.m. on August fifth. {six}Six proposed entries are waiting, {arr}and each one must be accepted, replaced or rejected.",
         en="The July books lock at 6 p.m. on 5 August. Six proposed entries are waiting, and each one must be accepted, replaced or rejected.",
         zh="七月账务 8 月 5 日 18:00 锁账。六条待入账意见正在等待处理，每一条都要接受、替换或拒绝。",
         st=("brand", "task · D01–D06 · all unposted")),
    dict(id="f02", ch=0, kind="limits",
         say="Each decision needs amounts and statement effects. {one}Only one independent reviewer is available, {hrs}for at most six hours a day.",
         zh="每项处理都要算清金额和报表影响；独立复核人只有 1 名，每天最多 6 小时。",
         st=("brand", "task · brief from 60_七月结账专项复核委托")),
    dict(id="f03", ch=0, kind="io",
         say="Fifty-five source files go in: {kinds}ledgers, valuations, policies and letters. {out}Two files must come out: a Word report and an Excel workbook.",
         en="55 source files go in: ledgers, valuations, policies and letters. Two files must come out: a Word report and an Excel workbook.",
         zh="输入 55 份材料：台账、估值、政策与函件。产出两份文件：一份 Word 报告，一份 Excel 底稿。",
         st=("sandbox", "/app/input_files · 55 read-only  →  /app/output")),
    dict(id="f04", ch=0, kind="sealed",
         say="The scoring rubric is not in the container. {lock}The agent works without seeing how it will be judged.",
         zh="评分标准不在容器里。Agent 在看不到评判方式的情况下工作。",
         st=("scorer", "tests/ and solution/ absent during the agent run")),

    # ------------------------------------------------------------------ 02 AGENT
    dict(id="f05", ch=1, kind="loop_intro",
         say="Claude Code runs the loop. {m}The model chooses an action. {h}Claude Code turns it into a tool call. {s}The command runs inside Docker, {o}and the output returns to the model.",
         zh="Claude Code 负责运行循环：模型选择动作，Claude Code 把它变成工具调用，命令在 Docker 里执行，输出再回到模型。",
         st=("harness", "harness · claude --print · cwd /app"), trace=(0.0, 5.2)),
    dict(id="f06", ch=1, kind="req12",
         say="{r1}The first request lists the input folder and creates the output folder. {r2}The second asks for two files: {reg}the register of proposed entries {ltr}and the review engagement letter.",
         zh="第一次请求列出输入目录、建好输出目录；第二次请求读取两份文件：待入账意见登记表和复核委托函。",
         st=("model", "requests 1–2 · 4 Bash calls"), trace=(5.2, 9.6)),
    dict(id="f07", ch=1, kind="obs2",
         say="Bash runs both inside the container. {reg}The register returns six rows, D zero one to D zero six, all unposted. {bin}The Word letter returns raw binary.",
         en="Bash runs both inside the container. The register returns six rows, D01 to D06, all unposted. The Word letter returns raw binary.",
         zh="Bash 在容器里执行这两条命令。登记表返回六行：D01 到 D06，均未过账；Word 委托函返回的却是一串二进制。",
         st=("sandbox", "steps 3–4 · exit 0 · 0.7 s / 0.2 s"), trace=(9.6, 10.4)),
    dict(id="f08", ch=1, kind="next",
         say="That observation shapes the next step. {r3}Request three reads the letter again with a Python Word library, {txt}and this time the text comes through.",
         zh="这个观察决定了下一步：第三次请求改用 Python 的 Word 库重新读取委托函，这次正文正常返回。",
         st=("model", "request 3 · python-docx · step 5"), trace=(13.0, 14.9)),
    dict(id="f09", ch=1, kind="fanout",
         say="{one}One response can carry several tool calls. {four}Request four reads four source files at once, {back}and Claude Code returns all four results together.",
         zh="一次响应可以携带多个工具调用。第四次请求同时读取四份材料，Claude Code 把四个结果一起送回。",
         st=("harness", "request 4 · 4 parallel Bash calls · steps 9–12"), trace=(24.1, 27.2)),
    dict(id="f10", ch=1, kind="plan",
         say="{tw}Request five writes a plan with To-do Write: {items}read the sources, analyze each entry, {wb}then build the workbook and the report.",
         en="Request five writes a plan with TodoWrite: read the sources, analyze each entry, then build the workbook and the report.",
         zh="第五次请求用 TodoWrite 写下计划：读材料、逐条分析各项意见，再做底稿和报告。",
         st=("harness", "TodoWrite · handled by Claude Code · no Bash"), trace=(31.5, 33.8)),
    dict(id="f11", ch=1, kind="montage",
         say="{seq}Over the next requests it keeps reading: designation documents, policies, standards and letters. {count}By request twelve, it has opened twenty-seven of the fifty-five files.",
         en="Over the next requests it keeps reading: designation documents, policies, standards and letters. By request 12, it has opened 27 of the 55 files.",
         zh="接下来的请求里它持续阅读：套期指定文件、内部政策、准则摘录和往来函件。到第 12 次请求，它已打开 55 份材料中的 27 份。",
         st=("sandbox", "requests 6–12 · counted by file names in commands"), trace=(36.6, 73.1)),
    dict(id="f12", ch=1, kind="selfmark",
         say="{tw}Request thirteen updates the plan and marks all six analyses done. {own}That status is the agent's own claim, not a check.",
         en="Request 13 updates the plan and marks all six analyses done. That status is the agent's own claim, not a check.",
         zh="第 13 次请求更新计划，把六项分析全部标为已完成。这只是 Agent 自己的标记，不是检验结果。",
         st=("harness", "request 13 · TodoWrite · step 35"), trace=(101.5, 103.4)),
    dict(id="f13", ch=1, kind="valq",
         say="{q}To size the swap's July change, it queries the daily valuation file {dates}for June thirtieth and July thirty-first.",
         en="To size the swap's July change, it queries the daily valuation file for 30 June and 31 July.",
         zh="为量化利率互换七月的价值变动，它查询逐日估值明细，取 6 月 30 日和 7 月 31 日两天。",
         st=("model", "request 15 · steps 39–40 · IRS-2026-0031"), trace=(118.4, 121.0)),
    dict(id="f14", ch=1, kind="valobs",
         say="{a}Minus one point two eight million, {b}then minus four point four zero million. {d}The July change is minus three point one two million yuan.",
         en="−1.28 million, then −4.40 million. The July change is −3.12 million yuan.",
         zh="6 月末 −1,277,351.45 元，7 月末 −4,395,835.74 元，七月变动 −3,118,484.29 元。",
         st=("sandbox", "observation · 12_衍生品交易与逐日估值明细"), trace=(121.0, 121.0)),
    dict(id="f15", ch=1, kind="workbook",
         say="Next the model writes {gen}a long Python script. {run}Bash runs it, {s3}and the workbook appears with three sheets, {s5}then two more.",
         zh="接着模型写出一段很长的 Python 脚本。Bash 执行后，底稿先出现三张表，随后再补上两张。",
         st=("model", "requests 16–17 · 6,980 + 3,844 output tokens · steps 42–43"), trace=(147.3, 205.4)),
    dict(id="f16", ch=1, kind="error",
         say="{try}Then a script to enrich two sheets {prt}prints \"enhanced\" twice, {err}and stops with a Name Error: a misspelled variable.",
         en="Then a script to enrich two sheets prints \"enhanced\" twice, and stops with a NameError: a misspelled variable.",
         zh="随后，一段补充两张表的脚本先打印两次 enhanced，接着因变量名拼错，以 NameError 中止。",
         st=("fail", "request 19 · step 46 · exit 1 · +239.9 s"), trace=(214.1, 240.3)),
    dict(id="f17", ch=1, kind="notsaved",
         say="{crash}The script crashed before saving, {none}so neither change reached the file. {rows}Sheet one still holds three rows.",
         zh="脚本在保存之前就崩溃了，两处修改都没有写进文件。第一张表仍然只有 3 行。",
         st=("fail", "printed ≠ saved · workbook unchanged"), trace=(240.3, 240.3)),
    dict(id="f18", ch=1, kind="moveon",
         say="{no}The agent doesn't notice yet. {s34}It enriches sheets three and four, {doc}then writes the Word report, {sec}one section for each entry.",
         zh="Agent 此时还没察觉。它补充了第三、四张表，然后写 Word 报告：每条意见一节。",
         st=("model", "requests 20–22 · 9,601 output tokens for the report"), trace=(242.7, 338.3)),
    dict(id="f19", ch=1, kind="selfcheck",
         say="{rb}Then it reads its own files back. {three}The check shows sheet one with only three rows.",
         zh="然后它读回自己的文件。检查结果显示，第一张表只有 3 行。",
         st=("sandbox", "request 23 · steps 53–55 · 套期关系指定: 3 rows × 13 cols"), trace=(341.3, 343.7)),
    dict(id="f20", ch=1, kind="realize",
         say="{look}It looks once more, {say}then states it plainly: {q}the sheet one and two enhancements weren't saved, because of the earlier error.",
         zh="它又查了一次，然后明确说出原因：第一、二张表的补充因为之前的错误没有保存。",
         st=("model", "requests 24–25 · recorded assistant text · +378.3 s"), trace=(365.1, 378.3)),
    dict(id="f21", ch=1, kind="repair",
         say="{rerun}It runs the edit again. {rcpt}This time the receipt reads \"All enhancements saved\", {rows}and both sheets now hold thirty-nine rows.",
         en="It runs the edit again. This time the receipt reads \"All enhancements saved\", and both sheets now hold 39 rows.",
         zh="它重新执行这次修改。这次回执是 All enhancements saved，两张表都变成 39 行。",
         st=("pass", "steps 59 and 61 · read back → re-run → saved"), trace=(378.2, 401.3)),
    dict(id="f22", ch=1, kind="finish",
         say="{fin}A final check, the plan is ticked off, and the agent stops: {tot}twenty-eight model requests, fifty-four tool calls, about seven minutes.",
         en="A final check, the plan is ticked off, and the agent stops: 28 model requests, 54 tool calls, about seven minutes.",
         zh="最后再检查一遍，计划全部打勾，Agent 结束：28 次模型请求、54 次工具调用，约 7 分钟。",
         st=("model", "agent trace 414.7 s · 44,737 output tokens"), trace=(396.6, 414.7)),

    # ------------------------------------------------------------------ 03 HARNESS
    dict(id="f23", ch=2, kind="trace",
         say="Here is the whole run. {calls}Fifty Bash commands and four To-do Write updates, all through Claude Code. {nofile}It never used the Read, Edit or Write tools; all file work went through Bash.",
         en="Here is the whole run. 50 Bash commands and 4 TodoWrite updates, all through Claude Code. It never used the Read, Edit or Write tools; all file work went through Bash.",
         zh="这是整次运行：50 次 Bash、4 次 TodoWrite，全部经由 Claude Code。它没有使用 Read、Edit、Write 工具，所有文件操作都走 Bash。",
         st=("harness", "54 tool calls · 28 requests · 414.7 s"), trace=(414.7, 414.7)),
    dict(id="f24", ch=2, kind="context",
         say="{grow}Each result is added to the model's context. {end}By the last request, the prompt has grown from about twenty-seven thousand to about a hundred thousand tokens.",
         en="Each result is added to the model's context. By the last request, the prompt has grown from about 27 thousand to about 100 thousand tokens.",
         zh="每个结果都会追加进模型的上下文。到最后一次请求，提示长度从约 2.7 万 token 增长到约 10 万。",
         st=("model", "prompt tokens per request · 26,560 → 99,752"), trace=(414.7, 414.7)),
    dict(id="f25", ch=2, kind="handoff",
         say="{stop}When the agent stops, {tests}Harbor copies the tests into the same container. {score}Only then does scoring begin.",
         zh="Agent 停止后，Harbor 才把测试复制进同一个容器。评分这时才开始。",
         st=("scorer", "same container · tests/ copied in · judge runs as root"), trace=(414.7, 414.7)),

    # ------------------------------------------------------------------ 04 CHECK
    dict(id="f26", ch=3, kind="chapter",
         say="An independent check now takes over.",
         zh="接下来，由独立检验接手。",
         title="Independent check", sub="The two submitted files are scored, one criterion at a time.",
         st=("scorer", "RewardKit 0.1.7 · Claude Code judge sessions")),
    dict(id="f27", ch=3, kind="judges",
         say="{rk}Reward Kit opens a separate judge session for each of twenty-seven criteria. {jm}The judge model is DeepSeek V four point one Flash. {nf}Nothing flows back to the agent.",
         en="RewardKit opens a separate judge session for each of 27 criteria. The judge model is deepseek-v4.1-flash. Nothing flows back to the agent.",
         zh="RewardKit 为 27 条评分项各开一个独立的裁判会话，裁判模型是 deepseek-v4.1-flash。评分结果不会回传给 Agent。",
         st=("scorer", "25 graded + 2 red lines · 280 judge API requests")),
    dict(id="f28", ch=3, kind="dv01",
         say="{num}One number holds. The workbook's D V zero one {rc}matches the judge's recomputation from the five-basis-point scenarios. {src}The agent copied it from the valuation sheet.",
         en="One number holds. The workbook's DV01 matches the judge's recomputation from the five-basis-point scenarios. The agent copied it from the valuation sheet.",
         zh="有一个数字对上了：底稿里的 DV01 与裁判按正负 5BP 情景复算的结果一致。这个值是 Agent 从估值底稿里取用的。",
         st=("pass", "R11 · met · tolerance ±0.01 CNY/BP")),
    dict(id="f29", ch=3, kind="d02",
         say="{d02}D zero two is subtler. {red}The agent didn't book the loan's loss to the cash-flow hedge reserve, so the red line holds. {half}But accepting it as a provisional net-investment hedge earns only half marks.",
         en="D02 is subtler. The agent didn't book the loan's loss to the cash-flow hedge reserve, so the red line holds. But accepting it as a provisional net-investment hedge earns only half marks.",
         zh="D02 更微妙：Agent 没有把借款汇兑损失记入现金流量套期储备，红线未触发；但它把该意见作为净投资套期的暂行处理接受，只拿到一半分。",
         st=("scorer", "G2 red line · clear   R51 · level 3 of 5 → 0.5")),
    dict(id="f30", ch=3, kind="formulas",
         say="{zero}And none of the five sheets contains a formula. {static}The amounts are typed-in values, so the calculation chain can't be traced to the source fields.",
         zh="此外，五张表里一个公式都没有。金额都是直接写入的数值，计算链无法追溯到来源字段。",
         st=("fail", "R19 · not met · 0 formulas in 5 sheets")),

    # ------------------------------------------------------------------ 05 RESULT
    dict(id="f31", ch=4, kind="tally",
         say="{pos}Of twenty positive criteria, three are met, six partly met, and eleven not met. {pen}No penalties were triggered, {red}and both red lines held.",
         en="Of 20 positive criteria, 3 are met, 6 partly met, and 11 not met. No penalties were triggered, and both red lines held.",
         zh="20 个正向评分项中，3 项满足、6 项部分满足、11 项未满足；5 个扣分项均未触发，两条红线都守住了。",
         st=("scorer", "positive weight 172 · penalties 0 / 5 · red lines 2 / 2 clear")),
    dict(id="f32", ch=4, kind="reward",
         say="{rw}The recorded reward is zero point three three three: {w}fifty-seven point two five of one hundred seventy-two weighted points. {pilot}One pilot run's rubric score, not accuracy, and not a ranking.",
         en="The recorded reward is 0.333: 57.25 of 172 weighted points. One pilot run's rubric score, not accuracy, and not a ranking.",
         zh="记录的奖励值为 0.333，即加权得分 57.25 / 172。这是一次试跑的评分结果，不是准确率，也不是排名。",
         st=("scorer", "reward 0.332849 · verifier_error 0")),
    dict(id="f33", ch=4, kind="outro",
         say="A professional task, an agent run, and an independent check. {site}Explore more on the Inference Net Challenge site.",
         en="A professional task, an agent run, and an independent check. Explore more on the InferenceNet Challenge site.",
         zh="专业任务、Agent 运行、独立检验。更多内容见 InferenceNet Challenge 网站。",
         st=("brand", "easonai-5589.github.io/inferencenet-challenge")),
]

# ---------------------------------------------------------------------------- persistent panels
CONF = dict(
    task_id="FIN-T1-003", domain="Finance", version="v1.1.2",
    title="July month-end close: corrections and review plan",
    title_zh="集团七月结账整改与复核安排",
    role="Lead reviewer · group treasury and shared-service centre",
    meta="55 input files · Word + Excel · A3 / C5",
    chips=[("MODEL", "qwen3.7-max"), ("HARNESS", "Claude Code 2.1.114"),
           ("SANDBOX", "Docker · Bash"), ("JUDGE", "deepseek-v4.1-flash")],
    total_tools=54, total_requests=28, inputs=55,
    plan_labels=[  # TodoWrite text prefix -> short label (faithful condensation)
        ("Read all critical source files", "Read the source files"),
        ("Analyze D01", "D01 · HR-01 swap reserve"),
        ("Analyze D02", "D02 · HR-03 USD loan FX loss"),
        ("Analyze D03", "D03 · HR-01 reserve release"),
        ("Analyze D04", "D04 · HKSub comparatives"),
        ("Analyze D05", "D05 · USSub disposal preview"),
        ("Analyze D06", "D06 · IRS counterparty value"),
        ("Create Excel workbook", "Excel workbook · 5 sheets"),
        ("Create Word report", "Word report"),
    ],
    # (trace s, label, value, colour) — values exactly as returned by recorded tool output
    found=[
        (10.3, "pending entries", "6 · unposted", "fg"),
        (111.0, "DV01 · sheet 16", "−132,480.55", "fg"),
        (121.0, "swap · July change", "−3,118,484.29", "model"),
    ],
    files_opened_label="files opened",
    xlsx="FIN-T1-003_月结调整与复核底稿.xlsx",
    docx="FIN-T1-003_七月结账整改与复核安排.docx",
)


def outputs(T):
    """State of /app/output at trace time T (from recorded tool results)."""
    out = []
    if T >= 173.7:
        sheets = ["套期关系指定", "有效性评估", "折算与储备"] + (["调整分录", "复核排程"] if T >= 205.4 else [])
        meta = f"{len(sheets)} sheets"
        if T >= 394.0:
            meta = "5 sheets · 39 / 39 rows in 1–2"
        elif T >= 342.3:
            meta = "5 sheets · sheet 1: 3 rows"
        size = "19,030 B" if T >= 401.3 else ("16,878 B" if T >= 341.7 else "")
        out.append(dict(kind="xlsx", name=CONF["xlsx"], meta=meta, size=size,
                        state="warn" if 240.3 <= T < 394.0 else "ok"))
    if T >= 338.3:
        out.append(dict(kind="docx", name=CONF["docx"], meta="188 ¶ · 6 tables · 52 headings",
                        size="44,984 B" if T >= 341.7 else "", state="ok"))
    return out


# ---------------------------------------------------------------------------- shot payloads (visuals)
REG = ['cat ".../61_七月待入账意见登记_20260803.csv"',
       'cat ".../60_七月结账专项复核委托_20260803.docx" | head -200']

PAY = {
    "f00": dict(pet=[(0.0, (720, 530)), ("a", (560, 622)), ("b", (640, 690))]),
    "f05": dict(as_="loop", accent="harness", phases=[dict(
        at=0.0, rq="", sub="Model → Claude Code → Docker → back to the model",
        stages=["qwen3.7-max", "Claude Code", "Bash · python3", "next request"],
        labels=["MODEL", "HARNESS", "DOCKER · BASH", "OBSERVATION"],
        beats=[("m", 0), ("h", 1), ("s", 2), ("o", 3)], route="o",
        cards=[dict(kick="MODEL · REMOTE API", title="Chooses the next action", role="model", at="m", hi=[("m", "h")],
                    lines=["Reads the task and every result so far", "Replies with text and tool calls", "Served through Alibaba Cloud Bailian"]),
               dict(kick="HARNESS · IN THE CONTAINER", title="Claude Code runs the loop", role="harness", at="h", hi=[("h", "s")],
                    lines=["Dispatches each tool call", "Keeps the session context", "Sends results back with the next request"]),
               dict(kick="SANDBOX · DOCKER", title="Commands run in /app", role="sandbox", at="s", hi=[("s", "o")],
                    lines=["Bash runs python3, openpyxl, python-docx", "Reads /app/input_files (read-only)", "Writes /app/output"])],
        foot="Harbor runs:  claude --print --output-format=stream-json --permission-mode=bypassPermissions")],
        pet=[("m", "card0"), ("h", "card1"), ("s", "card2"), ("o", (803, 470))]),
    "f06": dict(as_="loop", tk=[("r1", 5.2), (("r1", 3.4), 6.2), ("r2", 9.2), ("ltr", 9.6)], phases=[
        dict(at=0.0, rq="REQUEST 1 / 28", sub="List the inputs, create the output folder",
             stages=["qwen3.7-max", "Bash ×2", "ls · mkdir", "listing"],
             beats=[("r1", 0), (("r1", 1.2), 1), (("r1", 2.0), 2), (("r1", 3.0), 3)], route=("r1", 3.0),
             cards=[dict(kick="REQUEST · 2 tool calls", role="model", mono=True, size=13.5, at="r1", hi=[("r1", 1.3)],
                         lines=["ls -la /app/input_files/ | head -80", "mkdir -p /app/output && ls -la /app/output/"]),
                    dict(kick="EXECUTION · BASH", role="sandbox", mono=True, at=("r1", 1.8), cols=["sandbox", "sandbox"],
                         lines=["step 1 · exit 0 · 0.4 s", "step 2 · exit 0 · 0.1 s"]),
                    dict(kick="OBSERVATION", role="brand", mono=True, size=14, at=("r1", 2.8),
                         lines=["total 36308", "55 read-only input files", "/app/output: created, empty"])],
             foot="request 1 · two Bash calls in one response · +5.2 s"),
        dict(at="r2", rq="REQUEST 2 / 28", sub="Read the register and the engagement letter",
             stages=["qwen3.7-max", "Bash ×2", "cat · cat", "…"],
             beats=[("r2", 0), ("reg", 1), ("ltr", 2)],
             cards=[dict(kick="REQUEST · 2 tool calls", role="model", mono=True, size=13.5, at="r2", line_at=["reg", "ltr"],
                         hi=[("reg", 4.0)], lines=REG), None, None],
             foot="request 2 · +9.2 s")],
        pet=[("r1", "card0"), (("r1", 2.8), "card2"), ("r2", "card0")]),
    "f07": dict(as_="loop", overlay="binary", tk=[(0.0, 9.6), ("reg", 10.3), ("bin", 10.4)], phases=[dict(
        at=0.0, rq="REQUEST 2 / 28", sub="Bash runs both commands in the container",
        stages=["qwen3.7-max", "Bash ×2", "cat · cat", "2 results"],
        beats=[(0.0, 2), ("reg", 3)], route="bin",
        cards=[dict(kick="REQUEST · 2 tool calls", role="model", mono=True, size=13.5, at=0.0, lines=REG),
               dict(kick="OBSERVATION · step 3 · 61_七月待入账意见登记_20260803.csv", role="brand", mono=True, size=13,
                    at="reg", reveal=("reg", 2.0), hi=[("reg", "bin")], span=2, gap=3,
                    maxl=1, lines=["D01  HR-01   3,118,484.29  未过账  互换继续按原关系计入现金流量套期储备",
                           "D02  HR-03   4,480,000.00  未过账  美元借款7月汇兑损失计入现金流量套期储备",
                           "D03  HR-01     283,416.56  未过账  套期关系终止应把期初储备一次转损益",
                           "D04  HKSub              —  未过账  仅更新22号资产负债精度，18号权益和利润金额不动…",
                           "D05  USSub   6,000,000.00  未过账  按归母累计折算差额乘15/70预提处置收益",
                           "D06  IRS…31     35,371.91  未过账  以17号对手方估值替换16号采用值，差额全部作为…"]),
               None],
        foot="steps 3–4 · Bash · exit 0 · 0.7 s and 0.2 s · both results go back together")],
        pet=[(0.0, "card0"), ("reg", "card1"), ("bin", "card2")]),
    "f08": dict(as_="loop", tk=[(0.0, 10.4), ("r3", 13.0), ("txt", 14.8)], phases=[
        dict(at=0.0, rq="REQUEST 2 / 28", sub="The bytes from the .docx return to the model",
             stages=["qwen3.7-max", "—", "—", "raw bytes"], dim=[1, 2], beats=[(0.0, 3), (0.9, 0)], route=0.15,
             cards=[None, None,
                    dict(kick="OBSERVATION · step 4", role="fail", mono=True, size=13.5, at=0.0,
                         cols=[(226, 150, 150), (226, 150, 150), "fail"],
                         lines=["PK␃␄ [Content_Types].xml ��MO�@", "��/> {C��p(p,�D���8Y�/�L���:", "a Word file is a ZIP archive"])]),
        dict(at="r3", rq="REQUEST 3 / 28", sub="Read the letter again with python-docx",
             stages=["qwen3.7-max", "Bash ×3", "python3 -c", "text"],
             beats=[("r3", 0), (("r3", 0.9), 1), (("r3", 1.6), 2), ("txt", 3)], route="txt",
             cards=[dict(kick="REQUEST · 3 tool calls", role="model", mono=True, size=13.2, at="r3", hi=[("r3", 1.4)],
                         lines=['python3 -c "from docx import Document', "doc = Document('…/60_…委托.docx')",
                                'for p in doc.paragraphs: print(p.text)"', "+ cat 62_期初结存…csv", "+ cat 63_复核工时安排…csv"]),
                    dict(kick="EXECUTION · BASH", role="sandbox", mono=True, size=14, at=("r3", 1.4),
                         cols=["sandbox", "sandbox", "sandbox"],
                         lines=["step 5 · exit 0 · 1.0 s", "step 6 · exit 0 · 0.7 s", "step 7 · exit 0 · 0.3 s"]),
                    dict(kick="OBSERVATION · step 5", role="brand", size=14.5, at="txt", hi=[("txt", 2.4)],
                         lines=["七月结账专项复核委托及适用范围", "发文日期：2026-08-03，经财务负责人签批",
                                "7月结账锁账时间为 2026-08-05 18:00", "61号 D01 至 D06 均为待入账意见，全部尚未过账"])],
             foot="request 3 · the previous observation changed how the file is read")],
        pet=[(0.0, "card2"), (0.9, (803, 470)), ("r3", "card0"), ("txt", "card2")]),
    "f10": dict(as_="loop", accent="harness", tk=[("tw", 31.5), ("items", 33.8)], phases=[dict(
        at=0.0, rq="REQUEST 5 / 28", sub="TodoWrite: the plan is kept by Claude Code, not by Bash",
        stages=["qwen3.7-max", "TodoWrite", "no shell", "tool result"], dim=[2],
        beats=[("tw", 0), (("tw", 1.0), 1), ("wb", 3)], route="wb",
        cards=[dict(kick="REQUEST · 1 tool call", title="TodoWrite · 9 items", role="model", at="tw", hi=[("tw", "items")],
                    lines=["Read the source files · in progress", "Analyze D01 … D06 · pending", "Excel workbook · Word report"]),
               dict(kick="HANDLED BY CLAUDE CODE", title="No command runs", role="harness", at=("tw", 0.9),
                    hi=[(("tw", 0.9), "wb")], lines=["The list lives in the session", "Docker is not involved"]),
               dict(kick="OBSERVATION", role="brand", mono=True, size=14, at="wb",
                    lines=["Todos have been modified", "successfully."])],
        foot="step 13 · TodoWrite · +33.8 s")],
        pet=[("tw", "card0"), ("items", "plan"), ("wb", "card2")]),
    "f12": dict(as_="loop", accent="harness", tk=[("tw", 101.5), (("tw", 1.5), 103.4)], phases=[dict(
        at=0.0, rq="REQUEST 13 / 28", sub="The plan update marks all six analyses done",
        stages=["qwen3.7-max", "TodoWrite", "no shell", "tool result"], dim=[2],
        beats=[("tw", 0), (("tw", 1.0), 1)],
        cards=[dict(kick="REQUEST · TodoWrite", title="D01 … D06 → completed", role="model", at="tw",
                    lines=["Read the source files → completed", "Excel workbook → in progress", "3,396 output tokens in this response"]),
               dict(kick="CHECKED BY", title="No one", role="harness", at="own", hi=[("own", 3.5)],
                    lines=["A status the agent sets for itself", "The judge only sees the final files"]),
               dict(kick="/app/output · +103.4 s", title="Still empty", role="warn", at=("own", 0.9),
                    lines=["No workbook or report exists yet"])],
        foot="step 35 · TodoWrite · +103.4 s")],
        pet=[("tw", "plan"), ("own", "card1"), (("own", 1.6), "output")]),
    "f13": dict(as_="loop", tk=[("q", 118.4), (("dates", 1.4), 121.0)], phases=[dict(
        at=0.0, rq="REQUEST 15 / 28", sub="Query the swap's daily valuations",
        stages=["qwen3.7-max", "Bash ×2", "python3 · csv", "4 rows"],
        beats=[("q", 0), (("q", 1.2), 1), ("dates", 2), (("dates", 1.4), 3)], route=("dates", 1.4),
        cards=[dict(kick="REQUEST · step 40", role="model", mono=True, size=13, at="q", hi=[("q", "dates")],
                    lines=['python3 -c "import csv', "open('…/12_衍生品交易与逐日估值明细…csv')",
                           "if row['交易编号'] == 'IRS-2026-0031'", "and row['估值日'] in ('2026-06-30',", "  '2026-07-31', …)\""]),
               dict(kick="EXECUTION · BASH", role="sandbox", mono=True, size=14, at=("q", 1.4), hi=[("dates", 1.4)],
                    lines=["reads a 5.3 MB CSV", "in /app/input_files", "step 40 · exit 0 · 0.2 s"]),
               dict(kick="OBSERVATION · 4 rows", role="brand", mono=True, size=14, at=("dates", 1.4),
                    cols=[None, "model", None, "model"], hi=[(("dates", 1.4), 3)],
                    lines=["06-29   −1,162,561.22", "06-30   −1,277,351.45", "07-01   −1,109,140.00", "07-31   −4,395,835.74"])],
        foot="request 15 · steps 39–40 · +119.4 → +121.0 s")],
        pet=[("q", "card0"), ("dates", "card1"), (("dates", 1.5), "card2")]),
    "f15": dict(as_="loop", tk=[(0.0, 147.3), ("run", 173.2), ("s3", 173.7), ("s5", 205.4)], phases=[dict(
        at=0.0, rq="REQUESTS 16–17", sub="Each response writes a whole openpyxl script",
        stages=["6,980 tokens", "Bash", "python3", "sheet names"],
        beats=[(0.0, 0), ("run", 1), (("run", 0.6), 2), ("s3", 3)], route=("s5", 0.3),
        cards=[dict(kick="REQUEST · step 42", role="model", mono=True, size=13, at=0.0, hi=[(0.0, "run")],
                    lines=["python3 << 'PYEOF'", "import openpyxl", "from openpyxl.styles import Font,", "  PatternFill, Alignment, Border, Side", "from openpyxl.utils import get_column_letter"]),
               dict(kick="EXECUTION · BASH", role="sandbox", mono=True, size=14, at="run", line_at=["run", "s5"],
                    cols=["sandbox", "sandbox"], lines=["step 42 · exit 0 · 0.5 s", "step 43 · exit 0 · 0.6 s"]),
               dict(kick="OBSERVATION", role="brand", mono=True, size=13.2, at="s3",
                    line_at=["s3", ("s3", 0.25), ("s3", 0.5), "s5", ("s5", 0.25), ("s5", 0.5)],
                    lines=["Sheet 1 created: 套期关系指定", "Sheet 2 created: 有效性评估", "Sheet 3 created: 折算与储备",
                           "Sheet 4 created: 调整分录", "Sheet 5 created: 复核排程", "Total sheets: 5"])],
        foot="requests 16–17 · 6,980 + 3,844 output tokens · a file exists; correctness not yet known")],
        state=dict(out_kind="xlsx"),
        pet=[("gen", "card0"), ("run", "card1"), ("s3", "output")]),
    "f16": dict(as_="loop", accent="fail", tk=[("try", 214.1), (("try", 1.5), 239.9), ("err", 240.3)], phases=[dict(
        at=0.0, rq="REQUEST 19 / 28", sub="Enrich sheets 1 and 2 with detailed calculations",
        stages=["qwen3.7-max", "Bash", "python3", "exit 1"],
        beats=[("try", 0), (("try", 0.9), 1), (("try", 1.5), 2), ("err", 3)], fail="err",
        cards=[dict(kick="REQUEST · step 46", role="model", mono=True, size=13, at="try",
                    lines=["python3 << 'PYEOF'", "import openpyxl", "wb = openpyxl.load_workbook(", "  '/app/output/FIN-T1-003_…底稿.xlsx')", "…"]),
               dict(kick="EXECUTION · BASH", role="fail", mono=True, size=14, at=("try", 1.5), cols=["fail", None],
                    lines=["step 46 · exit 1 · 0.4 s", "+239.9 s"]),
               dict(kick="OBSERVATION · exit code 1", role="fail", mono=True, size=12.5, at="prt", hi=[("err", 4.0)], maxl=1,
                    line_at=["prt", ("prt", 0.5), "err", ("err", 0.2), ("err", 0.4), ("err", 0.6), ("err", 0.8)],
                    cols=[None, None, "fail", "fail", "fail", "fail", "fail"],
                    lines=["Sheet 1 enhanced", "Sheet 2 enhanced", "Traceback (most recent call…",
                           '  File "<stdin>", line 212', "NameError: name 'usub_headers'", "  is not defined. Did you", "  mean: 'ussub_headers'?"])],
        foot="step 46 · the tool call failed · Claude Code returns the traceback as the result")],
        pet=[("try", "card0"), ("prt", "card2")]),
    "f19": dict(as_="loop", tk=[("rb", 341.3), ("three", 343.7)], phases=[dict(
        at=0.0, rq="REQUEST 23 / 28", sub="Read both deliverables back",
        stages=["qwen3.7-max", "Bash ×3", "ls · openpyxl · docx", "structure"],
        beats=[("rb", 0), (("rb", 0.8), 1), (("rb", 1.4), 2), ("three", 3)],
        cards=[dict(kick="REQUEST · 3 tool calls", role="model", mono=True, size=13.5, at="rb",
                    lines=["ls -la /app/output/", "load_workbook(…xlsx): rows × cols", "Document(…docx): paragraphs, tables"]),
               dict(kick="EXECUTION · BASH", role="sandbox", mono=True, size=14, at=("rb", 1.3), cols=["sandbox"],
                    lines=["steps 53–55 · exit 0"]),
               dict(kick="OBSERVATION · step 54", role="brand", mono=True, size=13.5, at="three", hi=[("three", 3.5)],
                    cols=["warn", "warn", None, None, None],
                    lines=["套期关系指定:  3 rows × 13", "有效性评估:  21 rows × 6", "折算与储备:  50 rows × 7",
                           "调整分录:    47 rows × 10", "复核排程:    23 rows × 9"])],
        foot="request 23 · +341.3 s · the report reads back as 188 paragraphs, 6 tables, 52 headings")],
        state=dict(out_kind="xlsx"),
        pet=[("rb", "card0"), ("three", "card2")]),
    "f20": dict(as_="loop", overlay="quote", tk=[("look", 365.1), ("say", 370.9), ("q", 378.3)], phases=[
        dict(at=0.0, rq="REQUEST 24 / 28", sub="Look at sheet 1 once more",
             stages=["qwen3.7-max", "Bash", "python3", "3 rows"],
             beats=[("look", 0), (("look", 0.4), 1), (("look", 0.8), 2), ("say", 3)],
             cards=[dict(kick="REQUEST · step 57", role="model", mono=True, size=13.5, at="look",
                         lines=["for name in wb.sheetnames:", "  print(dimensions, col A cells)"]),
                    dict(kick="OBSERVATION · step 57", role="brand", mono=True, size=13.5, at=("look", 0.7),
                         cols=[None, "warn", None], lines=["=== 套期关系指定 ===", "Dimensions: 3 rows x 13 cols", "Non-empty cells in col A: 3"]),
                    None]),
        dict(at="q", rq="REQUEST 25 / 28", sub="The model names the cause in its reply",
             stages=["qwen3.7-max", "Bash", "python3", "3 rows"], beats=[("q", 0)],
             cards=[None, None, None])],
        quote=("The Sheet 1 and Sheet 2 enhancements weren't saved due to the earlier error. Let me reapply them.",
               "recorded assistant text · request 25 · +378.3 s"),
        pet=[("look", "card0"), (("look", 0.8), "card1"), ("q", (960, 640))]),
    "f21": dict(as_="loop", accent="pass", tk=[("rerun", 378.2), ("rcpt", 394.0), ("rows", 401.3)], phases=[dict(
        at=0.0, rq="REQUEST 25 / 28", sub="Re-apply the sheet 1 and 2 edits",
        stages=["qwen3.7-max", "Bash", "python3", "saved"],
        beats=[("rerun", 0), (("rerun", 0.7), 1), (("rerun", 1.3), 2), ("rcpt", 3)], route=("rows", 0.6),
        cards=[dict(kick="REQUEST · step 59", role="model", mono=True, size=13, at="rerun",
                    lines=["python3 << 'PYEOF'", "import openpyxl", "wb = openpyxl.load_workbook(", "  '/app/output/FI…'"]),
               dict(kick="OBSERVATION · step 59", role="pass", mono=True, size=14, at="rcpt", cols=[None, None, "pass"],
                    hi=[("rcpt", 3.0)], lines=["Sheet 1 enhanced", "Sheet 2 enhanced", "All enhancements saved"]),
               dict(kick="READ BACK · step 61", role="pass", mono=True, size=13.5, at="rows", cols=["pass", "pass"],
                    hi=[("rows", 3.0)], lines=["套期关系指定: 39 rows × 13", "有效性评估:  39 rows × 6"])],
        foot="steps 59 and 61 · +393.6 → +401.3 s · workbook 16,878 → 19,030 bytes")],
        state=dict(out_kind="xlsx"),
        pet=[("rerun", "card0"), ("rcpt", "card1"), ("rows", "output")]),
    "f22": dict(as_="loop", tk=[("fin", 396.6), ("tot", 414.7)], phases=[dict(
        at=0.0, rq="REQUEST 28 / 28", sub="Final checks, plan complete, final reply",
        stages=["qwen3.7-max", "Bash · TodoWrite", "ls · checks", "done"],
        beats=[("fin", 0), (("fin", 0.9), 1), (("fin", 1.5), 2), ("tot", 0)],
        cards=[dict(kick="REQUESTS 26–28", role="model", at="fin",
                    lines=["Final workbook and report checks", "TodoWrite: all 9 items completed", "Final reply: 七月结账专项整改完成"]),
               dict(kick="RUN TOTALS", title="28 requests · 54 tool calls", role="harness", at="tot", hi=[("tot", 3.0)],
                    lines=["50 Bash · 4 TodoWrite", "agent trace 414.7 s", "44,737 output tokens"]),
               dict(kick="/app/output", role="sandbox", mono=True, size=13, at=("tot", 0.9),
                    lines=["…七月结账整改与复核安排.docx", "  44,984 bytes", "…月结调整与复核底稿.xlsx", "  19,030 bytes"])],
        foot="+414.7 s · the agent session ends here")],
        pet=[("fin", "card0"), ("tot", "card1")]),
}

for _s in SHOTS:
    _p = PAY.get(_s["id"])
    if _p:
        _p = dict(_p)
        if "as_" in _p:
            _p["as"] = _p.pop("as_")
        _s.update(_p)

CONF.update(
    deliverables=[("docx", "Word report"), ("xlsx", "Excel workbook")],
    tests_lines=["rubric · 27 criteria", "reference solution", "judge prompt"],
    outro_q="Finance and HR tasks, judged against expert rubrics",
)

_E = [("D01", "HR-01", "Keep the HR-01 swap in the cash-flow hedge reserve under the original relationship", "3,118,484.29"),
      ("D02", "HR-03", "Book the HR-03 USD loan's July FX loss to the cash-flow hedge reserve", "4,480,000.00"),
      ("D03", "HR-01", "On termination, release HR-01's opening reserve to profit or loss at once", "283,416.56"),
      ("D04", "HKSub", "HKSub June comparatives: fix rounding only and park the gap in translation differences", "—"),
      ("D05", "USSub", "Accrue a USSub disposal gain in July at 15/70 of the cumulative translation difference", "6,000,000.00"),
      ("D06", "IRS-2026-0031", "Replace the adopted IRS-2026-0031 value with the counterparty's and call the whole gap CVA", "35,371.91")]

PAY2 = {
    "f01": dict(title="The task", sub="Group treasury · July close · proposed entries D01–D06",
                deadline="Books lock · 5 Aug 2026 · 18:00", badge_r="61_七月待入账意见登记 · 3 Aug",
                items=[dict(id=i, obj=o, title=tt, amount=am) for i, o, tt, am in _E],
                items_at="six", choice_at="arr",
                pet=[(0.0, (700, 360)), ("six", (648, 776)), ("arr", (960, 776))]),
    "f02": dict(title="What the brief asks", sub="From 60_七月结账专项复核委托 and the task instruction",
                brief=[("July books lock at 18:00 on 5 Aug; pending entries have been filed", "7月账务8月5日18:00锁账，共享中心已提交一批待入账意见"),
                       ("Resolve each entry, quantify its impact and draft replacement entries", "逐项处理待入账意见，算清金额与报表影响，形成可批准的替换分录"),
                       ("Restate HKSub's June comparatives; rehearse the USSub share sale", "同步更正HKSub 6月比较信息；为USSub股权转让做交割前预演"),
                       ("One independent reviewer, at most 6 hours a day on 4–5 Aug", "只有1名独立复核人，8月4日、5日每日最多6小时"),
                       ("Never present a proposal or plan as approved or done", "不得把建议或计划写成已获批准或已经执行")],
                pet=[(0.0, (640, 640)), ("one", (562, 832)), ("hrs", (900, 832))]),
    "f03": dict(title="The environment", sub="Harbor builds one Docker container for this run",
                files_at="kinds", out_at="out",
                pet=[(0.0, (700, 380)), ("kinds", (760, 836)), ("out", (900, 836))]),
    "f04": dict(title="The environment", sub="What the agent can and cannot see",
                pet=[(0.0, (900, 836)), ("lock", (1310, 692))]),
    "f09": dict(rq="REQUEST 4 / 28", sub="One response, four tool calls", c_one="one", c_n="four", c_back="back",
                trace=(24.1, 27.2), tk=[("one", 24.1), ("four", 24.9), (("four", 2.2), 27.2)],
                lanes=[dict(step=9, cmd='head -5 ".../16_中后台估值底稿_20260731.csv"', file="16 估值底稿", t0=25.1, t1=27.2),
                       dict(step=10, cmd='head -5 ".../17_对手方估值单_20260731.csv"', file="17 对手方估值", t0=25.9, t1=27.2),
                       dict(step=11, cmd='head -5 ".../15_套期指定与再平衡台账_20260731.csv"', file="15 套期台账", t0=26.4, t1=27.2),
                       dict(step=12, cmd='head -5 ".../24_境外子公司汇率来源核对单…csv"', file="24 汇率来源", t0=26.8, t1=27.2)],
                merge="4 results go back together with request 5",
                foot="steps 9–12 · started +25.1 to +26.8 s · all finished by +27.2 s",
                pet=[("one", (597, 432)), ("four", (1060, 630)), ("back", (1060, 702))]),
    "f11": dict(rq="REQUESTS 6–12", sub="Reading the sources", count_at="count",
                tk=[("seq", 36.6), (("count", 0.2), 73.1)],
                pet=[("seq", (760, 610)), ("count", (1300, 790))]),
    "f14": dict(rq="REQUEST 15 / 28", sub="Four rows come back; two of them matter here",
                points=[("06-29", -1162561.22, None), ("06-30", -1277351.45, "a"), ("07-01", -1109140.00, None), ("07-31", -4395835.74, "b")],
                delta="−3,118,484.29", delta_at="d",
                foot="data retrieval only · the accounting judgment comes later",
                pet=[("a", (787, 520)), ("b", (1063, 780)), ("d", (1200, 650))]),
    "f17": dict(rq="REQUEST 19 / 28", sub="The crash came before the save",
                flow=[("load", "workbook", "ok"), ("Sheet 1", "printed", "print"), ("Sheet 2", "printed", "print"),
                      ("line 212", "NameError", "fail"), ("save", "never ran", "never")],
                sheets=[("套期关系指定", "3 rows"), ("有效性评估", "21 rows")],
                foot="printed progress lines are not a save receipt",
                pet=[("crash", (1100, 466)), ("none", (1325, 540)), ("rows", (720, 730))]),
    "f18": dict(rq="REQUESTS 20–22", sub="Two more sheets, then the Word report",
                reqs=[("REQUEST 20 · step 47", "Enrich sheet 3", "Sheet 3 enhanced · All enhancements saved", "s34"),
                      ("REQUEST 21 · step 49", "Enrich sheet 4", "Sheet 4 enhanced · All enhancements saved", ("s34", 0.6)),
                      ("REQUEST 22 · step 51", "Write the report with python-docx", "9,601 output tokens · report saved", "doc")],
                doc_at="doc", sec_at="sec",
                sections=[("3.1 D01", "reject · replace", "借：公允价值变动损益 3,118,484.29"),
                          ("3.2 D02", "accept · provisional", "relabelled: 净投资套期储备"),
                          ("3.3 D03", "reject", "no July entry"),
                          ("3.4 D04", "accept · corrected", "rate 0.898513 · 9,997.00 to CTA"),
                          ("3.5 D05", "reject", "rehearsal only · 6,000,000.00"),
                          ("3.6 D06", "reject", "no July entry")],
                foot="the agent's recommendations · each still needs approval",
                pet=[("s34", (682, 650)), ("doc", (1100, 736)), ("sec", (1250, 736))]),
    "f23": dict(title="The whole run", sub="28 requests · 54 tool calls · 414.7 s",
                phases_=[(0, 104, "read & plan"), (106, 121, "evidence"), (147, 272, "workbook"), (275, 338, "report"), (341, 415, "check & repair")],
                marks=[(239.9, "NameError", "fail", "calls"), (378.3, "gap named", "warn", "nofile"), (393.6, "saved", "pass", "nofile")],
                counts=[("Bash", 50, "sandbox"), ("TodoWrite", 4, "harness"), ("Read", 0, "dim"), ("Edit", 0, "dim"), ("Write", 0, "dim")],
                count_at="calls", foot="dots stack when one response carries several tool calls",
                pet=[(0.0, (960, 640)), ("calls", (594, 762)), ("nofile", (1050, 762))]),
    "f24": dict(title="What the model sees", sub="Prompt tokens of each of the 28 requests",
                grow_at="grow", end_at="end",
                note="Each request carries the conversation so far: the task, the model's earlier replies and every tool result.",
                foot="input + cached tokens of each request · from the Claude Code session log",
                pet=[("grow", (1484, 425)), ("end", (1484, 425))]),
    "f25": dict(sub="Harbor ends the agent phase and starts scoring",
                pet=[("stop", (712, 520)), ("tests", (1240, 640)), ("score", (1150, 806))]),
    "f26": dict(pet=[(0.0, (960, 594))]),
    "f27": dict(sub="One judge session per criterion", rk_at="rk", jm_at="jm", nf_at="nf",
                grid_note="25 graded criteria + red lines G1, G2",
                judge_note="a different model from the agent · 280 judge API requests",
                pet=[("rk", (900, 600)), ("jm", (800, 716)), ("nf", (700, 796))]),
    "f28": dict(sub="R11 · the swap's DV01",
                pet=[("num", (725, 504)), ("rc", (1190, 604)), ("src", (960, 732))]),
    "f29": dict(sub="D02 · red line G2 and criterion R51",
                pet=[("d02", (960, 504)), ("red", (900, 612)), ("half", (1000, 700))]),
    "f30": dict(sub="R19 · can the amounts be traced?",
                sheets=["套期关系指定", "有效性评估", "折算与储备", "调整分录", "复核排程"],
                pet=[("zero", (1240, 660)), ("static", (900, 776))]),
    "f31": dict(sub="27 criteria · each judged on its own",
                labels=[("Positive criteria · 20", "pos", "3 met · 6 partly · 11 not met"),
                        ("Penalties · 5", "pen", "none triggered"),
                        ("Red lines · 2", "red", "both clear")],
                foot="partial credit shown as a fill · weights differ between criteria",
                pet=[("pos", (700, 470)), ("pen", (700, 600)), ("red", (700, 700))]),
    "f32": dict(value="0.333", formula="57.25 / 172 = 0.332849",
                line1="qwen3.7-max  +  Claude Code 2.1.114  ·  FIN-T1-003",
                line2="28 model requests · 54 tool calls · 414.7 s agent run",
                line3="judge deepseek-v4.1-flash · 27 criterion sessions",
                note="One pilot run's rubric score — not accuracy, not a ranking.",
                note2="the oracle reference solution scored 1.000 on this rubric in a separate run",
                pet=[("rw", (560, 600)), ("pilot", (690, 712))]),
    "f33": dict(pet=[(0.0, (560, 600)), ("site", (690, 594))]),
}

for _s in SHOTS:
    if _s["id"] in PAY2:
        _s.update(PAY2[_s["id"]])


def _st(fn):
    return fn


def _f10(ctx, sh, t, st):
    import gfx as G
    st["plan_reveal"] = G.seg(t, sh.cue("items") - 0.4, sh.cue("items") + 1.8)
    st["plan_hi"] = G.fade_io(t, sh.cue("tw"), sh.dur, 0.4)


def _f12(ctx, sh, t, st):
    import gfx as G
    st["self_tag"] = G.ease(G.seg(t, sh.cue("own"), sh.cue("own") + 0.5))
    k = G.fade_io(t, sh.cue("tw") + 0.2, sh.cue("own") + 0.6, 0.3)
    st["plan_flash"] = {j: k for j in range(1, 7)}
    st["plan_hi"] = k


def _out(name, kind="xlsx"):
    def f(ctx, sh, t, st):
        import gfx as G
        st["out_hi"] = G.ease(G.seg(t, sh.cue(name), sh.cue(name) + 0.5))
        st["out_kind"] = kind
    return f


def _found(name, label):
    def f(ctx, sh, t, st):
        import gfx as G
        st["found_hi"] = G.fade_io(t, sh.cue(name), sh.dur, 0.4)
        st["found_label"] = label
    return f


def _f22(ctx, sh, t, st):
    import gfx as G
    st["ledger_hi"] = {"req": G.fade_io(t, sh.cue("tot"), sh.dur, 0.3)}


STATE = {"f10": _f10, "f12": _f12, "f15": _out("s3"), "f17": _out("rows"), "f19": _out("three"),
         "f21": _out("rows"), "f22": _f22, "f07": _found("reg", "pending entries"),
         "f14": _found("d", "swap · July change"), "f18": _out("doc", "docx")}
