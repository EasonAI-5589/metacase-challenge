"""Render a run to MP4: parallel frame workers -> H.264 segments -> concat + narration mix.

usage: python engine/render.py fin [--workers 8] [--crf 17]
outputs: build/<run>/<run>.mp4, narration.wav, captions.{en,zh,bilingual}.srt, poster.jpg
"""
from __future__ import annotations

import argparse
import multiprocessing as mp
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

COLOR = ["-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv"]


def encoder(path, crf, pix):
    return subprocess.Popen(
        ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", pix, "-s", "1920x1080", "-r", "30", "-i", "-",
         "-vf", "scale=out_color_matrix=bt709:out_range=tv:flags=lanczos,format=yuv420p",
         "-c:v", "libx264", "-preset", "medium", "-crf", str(crf), "-profile:v", "high", "-threads", "2",
         "-x264-params", "keyint=60:min-keyint=30:scenecut=0", *COLOR, path],
        stdin=subprocess.PIPE)


def work(args):
    run, idx, f0, f1, out, crf = args
    import skia
    import compose
    ctx = compose.Ctx(run)
    surf = skia.Surface(1920, 1080)
    cv = surf.getCanvas()
    ct = surf.imageInfo().colorType()
    pix = "bgra" if ct == skia.kBGRA_8888_ColorType else "rgba"
    enc = encoder(out, crf, pix)
    t0 = time.time()
    for i in range(f0, f1):
        compose.frame(cv, ctx, i / 30.0)
        enc.stdin.write(surf.makeImageSnapshot().tobytes())
    enc.stdin.close()
    enc.wait()
    return idx, f1 - f0, time.time() - t0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--crf", type=int, default=17)
    a = ap.parse_args()
    import compose
    ctx = compose.Ctx(a.run)
    tl = ctx.tl
    outdir = os.path.join(ROOT, "build", a.run)
    segdir = os.path.join(outdir, "segments")
    os.makedirs(segdir, exist_ok=True)
    n = tl.nframes
    k = a.workers * 3
    bounds = [round(n * i / k) for i in range(k + 1)]
    jobs = [(a.run, i, bounds[i], bounds[i + 1], os.path.join(segdir, f"seg_{i:03d}.mp4"), a.crf) for i in range(k)]
    t0 = time.time()
    with mp.get_context("spawn").Pool(a.workers) as pool:
        for idx, nf, dt in pool.imap_unordered(work, jobs):
            print(f"segment {idx:03d}: {nf} frames in {dt:.1f}s", flush=True)
    print(f"frames rendered in {time.time() - t0:.1f}s")
    lst = os.path.join(segdir, "list.txt")
    with open(lst, "w") as f:
        for j in jobs:
            f.write(f"file '{j[4]}'\n")
    wav = tl.mix(os.path.join(outdir, "narration.wav"))
    out = os.path.join(outdir, f"{a.run}.mp4")
    subprocess.check_call(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-i", wav,
                           "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "144k", "-ar", "48000",
                           "-ac", "1", *COLOR, "-movflags", "+faststart", out])
    tl.write_srt(os.path.join(outdir, "captions"))
    print("wrote", out, f"{tl.duration:.3f}s", n, "frames")


if __name__ == "__main__":
    main()
