"""Skia drawing primitives shared by every scene (1920x1080, PR #27 palette)."""
from __future__ import annotations

import math
from functools import lru_cache

import skia

from fonts import collection, families

W, H = 1920, 1080

# PR #27 palette (task0001/index.html CSS variables)
PAGE = (5, 7, 10)
WIN = (11, 16, 23)
PANEL = (16, 22, 31)
EDGE = (34, 43, 57)
FG = (219, 225, 234)
WHITE = (255, 255, 255)
DIM = (127, 136, 153)
FAINT = (54, 64, 82)
BRAND = (143, 173, 214)
BRAND_TINT = (28, 39, 56)
MODEL = (240, 146, 95)
HARNESS = (185, 164, 247)
SANDBOX = (115, 213, 156)
SCORER = (143, 173, 214)
PASS = (115, 213, 156)
FAIL = (242, 119, 122)
WARN = (236, 190, 104)
INK = (8, 11, 16)

ROLE = {"model": MODEL, "harness": HARNESS, "sandbox": SANDBOX, "scorer": SCORER,
        "pass": PASS, "fail": FAIL, "warn": WARN, "brand": BRAND, "dim": DIM, "fg": FG}

FILE_COLORS = {"docx": (91, 141, 239), "xlsx": (63, 179, 127), "csv": (120, 170, 160),
               "pdf": (229, 83, 75), "html": (232, 150, 80), "log": (140, 150, 165),
               "py": (240, 200, 90)}


# ----------------------------------------------------------------------------- math
def clamp(x, a=0.0, b=1.0):
    return a if x < a else b if x > b else x


def seg(t, a, b):
    """0..1 progress of t across [a, b]."""
    if b <= a:
        return 1.0 if t >= a else 0.0
    return clamp((t - a) / (b - a))


def ease(x):
    x = clamp(x)
    return x * x * (3 - 2 * x)


def ease_out(x):
    x = clamp(x)
    return 1 - (1 - x) ** 3


def ease_in_out(x):
    x = clamp(x)
    return 4 * x ** 3 if x < 0.5 else 1 - (-2 * x + 2) ** 3 / 2


def back_out(x, s=1.4):
    x = clamp(x)
    return 1 + (s + 1) * (x - 1) ** 3 + s * (x - 1) ** 2


def lerp(a, b, t):
    return a + (b - a) * t


def mix(c1, c2, t):
    t = clamp(t)
    return tuple(int(round(lerp(a, b, t))) for a, b in zip(c1[:3], c2[:3]))


def fade_io(t, t0, t1, d=0.3):
    """Visible between t0 and t1 with d-second fades."""
    return ease(seg(t, t0, t0 + d)) * (1 - ease(seg(t, t1 - d, t1)))


# ----------------------------------------------------------------------------- paint
def color(c, a=1.0):
    a = clamp(a)
    return skia.Color(int(c[0]), int(c[1]), int(c[2]), int(round(255 * a)))


def paint(c, a=1.0, stroke=None, aa=True, cap=None, join=None, dash=None, blur=None):
    p = skia.Paint(AntiAlias=aa, Color=color(c, a))
    if stroke is not None:
        p.setStyle(skia.Paint.kStroke_Style)
        p.setStrokeWidth(stroke)
        p.setStrokeCap(cap or skia.Paint.kRound_Cap)
        p.setStrokeJoin(join or skia.Paint.kRound_Join)
    if dash:
        p.setPathEffect(skia.DashPathEffect.Make(list(dash), 0))
    if blur:
        p.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, blur))
    return p


def rrect(cv, x, y, w, h, r=10, fill=None, stroke=None, sw=1.5, a=1.0, fa=None, dash=None):
    if a <= 0.003 or w <= 0 or h <= 0:
        return
    rect = skia.RRect.MakeRectXY(skia.Rect.MakeXYWH(x, y, w, h), r, r)
    if fill is not None:
        cv.drawRRect(rect, paint(fill, a if fa is None else fa * a))
    if stroke is not None:
        inset = skia.RRect.MakeRectXY(skia.Rect.MakeXYWH(x + sw / 2, y + sw / 2, w - sw, h - sw),
                                      max(0, r - sw / 2), max(0, r - sw / 2))
        cv.drawRRect(inset, paint(stroke, a, stroke=sw, dash=dash))


def glow(cv, x, y, w, h, r, c, a=0.5, sigma=16, spread=0):
    if a <= 0.003:
        return
    rect = skia.RRect.MakeRectXY(skia.Rect.MakeXYWH(x - spread, y - spread, w + 2 * spread, h + 2 * spread), r, r)
    cv.drawRRect(rect, paint(c, a, blur=sigma))


def circle(cv, cx, cy, r, fill=None, stroke=None, sw=1.5, a=1.0):
    if a <= 0.003:
        return
    if fill is not None:
        cv.drawCircle(cx, cy, r, paint(fill, a))
    if stroke is not None:
        cv.drawCircle(cx, cy, r, paint(stroke, a, stroke=sw))


def line(cv, pts, c, sw=2, a=1.0, dash=None, cap=None):
    if a <= 0.003 or len(pts) < 2:
        return
    path = skia.Path()
    path.moveTo(*pts[0])
    for p in pts[1:]:
        path.lineTo(*p)
    cv.drawPath(path, paint(c, a, stroke=sw, dash=dash, cap=cap))


def poly(cv, pts, c, a=1.0):
    if a <= 0.003:
        return
    path = skia.Path()
    path.moveTo(*pts[0])
    for p in pts[1:]:
        path.lineTo(*p)
    path.close()
    cv.drawPath(path, paint(c, a))


def arrow_head(cv, x, y, ang, c, size=9, a=1.0):
    pts = [(x, y),
           (x - size * math.cos(ang - 0.5), y - size * math.sin(ang - 0.5)),
           (x - size * math.cos(ang + 0.5), y - size * math.sin(ang + 0.5))]
    poly(cv, pts, c, a)


def rounded_path(points, radius=14):
    """Polyline with rounded corners (for routes)."""
    path = skia.Path()
    path.moveTo(*points[0])
    for i in range(1, len(points) - 1):
        p0, p1, p2 = points[i - 1], points[i], points[i + 1]
        path.arcTo(p1[0], p1[1], p2[0], p2[1], radius)
    path.lineTo(*points[-1])
    return path


def path_point(path, frac):
    """Point and tangent angle at fraction of a path's length."""
    meas = skia.PathMeasure(path, False)
    L = meas.getLength()
    pos, tan = meas.getPosTan(clamp(frac) * L)
    return (pos.x(), pos.y()), math.atan2(tan.y(), tan.x())


def draw_path(cv, path, c, sw=2, a=1.0, dash=None, upto=1.0):
    if a <= 0.003 or upto <= 0:
        return
    if upto < 0.999:
        meas = skia.PathMeasure(path, False)
        L = meas.getLength()
        part = skia.Path()
        meas.getSegment(0, L * clamp(upto), part, True)
        path = part
    cv.drawPath(path, paint(c, a, stroke=sw, dash=dash))


def packet(cv, x, y, c, a=1.0, r=7):
    glow(cv, x - r, y - r, 2 * r, 2 * r, r, c, a=0.55 * a, sigma=8)
    circle(cv, x, y, r, fill=c, a=a)
    circle(cv, x, y, r * 0.45, fill=WHITE, a=0.85 * a)


# ----------------------------------------------------------------------------- text
_PARAS: dict = {}


def _build(text, size, col, weight, kind, width, align, ls):
    ps = skia.textlayout.ParagraphStyle()
    if align == "center":
        ps.setTextAlign(skia.textlayout.TextAlign.kCenter)
    elif align == "right":
        ps.setTextAlign(skia.textlayout.TextAlign.kRight)
    ts = skia.textlayout.TextStyle()
    ts.setFontFamilies(families(kind, weight))
    ts.setFontSize(size)
    ts.setForegroundPaint(skia.Paint(AntiAlias=True, Color=color(col)))
    if ls:
        ts.setLetterSpacing(ls)
    ps.setTextStyle(ts)
    b = skia.textlayout.ParagraphBuilder(ps, collection(), skia.Unicode())
    b.pushStyle(ts)
    b.addText(text)
    p = b.Build()
    p.layout(width)
    return p


@lru_cache(maxsize=256)
def line_height(size, weight, kind):
    return _build("Ag", size, FG, weight, kind, 4000.0, "left", 0.0).Height


def _para(text, size, col, weight, kind, width, align, ls, lh, maxlines):
    key = (text, size, col, weight, kind, width, align, ls, maxlines)
    p = _PARAS.get(key)
    if p is not None:
        return p
    if len(_PARAS) > 6000:
        _PARAS.clear()
    p = _build(text, size, col, weight, kind, width, align, ls)
    if maxlines:
        limit_h = maxlines * line_height(size, weight, kind) * 1.25 + 1
        limit_w = width if maxlines == 1 else None

        def too_big(q):
            if maxlines == 1:
                return q.LongestLine > width + 0.5 or q.Height > limit_h
            return q.Height > limit_h

        if too_big(p):
            lo, hi = 0, len(text)
            while lo < hi:
                mid = (lo + hi + 1) // 2
                q = _build(text[:mid].rstrip() + "…", size, col, weight, kind, width, align, ls)
                if too_big(q):
                    hi = mid - 1
                else:
                    lo = mid
            p = _build(text[:lo].rstrip() + "…", size, col, weight, kind, width, align, ls)
    _PARAS[key] = p
    return p


def text(cv, s, x, y, size=18, c=FG, weight=500, kind="sans", a=1.0, align="left",
         width=None, ls=0.0, lh=None, maxlines=None):
    """Draw text with its top at y. Returns (width, height).

    align with width=None anchors x at the left / centre / right of a single line.
    With width set, text wraps inside [x, x+width] and aligns within that box."""
    if not s:
        return 0.0, 0.0
    box = width if width is not None else 4000.0
    p = _para(s, size, tuple(c[:3]), weight, kind, box, "left" if width is None else align, ls, lh, maxlines)
    w = p.LongestLine if width is None else box
    h = p.Height
    dx = x
    if width is None and align == "center":
        dx = x - p.LongestLine / 2
    elif width is None and align == "right":
        dx = x - p.LongestLine
    if a > 0.003:
        if a < 0.997:
            cv.saveLayerAlpha(None, int(255 * clamp(a)))
            p.paint(cv, dx, y)
            cv.restore()
        else:
            p.paint(cv, dx, y)
    return (p.LongestLine if width is None else w), h


def measure(s, size=18, weight=500, kind="sans", ls=0.0, width=None):
    if not s:
        return 0.0, 0.0
    p = _para(s, size, FG, weight, kind, width or 4000.0, "left", ls, None, None)
    return (p.LongestLine if width is None else p.LongestLine), p.Height


def kicker(cv, s, x, y, c=DIM, a=1.0, size=15, align="left", weight=600):
    """Mono spaced label (PR #27 .kick)."""
    return text(cv, s, x, y, size=size, c=c, weight=weight, kind="mono", a=a, align=align, ls=1.8)


def typewriter(s, frac):
    n = int(round(len(s) * clamp(frac)))
    return s[:n]


def fmt_int(v):
    return f"{int(round(v)):,}"


# ----------------------------------------------------------------------------- icons
def icon_role(cv, kind, cx, cy, c, a=1.0, s=11):
    if kind == "model":  # diamond
        poly(cv, [(cx, cy - s), (cx + s, cy), (cx, cy + s), (cx - s, cy)], c, a)
    elif kind == "harness":  # hexagon outline + dot
        pts = [(cx + s * math.cos(math.pi / 3 * i + math.pi / 6), cy + s * math.sin(math.pi / 3 * i + math.pi / 6)) for i in range(6)]
        line(cv, pts + [pts[0]], c, sw=2.2, a=a)
        circle(cv, cx, cy, s * 0.32, fill=c, a=a)
    elif kind == "sandbox":  # square in square
        rrect(cv, cx - s, cy - s, 2 * s, 2 * s, 3, stroke=c, sw=2.2, a=a)
        rrect(cv, cx - s * 0.42, cy - s * 0.42, s * 0.84, s * 0.84, 1.5, fill=c, a=a)
    else:  # scorer target
        circle(cv, cx, cy, s, stroke=c, sw=2.2, a=a)
        circle(cv, cx, cy, s * 0.38, fill=c, a=a)


def icon_check(cv, cx, cy, c=PASS, a=1.0, s=9, sw=2.6, prog=1.0):
    pts = [(cx - s * 0.9, cy), (cx - s * 0.25, cy + s * 0.65), (cx + s, cy - s * 0.75)]
    path = skia.Path()
    path.moveTo(*pts[0]); path.lineTo(*pts[1]); path.lineTo(*pts[2])
    draw_path(cv, path, c, sw=sw, a=a, upto=prog)


def icon_cross(cv, cx, cy, c=FAIL, a=1.0, s=7, sw=2.6):
    line(cv, [(cx - s, cy - s), (cx + s, cy + s)], c, sw, a)
    line(cv, [(cx + s, cy - s), (cx - s, cy + s)], c, sw, a)


def icon_lock(cv, cx, cy, c=DIM, a=1.0, s=14, opened=0.0):
    rrect(cv, cx - s, cy - s * 0.15, 2 * s, s * 1.45, 4, fill=c, a=a)
    lift = s * 0.55 * clamp(opened)
    path = skia.Path()
    r = s * 0.62
    path.addArc(skia.Rect.MakeXYWH(cx - r, cy - s * 0.15 - r * 1.55 - lift, 2 * r, 2 * r * 1.15), 180, 180)
    cv.drawPath(path, paint(c, a, stroke=s * 0.26))
    line(cv, [(cx - r, cy - s * 0.15 - r * 0.45 - lift), (cx - r, cy - s * 0.12 - lift * (1 if opened > 0 else 0))], c, s * 0.26, a)
    line(cv, [(cx + r, cy - s * 0.15 - r * 0.45 - lift), (cx + r, cy - s * 0.12)], c, s * 0.26, a)
    circle(cv, cx, cy + s * 0.5, s * 0.18, fill=INK, a=a)


def icon_file(cv, x, y, kind, a=1.0, w=34, h=42, label=True):
    c = FILE_COLORS.get(kind, DIM)
    fold = w * 0.32
    path = skia.Path()
    path.moveTo(x, y + 4)
    path.quadTo(x, y, x + 4, y)
    path.lineTo(x + w - fold, y)
    path.lineTo(x + w, y + fold)
    path.lineTo(x + w, y + h - 4)
    path.quadTo(x + w, y + h, x + w - 4, y + h)
    path.lineTo(x + 4, y + h)
    path.quadTo(x, y + h, x, y + h - 4)
    path.close()
    cv.drawPath(path, paint(mix(c, PANEL, 0.72), a))
    cv.drawPath(path, paint(c, a, stroke=1.6))
    poly(cv, [(x + w - fold, y), (x + w, y + fold), (x + w - fold, y + fold)], c, a * 0.8)
    if label:
        text(cv, kind.upper(), x + w / 2, y + h * 0.52, size=max(9, w * 0.27), c=c, weight=700, kind="mono", a=a, align="center")


def icon_folder(cv, x, y, w=30, h=22, c=DIM, a=1.0):
    rrect(cv, x, y + 4, w, h - 4, 3, fill=mix(c, PANEL, 0.6), stroke=c, sw=1.5, a=a)
    rrect(cv, x, y, w * 0.45, 7, 2, fill=c, a=a)


def stamp(cv, s, cx, cy, c, a=1.0, size=30, rot=-8.0, scale=1.0):
    if a <= 0.003:
        return
    cv.save()
    cv.translate(cx, cy)
    cv.rotate(rot)
    cv.scale(scale, scale)
    tw, th = measure(s, size, 800, "sans", ls=4)
    rrect(cv, -tw / 2 - 18, -th / 2 - 8, tw + 36, th + 16, 8, fill=INK, stroke=c, sw=3.5, a=a, fa=0.75)
    text(cv, s, 0, -th / 2, size=size, c=c, weight=800, a=a, align="center", ls=4)
    cv.restore()


# ----------------------------------------------------------------------------- guide
# Pixel guide in the spirit of the PR #27 replay (peach body, sleepy eyes, pointer stick).
PET_OUT = (122, 74, 56)
PET_BODY = (242, 178, 138)
PET_LIGHT = (250, 204, 168)
PET_SHADE = (220, 144, 110)
PET_EYE = (86, 52, 40)
STICK = (226, 196, 158)

_BODY_ROWS = [  # (row, col0, col1) inclusive, body silhouette
    (1, 3, 5), (1, 10, 12),
    (2, 2, 13), (3, 1, 14), (4, 1, 14), (5, 1, 14), (6, 1, 14), (7, 2, 13),
]


def pet(cv, x, y, u=6.0, t=0.0, walking=False, a=1.0, blink=False, hand=None):
    """Draw the guide with its feet at (x, y). Returns the hand position."""
    if a <= 0.003:
        return (x, y)
    gw = 16
    ox = x - gw * u / 2
    bob = 0.0
    step = 0
    if walking:
        step = int(t * 8) % 2
        bob = -u * 0.35 * (1 if step else 0)
    else:
        bob = -u * 0.15 * (1 + math.sin(t * 2.4)) / 2
    oy = y - 10 * u + bob

    def cell(r, c0, c1, col, alpha=1.0, dy=0.0, h=1.0):
        rrect(cv, ox + c0 * u, oy + (r + dy) * u, (c1 - c0 + 1) * u, h * u, 0, fill=col, a=a * alpha)

    # outline (draw silhouette expanded)
    for r, c0, c1 in _BODY_ROWS:
        rrect(cv, ox + (c0 - 0.5) * u, oy + (r - 0.5) * u, (c1 - c0 + 2) * u, 2 * u, 0, fill=PET_OUT, a=a)
    # legs (alternate when walking)
    legs = [(3, 4), (7, 8), (11, 12)]
    for i, (c0, c1) in enumerate(legs):
        lift = (0.6 if (i % 2 == step) and walking else 0.0)
        rrect(cv, ox + (c0 - 0.5) * u, oy + (7.5 - lift) * u, (c1 - c0 + 2) * u, 2.5 * u, 0, fill=PET_OUT, a=a)
        cell(8 - lift, c0, c1, PET_SHADE, h=1.5)
    # arms
    rrect(cv, ox + (-1.5) * u, oy + 3.5 * u, 2 * u, 2 * u, 0, fill=PET_OUT, a=a)
    cell(4, -1, -1, PET_BODY)
    rrect(cv, ox + 14.5 * u, oy + 3.5 * u, 2 * u, 2 * u, 0, fill=PET_OUT, a=a)
    cell(4, 15, 15, PET_BODY)
    # body fill
    for r, c0, c1 in _BODY_ROWS:
        col = PET_LIGHT if r <= 2 else (PET_SHADE if r >= 7 else PET_BODY)
        cell(r, c0, c1, col)
    cell(6, 1, 14, PET_SHADE, alpha=0.55)
    # eyes
    if blink:
        cell(4, 4, 5, PET_EYE, dy=0.35, h=0.3)
        cell(4, 10, 11, PET_EYE, dy=0.35, h=0.3)
    else:
        cell(4, 4, 5, PET_EYE, dy=0.15, h=0.55)
        cell(4, 10, 11, PET_EYE, dy=0.15, h=0.55)
    # mouth
    cell(5, 7, 7, PET_OUT, dy=0.2, h=0.8)
    cell(5, 8, 8, PET_OUT, dy=0.2, h=0.8)
    cell(5, 7, 8, PET_OUT, dy=0.75, h=0.35)
    return (ox + 15.5 * u, oy + 4.5 * u)


def pointer(cv, hand, tip, a=1.0, prog=1.0):
    if a <= 0.003 or prog <= 0:
        return
    hx, hy = hand
    tx, ty = lerp(hx, tip[0], prog), lerp(hy, tip[1], prog)
    line(cv, [(hx, hy), (tx, ty)], PET_OUT, sw=6.5, a=a)
    line(cv, [(hx, hy), (tx, ty)], STICK, sw=3.8, a=a)
    circle(cv, tx, ty, 6.5, stroke=STICK, sw=2.4, a=a)
    circle(cv, tx, ty, 2.2, fill=STICK, a=a)
