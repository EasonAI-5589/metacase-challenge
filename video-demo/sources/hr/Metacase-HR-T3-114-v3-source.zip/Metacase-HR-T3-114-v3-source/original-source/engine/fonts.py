"""Font setup for the offline Skia renderer.

Inter (OFL) is shipped with the website as a variable woff2; static weight
instances are generated once into ../fonts/. SF Mono and PingFang SC are the
macOS system fonts the approved PR #27 replay was captured with; they are read
in place and never copied.
"""
from __future__ import annotations

import os
from functools import lru_cache

import skia

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.normpath(os.path.join(HERE, "..", "fonts"))
INTER_SRC = os.path.join(FONT_DIR, "inter-latin.woff2")
SF_MONO = "/System/Library/Fonts/SFNSMono.ttf"
INTER_WEIGHTS = (400, 500, 600, 700, 800)
MONO_WEIGHTS = (400, 500, 600, 700)


def _inter_path(w: int) -> str:
    return os.path.join(FONT_DIR, f"Inter-{w}.ttf")


def build_static_inter() -> None:
    missing = [w for w in INTER_WEIGHTS if not os.path.exists(_inter_path(w))]
    if not missing:
        return
    from fontTools.ttLib import TTFont
    from fontTools.varLib import instancer

    for w in missing:
        f = TTFont(INTER_SRC)
        f.flavor = None
        inst = instancer.instantiateVariableFont(f, {"wght": w})
        inst.save(_inter_path(w))


def _mono_typeface(weight: int) -> skia.Typeface:
    base = skia.Typeface.MakeFromFile(SF_MONO)
    if base is None:
        return skia.FontMgr().matchFamilyStyle("Menlo", skia.FontStyle.Normal())
    try:
        tag = (ord("w") << 24) | (ord("g") << 16) | (ord("h") << 8) | ord("t")
        coord = skia.FontArguments.VariationPosition.Coordinate(tag, float(weight))
        coords = skia.FontArguments.VariationPosition.Coordinates([coord])
        pos = skia.FontArguments.VariationPosition(coords)
        args = skia.FontArguments()
        args.setVariationDesignPosition(pos)
        clone = base.makeClone(args)
        return clone or base
    except Exception:
        return base


CJK_WEIGHTS = (400, 500, 600)


@lru_cache(maxsize=1)
def provider() -> skia.textlayout.TypefaceFontProvider:
    build_static_inter()
    prov = skia.textlayout.TypefaceFontProvider()
    for w in INTER_WEIGHTS:
        prov.registerTypeface(skia.Typeface.MakeFromFile(_inter_path(w)), f"Inter{w}")
    for w in MONO_WEIGHTS:
        prov.registerTypeface(_mono_typeface(w), f"Mono{w}")
    system = skia.FontMgr()
    for w in CJK_WEIGHTS:
        style = skia.FontStyle(w, skia.FontStyle.kNormal_Width, skia.FontStyle.kUpright_Slant)
        tf = system.matchFamilyStyle("PingFang SC", style)
        prov.registerTypeface(tf, f"CJK{w}")
    # Symbols that neither Inter nor PingFang carry (arrows, check marks).
    sym = system.matchFamilyStyle("Apple Symbols", skia.FontStyle.Normal())
    if sym is not None:
        prov.registerTypeface(sym, "Sym")
    serif = system.matchFamilyStyle("Georgia", skia.FontStyle.Normal())
    if serif is not None:  # the PR #27 logo mark is a Georgia "N"
        prov.registerTypeface(serif, "Serif")
    return prov


@lru_cache(maxsize=1)
def collection() -> skia.textlayout.FontCollection:
    fc = skia.textlayout.FontCollection()
    fc.setDefaultFontManager(provider())
    return fc


def families(kind: str, weight: int) -> list[str]:
    cjk = min(CJK_WEIGHTS, key=lambda x: abs(x - weight))
    if kind == "serif":
        return ["Serif", f"CJK{cjk}"]
    if kind == "mono":
        w = min(MONO_WEIGHTS, key=lambda x: abs(x - weight))
        return [f"Mono{w}", f"CJK{cjk}", "Sym"]
    w = min(INTER_WEIGHTS, key=lambda x: abs(x - weight))
    return [f"Inter{w}", f"CJK{cjk}", "Sym"]
