"""Assemble the delivery set for one run: MP4, poster, captions, provenance, README.

usage: python engine/package.py fin|hr
writes deliver/assets/video/<name>.mp4|-poster.jpg and deliver/docs/video/<doc>/...
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import compose  # noqa: E402
import rundata  # noqa: E402
from timeline import FPS  # noqa: E402

NAMES = {"fin": ("finance-story-demo", "finance"), "hr": ("hr-agent-replay", "hr")}
POSTER = {"fin": ("f09", ("back", 1.2)), "hr": ("h13", ("amt", 1.0))}
CHAPTERS = ["TASK", "AGENT", "HARNESS", "CHECK", "RESULT"]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def probe(path):
    out = subprocess.check_output(["ffprobe", "-v", "error", "-show_entries",
                                   "stream=codec_type,codec_name,profile,width,height,pix_fmt,color_space,color_primaries,color_transfer,color_range,r_frame_rate,nb_frames,sample_rate,channels:format=duration,size",
                                   "-of", "json", path])
    return json.loads(out)


def main(run):
    ctx = compose.Ctx(run)
    tl = ctx.tl
    name, doc = NAMES[run]
    build = os.path.join(ROOT, "build", run)
    out_v = os.path.join(ROOT, "deliver", "assets", "video")
    out_d = os.path.join(ROOT, "deliver", "docs", "video", doc)
    os.makedirs(out_v, exist_ok=True)
    os.makedirs(out_d, exist_ok=True)
    mp4 = os.path.join(out_v, f"{name}.mp4")
    shutil.copyfile(os.path.join(build, f"{run}.mp4"), mp4)
    sid, c = POSTER[run]
    sh = next(s for s in tl.shots if s.id == sid)
    png = os.path.join(build, "poster.png")
    compose.render_still(ctx, sh.start + sh.cue(c), png)
    poster = os.path.join(out_v, f"{name}-poster.jpg")
    subprocess.check_call(["ffmpeg", "-v", "error", "-y", "-i", png, "-q:v", "2", poster])
    for lang in ("en", "zh", "bilingual"):
        shutil.copyfile(os.path.join(build, f"captions.{lang}.srt"), os.path.join(out_d, f"captions.{lang}.srt"))
    run_data = rundata.load(run)
    data_path, log_glob = rundata.SOURCES[run]
    import glob
    log = glob.glob(log_glob)[0]
    src_files = sorted(os.path.join(dp, f) for dp, _, fs in os.walk(os.path.join(ROOT, "engine")) for f in fs if f.endswith(".py"))
    src_files += [os.path.join(ROOT, "story", f"{run}.py")]
    p = probe(mp4)
    chapters = []
    for i, (a, b) in enumerate(tl.chapters):
        chapters.append({"name": CHAPTERS[i], "start_seconds": round(a, 3), "end_seconds": round(b, 3)})
    shots = [{"id": s.id, "chapter": CHAPTERS[s.ch], "kind": s.kind, "start_seconds": round(s.start, 3),
              "end_seconds": round(s.end, 3), "narration_en": s.en, "caption_zh": s.zh,
              "trace_seconds": s.d.get("trace")} for s in tl.shots]
    prov = {
        "version": "sufe-claude-relay-v1",
        "task_id": ctx.conf["task_id"],
        "run": run,
        "status": "awaiting user review",
        "model": "qwen3.7-max", "harness": "Claude Code 2.1.114", "runner": "Harbor 0.20.0",
        "judge_model": ctx.conf["chips"][3][1],
        "recorded_agent_seconds": run_data.duration,
        "model_requests": len(run_data.requests), "tool_calls": len(run_data.tool_steps),
        "reward": run_data.result["reward"],
        "duration_seconds": round(float(p["format"]["duration"]), 3),
        "frames": tl.nframes, "fps": f"{FPS}/1", "resolution": [1920, 1080],
        "streams": p["streams"],
        "voice": "en-US-AriaNeural (same voice as the approved PR #27 replay), rate +12% to match its 1.12 pacing",
        "audio_is_synthetic": True,
        "audio_processing": "per-shot neural TTS clips placed on the shot timeline, loudnorm I=-16.5 LUFS, AAC 48 kHz mono",
        "burned_captions": ["en", "zh"],
        "renderer": "offline Skia (skia-python) frame renderer; no browser, no CDP; H.264 High via libx264",
        "chapters": chapters,
        "shots": shots,
        "files": {
            f"assets/video/{name}.mp4": {"bytes": os.path.getsize(mp4), "sha256": sha(mp4)},
            f"assets/video/{name}-poster.jpg": {"bytes": os.path.getsize(poster), "sha256": sha(poster)},
            **{f"docs/video/{doc}/captions.{l}.srt": {"bytes": os.path.getsize(os.path.join(out_d, f"captions.{l}.srt")),
                                                      "sha256": sha(os.path.join(out_d, f"captions.{l}.srt"))}
               for l in ("en", "zh", "bilingual")},
        },
        "sources": {
            "run_export": {"path": data_path, "sha256": sha(data_path)},
            "session_log": {"path": log, "sha256": sha(log)},
            "facts_audit": f"/Users/user/Documents/ChatGPT/InferenceNet/research/sufe-video-alignment-20261018/{'finance' if run == 'fin' else 'hr'}-audit.md",
        },
        "editable_source": {
            "directory": ROOT,
            "files_sha256": {os.path.relpath(f, ROOT): sha(f) for f in src_files},
            "rebuild": [f"python engine/voice.py {run}", f"python engine/render.py {run}", f"python engine/package.py {run}"],
        },
        "boundaries": [
            "Editorial replay of an existing recorded pilot run; no new agent run, no re-scoring.",
            "Request numbers are the 28 assistant message ids of the Claude Code session log; tool steps are run-export indexes.",
            "Claude Code and Bash run inside the task's Docker container; the model is reached through an API.",
            "The rubric and tests are absent during the agent run; Harbor copies tests into the same container afterwards.",
            "Judge sessions are separate per criterion; scores never feed back into the recorded agent run.",
        ],
    }
    json.dump(prov, open(os.path.join(out_d, "provenance.json"), "w"), ensure_ascii=False, indent=1)
    print(json.dumps({"mp4": mp4, "duration": prov["duration_seconds"], "sha256": prov["files"][f"assets/video/{name}.mp4"]["sha256"],
                      "poster": poster}, indent=1))


if __name__ == "__main__":
    main(sys.argv[1])
