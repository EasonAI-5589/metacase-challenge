"""Recorded-run facts used by the replay: steps, the 28 model requests and state at a trace time.

Sources (read-only):
  video/data/{fin,hr}.json            curated run export (steps, task, deliverables, criteria)
  jobs/.../agent/sessions/.../*.jsonl Claude Code session log (assistant message ids = requests)
"""
from __future__ import annotations

import bisect
import datetime as dt
import glob
import json
import os
from functools import lru_cache

BASE = "/Users/user/Documents/ChatGPT/InferenceNet/research/benchmark-expansion-finance-hr-20261018"
SOURCES = {
    "fin": (f"{BASE}/video/data/fin.json",
            f"{BASE}/jobs/cc-qwen37max-fin-20261018-r2/FIN-T1-003__EUsH44A/agent/sessions/projects/-app/*.jsonl"),
    "hr": (f"{BASE}/video/data/hr.json",
           f"{BASE}/jobs/cc-qwen37max-hr-20261018/人力资源001__zedAv55/agent/sessions/projects/-app/*.jsonl"),
}

TOOL_KIND = {"Bash": "bash", "TodoWrite": "todo", "Write": "write", "Read": "read", "Edit": "edit"}


def _ts(s: str) -> float:
    return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


class Run:
    def __init__(self, key: str):
        self.key = key
        data_path, log_glob = SOURCES[key]
        self.data = json.load(open(data_path))
        self.task = self.data["task"]
        self.agent = self.data["agent"]
        self.steps = self.agent["steps"]
        self.duration = float(self.agent["session"]["duration_s"])
        self.criteria = self.data["judging"]["criteria"]
        self.result = self.data["judging"]["result"]
        self.materials = self.data["materials"]
        log = glob.glob(log_glob)[0]
        rows = [json.loads(l) for l in open(log) if l.strip()]
        t0 = _ts(next(r for r in rows if r.get("timestamp"))["timestamp"])
        order, info = [], {}
        tool_seq = []  # (request index, tool name, tool_use id) in log order
        for r in rows:
            if r.get("type") != "assistant":
                continue
            m = r["message"]
            mid = m["id"]
            if mid not in info:
                order.append(mid)
                info[mid] = {"t": _ts(r["timestamp"]) - t0, "out": 0, "ctx": 0, "tools": []}
            u = m.get("usage") or {}
            info[mid]["out"] = max(info[mid]["out"], u.get("output_tokens") or 0)
            ctx = (u.get("input_tokens") or 0) + (u.get("cache_read_input_tokens") or 0) + (u.get("cache_creation_input_tokens") or 0)
            info[mid]["ctx"] = max(info[mid]["ctx"], ctx)
            for c in m.get("content", []):
                if c.get("type") == "tool_use":
                    k = order.index(mid) + 1
                    info[mid]["tools"].append(c.get("name"))
                    tool_seq.append((k, c.get("name")))
        self.requests = [dict(k=i + 1, **info[mid]) for i, mid in enumerate(order)]
        # map tool steps (in order) to requests
        tsteps = [s for s in self.steps if s.get("tool")]
        assert len(tsteps) == len(tool_seq), (len(tsteps), len(tool_seq))
        for s, (k, name) in zip(tsteps, tool_seq):
            assert s["tool"] == name, (s["i"], s["tool"], name)
            s["req"] = k
        self.tool_steps = tsteps
        self._req_t = [r["t"] for r in self.requests]
        self._tool_t = [s["t_s"] for s in tsteps]

    # ---------------------------------------------------------------- state at trace time T
    def requests_done(self, T: float) -> int:
        return bisect.bisect_right(self._req_t, T + 1e-6)

    def tools_done(self, T: float) -> list[dict]:
        n = bisect.bisect_right(self._tool_t, T + 1e-6)
        return self.tool_steps[:n]

    def out_tokens(self, T: float) -> int:
        """Output tokens, spread over each response's generation window
        (first log row of the response -> its first tool call, or the next response)."""
        total = 0.0
        for i, r in enumerate(self.requests):
            t0 = r["t"]
            if T < t0:
                break
            calls = [s["t_s"] for s in self.tool_steps if s["req"] == r["k"]]
            t1 = calls[0] if calls else (self.requests[i + 1]["t"] if i + 1 < len(self.requests) else self.duration)
            frac = 1.0 if t1 <= t0 else min(1.0, (T - t0) / (t1 - t0))
            total += r["out"] * frac
        return int(round(total))

    def ctx_tokens(self, T: float) -> int:
        n = self.requests_done(T)
        return self.requests[n - 1]["ctx"] if n else 0

    def plan(self, T: float):
        todos = None
        for s in self.steps:
            if s.get("todos") and s["t_s"] <= T + 1e-6:
                todos = s["todos"]
        return todos

    def files_opened(self, T: float) -> list[str]:
        seen = []
        for s in self.steps:
            if s["t_s"] > T + 1e-6:
                break
            for f in s.get("files") or []:
                if f not in seen:
                    seen.append(f)
        return seen

    def step(self, i: int) -> dict:
        return self.steps[i]

    def crit(self, cid: str) -> dict:
        return next(c for c in self.criteria if c["id"] == cid)


@lru_cache(maxsize=2)
def load(key: str) -> Run:
    return Run(key)
