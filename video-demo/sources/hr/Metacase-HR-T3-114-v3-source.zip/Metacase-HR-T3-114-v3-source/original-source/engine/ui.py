"""Persistent UI shared by all shots: header, columns, chips row, loop frame, captions."""
from __future__ import annotations

import math

import skia

from gfx import *  # noqa: F401,F403
import gfx as G

CHAPTERS = ["TASK", "AGENT", "HARNESS", "CHECK", "RESULT"]

# column geometry (1080p)
LX, LW = 42, 394
CX, CW = 470, 980
RX, RW = 1484, 394
TOP, BOT = 108, 892
PANEL_Y = 210

CHIP_W, CHIP_H, CHIP_Y = 222, 66, 108
CHIP_X = [480 + i * 246 for i in range(4)]
CHIP_CX = [x + CHIP_W / 2 for x in CHIP_X]
TRACK_Y = 191

STAGE_Y, STAGE_H, STAGE_W = 332, 76, 206
STAGE_X = [502 + i * 236 for i in range(4)]
CARD_Y, CARD_H, CARD_W = 480, 228, 290
CARD_X = [502, 815, 1128]
PET_LANE = 874


def background(cv):
    cv.clear(G.color(G.PAGE))
    shader = skia.GradientShader.MakeRadial(
        skia.Point(960, 0), 1500,
        [G.color((17, 26, 38)), G.color(G.WIN), G.color((7, 10, 15))],
        [0.0, 0.58, 1.0])
    p = skia.Paint(Shader=shader)
    cv.drawRect(skia.Rect.MakeWH(G.W, G.H), p)


def header(cv, chap, prog, clock, a=1.0, note="RECORDED TRACE · GUIDED REPLAY"):
    G.rrect(cv, 0, 0, G.W, 84, 0, fill=(8, 11, 16), fa=0.62)
    G.line(cv, [(0, 84.5), (G.W, 84.5)], (24, 32, 44), sw=1)
    G.rrect(cv, 42, 22, 40, 40, 10, fill=(25, 25, 25), stroke=(58, 67, 82), sw=1.5)
    G.text(cv, "N", 62, 25, size=29, c=G.WHITE, kind="serif", align="center")
    w, _ = G.text(cv, "Inference", 98, 22, size=32, c=G.WHITE, weight=600, ls=-1.0)
    w2, _ = G.text(cv, "Net", 98 + w, 22, size=32, c=G.BRAND, weight=600, ls=-1.0)
    G.text(cv, "PROFESSIONAL TASKS", 98 + w + w2 + 16, 38, size=13, c=G.DIM, kind="mono", ls=2.4)
    for i, name in enumerate(CHAPTERS):
        cx = 652 + i * 154
        done = i < chap
        cur = i == chap
        col = G.WHITE if cur else ((178, 188, 202) if done else (92, 102, 120))
        nw, _ = G.measure(f"0{i + 1}", 14, 500, "mono")
        lw, _ = G.measure(name, 20, 600, "sans", ls=1.4)
        x0 = cx - (nw + 8 + lw) / 2
        G.text(cv, f"0{i + 1}", x0, 30, size=14, c=col, kind="mono", a=0.9)
        G.text(cv, name, x0 + nw + 8, 24, size=20, c=col, weight=600, ls=1.4)
        G.rrect(cv, cx - 61, 60, 122, 4, 2, fill=(28, 36, 49))
        if done:
            G.rrect(cv, cx - 61, 60, 122, 4, 2, fill=G.BRAND, a=0.85)
        elif cur:
            G.rrect(cv, cx - 61, 60, max(4, 122 * G.clamp(prog)), 4, 2, fill=G.MODEL)
    G.text(cv, note, 1878, 18, size=14, c=G.DIM, kind="mono", align="right", ls=2.2)
    if clock:
        lab, val = clock
        vw, _ = G.measure(val, 19, 600, "mono")
        G.text(cv, val, 1878, 43, size=19, c=G.WHITE, weight=600, kind="mono", align="right")
        G.text(cv, lab, 1878 - vw - 10, 45, size=17, c=G.DIM, kind="mono", align="right")


def captions(cv, en, zh, st, a=1.0):
    if a <= 0.003:
        return
    _, h_en = G.measure(en, 30, 600, "sans", width=1660)
    two = h_en > 50
    zh_size = 25 if two else 27
    _, h_zh = G.measure(zh, zh_size, 500, "sans", width=1660) if zh else (0, 0)
    y = 906 if two else 914
    if two and h_zh > 45:
        y = 898
    G.text(cv, en, 130, y, size=30, c=G.WHITE, weight=600, a=a, align="center", width=1660)
    y += h_en + 6
    if zh:
        G.text(cv, zh, 130, y, size=zh_size, c=(190, 198, 211), weight=500, a=a, align="center", width=1660)
        y += h_zh
    if st and y <= 1040:
        role, s = st
        c = G.ROLE.get(role, G.DIM)
        G.text(cv, s, 960, max(y + 6, 1040), size=15, c=G.mix(c, G.DIM, 0.25), kind="mono", a=a * 0.95, align="center", ls=0.6)


def progress(cv, frac):
    G.rrect(cv, 0, 1075, G.W * G.clamp(frac), 5, 0, fill=G.MODEL, a=0.95)


def panel(cv, x, y, w, h, a=1.0, accent=None, accent_a=0.0, r=14):
    G.rrect(cv, x, y, w, h, r, fill=G.PANEL, fa=0.92, a=a)
    G.rrect(cv, x, y, w, h, r, stroke=G.EDGE, sw=1.5, a=a)
    if accent is not None and accent_a > 0.01:
        G.glow(cv, x, y, w, h, r, accent, a=0.10 * accent_a * a, sigma=18)
        G.rrect(cv, x, y, w, h, r, stroke=accent, sw=1.8, a=a * accent_a * 0.75)


def pill(cv, s, x, y, c, a=1.0, size=14, align="left", fill=None):
    tw, th = G.measure(s, size, 500, "mono")
    w = tw + 22
    if align == "right":
        x -= w
    elif align == "center":
        x -= w / 2
    G.rrect(cv, x, y, w, th + 8, (th + 8) / 2, fill=fill if fill else G.INK, fa=0.6, stroke=c, sw=1.3, a=a)
    G.text(cv, s, x + 11, y + 4, size=size, c=c, kind="mono", a=a)
    return w


# ----------------------------------------------------------------------------- chips row
ROLE_KEYS = ["model", "harness", "sandbox", "scorer"]


def chips(cv, values, active=None, a=1.0, dims=None, pulse=0.0, track_pos=None):
    """values: list of (kicker, value) for MODEL/HARNESS/SANDBOX/JUDGE."""
    if a <= 0.003:
        return
    for i, (kick, val) in enumerate(values):
        role = ROLE_KEYS[i]
        rc = G.ROLE[role]
        x = CHIP_X[i]
        act = active.get(role, 0.0) if isinstance(active, dict) else (1.0 if active == role else 0.0)
        dim = (dims or {}).get(role, 0.0)
        ca = a * (1 - 0.55 * dim)
        if act > 0.01:
            G.glow(cv, x, CHIP_Y, CHIP_W, CHIP_H, 12, rc, a=0.28 * act * ca, sigma=14)
        G.rrect(cv, x, CHIP_Y, CHIP_W, CHIP_H, 12, fill=G.mix(G.PANEL, rc, 0.10 * act), fa=0.92, a=ca)
        G.rrect(cv, x, CHIP_Y, CHIP_W, CHIP_H, 12, stroke=G.mix(G.EDGE, rc, act), sw=1.5 + 0.8 * act, a=ca)
        G.icon_role(cv, role, x + 30, CHIP_Y + 33, G.mix(G.DIM, rc, 0.35 + 0.65 * act), a=ca, s=10)
        G.text(cv, kick, x + 54, CHIP_Y + 13, size=14, c=G.mix(G.DIM, rc, 0.4 + 0.6 * act), weight=600, kind="mono", a=ca, ls=1.6)
        vs = 16.5
        while vs > 12 and G.measure(val, vs, 500)[0] > CHIP_W - 64:
            vs -= 0.5
        G.text(cv, val, x + 54, CHIP_Y + 34 + (16.5 - vs) * 0.5, size=vs, c=G.mix(G.DIM, G.FG, 0.45 + 0.55 * act), weight=500, a=ca)
    # signal track
    G.line(cv, [(CHIP_CX[0], TRACK_Y), (CHIP_CX[3], TRACK_Y)], (30, 39, 52), sw=2, a=a)
    for i in range(4):
        G.circle(cv, CHIP_CX[i], TRACK_Y, 4, fill=(48, 58, 75), a=a)
    if track_pos is not None:
        pos, role = track_pos
        x = G.lerp(CHIP_CX[0], CHIP_CX[3], pos / 3.0)
        rc = G.ROLE[role]
        G.glow(cv, x - 13, TRACK_Y - 13, 26, 26, 13, rc, a=0.45 * a, sigma=9)
        G.circle(cv, x, TRACK_Y, 10, fill=rc, a=a)
        G.circle(cv, x, TRACK_Y, 4, fill=G.WHITE, a=a * 0.9)


# ----------------------------------------------------------------------------- loop frame
STAGES = [("MODEL", "model"), ("TOOL CALL", "harness"), ("DOCKER · BASH", "sandbox"), ("OBSERVATION", "brand")]


def stage_boxes(cv, values, act=None, a=1.0, fail=0.0, labels=None, container=1.0, sub=None, dim=None):
    """values: 4 strings. act: dict index->0..1 highlight. dim: stage indexes drawn faded."""
    act = act or {}
    dim = dim or ()
    if container > 0.01:
        # Claude Code + Bash live inside the task container; the model is a remote API.
        x0, x1 = STAGE_X[1] - 12, STAGE_X[2] + STAGE_W + 12
        G.rrect(cv, x0, STAGE_Y - 22, x1 - x0, STAGE_H + 34, 12, stroke=G.SANDBOX, sw=1.4, a=a * 0.55 * container, dash=(7, 6))
        G.text(cv, "inside the Docker container", x1 - 12, STAGE_Y - 19, size=12, c=G.SANDBOX, kind="mono", a=a * 0.85 * container, align="right")
        G.text(cv, "remote API", STAGE_X[0] + 14, STAGE_Y - 19, size=12, c=G.MODEL, kind="mono", a=a * 0.8 * container)
    for i, (kick, role) in enumerate(STAGES):
        lab = labels[i] if labels else kick
        rc = G.ROLE[role]
        if i == 3 and fail > 0:
            rc = G.mix(rc, G.FAIL, fail)
        x = STAGE_X[i]
        k = act.get(i, 0.0)
        sa = a * (0.38 if i in dim else 1.0)
        if k > 0.01:
            G.glow(cv, x, STAGE_Y, STAGE_W, STAGE_H, 10, rc, a=0.32 * k * sa, sigma=14)
        G.rrect(cv, x, STAGE_Y, STAGE_W, STAGE_H, 10, fill=G.mix((13, 18, 26), rc, 0.12 * k), fa=0.95, a=a)
        G.rrect(cv, x, STAGE_Y, STAGE_W, STAGE_H, 10, stroke=G.mix(G.EDGE, rc, 0.25 + 0.75 * k), sw=1.5 + k, a=sa)
        G.text(cv, lab, x + 16, STAGE_Y + 13, size=13.5, c=G.mix(G.DIM, rc, 0.55 + 0.45 * k), weight=600, kind="mono", a=sa, ls=1.4)
        G.text(cv, values[i], x + 16, STAGE_Y + 38, size=19, c=G.mix(G.DIM, G.FG, 0.55 + 0.45 * k), weight=600, a=sa, maxlines=1, width=STAGE_W - 26)
        if i < 3:
            ax = x + STAGE_W + 4
            G.line(cv, [(ax, STAGE_Y + STAGE_H / 2), (ax + 22, STAGE_Y + STAGE_H / 2)], (60, 72, 92), sw=1.6, a=a)
            G.arrow_head(cv, ax + 26, STAGE_Y + STAGE_H / 2, 0, (60, 72, 92), size=7, a=a)
    if sub:
        G.text(cv, sub, STAGE_X[0] + STAGE_W / 2, STAGE_Y + STAGE_H + 6, size=12, c=G.DIM, kind="mono", a=a * 0.7, align="center")


def return_path():
    xo = STAGE_X[3] + STAGE_W / 2
    xm = STAGE_X[0] + STAGE_W / 2
    yb = STAGE_Y + STAGE_H
    return G.rounded_path([(xo, yb + 2), (xo, yb + 30), (xm, yb + 30), (xm, yb + 2)], 14)


def return_route(cv, a=1.0, hi=0.0, label="results return to the model in the next request", prog=None):
    path = return_path()
    G.draw_path(cv, path, G.mix((52, 64, 84), G.BRAND, hi), sw=1.8 + hi, a=a)
    p, ang = G.path_point(path, 0.999)
    G.arrow_head(cv, p[0], p[1] - 2, ang, G.mix((52, 64, 84), G.BRAND, hi), size=8, a=a)
    G.text(cv, label, 960, STAGE_Y + STAGE_H + 37, size=14, c=G.mix(G.DIM, G.BRAND, hi), kind="mono", a=a * 0.9, align="center")
    if prog is not None and 0 < prog < 1:
        (x, y), _ = G.path_point(path, prog)
        G.packet(cv, x, y, G.BRAND, a=a)


def forward_packet(cv, frac, c, a=1.0):
    """Packet travelling MODEL -> TOOL CALL -> DOCKER -> OBSERVATION along the stage row (frac 0..3)."""
    if frac <= 0 or frac >= 3 or a <= 0.01:
        return
    i = int(frac)
    f = frac - i
    x0 = STAGE_X[i] + STAGE_W / 2
    x1 = STAGE_X[i + 1] + STAGE_W / 2
    G.packet(cv, G.lerp(x0, x1, G.ease_in_out(f)), STAGE_Y + STAGE_H / 2, c, a=a)


def detail_card(cv, i, kick, title, lines, role="brand", act=0.0, a=1.0, mono=False, size=None,
                reveal=1.0, line_cols=None, x=None, w=None, y=None, h=None, title_c=None, line_a=None, span=1, gap=None,
                maxl=3):
    x = CARD_X[i] if x is None else x
    w = (CARD_W * span + 23 * (span - 1)) if w is None else w
    y = CARD_Y if y is None else y
    h = CARD_H if h is None else h
    rc = G.ROLE.get(role, role) if isinstance(role, str) else role
    if act > 0.01:
        G.glow(cv, x, y, w, h, 12, rc, a=0.22 * act * a, sigma=16)
    G.rrect(cv, x, y, w, h, 12, fill=G.mix((13, 18, 26), rc, 0.06 * act), fa=0.96, a=a)
    G.rrect(cv, x, y, w, h, 12, stroke=G.mix(G.EDGE, rc, 0.2 + 0.8 * act), sw=1.5 + act, a=a)
    G.text(cv, kick, x + 18, y + 17, size=13.5, c=G.mix(G.DIM, rc, 0.5 + 0.5 * act), weight=600, kind="mono", a=a, ls=1.5)
    yy = y + 42
    if title:
        _, th = G.text(cv, title, x + 18, yy, size=21, c=title_c or G.FG, weight=600, a=a, width=w - 36, lh=1.15)
        yy += th + 8
    sz = size or (14.5 if mono else 16.5)
    n = len(lines)
    for j, ln in enumerate(lines):
        la = G.ease(G.clamp(reveal * n - j)) if reveal < 1 else 1.0
        if line_a is not None and j < len(line_a):
            la = line_a[j]
        if la <= 0.01:
            continue
        col = (line_cols[j] if line_cols and j < len(line_cols) and line_cols[j] else (G.FG if not mono else (196, 204, 216)))
        _, lh = G.text(cv, ln, x + 18, yy, size=sz, c=col, kind="mono" if mono else "sans", a=a * la,
                       width=w - 36, maxlines=maxl)
        yy += lh + (gap if gap is not None else (4 if mono else 7))
        if yy > y + h - 14:
            break
    return yy


def kv(cv, x, y, label, value, a=1.0, vc=None, vsize=28, w=None):
    G.text(cv, label, x, y, size=14, c=G.DIM, kind="mono", a=a, ls=0.6)
    G.text(cv, value, x, y + 20, size=vsize, c=vc or G.FG, weight=600, a=a)
