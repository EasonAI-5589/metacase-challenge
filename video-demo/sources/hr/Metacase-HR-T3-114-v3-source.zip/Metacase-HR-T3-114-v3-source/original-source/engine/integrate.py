"""Install the relay edition into the 4198 website worktree, after backing up what is there.

usage: python engine/integrate.py [--dry-run]
Backup: site-before-relay/<relative path> + site-before-relay/manifest.json (sha256 of every replaced file).
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SITE = "/Users/user/Documents/ChatGPT/InferenceNet/worktrees/website/website/home-challenges-20261018"
DELIVER = os.path.join(ROOT, "deliver")
BACKUP = os.path.join(ROOT, "site-before-relay")
OLD_TAG = "20261019-claude-sufe-v1"
NEW_TAG = "20261019-claude-relay-v2"
OLD_CH_LANG = "20261019-challenge-copy"
NEW_CH_LANG = "20261019-challenge-relay-v2"

MEDIA = ["assets/video/finance-story-demo.mp4", "assets/video/finance-story-demo-poster.jpg",
         "assets/video/hr-agent-replay.mp4", "assets/video/hr-agent-replay-poster.jpg"]
DOCS = [f"docs/video/{d}/{f}" for d in ("finance", "hr")
        for f in ("README.md", "provenance.json", "captions.en.srt", "captions.zh.srt", "captions.bilingual.srt")]
TEXT = ["index.html", "challenge.html", "professional-tasks.html", "README.md",
        "assets/i18n/challenge.zh.json", "assets/i18n/professional-tasks.zh.json",
        "scripts/test-initiative.mjs", "scripts/test-dual-board.mjs"]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def fmt_dur(sec):
    m, s = divmod(int(round(sec)), 60)
    return m, s


def replace_once(text, old, new, path, count=1):
    n = text.count(old)
    if n != count:
        raise SystemExit(f"{path}: expected {count} occurrence(s) of {old[:70]!r}, found {n}")
    return text.replace(old, new)


def readme_for(doc, prov):
    ch = "; ".join(f"{c['name']} {c['start_seconds']:.1f}–{c['end_seconds']:.1f} s" for c in prov["chapters"])
    m, s = fmt_dur(prov["duration_seconds"])
    if doc == "finance":
        body = """The task: decide each of six unposted entries (D01–D06) before the July close, with a Word report and an Excel
workbook as deliverables. The replay follows the recorded requests of qwen3.7-max in Claude Code 2.1.114
(Harbor 0.20.0): request 1–2 list, create and read; a `.docx` read with `cat` returns ZIP bytes and request 3
switches to python-docx; request 4 sends four parallel Bash calls; TodoWrite is handled by Claude Code itself;
request 15 reads the swap valuations (30 Jun −1,277,351.45, 31 Jul −4,395,835.74); requests 16–17 write the
workbook; request 19 fails with the recorded `NameError` before the save; requests 23–25 read the files back, the
model states the cause in its reply and re-runs the edit; the read-back shows 39 rows. HARNESS shows the whole
trace (50 Bash, 4 TodoWrite, no Read/Edit/Write), prompt growth from 26,560 to 99,752 tokens and the handoff:
Harbor copies tests into the same container after the agent stops. CHECK: DV01 −132,480.55 CNY/BP copied from
sheet 16 and recomputed by the judge (R11 met); D02 keeps red line G2 clear but R51 = 0.5; no formulas in five
sheets (R19 not met). RESULT: 3 met, 6 partly met, 11 not met, no penalties, both red lines clear;
reward 0.332849 = 57.25 / 172."""
    else:
        body = """The task (fictional, synthetic records): review a six-week supervisor training at three cold-chain sites
against a delayed fourth site, then decide acceptance and payment for three vendor work packages (¥816,000).
The replay follows the recorded requests of qwen3.7-max in Claude Code 2.1.114 (Harbor 0.20.0): request 2 sends
eight parallel previews; TodoWrite keeps the plan; the data-use rule is read from the task materials; request 7
is one 19,223-token response that the Write tool saves as a 1,336-line script; the first run (no error) labels
WP-A “验收通过” while retaining 10 %; the model names problems in its own WP-A logic and sample filter, runs two
checks, two Reads and four Edits, and the re-run makes WP-A “附条件验收” (220,320 / 24,480). No tool call failed.
HARNESS: 33 Bash, 4 TodoWrite, 1 Write, 2 Read, 4 Edit; prompt growth from 25,021 to 89,340 tokens; handoff into
the same container. CHECK (judge qwen3.7-plus, 34 criterion sessions): R20 met; per-site comparisons R14–R16 and
the source index R1/R19 not met; penalty R32 triggered because all ten people with too few opportunities were
marked as not meeting the standard (−7 raw weighted points). RESULT: 6 of 28 positive criteria met, 1 of 6
penalties; reward 0.207547 = (29 − 7) / 106."""
    return f"""# {prov['task_id']} narrated replay — relay edition

{prov['duration_seconds']:.3f} s ({m} min {s:02d} s) · 1920×1080 · 30 fps · H.264 High (BT.709) + AAC 48 kHz mono ·
English narration `en-US-AriaNeural`, the voice of the approved PR #27 replay (requested at +12 % to match its 1.12 pace) ·
burned English / Chinese captions. Status: awaiting the user's review.

Chapters: {ch}.

{body}

Boundaries: an editorial replay of the existing recorded pilot run — nothing was re-run or re-scored. Request numbers are
the 28 assistant message ids in the Claude Code session log; tool steps are run-export indexes; shot lengths follow the
narration, so the timeline is compressed and the header clock shows the recorded agent time. Claude Code and Bash run
inside the task's Docker container; the model is reached through an API. The rubric is absent during the agent run and
scores never flow back to it. The reward is one pilot run's rubric score, not accuracy and not a ranking.

`provenance.json` lists stream parameters, chapters, every shot with its narration and caption, file and source hashes.
The SRT files are generated from the same storyboard text that was synthesised.

Editable source (outside the website): `research/sufe-video-claude-relay-20261018/` — Skia renderer `engine/`,
storyboard `story/{prov['run']}.py`. Rebuild: `python engine/voice.py {prov['run']} && python engine/render.py {prov['run']} && python engine/package.py {prov['run']}`.
"""


def main(dry):
    if os.path.exists(BACKUP):
        raise SystemExit(f"backup exists: {BACKUP} (refusing to overwrite it)")
    manifest = {"site": SITE, "replaced_files": {}}
    for rel in MEDIA + DOCS + TEXT:
        p = os.path.join(SITE, rel)
        if os.path.exists(p):
            manifest["replaced_files"][rel] = {"bytes": os.path.getsize(p), "sha256": sha(p)}
    print(f"backing up {len(manifest['replaced_files'])} files")
    if not dry:
        for rel in manifest["replaced_files"]:
            dst = os.path.join(BACKUP, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(os.path.join(SITE, rel), dst)
        json.dump(manifest, open(os.path.join(BACKUP, "manifest.json"), "w"), indent=1)

    prov = {d: json.load(open(os.path.join(DELIVER, "docs", "video", d, "provenance.json"))) for d in ("finance", "hr")}
    # media + docs
    for rel in MEDIA + [r for r in DOCS if not r.endswith("README.md")]:
        src = os.path.join(DELIVER, rel)
        if not dry:
            shutil.copyfile(src, os.path.join(SITE, rel))
    for d in ("finance", "hr"):
        text = readme_for(d, prov[d])
        open(os.path.join(DELIVER, "docs", "video", d, "README.md"), "w").write(text)
        if not dry:
            open(os.path.join(SITE, "docs", "video", d, "README.md"), "w").write(text)

    fm, fs = fmt_dur(prov["finance"]["duration_seconds"])
    hm, hs = fmt_dur(prov["hr"]["duration_seconds"])
    edits = {
        "index.html": [(OLD_TAG, NEW_TAG, 3)],
        "challenge.html": [
            (OLD_TAG, NEW_TAG, 6),
            (f"language.js?v={OLD_CH_LANG}", f"language.js?v={NEW_CH_LANG}", 1),
            ("<span>2 min 44 sec · English narration · English / Chinese captions</span>",
             f"<span>{fm} min {fs:02d} sec · English narration · English / Chinese captions</span>", 1),
            ("<span>2 min 56 sec · English narration · English / Chinese captions</span>",
             f"<span>{hm} min {hs:02d} sec · English narration · English / Chinese captions</span>", 1)],
        "assets/i18n/challenge.zh.json": [
            ('"2 min 44 sec · English narration · English / Chinese captions": "2 分 44 秒 · 英文旁白 · 中英文字幕"',
             f'"{fm} min {fs:02d} sec · English narration · English / Chinese captions": "{fm} 分 {fs:02d} 秒 · 英文旁白 · 中英文字幕"', 1),
            ('"2 min 56 sec · English narration · English / Chinese captions": "2 分 56 秒 · 英文旁白 · 中英文字幕"',
             f'"{hm} min {hs:02d} sec · English narration · English / Chinese captions": "{hm} 分 {hs:02d} 秒 · 英文旁白 · 中英文字幕"', 1)],
        "professional-tasks.html": [
            (OLD_TAG, NEW_TAG, 4),
            ("A 2-minute 44-second narrated walkthrough of FIN-T1-003: the task, each tool round trip inside Claude Code, a real script error and the agent’s own repair, then the independent review and pilot result. English synthetic narration with English / Chinese captions; the timeline is compressed from a recorded run.",
             f"A {fm}-minute {fs}-second narrated walkthrough of FIN-T1-003: the task, each request and tool round trip inside Claude Code, a real script error and the agent’s own repair, then the independent review and pilot result. English synthetic narration with English / Chinese captions; the timeline is compressed from a recorded run.", 1)],
        "assets/i18n/professional-tasks.zh.json": [
            ('"A 2-minute 44-second narrated walkthrough of FIN-T1-003: the task, each tool round trip inside Claude Code, a real script error and the agent’s own repair, then the independent review and pilot result. English synthetic narration with English / Chinese captions; the timeline is compressed from a recorded run.": "2 分 44 秒讲解 FIN-T1-003：任务、Claude Code 中的每次工具往返、',
             f'"A {fm}-minute {fs}-second narrated walkthrough of FIN-T1-003: the task, each request and tool round trip inside Claude Code, a real script error and the agent’s own repair, then the independent review and pilot result. English synthetic narration with English / Chinese captions; the timeline is compressed from a recorded run.": "{fm} 分 {fs} 秒讲解 FIN-T1-003：任务、Claude Code 中的每次请求与工具往返、', 1)],
        "scripts/test-initiative.mjs": [(OLD_TAG, NEW_TAG, 1)],
        "scripts/test-dual-board.mjs": [
            (f"{{ 'challenge.html': '{OLD_CH_LANG}', 'professional-tasks.html': '{OLD_TAG}' }}",
             f"{{ 'challenge.html': '{NEW_CH_LANG}', 'professional-tasks.html': '{NEW_TAG}' }}", 1)],
    }
    for rel, reps in edits.items():
        p = os.path.join(SITE, rel)
        t = open(p, encoding="utf-8").read()
        for old, new, n in reps:
            t = replace_once(t, old, new, rel, n)
        if not dry:
            open(p, "w", encoding="utf-8").write(t)
        print("edited", rel, len(reps), "replacement group(s)")
    # README: tag mention + the narrated-demos section
    p = os.path.join(SITE, "README.md")
    t = open(p, encoding="utf-8").read()
    t = replace_once(t, f"`{OLD_TAG}` for the SUFE walkthrough captions.", f"`{NEW_TAG}` for the SUFE walkthrough captions.", "README.md")
    head = "## Business analysis narrated demos\n"
    i = t.index(head)
    j = t.index("\n## ", i + len(head))
    section = open(os.path.join(ROOT, "docs", "site-readme-section.md"), encoding="utf-8").read().strip("\n") + "\n"
    t = t[:i] + section + t[j:]
    if not dry:
        open(p, "w", encoding="utf-8").write(t)
    print("edited README.md")


if __name__ == "__main__":
    main("--dry-run" in sys.argv)
