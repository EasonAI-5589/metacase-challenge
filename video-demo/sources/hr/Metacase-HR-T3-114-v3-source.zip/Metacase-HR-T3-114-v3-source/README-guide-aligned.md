# Finance guide alignment v2

本版针对首页 **Challenge 2 · Agent demo / Business Analysis & Deliverables** 的金融月结审核视频，将宠物、指棒、移动姿态、旁白提示点和局部高亮对齐 task0001 v3.2。宠物始终保持参考形象的朝右方向，不镜像或转身；片头入场与片尾退场依据第一视频的实际动画和时间关系复现。片头、片尾的整体动画也依据实际参考移植：84 个符号与角色图形汇聚、Logo 弹性显现、聚光背景、分隔线和片尾文字依次出现。

保留当前金融接力版的 34 个镜头、93 个宠物提示点、8846 帧、1920×1080、30 fps，视频时长为 294.866667 秒（约 4 分 55 秒）。原故事、金融事实、评分、英文旁白、双语字幕和缓存音频保持原样。本版没有执行新 Agent 运行或重新评分。

## 来源与编辑入口

- 上游金融版本：`sufe-claude-relay-v2`，原工程目录 `research/sufe-video-claude-relay-20261018/`。
- 收到的源码 ZIP SHA-256：`0e6576985e25ef5ab8cb512f13b4068f4a13c7680570215d1027a03651befbb7`。
- 上游金融 MP4 SHA-256：`d8792c91fa0cc43e107cae89e5be901bb4d19028cba243fc166327d1aa3b65be`。
- 宠物参考：`replay-deepagents-v3-2/site/original-guide.js`，SHA-256 为 `9246340ec582e46bdc2339a8824deba064ec2fa30dbb3be9c6839ee815b95e68`。
- `engine/reference_pet.py` 将参考宠物的 **14 个 SVG path 元素**及颜色移植为 Skia；嘴部元素保留静止与移动两种路径状态。输出大小为参考 CSS 宠物的 1.5 倍，每个原始 SVG 单位对应 4 个输出像素。
- `reference/task0001-v3.2/` 保留实际参考的 `original-guide.js`、`pet-overlay.css`、`enhancement.js`、`enhancement.css`、`index.html` 和 `timeline.json`；打包 provenance 记录各文件哈希。
- `engine/reference_bookends.py` 移植原 `index.html` 的 `OPEN_PTC`、`renderOpen`、`renderEnd` 和 CSS 聚光背景，保留 `mulberry32(20261018)` 及随机调用顺序。参考 HTML SHA-256 为 `d229957a3c3b48d3369d817d33427d2845a47e4011e07dff9d103d0bf83a93d7`。原 5.0 / 5.2 秒的演示时钟映射到金融片头 8.334208 秒、片尾 7.441333 秒，原金融角色、任务中英标题和片尾文案保留，符号替换为金融事实；不改旁白或音频时间轴。
- `engine/guide.py` 控制绝对时间轴上的移动、固定朝右姿态、入场退场、指棒收回和交接；`engine/guide_targets.py` 将原有提示点映射到金融场景中的高亮区域。
- `engine/compose.py` 将新引导层接入现有画面。`story/fin.py`、`data/`、`build/fin/voice/` 和 `voice.json` 是保留的故事、运行证据和音频缓存。
- `original-source/`、原 `README.md`、原 `requirements.txt` 和 `MANIFEST.json` 是来源记录，继续保留。此次 Windows 重建请使用本文件与 `requirements-render.txt`。

## Windows 本地重建

已使用 Python **3.12.7**、skia-python **144.0.post2**、NumPy **2.3.5**、pybind11 **3.1.0** 验证渲染流程。Inter 静态字体已包含；`fonttools 4.51.0` 与 `Brotli 1.0.9` 是重新生成静态字体时使用的已安装版本。Pillow 12.0.0 在制作机上可用，但核心渲染、封面和打包命令不依赖它。

FFmpeg 和 ffprobe 是独立程序，FFmpeg 需支持 `libx264`、AAC 与 `loudnorm`。制作机核验版本为 `N-119917-g8087777e66-20250617`。Python 环境、软件安装包和 FFmpeg 不随源码分发；安装依赖需要可访问包源，或者预先准备对应 wheel。依赖安装完成后，下面的渲染与打包过程使用已有音频缓存，可离线执行。

从这个源码文件夹打开 PowerShell。首次准备环境：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-render.txt
```

如果 FFmpeg 与 ffprobe 已在 PATH 中，可以直接运行。否则将以下两个示例路径替换为本机实际文件：

```powershell
$env:FFMPEG = 'C:\tools\ffmpeg\bin\ffmpeg.exe'
$env:FFPROBE = 'C:\tools\ffmpeg\bin\ffprobe.exe'
```

先输出一个短预览，时间区间使用原视频的绝对秒数；输出帧数按 30 fps 对齐：

```powershell
.\.venv\Scripts\python.exe -X utf8 engine/render.py fin --workers 2 --preview-range 63:75 --output build/fin/preview-word-read.mp4
```

完整重建与交付打包：

```powershell
.\.venv\Scripts\python.exe -X utf8 engine/render.py fin --workers 2
.\.venv\Scripts\python.exe -X utf8 engine/package.py fin
```

这些命令复用 34 段 MP3 缓存，不需要调用 `voice.py`、TTS 服务、模型 API 或原始私有会话。完整渲染默认写入 `build/fin/fin.mp4`，并生成 `fin.font-selection.json`、`fin.render-receipt.json` 与三份字幕。打包读取该默认完整视频并核对 receipt 中的成片、输入和实际字体文件哈希；`--output` 用于预览时，不会自动改写完整视频的打包入口。

默认使用 2 个 worker，每个编码器使用 2 个线程、1 个滤镜线程；每段结束后回收 worker，避免跨整片积累文字与绘图缓存。`--segment-frames` 默认 400，范围为 1–400；完整视频均衡分为 23 段，每段 384 或 385 帧。先渲染首段和末段，再处理中间段，因此可先审看完整片头和片尾。更高的 `--workers` 仅应在可用内存充足时显式设置。

静态背景在每个 worker 内只绘制一次再复用原尺寸像素。分段保存在按输入与渲染设置指纹命名的 `build/fin/segments-*` 中。中断后重跑同一命令会按 receipt 的 SHA-256、帧数和输入指纹复用已完成分段；失败或残缺分段会重新渲染。也可用 `--resume-dir` 指向已有分段目录，但源码、字体和渲染设置必须匹配。拼接仍按时间顺序进行。分段和临时编码文件不加入源码交付。

## 字体与几何检查

正文沿用随包 Inter。Windows 系统字体按角色选择 Consolas、Microsoft YaHei、Segoe UI Symbol、Georgia，另用 Segoe UI 补足记录中二进制读取示例的替代字符等字形。系统字体只在本机读取，不复制进源码包。缺失字体或探针字形会显式报错；实际字体选择和文件哈希记录在打包后的 `font-selection.json`。由于系统字体不同，Windows 与原 macOS 排版的字宽可能略有差别。

单独检查几何：

```powershell
.\.venv\Scripts\python.exe -X utf8 engine/check_guide.py
```

检查覆盖全部 8846 帧的有限坐标、身体下边界、可见指棒中心线与身体多边形的相交情况，以及 93 个 cue 两侧的位置和姿态连续性。脚本同时比较原始 MANIFEST 中所有非 engine 文件，并核对三种字幕与 `docs` 逐字节一致。逐帧最大位移作为诊断值记录，不用任意速度阈值替代视觉判断。

打包时会再次对当时的源码执行纯几何审核，将该源码快照的哈希绑定到报告；同时通过 ffprobe 核对完整视频的帧数、帧率和分辨率。它不重跑光栅渲染。几何检查验证指棒中心线，不覆盖描边半径；文字遮挡、焦点框是否清楚和完整视听体验仍应查看成片。

## 输出

`deliver/` 中的网站替换文件：

- `assets/video/finance-story-demo.mp4`
- `assets/video/finance-story-demo-poster.jpg`
- `docs/video/finance/captions.en.srt`
- `docs/video/finance/captions.zh.srt`
- `docs/video/finance/captions.bilingual.srt`
- `docs/video/finance/provenance.json`
- `docs/video/finance/font-selection.json`
- `docs/video/finance/guide-geometry-qa.json`
- `docs/video/finance/render-receipt.json`
- `docs/video/finance/README.md`

`provenance.json` 标识版本 `finance-guide-aligned-v2`、上游来源、参考宠物的 14 个路径元素、固定朝右和片头片尾对齐策略、当前编辑源码和输出文件哈希，并保持 `awaiting user review` 状态。源码路径以本包根目录为基准，使用正斜杠；系统字体使用逻辑相对路径，不公开工作站绝对路径。
