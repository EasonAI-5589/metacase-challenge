"""Draw every 5th frame of the HR film and list any Chinese text that would still reach the screen."""
import json, os, re, sys
SRC = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
os.chdir(SRC); sys.path[:0] = [os.path.join(SRC, "engine"), SRC]
import skia, gfx as G, compose
ctx = compose.Ctx("hr")
CJK = re.compile(r"[　-〿一-鿿＀-￯]")
seen = {}
orig_para = G._para
def para(s, *a, **k):
    if CJK.search(s):
        seen.setdefault(s, set()).add(cur[0])
    return orig_para(s, *a, **k)
G._para = para
G._PARAS.clear()
cur = [None]
surf = skia.Surface(1920, 1080); cv = surf.getCanvas()
for f in range(0, ctx.tl.nframes, 5):
    sh, t, _ = ctx.tl.locate(f / 30)
    cur[0] = sh.id
    compose.frame(cv, ctx, f / 30)
out = {s: sorted(v) for s, v in seen.items()}
json.dump(out, open(os.path.join(SRC, "build", "hr", "cjk-onscreen.json"), "w"), ensure_ascii=False, indent=1)
print(len(out), "strings with Chinese reach the screen")
for s, v in out.items():
    print(v[:3], s)
