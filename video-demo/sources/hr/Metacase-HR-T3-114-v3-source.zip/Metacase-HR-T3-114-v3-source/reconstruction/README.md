# HR-T3-114 reconstruction tools

The v2 HR source was never archived, so `story/hr.py`, `data/hr.json` and
`data/hr.requests.jsonl` were rebuilt from the published v2 film. These scripts are
the record of how. They read frames of the v2 film, which are not included here:
extract them from the v2 `assets/video/hr-agent-replay.mp4` (git history) into
`build/hr/ref-frames/<shot>_<0|1|2>.png` at 35, 70 and 95 % of each shot.

| script | what it does |
| --- | --- |
| `trace_extract.py` | reads the request bars and tool dots off the v2 "whole run" frame (h16) → `trace_raw.json` |
| `context_raw.json`, `context_cols.json` | prompt-token readings from the v2 context chart (h17) |
| `build_hr_data.py` | writes `data/hr.json` and `data/hr.requests.jsonl` from those readings and the values printed on screen (run from the source root: `python reconstruction/build_hr_data.py .`) |
| `voice_hr.py` | runs `engine/voice.py hr` where no ffprobe is available, and stores portable clip paths |
| `stills.py`, `pair.py` | render v3 stills at the v2 sample points and pair them with the v2 frames |
| `cjk_scan.py` | draws every 5th frame and lists any Chinese text that would reach the screen |

What is exact, approximate and unknown is listed under `reconstruction` in
`docs/video/hr/provenance.json`.
