"""Read request bars and tool dots off the original HR 'whole run' frame (h16).
Geometry from engine/scenes_x.py draw_trace: X(s)=652+(1408-652)*s/364.9; bar bottom 430,
height 8+70*out/maxo; dots at y=470+15*stack, r=5.5."""
import skia, numpy as np, json
from collections import deque
a=np.asarray(skia.Image.open('ref/frames/h16_2.png').toarray()).astype(int)[:,:,:3]
X0,X1,DUR=652,1408,364.9
t_of=lambda x:(x-X0)*DUR/(X1-X0)
def comps(mask):
    seen=np.zeros_like(mask,bool); out=[]
    ys,xs=np.nonzero(mask)
    for y,x in zip(ys,xs):
        if seen[y,x]: continue
        q=deque([(y,x)]); seen[y,x]=True; pts=[]
        while q:
            cy,cx=q.popleft(); pts.append((cy,cx))
            for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
                ny,nx=cy+dy,cx+dx
                if 0<=ny<mask.shape[0] and 0<=nx<mask.shape[1] and mask[ny,nx] and not seen[ny,nx]:
                    seen[ny,nx]=True; q.append((ny,nx))
        out.append(np.array(pts))
    return out
def near(c,ref,tol): return (np.abs(a-np.array(ref)).sum(axis=2)<tol)
# bars
region=np.zeros(a.shape[:2],bool); region[340:431,640:1420]=True
bm=near(a,(216,131,87),70)&region
bars=[]
for p in comps(bm):
    if len(p)<10: continue
    ys,xs=p[:,0],p[:,1]
    bars.append(dict(x=float(xs.mean()),top=int(ys.min()),bot=int(ys.max()),w=int(xs.max()-xs.min()+1)))
bars.sort(key=lambda b:b['x'])
# dots
region=np.zeros(a.shape[:2],bool); region[460:620,640:1420]=True
dots=[]
for name,ref in (('Bash',(115,211,157)),('TodoWrite',(181,162,249)),('Yellow',(236,190,104))):
    m=near(a,ref,60)&region
    for p in comps(m):
        if len(p)<40: continue
        ys,xs=p[:,0],p[:,1]
        w=xs.max()-xs.min()+1; h=ys.max()-ys.min()+1
        if w>16 or h>16:  # merged or dashed line; report
            dots.append(dict(kind=name,x=float(xs.mean()),y=float(ys.mean()),w=int(w),h=int(h),n=len(p),merged=True)); continue
        dots.append(dict(kind=name,x=float(xs.mean()),y=float(ys.mean()),w=int(w),h=int(h),n=len(p)))
dots.sort(key=lambda d:(round(d['x']),d['y']))
print('bars',len(bars))
for b in bars: print(f"  x={b['x']:.1f} t={t_of(b['x']):.1f} h={430-b['top']+1} w={b['w']}")
print('dots',len(dots))
for d in dots: print(f"  {d['kind']:9} x={d['x']:.1f} t={t_of(d['x']):.1f} y={d['y']:.1f} stack={(d['y']-470)/15:.2f} {d.get('merged','')} w{d['w']}h{d['h']}")
json.dump(dict(bars=bars,dots=dots),open('work/trace_raw.json','w'),indent=1)
