"""Render v3 stills at 35/70/95 % of each shot and pair them with the published v2 frames."""
import os, sys
SRC = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
os.chdir(SRC); sys.path[:0] = [os.path.join(SRC, "engine"), SRC]
import compose
ctx = compose.Ctx("hr")
OUT = os.path.join(SRC, "build", "hr", "cmp"); os.makedirs(OUT, exist_ok=True)
REF = os.path.join(SRC, "build", "hr", "ref-frames")
only = set(sys.argv[1:])
for sh in ctx.tl.shots:
    if only and sh.id not in only:
        continue
    for j, f in enumerate((0.35, 0.70, 0.95)):
        p = os.path.join(OUT, f"{sh.id}_{j}_new.png")
        compose.render_still(ctx, sh.start + sh.dur * f, p)
    print(sh.id, flush=True)
