"""Run engine/voice.py for hr on macOS: durations from a decode with the bundled ffmpeg."""
import asyncio, json, os, subprocess, sys
SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
SRC = os.path.normpath(SRC)
sys.path[:0] = [SRC, os.path.join(SRC, "engine")]
import voice  # noqa: E402
FF = os.environ.get("FFMPEG", "ffmpeg")

def duration(path):
    raw = subprocess.check_output([FF, "-v", "error", "-i", path, "-f", "s16le", "-ac", "1", "-ar", "48000", "-"])
    return len(raw) / 2 / 48000

voice.duration = duration
run = sys.argv[1] if len(sys.argv) > 1 else "hr"
asyncio.run(voice.build(run))
p = os.path.join(SRC, "build", run, "voice.json")
m = json.load(open(p))
for v in m:
    v["mp3"] = os.path.relpath(v["mp3"], SRC).replace(os.sep, "/")
json.dump(m, open(p, "w"), ensure_ascii=False, indent=1)
