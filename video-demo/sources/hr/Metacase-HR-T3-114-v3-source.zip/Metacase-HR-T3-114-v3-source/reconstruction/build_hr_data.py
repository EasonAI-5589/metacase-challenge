"""Reconstruct data/hr.json and data/hr.requests.jsonl from the published HR replay (v2, relay edition).

The original run export and session log were not available. Every value below is read off the
published video (assets/video/hr-agent-replay.mp4, SHA-256 15f71e8d…) with the engine's own drawing
rules, which are known exactly (engine/scenes_x.py, engine/panels.py, engine/rundata.py):

- request times: x positions of the 28 output-token bars in the 'whole run' chart (h16);
- tool-call times and kinds: the 44 dots of that chart (colour = Bash / TodoWrite / Read-Edit-Write),
  replaced by the exact times printed on screen where a scene shows them (h06, h07, h09, h10, h12, h13);
- output tokens: the run-ledger totals printed at 25 frames (exact) split inside each group by bar height;
- prompt tokens: 12 exact ledger values; the others from the prompt chart (h17), bias-corrected;
- plans, files and criteria: the plan card, file grid, 'agent found' card and rubric grid.
The result reproduces every ledger value read from the published frames (see check at the end).
"""
import json
import os
import sys
from datetime import datetime, timedelta, timezone

ROOT = sys.argv[1] if len(sys.argv) > 1 else "."

# ---------------------------------------------------------------------------------- requests
# (request, start time s, output tokens, prompt tokens)
REQ_T = [7.08, 12.5, 23.2, 31.2, 47.9, 65.5, 69.5, 203.7, 221.835, 243.8, 249.9, 258.2, 262.3, 268.3,
         271.6, 273.3, 281.8, 287.2, 291.4, 296.1, 304.9, 306.8, 312.8, 318.5, 325.3, 333.6, 342.3, 357.7]
OUT = [546, 636, 334, 700, 633, 1202, 19223, 79, 1957,
       688, 688, 138, 689,            # requests 10-13 = 2,203
       150, 150, 150, 448,            # requests 14-17 = 898
       402, 134, 134, 670, 671,       # requests 18-22 = 2,011
       233, 30,                       # requests 23-24
       735, 147, 736, 737]            # requests 25-28 = 2,355
assert sum(OUT) == 33040, sum(OUT)
EXACT_CTX = {1: 25021, 2: 26325, 3: 32073, 5: 45222, 7: 47859, 8: 67110, 9: 71351, 13: 76129,
             17: 78176, 23: 86699, 24: 87225, 28: 89340}
CHART_CTX = [25116, 26583, 32266, 32816, 45283, 46750, 48033, 67283, 71500, 73700, 75350, 76083, 76266,
             77183, 77366, 77366, 78283, 82683, 83416, 84333, 85433, 85433, 86900, 87450, 87633, 88550,
             88916, 89466]
anchors = sorted(EXACT_CTX)
def bias(k):
    lo = max([a for a in anchors if a <= k], default=anchors[0])
    hi = min([a for a in anchors if a >= k], default=anchors[-1])
    b = lambda a: CHART_CTX[a - 1] - EXACT_CTX[a]
    if lo == hi:
        return b(lo)
    return b(lo) + (b(hi) - b(lo)) * (k - lo) / (hi - lo)
CTX = [EXACT_CTX.get(k, int(round((CHART_CTX[k - 1] - bias(k)) / 10.0) * 10)) for k in range(1, 29)]

# ---------------------------------------------------------------------------------- materials
CSV = ["三时点情境测验答题明细", "中心月度运营指标", "主管范围与轮班花名册", "到课、补训与豁免事件",
       "带教约谈与行动承诺", "异常处置机会暴露日志", "异常工单生命周期", "设备、气象和货型扰动"]
XLSX = ["采购工作包与结算规则", "历史基准与同期参照", "训练单元和教学场次账", "现场处置行为编码", "证据完整性复核清单"]
DOCX = ["任务授权、伦理边界与决策权限", "学习数据最小使用规范"]
UNSEEN = ["Word material A (name not shown in the published video)",
          "Word material B (name not shown in the published video)"]
known = sorted([(n, "csv") for n in CSV] + [(n, "xlsx") for n in XLSX] + [(n, "docx") for n in DOCX])
# Grid order in the published frames: c c c d c x d c c / c x x d c x d x. The two unseen Word files
# sit after 训练单元和教学场次账 and after 证据完整性复核清单 respectively.
order = []
for name, kind in known:
    order.append((name, kind))
    if name == "训练单元和教学场次账":
        order.append((UNSEEN[0], "docx"))
    if name == "证据完整性复核清单":
        order.append((UNSEEN[1], "docx"))
ext = {"csv": ".csv", "xlsx": ".xlsx", "docx": ".docx"}
materials = [dict(name=n + ext[k], kind=k, opened_step=None) for n, k in order]
assert "".join({"csv": "c", "xlsx": "x", "docx": "d"}[m["kind"]] for m in materials) == "cccdcxdcccxxdcxdx"

# ---------------------------------------------------------------------------------- plans
def todos(statuses, labels):
    return [dict(text=l, status=s) for l, s in zip(labels, statuses)]
P7a = ["Read all source files", "Validate the samples", "Learning · opportunity · behaviour",
       "Trained vs delayed sites", "Package status and payments", "Excel workbook", "Word decision memo"]
P7b = ["Read all source files", "Build the analysis pipeline", "Learning · opportunity · behaviour",
       "Trained vs delayed sites", "Package status and payments", "Excel workbook", "Word decision memo"]
P8 = P7b + ["Validate the output files"]

# ---------------------------------------------------------------------------------- steps
steps = []
def step(i, t, tool=None, **kw):
    s = dict(i=i, t_s=t)
    if tool:
        s["tool"] = tool
    s.update(kw)
    steps.append(s)
    return s
step(0, 0.0, kind="start")
step(1, 7.5, "Bash"); step(2, 7.9, "Bash")
for j, t in enumerate([13.1, 13.4, 13.8, 14.1, 14.5, 14.9, 15.3, 16.5]):
    step(3 + j, t, "Bash", files=[CSV[[0, 1, 2, 3, 4, 5, 6, 7][j]] + ".csv"])
step(11, 25.4, "TodoWrite", todos=todos(["in_progress"] + ["pending"] * 6, P7a))
step(12, 29.0, kind="text")
reads45 = [n + ".xlsx" for n in XLSX] + [n + ".docx" for n in DOCX] + [u + ".docx" for u in UNSEEN]
for j, t in enumerate([32.4, 33.1, 34.0, 34.8, 35.5]):
    step(13 + j, t, "Bash", files=[reads45[j]])
step(18, 46.0, kind="text")
for j, t in enumerate([49.0, 49.4, 50.3, 50.5]):
    step(19 + j, t, "Bash", files=[reads45[5 + j]])
step(23, 66.9, "TodoWrite", todos=todos(["completed", "in_progress"] + ["pending"] * 5, P7b))
step(24, 199.8, "Write")
step(25, 202.0, kind="text")
step(26, 204.3, "Bash")
step(27, 223.8, "Bash"); step(28, 227.1, "Bash")
step(29, 244.4, "Read"); step(30, 252.4, "Edit"); step(31, 259.7, "Edit"); step(32, 265.4, "Edit")
step(33, 268.7, "Bash"); step(34, 271.8, "Read"); step(35, 275.3, "Edit")
step(36, 279.0, kind="text"); step(37, 280.5, kind="text")
step(38, 282.4, "Bash")
step(39, 288.0, "TodoWrite", todos=todos(["completed"] * 7 + ["in_progress"], P8))
for j, t in enumerate([292.1, 292.8, 296.6, 305.0, 307.2, 315.3, 318.6]):
    step(40 + j, t, "Bash")
step(47, 327.1, "Bash"); step(48, 335.1, "Bash")
step(49, 343.5, "TodoWrite", todos=todos(["completed"] * 8, P8))
step(50, 357.7, kind="text")
tool_steps = [s for s in steps if s.get("tool")]
assert len(tool_steps) == 44
# tools per request (by time: each tool belongs to the latest request that started before it)
req_tools = {k: [] for k in range(1, 29)}
for s in tool_steps:
    k = max(i + 1 for i, t in enumerate(REQ_T) if t <= s["t_s"])
    req_tools[k].append(s["tool"])
counts = [len(req_tools[k]) for k in range(1, 29)]
assert counts == [2, 8, 1, 5, 4, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 0], counts

# ---------------------------------------------------------------------------------- criteria
ids = ["R1"] + [f"R{n}" for n in range(3, 36)]
met = {"R7", "R9", "R11", "R18", "R20", "R22"}
penalties = {f"R{n}" for n in range(27, 33)}
criteria = []
for cid in ids:
    if cid in penalties:
        criteria.append(dict(id=cid, negate=True, value=0.0 if cid == "R32" else 1.0))
    else:
        criteria.append(dict(id=cid, value=1.0 if cid in met else 0.0))
for c in criteria:
    if c["id"] in ("R20", "R32"):
        c["weight"] = 7

data = dict(
    schema="inferencenet-protask-replay/1",
    partial=["reconstructed from the published v2 video; see provenance.method"],
    task=dict(key="HR", id="HR-T3-114", domain_en="HR", fictional=True,
              title_en="Cold-chain supervisor training: impact review and vendor acceptance",
              title_zh="冷链仓储一线主管异常处置训练成效与服务采购验收"),
    materials=materials,
    agent=dict(harness="Claude Code 2.1.114", runner="Harbor 0.20.0", requested_model="qwen3.7-max",
               session=dict(model_responses=28, duration_s=364.9), tool_calls=44, steps=steps),
    deliverables=dict(files=[
        dict(name="项目验收与整改决策备忘录.docx", bytes=41290, paragraphs=73, tables=3),
        dict(name="训练成效与验收决策工作簿.xlsx", bytes=23842, sheets=9)]),
    judging=dict(judge=dict(model="qwen3.7-plus", harness="RewardKit 0.1.7", api_requests=303),
                 criteria=criteria,
                 result=dict(reward=0.207547, positive_weight=106, passed_weight=29, penalty=7)),
    provenance=dict(
        method="Reconstructed from the published HR-T3-114 replay (relay v2 edition, assets/video/hr-agent-replay.mp4, "
               "SHA-256 15f71e8d0ab128a658c9f1fa7cf8ba96ee6a415d96d8969f475328eadf9cecb4). The original run export "
               "(SHA-256 5aa8822c…) and session log (SHA-256 9d20ca43…) were not available.",
        exact=["28 request count", "44 tool calls and kinds", "tool times printed on screen", "25 run-ledger readings",
               "12 prompt-token values", "plans", "deliverable metadata", "criteria results and totals"],
        approximate=["other request start times (±0.3 s, chart pixels)", "per-request output tokens inside each ledger group",
                     "other prompt-token values (±150 tokens, chart pixels)", "other tool times (±0.3 s)"],
        unknown=["names of two Word inputs", "individual criterion weights other than R20 and R32"]),
)
os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
with open(os.path.join(ROOT, "data", "hr.json"), "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=1)

# ---------------------------------------------------------------------------------- request log
t0 = datetime(2026, 10, 18, 9, 0, 0, tzinfo=timezone.utc)
ts = lambda s: (t0 + timedelta(seconds=s)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
rows = [dict(type="baseline", timestamp=ts(0.0))]
for k in range(1, 29):
    content = [dict(type="tool_use", name=n) for n in req_tools[k]]
    rows.append(dict(type="assistant", timestamp=ts(REQ_T[k - 1]),
                     message=dict(id=f"msg_hr_reconstructed_{k:02d}",
                                  usage=dict(input_tokens=CTX[k - 1], output_tokens=OUT[k - 1],
                                             cache_read_input_tokens=0, cache_creation_input_tokens=0),
                                  content=content)))
with open(os.path.join(ROOT, "data", "hr.requests.jsonl"), "w", encoding="utf-8") as f:
    for r in rows:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")
print("wrote", len(steps), "steps,", len(rows) - 1, "requests; ctx:", CTX)
