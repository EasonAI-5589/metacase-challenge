import glob, os
from PIL import Image
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "build", "hr")
for p in sorted(glob.glob(f"{D}/cmp/*_new.png")):
    k = os.path.basename(p)[:-8]
    a = Image.open(f"{D}/ref-frames/{k}.png").convert("RGB").resize((960, 540))
    b = Image.open(p).convert("RGB").resize((960, 540))
    c = Image.new("RGB", (960, 1080)); c.paste(a, (0, 0)); c.paste(b, (0, 540))
    c.save(f"{D}/cmp/{k}.jpg", quality=88)
