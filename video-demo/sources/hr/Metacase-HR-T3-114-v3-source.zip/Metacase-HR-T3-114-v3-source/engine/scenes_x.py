"""Special centre-panel scenes: task setup, container, fan-out, file montage, error anatomy,
whole-run trace, handoff to the judge and the scoring views. Data come from the shot payload."""
from __future__ import annotations

import math

import gfx as G
import ui as U
from scenes import cue, after, loop_frame, SCENES, FULL

IX0, IX1 = 502, 1418  # inner content x range of the centre panel


def frame(cv, a, title, sub, rq="", accent=None, accent_a=0.0, title_c=None):
    U.panel(cv, U.CX, U.PANEL_Y, U.CW, U.BOT - U.PANEL_Y, a=a, accent=accent, accent_a=accent_a)
    G.text(cv, title, IX0, 226, size=31, c=title_c or G.HARNESS, weight=600, a=a, ls=-0.4)
    if sub:
        G.text(cv, sub, IX0, 270, size=19.5, c=G.FG, a=a, maxlines=1, width=780)
    if rq:
        G.text(cv, rq, IX1, 238, size=16, c=G.FG, kind="mono", a=a, align="right", ls=1.0)


# ============================================================================ TASK chapter
def draw_task(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, d.get("title", "The task"), d.get("sub", ""), d.get("rq", ""), title_c=G.BRAND)
    # lock-clock badge
    kb = after(sh, t, 0.0, 0.5)
    G.rrect(cv, IX0, 314, 430, 46, 23, fill=G.BRAND_TINT, stroke=G.BRAND, sw=1.4, a=a * kb)
    G.icon_lock(cv, IX0 + 28, 337, G.BRAND, a=a * kb, s=9)
    G.text(cv, d["deadline"], IX0 + 50, 325, size=17, c=G.FG, kind="mono", a=a * kb)
    G.text(cv, d.get("badge_r", ""), IX1, 325, size=15, c=G.DIM, kind="mono", a=a * kb, align="right")
    items = d["items"]
    cols = 3
    cw = (IX1 - IX0 - 2 * 20) / cols
    ch_ = 186
    for j, it in enumerate(items):
        r, c = divmod(j, cols)
        x = IX0 + c * (cw + 20)
        y = 384 + r * (ch_ + 18)
        k = a * G.ease(G.seg(t, cue(sh, d.get("items_at", 0.0)) + j * 0.16, cue(sh, d.get("items_at", 0.0)) + j * 0.16 + 0.45))
        if k <= 0.01:
            continue
        yy = y + (1 - k) * 18
        G.rrect(cv, x, yy, cw, ch_, 12, fill=(13, 18, 26), fa=0.96, stroke=G.EDGE, sw=1.4, a=k)
        G.text(cv, it["id"], x + 16, yy + 14, size=17, c=G.MODEL, weight=700, kind="mono", a=k)
        U.pill(cv, it["obj"], x + cw - 14, yy + 12, G.DIM, a=k, size=12.5, align="right")
        G.text(cv, it["title"], x + 16, yy + 44, size=15.5, c=G.FG, a=k, width=cw - 32, maxlines=3)
        G.text(cv, it.get("amount", ""), x + 16, yy + ch_ - 64, size=15, c=G.DIM, kind="mono", a=k)
        G.text(cv, it.get("tag", "unposted"), x + cw - 16, yy + ch_ - 64, size=13, c=G.WARN, kind="mono", a=k, align="right")
        kc = a * G.ease(G.seg(t, cue(sh, d.get("choice_at", 99)) + j * 0.12, cue(sh, d.get("choice_at", 99)) + j * 0.12 + 0.4))
        if kc > 0.01:
            cx_ = x + 16
            for lab in d.get("choices", ("accept", "replace", "reject")):
                w = U.pill(cv, lab, cx_, yy + ch_ - 36, G.BRAND, a=kc, size=12.5)
                cx_ += w + 8
            pulse = 0.6 + 0.4 * math.sin((t - cue(sh, d["choice_at"])) * 5)
            G.text(cv, "?", x + cw - 22, yy + ch_ - 40, size=22, c=G.WARN, weight=700, a=kc * pulse, align="center")


def draw_limits(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, d.get("title", "What the brief asks"), d.get("sub", ""), title_c=G.BRAND)
    y = 330
    for j, (en, zh) in enumerate(d["brief"]):
        k = a * G.ease(G.seg(t, 0.2 + j * 0.35, 0.65 + j * 0.35))
        G.circle(cv, IX0 + 10, y + 13, 4.5, fill=G.BRAND, a=k)
        G.text(cv, en, IX0 + 30, y, size=19, c=G.FG, a=k, maxlines=1, width=880)
        # v3 (English only): the grey line quoted the Chinese brief; its English
        # rendering repeats the bullet above, so the English edition omits it.
        y += 64
    # reviewer capacity
    k1 = a * after(sh, t, "one", 0.5)
    by = 680
    G.rrect(cv, IX0, by, IX1 - IX0, 150, 12, fill=(13, 18, 26), fa=0.96, stroke=G.EDGE, sw=1.4, a=k1)
    G.kicker(cv, "INDEPENDENT REVIEW CAPACITY", IX0 + 20, by + 18, c=G.WARN, a=k1, size=13.5)
    # person glyph
    px, py = IX0 + 60, by + 92
    G.circle(cv, px, py - 18, 12, fill=G.WARN, a=k1)
    G.rrect(cv, px - 20, py - 2, 40, 30, 12, fill=G.WARN, a=k1)
    G.text(cv, "1 reviewer", px, py + 34, size=14, c=G.FG, kind="mono", a=k1, align="center")
    k2 = after(sh, t, "hrs", 0.6)
    for j, day in enumerate(("4 Aug", "5 Aug")):
        x = IX0 + 150 + j * 380
        G.rrect(cv, x, by + 56, 350, 40, 8, stroke=(52, 62, 80), sw=1.3, a=k1)
        G.rrect(cv, x, by + 56, 350 * k2, 40, 8, fill=G.mix(G.PANEL, G.WARN, 0.35), a=a * k2)
        G.text(cv, f"{day} · at most 6 h", x + 16, by + 66, size=16, c=G.FG, kind="mono", a=k1)
    G.text(cv, "= 12 h before the books lock", IX0 + 150, by + 110, size=15, c=G.WARN, kind="mono", a=a * k2)


def container(cv, a, x, y, w, h, label="Docker container · Harbor 0.20.0", hi=0.0, dim=0.0):
    G.rrect(cv, x, y, w, h, 16, fill=G.mix(G.PANEL, G.SANDBOX, 0.03), fa=0.6, a=a)
    G.rrect(cv, x, y, w, h, 16, stroke=G.SANDBOX, sw=1.6 + hi, a=a * (0.55 + 0.4 * hi) * (1 - 0.5 * dim), dash=(9, 7))
    G.icon_role(cv, "sandbox", x + 24, y + 22, G.SANDBOX, a=a, s=8)
    G.text(cv, label, x + 44, y + 12, size=14, c=G.SANDBOX, kind="mono", a=a, ls=1.0)


def file_grid(cv, ctx, x, y, cols, tw, th, gap, a, lit=None, appear=1.0, show_nums=True, hot=None):
    mats = ctx.run.materials
    n = len(mats)
    for j, m in enumerate(mats):
        r, c = divmod(j, cols)
        k = a * G.ease(G.clamp(appear * n * 1.0 - j * 1.0 + 1))
        if k <= 0.01:
            continue
        kind = m["kind"]
        col = G.FILE_COLORS.get(kind, G.DIM)
        on = (lit is None) or (m["name"] in lit)
        fx = x + c * (tw + gap)
        fy = y + r * (th + gap)
        alpha = k * (1.0 if on else 0.32)
        if hot and m["name"] == hot[0] and hot[1] > 0.01:
            G.glow(cv, fx, fy, tw, th, 6, col, a=0.6 * hot[1] * a, sigma=10)
        G.rrect(cv, fx, fy, tw, th, 6, fill=G.mix(G.PANEL, col, 0.22 if on else 0.05), stroke=G.mix(G.EDGE, col, 0.8 if on else 0.25), sw=1.2, a=alpha)
        if show_nums:
            num = m["name"].split("_")[0] if m["name"][:2].isdigit() else ""
            G.text(cv, num or kind[:3].upper(), fx + tw / 2, fy + 6, size=13, c=G.FG if on else G.DIM, kind="mono", a=alpha, align="center")
            G.text(cv, kind.upper(), fx + tw / 2, fy + th - 18, size=10, c=col, kind="mono", a=alpha, align="center")


def io_layout(cv, sh, t, a, ctx, with_tests=False):
    d = sh.d
    frame(cv, a, d.get("title", "The environment"), d.get("sub", ""), title_c=G.BRAND)
    conf = ctx.conf
    cw = 680
    container(cv, a, IX0, 314, cw, 520)
    G.text(cv, "claude 2.1.114 · python3 · LibreOffice", IX0 + cw - 20, 326, size=12.5, c=G.DIM, kind="mono", a=a, align="right")
    lab = f"/app/input_files · {conf['inputs']} files · read-only"
    G.icon_folder(cv, IX0 + 24, 364, w=24, h=18, c=G.BRAND, a=a)
    G.text(cv, lab, IX0 + 58, 364, size=15, c=G.FG, kind="mono", a=a)
    G.icon_lock(cv, IX0 + 58 + G.measure(lab, 15, 500, "mono")[0] + 20, 374, G.DIM, a=a, s=7)
    appear = G.seg(t, cue(sh, d.get("files_at", 0.0)) - 1.2, cue(sh, d.get("files_at", 0.0)) + 1.8)
    cols = d.get("cols", 11)
    tw = d.get("tw", 50)
    file_grid(cv, ctx, IX0 + 24, 398, cols, tw, 48, 8, a, appear=appear)
    kinds = {}
    for m in ctx.run.materials:
        kinds[m["kind"]] = kinds.get(m["kind"], 0) + 1
    lx = IX0 + 24
    ly = 398 + ((len(ctx.run.materials) + cols - 1) // cols) * 56 + 4
    for kind, n in sorted(kinds.items(), key=lambda kv: -kv[1]):
        col = G.FILE_COLORS.get(kind, G.DIM)
        G.rrect(cv, lx, ly + 4, 12, 12, 3, fill=col, a=a * appear)
        tw_, _ = G.text(cv, f"{kind.upper()} {n}", lx + 18, ly, size=14, c=G.DIM, kind="mono", a=a * appear)
        lx += tw_ + 36
    ko = after(sh, t, d.get("out_at", 99), 0.5) if not with_tests else 1.0
    oy = ly + 46
    if ko > 0.01:
        G.icon_folder(cv, IX0 + 24, oy, w=24, h=18, c=G.SANDBOX, a=a * ko)
        G.text(cv, "/app/output", IX0 + 58, oy, size=15, c=G.FG, kind="mono", a=a * ko)
        for j, (kind, lab2) in enumerate(conf.get("deliverables", [("docx", "Word report"), ("xlsx", "Excel workbook")])):
            xx = IX0 + 24 + j * 326
            yy = oy + 30
            base = cue(sh, d.get("out_at", 0.0)) if not with_tests else -1.0
            kj = a * G.ease(G.seg(t, base + 0.3 * j, base + 0.3 * j + 0.5))
            G.rrect(cv, xx, yy, 316, 60, 10, stroke=G.FILE_COLORS[kind], sw=1.4, a=kj, dash=(6, 5))
            G.icon_file(cv, xx + 12, yy + 9, kind, a=kj, w=30, h=40)
            G.text(cv, lab2, xx + 54, yy + 9, size=16, c=G.FG, weight=600, a=kj)
            G.text(cv, "written by the agent", xx + 54, yy + 33, size=12.5, c=G.DIM, kind="mono", a=kj)


def draw_io(cv, sh, t, a, ctx):
    io_layout(cv, sh, t, a, ctx, with_tests=False)


def tests_card(cv, a, x, y, w, h, k_lock, conf, inside=0.0, foot=None, foot_a=1.0):
    G.rrect(cv, x, y, w, h, 14, fill=(14, 18, 27), fa=0.97, stroke=G.SCORER, sw=1.6, a=a)
    G.icon_lock(cv, x + w / 2, y + 52, G.SCORER, a=a, s=16, opened=1 - k_lock)
    G.text(cv, "tests/", x + w / 2, y + 86, size=22, c=G.FG, weight=600, kind="mono", a=a, align="center")
    lines = conf.get("tests_lines", ["rubric · criteria", "reference solution"])
    for j, ln in enumerate(lines):
        G.text(cv, ln, x + w / 2, y + 126 + j * 26, size=13.5, c=G.DIM, kind="mono", a=a, align="center")
    if foot:
        for j, ln in enumerate(foot):
            G.text(cv, ln, x + w / 2, y + h - 66 + j * 24, size=13.5, c=G.SCORER, kind="mono", a=a * foot_a, align="center")


def draw_sealed(cv, sh, t, a, ctx):
    d = sh.d
    io_layout(cv, sh, t, a, ctx, with_tests=True)
    k = after(sh, t, 0.0, 0.6)
    kl = after(sh, t, "lock", 0.5)
    x = IX0 + 702
    G.text(cv, "OUTSIDE THE CONTAINER", x + (IX1 - x) / 2, 326, size=12.5, c=G.SCORER, kind="mono", a=a * k, align="center", ls=1.2)
    tests_card(cv, a * k, x, 360, IX1 - x, 330, kl, ctx.conf, foot=("copied in only", "after the agent stops") if kl > 0.01 else None, foot_a=kl)


# ============================================================================ AGENT chapter specials
def draw_fanout(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, "Claude Code · tool loop", d.get("sub", ""), d.get("rq", ""), accent=G.HARNESS, accent_a=0.35)
    lanes = d["lanes"]
    n = len(lanes)
    t_one, t_n, t_back = cue(sh, d.get("c_one", 0.0)), cue(sh, d.get("c_n", 0.0)), cue(sh, d.get("c_back", 0.0))
    # model box
    mx, my, mw, mh = IX0, 330, 190, 96
    km = a
    act_m = G.fade_io(t, t_one - 0.2, t_n + 0.6, 0.3) + G.ease(G.seg(t, t_back + 0.8, t_back + 1.2))
    act_m = min(1.0, act_m)
    G.glow(cv, mx, my, mw, mh, 12, G.MODEL, a=0.3 * act_m * a, sigma=14)
    G.rrect(cv, mx, my, mw, mh, 12, fill=G.mix((13, 18, 26), G.MODEL, 0.1 * act_m), stroke=G.mix(G.EDGE, G.MODEL, 0.3 + 0.7 * act_m), sw=1.5 + act_m, a=km)
    G.text(cv, "MODEL", mx + 16, my + 14, size=13.5, c=G.MODEL, weight=600, kind="mono", a=km, ls=1.4)
    G.text(cv, "1 response", mx + 16, my + 38, size=19, c=G.FG, weight=600, a=km)
    G.text(cv, f"{n} tool calls", mx + 16, my + 64, size=14, c=G.DIM, kind="mono", a=km)
    # harness column
    hx = IX0 + 250
    LH = 72 if n <= 4 else 44
    BH = 52 if n <= 4 else 38
    G.rrect(cv, hx, 314, 640 + (IX1 - IX0 - 890), 30 + n * LH + 20, 14, stroke=G.SANDBOX, sw=1.3, a=a * 0.5, dash=(8, 6))
    G.text(cv, "inside the Docker container · Claude Code runs each call with Bash", hx + 16, 322, size=12.5, c=G.SANDBOX, kind="mono", a=a * 0.85)
    T0, T1 = d["trace"]
    tr = sh.trace_at(t)
    for j, ln in enumerate(lanes):
        y = 352 + j * LH
        kj = a * G.ease(G.seg(t, t_n + j * 0.14, t_n + j * 0.14 + 0.35))
        # fan line
        path = G.rounded_path([(mx + mw, my + mh / 2), (mx + mw + 24, my + mh / 2), (mx + mw + 24, y + BH / 2), (hx + 14, y + BH / 2)], 10)
        G.draw_path(cv, path, G.mix((60, 72, 92), G.HARNESS, 0.6), sw=1.8, a=kj, upto=G.ease(G.seg(t, t_n + j * 0.14, t_n + j * 0.14 + 0.5)))
        # call chip + command
        G.rrect(cv, hx + 14, y, 86, BH, 9, fill=G.mix((13, 18, 26), G.HARNESS, 0.12), stroke=G.HARNESS, sw=1.4, a=kj)
        if n <= 4:
            G.text(cv, "Bash", hx + 57, y + 8, size=15, c=G.HARNESS, weight=600, kind="mono", a=kj, align="center")
            G.text(cv, f"step {ln['step']}", hx + 57, y + 29, size=12, c=G.DIM, kind="mono", a=kj, align="center")
        else:
            G.text(cv, f"Bash · {ln['step']}", hx + 57, y + 10, size=13, c=G.HARNESS, weight=600, kind="mono", a=kj, align="center")
        bx = hx + 116
        bw = IX1 - 24 - bx
        G.rrect(cv, bx, y, bw, BH, 9, fill=(10, 14, 20), stroke=G.EDGE, sw=1.2, a=kj)
        G.text(cv, ln["cmd"], bx + 14, y + (7 if n <= 4 else 4), size=13.5 if n <= 4 else 13, c=(196, 204, 216), kind="mono", a=kj, maxlines=1, width=bw - 110)
        # progress from the recorded start/end
        s0, s1 = ln["t0"], ln["t1"]
        if tr is not None and tr >= s1:
            f = 1.0
        elif tr is not None and tr >= s0:
            f = G.clamp((tr - s0) / max(0.05, s1 - s0))
        else:
            f = 0.0
        py_ = y + (34 if n <= 4 else 26)
        G.rrect(cv, bx + 14, py_, bw - 120, 5, 2.5, fill=(32, 40, 54), a=kj)
        G.rrect(cv, bx + 14, py_, (bw - 120) * f, 5, 2.5, fill=G.SANDBOX, a=kj)
        st = "exit 0" if f >= 1 else (f"+{s0:.1f} s" if f > 0 else "queued")
        G.text(cv, st, bx + bw - 14, y + (26 if n <= 4 else 11), size=13, c=G.SANDBOX if f >= 1 else G.DIM, kind="mono", a=kj, align="right")
    # merge back
    kb = G.ease(G.seg(t, t_back, t_back + 0.9))
    ry = 352 + n * LH + 10
    if kb > 0.01:
        G.rrect(cv, hx + 116, ry, IX1 - 24 - hx - 116, 40, 10, fill=G.mix(G.PANEL, G.BRAND, 0.12), stroke=G.BRAND, sw=1.4, a=a * kb)
        G.text(cv, d.get("merge", "all results go back together in the next request"), hx + 132, ry + 10, size=14.5, c=G.BRAND, kind="mono", a=a * kb)
        path = G.rounded_path([(hx + 116, ry + 20), (mx + mw / 2, ry + 20), (mx + mw / 2, my + mh + 4)], 14)
        G.draw_path(cv, path, G.BRAND, sw=2, a=a * kb, upto=kb)
        if kb >= 0.99:
            G.arrow_head(cv, mx + mw / 2, my + mh + 4, -math.pi / 2, G.BRAND, size=9, a=a)
        fpk = G.seg(t, t_back + 0.2, t_back + 1.3)
        if 0 < fpk < 1:
            (px, py), _ = G.path_point(path, G.ease_in_out(fpk))
            G.packet(cv, px, py, G.BRAND, a=a)
    if d.get("foot"):
        fx, fw = (752, 300) if sh.id in ("f09", "h06") else (IX0, 640)
        G.text(cv, d["foot"], fx, 744 if n <= 4 else 780, size=15, c=G.DIM, kind="mono", a=a,
               maxlines=None if sh.id in ("f09", "h06") else 1, width=fw)


def draw_montage(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, "Claude Code · tool loop", d.get("sub", ""), d.get("rq", ""), accent=G.SANDBOX, accent_a=0.3)
    T = sh.trace_at(t)
    opened = ctx.run.files_opened(T) if T is not None else []
    cols = 11
    gx, gy = IX0, 322
    # recently opened file (for the glow)
    recent = None
    for s in ctx.run.steps:
        if s["t_s"] <= (T or 0) and s.get("files"):
            recent = (s["files"][-1], s["t_s"])
    hot = (recent[0], max(0.0, 1 - ((T or 0) - recent[1]) / 3.0)) if recent else None
    file_grid(cv, ctx, gx, gy, cols, 76, 48, 8, a, lit=set(opened), hot=hot)
    rows = (len(ctx.run.materials) + cols - 1) // cols
    # ticker of the latest opened files
    ty = gy + rows * 56 + 14
    G.kicker(cv, "LATEST OPENED · file names in recorded commands", IX0, ty, c=G.SANDBOX, a=a, size=13)
    recents = []
    for s in ctx.run.steps:
        if T is not None and s["t_s"] <= T:
            for f in s.get("files") or []:
                if f not in [r[0] for r in recents]:
                    recents.append((f, s["t_s"], s["i"]))
    for j, (f, ts, si) in enumerate(reversed(recents[-4:])):
        al = a * (1.0 - 0.18 * j)
        G.text(cv, f"+{ts:05.1f} s", IX0, ty + 28 + j * 26, size=14, c=G.DIM, kind="mono", a=al)
        G.text(cv, f"step {si}", IX0 + 100, ty + 28 + j * 26, size=14, c=G.DIM, kind="mono", a=al)
        G.text(cv, f, IX0 + 180, ty + 28 + j * 26, size=14.5, c=G.FG if j == 0 else (180, 188, 200), kind="mono", a=al, maxlines=1, width=560)
    kc = after(sh, t, d.get("count_at", 99), 0.5)
    cx_ = IX1 - 120
    G.text(cv, f"{len(opened)}", cx_, ty + 14, size=64, c=G.SANDBOX, weight=600, a=a * (0.35 + 0.65 * kc), align="center")
    G.text(cv, f"of {len(ctx.run.materials)} opened", cx_, ty + 92, size=15, c=G.DIM, kind="mono", a=a, align="center")


def draw_valobs(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, "Observation · step 40", d.get("sub", ""), d.get("rq", ""), title_c=G.BRAND, accent=G.BRAND, accent_a=0.3)
    pts = d["points"]  # (label, value, key)
    vmin = min(v for _, v, _ in pts)
    x0, x1 = IX0 + 90, IX1 - 260
    y0 = 400
    H_ = 340
    G.text(cv, "当日MTM_元 · IRS-2026-0031 · from 12_衍生品交易与逐日估值明细", IX0, 318, size=13.5, c=G.DIM, kind="mono", a=a)
    G.line(cv, [(x0 - 40, y0), (x1 + 40, y0)], (60, 72, 92), sw=1.6, a=a)
    G.text(cv, "0", x0 - 56, y0 - 10, size=13, c=G.DIM, kind="mono", a=a, align="right")
    n = len(pts)
    bw = 70
    pos = {}
    for j, (lab, v, key) in enumerate(pts):
        x = x0 + j * (x1 - x0) / (n - 1)
        h = H_ * v / vmin
        hl = after(sh, t, key, 0.5) if key else 0.0
        col = G.mix(G.FAINT, G.MODEL, hl) if key else G.FAINT
        k = a * G.ease(G.seg(t, 0.1 + j * 0.15, 0.6 + j * 0.15))
        G.rrect(cv, x - bw / 2, y0, bw, h * k, 6, fill=col, a=a * (0.55 + 0.45 * hl))
        G.text(cv, lab, x, y0 - 30, size=14, c=G.FG if key else G.DIM, kind="mono", a=a, align="center")
        G.text(cv, G_fmt(v), x, y0 + h * k + 10, size=17 if key else 14, c=G.FG if key else G.DIM, weight=600 if key else 500, kind="mono", a=a * (0.4 + 0.6 * k), align="center")
        pos[key] = (x, y0 + h)
    kd = after(sh, t, d.get("delta_at", 99), 0.6)
    if kd > 0.01 and "a" in pos and "b" in pos:
        xa, ya = pos["a"]
        xb, yb = pos["b"]
        bx = x1 + 120
        G.line(cv, [(xa + bw / 2 + 6, ya), (bx, ya)], G.MODEL, sw=1.4, a=a * kd, dash=(5, 5))
        G.line(cv, [(xb + bw / 2 + 6, yb), (bx, yb)], G.MODEL, sw=1.4, a=a * kd, dash=(5, 5))
        G.line(cv, [(bx, ya), (bx, ya + (yb - ya) * kd)], G.MODEL, sw=2.4, a=a)
        G.arrow_head(cv, bx, ya + (yb - ya) * kd, math.pi / 2, G.MODEL, size=10, a=a * kd)
        G.text(cv, "July change", bx + 18, (ya + yb) / 2 - 30, size=15, c=G.DIM, kind="mono", a=a * kd)
        G.text(cv, d["delta"], bx + 18, (ya + yb) / 2 - 6, size=24, c=G.MODEL, weight=600, a=a * kd)
    if d.get("foot"):
        G.text(cv, d["foot"], IX0, 770, size=15, c=G.DIM, kind="mono", a=a,
               maxlines=None if sh.id == "f14" else 1, width=240 if sh.id == "f14" else 916)


def G_fmt(v):
    s = f"{abs(v):,.2f}"
    return ("−" if v < 0 else "") + s


def draw_notsaved(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, "Why nothing was saved", d.get("sub", ""), d.get("rq", ""), title_c=G.FAIL, accent=G.FAIL, accent_a=0.3)
    steps_ = d["flow"]  # (label, sub, state)
    n = len(steps_)
    gap = 22
    bw = (IX1 - IX0 - gap * (n - 1)) / n
    y = 344
    for j, (lab, sub, st) in enumerate(steps_):
        x = IX0 + j * (bw + gap)
        k = a * G.ease(G.seg(t, 0.15 + j * 0.25, 0.55 + j * 0.25))
        col = {"ok": G.SANDBOX, "print": G.FG, "fail": G.FAIL, "never": G.DIM}[st]
        kf = after(sh, t, "crash", 0.4) if st == "fail" else 0.0
        shake = math.sin(t * 40) * 3 * G.fade_io(t, cue(sh, "crash"), cue(sh, "crash") + 0.5, 0.1) if st == "fail" else 0
        if st == "never":
            kn = after(sh, t, "none", 0.5)
            G.rrect(cv, x, y, bw, 120, 12, stroke=G.DIM, sw=1.6, a=k, dash=(7, 6))
            G.text(cv, lab, x + bw / 2, y + 30, size=17, c=G.DIM, weight=600, kind="mono", a=k, align="center")
            G.text(cv, sub, x + bw / 2, y + 64, size=14, c=G.DIM, kind="mono", a=k, align="center", width=None)
            if kn > 0.01:
                G.stamp(cv, "NOT REACHED", x + bw / 2, y + 160, G.FAIL, a=a * kn, size=20, rot=-6)
        else:
            if kf > 0.01:
                G.glow(cv, x + shake, y, bw, 120, 12, G.FAIL, a=0.4 * kf * a, sigma=16)
            G.rrect(cv, x + shake, y, bw, 120, 12, fill=G.mix((13, 18, 26), col, 0.08), stroke=G.mix(G.EDGE, col, 0.8), sw=1.6, a=k)
            G.text(cv, lab, x + bw / 2 + shake, y + 30, size=17, c=col, weight=600, kind="mono", a=k, align="center")
            G.text(cv, sub, x + bw / 2 + shake, y + 64, size=14, c=G.DIM, kind="mono", a=k, align="center")
        if j < n - 1:
            ax = x + bw + 3
            G.arrow_head(cv, ax + gap - 6, y + 60, 0, (80, 92, 112), size=8, a=k)
            G.line(cv, [(ax, y + 60), (ax + gap - 8, y + 60)], (80, 92, 112), sw=1.6, a=k)
    # file on disk
    kr = after(sh, t, "rows", 0.5)
    fy = 600
    G.rrect(cv, IX0, fy, IX1 - IX0, 150, 12, fill=(13, 18, 26), fa=0.96, stroke=G.mix(G.EDGE, G.WARN, 0.4 + 0.6 * kr), sw=1.5, a=a)
    G.icon_file(cv, IX0 + 22, fy + 22, "xlsx", a=a, w=40, h=50)
    G.text(cv, "/app/output/" + ctx.conf["xlsx"], IX0 + 80, fy + 20, size=16, c=G.FG, weight=600, kind="mono", a=a, maxlines=1, width=760)
    G.text(cv, "on disk: unchanged since step 43", IX0 + 80, fy + 48, size=14, c=G.DIM, kind="mono", a=a)
    for j, (sheet, rows_) in enumerate(d["sheets"]):
        x = IX0 + 80 + j * 300
        G.rrect(cv, x, fy + 84, 280, 44, 8, fill=G.mix(G.PANEL, G.WARN, 0.12 * kr), stroke=G.mix(G.EDGE, G.WARN, kr), sw=1.4, a=a)
        G.text(cv, sheet, x + 14, fy + 96, size=15, c=G.FG, a=a)
        G.text(cv, rows_, x + 266, fy + 96, size=15, c=G.WARN if kr > 0.5 else G.DIM, kind="mono", weight=600, a=a, align="right")
    G.text(cv, d.get("foot", ""), IX0, 778, size=15, c=G.DIM, kind="mono", a=a, maxlines=1, width=916)


def draw_moveon(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, "Claude Code · tool loop", d.get("sub", ""), d.get("rq", ""), accent=G.SANDBOX, accent_a=0.3)
    # left: three requests
    y = 330
    for j, (rq, what, res, at) in enumerate(d["reqs"]):
        k = a * after(sh, t, at, 0.45)
        G.rrect(cv, IX0, y, 360, 92, 10, fill=(13, 18, 26), fa=0.96, stroke=G.EDGE, sw=1.3, a=k)
        G.text(cv, rq, IX0 + 16, y + 12, size=13, c=G.MODEL, weight=600, kind="mono", a=k, ls=1.2)
        G.text(cv, what, IX0 + 16, y + 36, size=16.5, c=G.FG, weight=600, a=k, maxlines=1, width=330)
        G.text(cv, res, IX0 + 16, y + 62, size=13.5, c=G.SANDBOX, kind="mono", a=k, maxlines=1, width=330)
        y += 106
    # right: the report outline
    kd = after(sh, t, d.get("doc_at", 99), 0.5)
    rx, ry, rw, rh = IX0 + 390, 330, IX1 - IX0 - 390, 404
    G.rrect(cv, rx, ry, rw, rh, 12, fill=(16, 20, 28), fa=0.98, stroke=G.mix(G.EDGE, G.FILE_COLORS["docx"], 0.6), sw=1.4, a=a * kd)
    G.icon_file(cv, rx + 16, ry + 14, "docx", a=a * kd, w=30, h=38)
    G.text(cv, ctx.conf["docx"], rx + 58, ry + 14, size=14.5, c=G.FG, weight=600, a=a * kd, maxlines=1, width=rw - 74)
    G.text(cv, "188 paragraphs · 6 tables · 52 headings", rx + 58, ry + 36, size=12.5, c=G.DIM, kind="mono", a=a * kd)
    G.text(cv, "三、各项意见处置详情", rx + 18, ry + 70, size=16, c=G.FG, weight=600, a=a * kd)
    for j, (sec, decision, note) in enumerate(d["sections"]):
        kj = a * G.ease(G.seg(t, cue(sh, d.get("sec_at", 99)) + j * 0.22, cue(sh, d.get("sec_at", 99)) + j * 0.22 + 0.4)) * kd
        yy = ry + 102 + j * 48
        G.text(cv, sec, rx + 18, yy + 4, size=15, c=G.FG, kind="mono", a=kj)
        w = U.pill(cv, decision, rx + 110, yy, G.BRAND, a=kj, size=13)
        G.text(cv, note, rx + 120 + w, yy + 4, size=13.5, c=G.DIM, a=kj, maxlines=1, width=rw - 140 - w)
    G.text(cv, d.get("foot", ""), IX0, 760, size=15, c=G.DIM, kind="mono", a=a,
           maxlines=None if sh.id == "f18" else 1, width=240 if sh.id == "f18" else 916)


def draw_quote(cv, sh, t, a, ctx):
    q, tag = sh.d["quote"]
    k = after(sh, t, "q", 0.5)
    if k <= 0.01:
        return
    x, y, w, h = U.CARD_X[0], U.CARD_Y, U.CARD_X[2] + U.CARD_W - U.CARD_X[0], U.CARD_H
    G.glow(cv, x, y, w, h, 14, G.MODEL, a=0.18 * k * a, sigma=18)
    G.rrect(cv, x, y, w, h, 14, fill=G.mix((13, 18, 26), G.MODEL, 0.06), fa=0.98, stroke=G.MODEL, sw=1.8, a=a * k)
    G.kicker(cv, "MODEL · TEXT IN ITS REPLY", x + 22, y + 20, c=G.MODEL, a=a * k, size=13.5)
    G.text(cv, "“" + q + "”", x + 22, y + 56, size=27, c=G.WHITE, weight=600, a=a * k, width=w - 44)
    G.text(cv, tag, x + 22, y + h - 38, size=14, c=G.DIM, kind="mono", a=a * k)


import scenes as _S  # noqa: E402
_S.OVERLAYS["quote"] = draw_quote


# ============================================================================ HARNESS chapter
def trace_axes(cv, a, x0, x1, dur, y_top, y_bot):
    for s in range(0, int(dur) + 1, 60):
        x = x0 + (x1 - x0) * s / dur
        G.line(cv, [(x, y_top), (x, y_bot)], (30, 38, 50), sw=1, a=a)
        G.text(cv, f"{s} s", x, y_bot + 8, size=12.5, c=G.DIM, kind="mono", a=a, align="center")


def draw_trace(cv, sh, t, a, ctx):
    d = sh.d
    run = ctx.run
    frame(cv, a, d.get("title", "The whole run"), d.get("sub", ""), d.get("rq", ""), accent=G.HARNESS, accent_a=0.3)
    x0, x1 = IX0 + 150, IX1 - 10
    dur = run.duration
    sweep = G.ease(G.seg(t, 0.1, 2.4))
    cut = dur * sweep
    X = lambda s: x0 + (x1 - x0) * s / dur
    trace_axes(cv, a, x0, x1, dur, 330, 640)
    # phase bands
    for (s0, s1, lab) in d.get("phases_", []):
        G.rrect(cv, X(s0), 318, X(s1) - X(s0), 20, 4, fill=(26, 34, 46), a=a)
        G.text(cv, lab, (X(s0) + X(s1)) / 2, 320, size=12, c=G.DIM, kind="mono", a=a, align="center", maxlines=1, width=None)
    # model lane: generation windows sized by output tokens
    G.text(cv, "model", IX0, 368, size=15, c=G.MODEL, kind="mono", a=a)
    G.text(cv, "output tokens", IX0, 388, size=11.5, c=G.DIM, kind="mono", a=a)
    maxo = max(r["out"] for r in run.requests)
    for r in run.requests:
        if r["t"] > cut:
            continue
        h = 8 + 70 * r["out"] / maxo
        G.rrect(cv, X(r["t"]) - 3, 430 - h, 6, h, 2, fill=G.MODEL, a=a * 0.9)
    G.line(cv, [(x0, 432), (x1, 432)], (52, 62, 80), sw=1, a=a)
    # tool lane
    G.text(cv, "tools", IX0, 470, size=15, c=G.SANDBOX, kind="mono", a=a)
    by_t = {}
    for s in run.tool_steps:
        if s["t_s"] > cut:
            continue
        key = s["req"]
        by_t.setdefault(key, 0)
        stack = by_t[key]
        by_t[key] += 1
        col = {"Bash": G.SANDBOX, "TodoWrite": G.HARNESS}.get(s["tool"], G.WARN)
        if s.get("is_error"):
            col = G.FAIL
        G.circle(cv, X(s["t_s"]), 470 + stack * 15, 5.5, fill=col, a=a)
    # markers
    for mi, (ts, lab, role, at) in enumerate(d.get("marks", [])):
        km = after(sh, t, at, 0.5)
        if km <= 0.01 or ts > cut:
            continue
        x = X(ts)
        c = G.ROLE[role]
        yl = 572 + (mi % 2) * 24
        G.line(cv, [(x, 350), (x, yl - 4)], c, sw=1.4, a=a * km, dash=(4, 4))
        G.text(cv, lab, x, yl, size=13, c=c, kind="mono", a=a * km, align="center")
    # legend + counts
    k2 = after(sh, t, d.get("count_at", 99), 0.5)
    y = 690
    for j, (lab, n, role) in enumerate(d.get("counts", [])):
        x = IX0 + j * 184
        c = G.ROLE[role] if n else G.DIM
        G.rrect(cv, x, y, 170, 70, 10, fill=G.mix(G.PANEL, c, 0.10 if n else 0.0), stroke=G.mix(G.EDGE, c, 0.7 if n else 0.2), sw=1.3, a=a * k2)
        G.text(cv, str(n), x + 16, y + 10, size=28, c=c, weight=600, a=a * k2)
        G.text(cv, lab, x + 16, y + 46, size=13, c=G.DIM, kind="mono", a=a * k2)
    if d.get("foot"):
        G.text(cv, d["foot"], IX0, 778 if sh.id in ("f23", "h16") else 790, size=15, c=G.DIM, kind="mono", a=a,
               maxlines=None if sh.id in ("f23", "h16") else 1, width=210 if sh.id in ("f23", "h16") else 916)


def draw_context(cv, sh, t, a, ctx):
    d = sh.d
    run = ctx.run
    frame(cv, a, d.get("title", "What the model sees"), d.get("sub", ""), d.get("rq", ""), accent=G.MODEL, accent_a=0.3)
    x0, x1 = IX0 + 150, IX1 - 10
    dur = run.duration
    X = lambda s: x0 + (x1 - x0) * s / dur
    y_top, y_bot = 340, 640
    trace_axes(cv, a, x0, x1, dur, y_top, y_bot)
    vmax = 110000
    Y = lambda v: y_bot - (y_bot - y_top) * v / vmax
    for v in (25000, 50000, 75000, 100000):
        G.line(cv, [(x0, Y(v)), (x1, Y(v))], (28, 35, 47), sw=1, a=a)
        G.text(cv, f"{v // 1000}k", x0 - 12, Y(v) - 9, size=12.5, c=G.DIM, kind="mono", a=a, align="right")
    G.text(cv, "tokens", IX0, 350, size=15, c=G.MODEL, kind="mono", a=a)
    grow = G.ease(G.seg(t, cue(sh, d.get("grow_at", 0.0)), cue(sh, d.get("end_at", 2.0)) + 0.5))
    pts = [(X(r["t"]), Y(r["ctx"])) for r in run.requests]
    n = max(2, int(round(len(pts) * grow)))
    vis = pts[:n]
    if len(vis) >= 2:
        import skia
        area = skia.Path()
        area.moveTo(vis[0][0], y_bot)
        for p in vis:
            area.lineTo(*p)
        area.lineTo(vis[-1][0], y_bot)
        area.close()
        cv.drawPath(area, G.paint(G.MODEL, a * 0.14))
        G.line(cv, vis, G.MODEL, sw=2.4, a=a)
        for p in vis:
            G.circle(cv, p[0], p[1], 3.2, fill=G.MODEL, a=a)
    r0, rN = run.requests[0], run.requests[-1]
    G.text(cv, f"request 1 · {r0['ctx']:,}", pts[0][0] + 8, pts[0][1] + 12, size=14, c=G.FG, kind="mono", a=a)
    ke = after(sh, t, d.get("end_at", 99), 0.5)
    G.text(cv, f"request {len(pts)} · {rN['ctx']:,}", pts[-1][0] - 6, pts[-1][1] - 32, size=14, c=G.FG, kind="mono", a=a * ke, align="right")
    G.text(cv, d.get("note", ""), IX0, 700, size=17, c=G.FG, a=a, maxlines=2, width=916)
    if d.get("foot"):
        G.text(cv, d["foot"], IX0, 790, size=15, c=G.DIM, kind="mono", a=a,
               maxlines=None if sh.id in ("f24", "h17") else 1, width=450 if sh.id in ("f24", "h17") else 916)


def draw_handoff(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, "Same container, new phase", d.get("sub", ""), "", title_c=G.SCORER, accent=G.SCORER, accent_a=0.3)
    cx, cy, cw, ch = IX0, 314, IX1 - IX0, 520
    container(cv, a, cx, cy, cw, ch, label="Docker container · the same one", hi=after(sh, t, "tests", 0.5))
    ks = after(sh, t, "stop", 0.5)
    # agent session box (ends)
    G.rrect(cv, cx + 24, cy + 56, 380, 150, 12, fill=(14, 19, 27), stroke=G.mix(G.HARNESS, G.FAINT, ks), sw=1.5, a=a)
    G.icon_role(cv, "harness", cx + 50, cy + 82, G.mix(G.HARNESS, G.DIM, ks), a=a, s=9)
    G.text(cv, "Claude Code · agent session", cx + 70, cy + 72, size=16, c=G.mix(G.FG, G.DIM, ks), weight=600, a=a)
    G.text(cv, "model: qwen3.7-max", cx + 44, cy + 110, size=14, c=G.DIM, kind="mono", a=a)
    G.text(cv, f"ended at +{ctx.run.duration:.1f} s" if ks > 0.5 else "running", cx + 44, cy + 136, size=14, c=G.WARN if ks > 0.5 else G.SANDBOX, kind="mono", a=a)
    if ks > 0.01:
        G.text(cv, "no further calls", cx + 44, cy + 162, size=14, c=G.DIM, kind="mono", a=a * ks)
    # outputs
    G.icon_folder(cv, cx + 24, cy + 236, w=24, h=18, c=G.SANDBOX, a=a)
    G.text(cv, "/app/output · submitted files", cx + 58, cy + 236, size=15, c=G.FG, kind="mono", a=a)
    for j, kind in enumerate(("docx", "xlsx")):
        G.rrect(cv, cx + 24 + j * 194, cy + 270, 180, 64, 10, fill=(14, 19, 27), stroke=G.FILE_COLORS[kind], sw=1.3, a=a)
        G.icon_file(cv, cx + 36 + j * 194, cy + 282, kind, a=a, w=30, h=40)
        G.text(cv, kind.upper(), cx + 80 + j * 194, cy + 292, size=16, c=G.FG, weight=600, kind="mono", a=a)
    # tests slide in
    kt = after(sh, t, "tests", 0.8)
    tx = G.lerp(IX1 + 60, cx + cw - 330, kt)
    if kt > 0.01:
        tests_card(cv, a * min(1.0, kt * 1.4), tx, cy + 56, 300, 250, 1 - kt, ctx.conf)
        G.text(cv, "copied in by Harbor", tx + 150, cy + 318, size=14, c=G.SCORER, kind="mono", a=a * kt, align="center")
    kj = after(sh, t, "score", 0.6)
    if kj > 0.01:
        G.rrect(cv, cx + 430, cy + 380, cw - 454, 110, 12, fill=G.mix(G.PANEL, G.SCORER, 0.10), stroke=G.SCORER, sw=1.6, a=a * kj)
        G.icon_role(cv, "scorer", cx + 462, cy + 412, G.SCORER, a=a * kj, s=10)
        G.text(cv, "RewardKit · judge sessions run as root", cx + 484, cy + 400, size=17, c=G.FG, weight=600, a=a * kj)
        G.text(cv, "they read /app/output; inputs only to check facts", cx + 462, cy + 429, size=14, c=G.DIM, kind="mono", a=a * kj)
        G.text(cv, "no channel back to the finished agent run", cx + 462, cy + 453, size=14, c=G.SCORER, kind="mono", a=a * kj)


# ============================================================================ CHECK chapter
def check_frame(cv, a, title, sub):
    frame(cv, a, title, sub, "", title_c=G.SCORER, accent=G.SCORER, accent_a=0.35)


def draw_judges(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    crits = [c["id"] for c in ctx.run.criteria]
    # files -> RewardKit
    G.rrect(cv, IX0, 330, 190, 150, 12, fill=(14, 19, 27), stroke=G.EDGE, sw=1.3, a=a)
    G.text(cv, "submitted", IX0 + 16, 344, size=13, c=G.DIM, kind="mono", a=a)
    for j, kind in enumerate(("docx", "xlsx")):
        G.icon_file(cv, IX0 + 22 + j * 82, 376, kind, a=a, w=40, h=50)
    G.text(cv, "/app/output", IX0 + 16, 444, size=13, c=G.SANDBOX, kind="mono", a=a)
    G.line(cv, [(IX0 + 196, 405), (IX0 + 236, 405)], G.SCORER, sw=1.8, a=a)
    G.arrow_head(cv, IX0 + 240, 405, 0, G.SCORER, size=8, a=a)
    G.rrect(cv, IX0 + 246, 360, 170, 90, 12, fill=G.mix(G.PANEL, G.SCORER, 0.12), stroke=G.SCORER, sw=1.5, a=a)
    G.text(cv, "RewardKit", IX0 + 331, 378, size=18, c=G.FG, weight=600, a=a, align="center")
    G.text(cv, "0.1.7 · in order", IX0 + 331, 406, size=12.5, c=G.DIM, kind="mono", a=a, align="center")
    # grid of criterion sessions
    gx, gy = IX0 + 446, 330
    cols = 7
    tw, th = 60, 44
    t0, t1 = cue(sh, d.get("rk_at", 0.0)), cue(sh, d.get("jm_at", 3.0)) + 1.5
    for j, cid in enumerate(crits):
        r, c = divmod(j, cols)
        x = gx + c * (tw + 7)
        y = gy + r * (th + 7)
        on = G.seg(t, t0 + (t1 - t0) * j / len(crits), t0 + (t1 - t0) * (j + 1) / len(crits))
        red = cid.startswith("G")
        col = G.FAIL if red else G.SCORER
        G.rrect(cv, x, y, tw, th, 7, fill=G.mix(G.PANEL, col, 0.14 * on), stroke=G.mix(G.EDGE, col, on), sw=1.3, a=a)
        G.text(cv, cid, x + tw / 2, y + 12, size=14, c=G.mix(G.DIM, G.FG, on), kind="mono", weight=600, a=a, align="center")
    rows = (len(crits) + cols - 1) // cols
    G.text(cv, d.get("grid_note", ""), gx, gy + rows * (th + 7) + 6, size=13, c=G.DIM, kind="mono", a=a)
    # judge model
    km = after(sh, t, d.get("jm_at", 99), 0.5)
    my = 640
    G.rrect(cv, IX0 + 246, my, 400, 74, 12, fill=G.mix(G.PANEL, G.SCORER, 0.10), stroke=G.SCORER, sw=1.5, a=a * km)
    G.icon_role(cv, "scorer", IX0 + 276, my + 37, G.SCORER, a=a * km, s=10)
    G.text(cv, "judge model", IX0 + 298, my + 12, size=13, c=G.DIM, kind="mono", a=a * km)
    G.text(cv, ctx.conf["chips"][3][1], IX0 + 298, my + 34, size=20, c=G.FG, weight=600, a=a * km)
    G.text(cv, d.get("judge_note", ""), IX0 + 668, my + 14, size=13.5, c=G.DIM, kind="mono", a=a * km, maxlines=2, width=246)
    # no feedback
    kn = after(sh, t, d.get("nf_at", 99), 0.5)
    if kn > 0.01:
        y = 772
        G.rrect(cv, IX0, y - 22, 220, 44, 10, stroke=G.FAINT, sw=1.3, a=a * kn)
        G.text(cv, "agent run · ended", IX0 + 110, y - 10, size=14, c=G.DIM, kind="mono", a=a * kn, align="center")
        G.line(cv, [(IX0 + 230, y), (IX0 + 420, y)], G.FAINT, sw=2, a=a * kn, dash=(6, 6))
        G.icon_cross(cv, IX0 + 325, y, G.FAIL, a=a * kn, s=10, sw=3)
        G.text(cv, "scores never reach the agent", IX0 + 440, y - 10, size=15, c=G.SCORER, kind="mono", a=a * kn)


def score_table(cv, a, rows, x, y, w, k_rows):
    """rows: list of (label, value, note, colour)."""
    for j, (lab, val, note, col) in enumerate(rows):
        k = a * k_rows[j]
        if k <= 0.01:
            continue
        yy = y + j * 70
        G.rrect(cv, x, yy, w, 58, 10, fill=(13, 18, 26), fa=0.96, stroke=G.mix(G.EDGE, G.ROLE.get(col, G.FG), 0.6), sw=1.3, a=k)
        G.text(cv, lab, x + 18, yy + 10, size=13.5, c=G.DIM, kind="mono", a=k, maxlines=1, width=300)
        G.text(cv, note, x + 18, yy + 32, size=13, c=G.DIM, a=k, maxlines=1, width=300)
        G.text(cv, val, x + w - 18, yy + 13, size=22, c=G.ROLE.get(col, G.FG), weight=600, kind="mono", a=k, align="right")


def verdict(cv, a, x, y, cid, title, result, col, k):
    if k <= 0.01:
        return
    c = G.ROLE.get(col, col)
    G.glow(cv, x, y, IX1 - x, 70, 12, c, a=0.15 * k * a, sigma=14)
    G.rrect(cv, x, y, IX1 - x, 70, 12, fill=G.mix(G.PANEL, c, 0.12), stroke=c, sw=1.8, a=a * k)
    G.text(cv, cid, x + 20, y + 22, size=20, c=c, weight=700, kind="mono", a=a * k)
    tx = max(x + 90, x + 20 + G.measure(cid, 20, 700, "mono")[0] + 20)
    G.text(cv, title, tx, y + 13, size=15, c=G.FG, a=a * k, maxlines=2, width=IX1 - tx - 160)
    G.text(cv, result, IX1 - 20, y + 20, size=22, c=c, weight=700, a=a * k, align="right")


def draw_dv01(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    G.icon_lock(cv, IX1 - 30, 250, G.SCORER, a=a, s=10, opened=1.0)
    k1 = after(sh, t, "num", 0.5)
    k2 = after(sh, t, "rc", 0.5)
    k3 = after(sh, t, "src", 0.5)
    w = (IX1 - IX0 - 30) / 2
    # left: workbook cell
    G.kicker(cv, "IN THE SUBMITTED WORKBOOK", IX0, 324, c=G.SANDBOX, a=a * k1, size=13)
    G.rrect(cv, IX0, 352, w, 150, 12, fill=(13, 18, 26), fa=0.96, stroke=G.SANDBOX, sw=1.5, a=a * k1)
    G.text(cv, "套期关系指定 ! B24 · DV01", IX0 + 20, 368, size=15, c=G.DIM, kind="mono", a=a * k1)
    G.text(cv, "−132,480.55", IX0 + 20, 398, size=40, c=G.FG, weight=600, a=a * k1)
    G.text(cv, "CNY / BP · note: 16号估值底稿", IX0 + 20, 456, size=14, c=G.DIM, kind="mono", a=a * k1)
    # right: judge recompute
    x2 = IX0 + w + 30
    G.kicker(cv, "JUDGE RECOMPUTES FROM ±5 BP SCENARIOS", x2, 324, c=G.SCORER, a=a * k2, size=13)
    G.rrect(cv, x2, 352, w, 150, 12, fill=(13, 18, 26), fa=0.96, stroke=G.SCORER, sw=1.5, a=a * k2)
    G.text(cv, "(−5,058,238.49 − (−3,733,432.99)) / 10", x2 + 20, 372, size=15.5, c=G.FG, kind="mono", a=a * k2)
    G.text(cv, "= −132,480.55", x2 + 20, 404, size=34, c=G.SCORER, weight=600, a=a * k2)
    G.text(cv, "tolerance ±0.01 CNY/BP", x2 + 20, 458, size=14, c=G.DIM, kind="mono", a=a * k2)
    verdict(cv, a, IX0, 532, "R11", "DV01 for IRS-2026-0031 · numbers and calculations · weight 7", "met", "pass", k2)
    # source note
    if k3 > 0.01:
        y = 630
        G.rrect(cv, IX0, y, IX1 - IX0, 100, 12, fill=G.mix(G.PANEL, G.MODEL, 0.06), stroke=G.mix(G.EDGE, G.MODEL, 0.7), sw=1.4, a=a * k3)
        G.text(cv, "WHERE THE AGENT GOT IT", IX0 + 20, y + 14, size=13, c=G.MODEL, kind="mono", weight=600, a=a * k3, ls=1.4)
        G.text(cv, "step 36 · +108.2 s · 16_中后台估值底稿_20260731.csv → DV01_元: -132480.55", IX0 + 20, y + 42, size=15, c=G.FG, kind="mono", a=a * k3, maxlines=1, width=880)
        G.text(cv, "written into the workbook as a constant · the agent did not derive it", IX0 + 20, y + 70, size=14, c=G.DIM, a=a * k3)


def draw_d02(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    k1 = after(sh, t, "d02", 0.5)
    k2 = after(sh, t, "red", 0.5)
    k3 = after(sh, t, "half", 0.5)
    w = (IX1 - IX0 - 30) / 2
    for j, (kick, lines, col, k) in enumerate((
            ("PROPOSED · REGISTER D02", ["借：其他综合收益——现金流量套期储备", "    4,480,000.00", "贷：外币借款 4,480,000.00"], G.WARN, k1),
            ("AGENT'S REPORT · 3.2", ["接受作为暂行处理意见，科目名称修正为：", "借：其他综合收益——净投资套期储备", "贷：外币借款 4,480,000.00"], G.BRAND, k1))):
        x = IX0 + j * (w + 30)
        G.kicker(cv, kick, x, 324, c=col, a=a * k, size=13)
        G.rrect(cv, x, 352, w, 150, 12, fill=(13, 18, 26), fa=0.96, stroke=col, sw=1.4, a=a * k)
        for i, ln in enumerate(lines):
            G.text(cv, ln, x + 20, 370 + i * 36, size=17, c=G.FG, a=a * k, maxlines=1, width=w - 40)
    verdict(cv, a, IX0, 540, "G2", "Red line: book the July FX loss to the cash-flow hedge reserve as the final, executable entry?", "clear", "pass", k2)
    verdict(cv, a, IX0, 628, "R51", "Conclusion on HR-03 and the D02 approval boundary · level 3 of 5 → 0.5 × weight 10", "5 / 10", "warn", k3)


def draw_formulas(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    k1 = after(sh, t, "zero", 0.5)
    k2 = after(sh, t, "static", 0.5)
    # spreadsheet mock
    x, y, w, h = IX0, 320, 560, 360
    G.rrect(cv, x, y, w, h, 10, fill=(18, 22, 30), stroke=G.EDGE, sw=1.3, a=a)
    G.rrect(cv, x, y, w, 40, 10, fill=(24, 30, 40), a=a)
    G.text(cv, "fx", x + 16, y + 10, size=16, c=G.DIM, kind="mono", a=a)
    G.text(cv, "-132480.55", x + 60, y + 10, size=16, c=G.FG, kind="mono", a=a)
    G.text(cv, "a typed-in value, not =…", x + w - 16, y + 12, size=13, c=G.WARN, kind="mono", a=a * k2, align="right")
    cols_ = ["A", "B", "C", "D", "E"]
    cw = (w - 40) / len(cols_)
    for j, c in enumerate(cols_):
        G.text(cv, c, x + 40 + j * cw + cw / 2, y + 48, size=13, c=G.DIM, kind="mono", a=a, align="center")
    for r in range(7):
        ry = y + 72 + r * 40
        G.text(cv, str(20 + r), x + 20, ry + 10, size=13, c=G.DIM, kind="mono", a=a, align="center")
        G.line(cv, [(x + 36, ry), (x + w - 4, ry)], (34, 42, 56), sw=1, a=a)
    sel_y = y + 72 + 4 * 40
    G.rrect(cv, x + 40 + cw, sel_y, cw, 40, 3, stroke=G.SANDBOX, sw=2.2, a=a)
    G.text(cv, "DV01", x + 40 + cw / 2, sel_y + 11, size=14, c=G.FG, a=a, align="center")
    G.text(cv, "-132480.55", x + 40 + cw + cw / 2, sel_y + 11, size=13.5, c=G.FG, kind="mono", a=a, align="center")
    G.text(cv, "CNY/BP", x + 40 + 2 * cw + cw / 2, sel_y + 11, size=13.5, c=G.DIM, kind="mono", a=a, align="center")
    G.text(cv, "16号估值底稿", x + 40 + 3 * cw + cw / 2, sel_y + 11, size=13.5, c=G.DIM, a=a, align="center")
    # per-sheet formula counts
    sx = x + w + 30
    G.kicker(cv, "FORMULAS PER SHEET", sx, 324, c=G.SCORER, a=a * k1, size=13)
    for j, sheet in enumerate(d["sheets"]):
        yy = 352 + j * 62
        G.rrect(cv, sx, yy, IX1 - sx, 50, 9, fill=(13, 18, 26), stroke=G.mix(G.EDGE, G.FAIL, 0.5 * k1), sw=1.3, a=a * k1)
        G.text(cv, sheet, sx + 16, yy + 13, size=16, c=G.FG, a=a * k1)
        G.text(cv, "0", IX1 - 20, yy + 10, size=22, c=G.FAIL, weight=700, kind="mono", a=a * k1, align="right")
    verdict(cv, a, IX0, 704, "R19", "Amounts traceable through kept formulas to source fields · weight 3", "not met", "fail", k2)


def draw_tally(cv, sh, t, a, ctx):
    d = sh.d
    run = ctx.run
    check_frame(cv, a, "Rubric result", d.get("sub", ""))
    groups = d.get("groups") or auto_groups(run, d)
    y = 326
    for (label, items, at, note) in groups:
        k = after(sh, t, at, 0.5)
        G.text(cv, label, IX0, y, size=15, c=G.FG, weight=600, a=a * k)
        G.text(cv, note, IX1, y, size=14, c=G.DIM, kind="mono", a=a * k, align="right")
        cols = 10
        tw, th = (IX1 - IX0 - 9 * 8) / cols, 40
        for j, (cid, st, fr) in enumerate(items):
            r, c = divmod(j, cols)
            x = IX0 + c * (tw + 8)
            yy = y + 30 + r * (th + 8)
            col = {"met": G.PASS, "partial": G.WARN, "not": G.FAIL, "clear": G.SANDBOX, "hit": G.FAIL}[st]
            kj = a * G.ease(G.seg(t, cue(sh, at) + j * 0.05, cue(sh, at) + j * 0.05 + 0.35))
            G.rrect(cv, x, yy, tw, th, 7, fill=G.mix(G.PANEL, col, 0.08), stroke=G.mix(G.EDGE, col, 0.85), sw=1.3, a=kj)
            if st == "partial":
                G.rrect(cv, x + 2, yy + th - 8, (tw - 4) * fr, 6, 3, fill=col, a=kj)
            elif st in ("met", "clear"):
                G.rrect(cv, x + 2, yy + th - 8, tw - 4, 6, 3, fill=col, a=kj)
            G.text(cv, cid, x + tw / 2, yy + 8, size=13.5, c=G.FG, kind="mono", weight=600, a=kj, align="center")
        rows = (len(items) + cols - 1) // cols
        y += 30 + rows * (th + 8) + 26
    if d.get("foot"):
        G.text(cv, d["foot"], IX0, y + 4, size=15, c=G.DIM, kind="mono", a=a, maxlines=1, width=916)


def auto_groups(run, d):
    pos, pen, red = [], [], []
    for c in run.criteria:
        v = float(c["value"])
        if c.get("group") == "gating":
            red.append((c["id"], "clear" if v >= 1 else "hit", 1.0))
        elif c.get("negate"):
            pen.append((c["id"], "clear" if v >= 1 else "hit", 1.0))
        else:
            pos.append((c["id"], "met" if v >= 1 else ("partial" if v > 0 else "not"), v))
    out = []
    labels = d["labels"]
    out.append((labels[0][0], pos, labels[0][1], labels[0][2]))
    out.append((labels[1][0], pen, labels[1][1], labels[1][2]))
    if red:
        out.append((labels[2][0], red, labels[2][1], labels[2][2]))
    return out


def draw_reward(cv, sh, t, a, ctx):
    d = sh.d
    k = G.ease(G.seg(t, 0.0, 0.7))
    G.text(cv, d.get("kicker", "RUBRIC REWARD"), 960, 232, size=16, c=G.DIM, kind="mono", a=a * k, align="center", ls=6)
    kv = after(sh, t, "rw", 0.6)
    G.text(cv, d["value"], 960, 262, size=150, c=G.WARN, weight=700, a=a * kv, align="center", ls=-4)
    kw = after(sh, t, "w", 0.5)
    G.text(cv, d["formula"], 960, 446, size=26, c=G.FG, kind="mono", a=a * kw, align="center")
    x, y, w, h = 560, 512, 800, 150
    G.rrect(cv, x, y, w, h, 14, fill=G.mix(G.PANEL, G.WARN, 0.06), stroke=G.WARN, sw=1.6, a=a * kw)
    G.text(cv, d["line1"], 960, y + 22, size=21, c=G.FG, weight=600, a=a * kw, align="center")
    G.text(cv, d["line2"], 960, y + 64, size=15.5, c=G.DIM, kind="mono", a=a * kw, align="center")
    G.text(cv, d["line3"], 960, y + 98, size=15.5, c=G.DIM, kind="mono", a=a * kw, align="center")
    kp = after(sh, t, "pilot", 0.5)
    G.text(cv, d["note"], 960, 700, size=19, c=G.FG, a=a * kp, align="center")
    G.text(cv, d.get("note2", ""), 960, 736, size=15, c=G.DIM, kind="mono", a=a * kp, align="center")


# ============================================================================ HR specials
def draw_sites(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, d.get("title", "The setting"), d.get("sub", ""), title_c=G.BRAND)
    sites = [("SYN-HUB-01", "trained", 0), ("SYN-HUB-02", "trained", 1), ("SYN-HUB-03", "trained", 2), ("SYN-HUB-04", "delayed", 3)]
    cw = (IX1 - IX0 - 3 * 20) / 4
    for j, (sid, kind, _) in enumerate(sites):
        x = IX0 + j * (cw + 20)
        delayed = kind == "delayed"
        at = cue(sh, "d") if delayed else 0.25 + j * 0.3
        k = a * G.ease(G.seg(t, at, at + 0.5))
        col = G.BRAND if delayed else G.SANDBOX
        G.rrect(cv, x, 330, cw, 230, 14, fill=G.mix((13, 18, 26), col, 0.08), stroke=col, sw=1.6, a=k)
        # warehouse glyph
        cx_ = x + cw / 2
        G.poly(cv, [(cx_ - 46, 400), (cx_, 368), (cx_ + 46, 400)], col, a=k * 0.9)
        G.rrect(cv, cx_ - 40, 400, 80, 52, 3, fill=G.mix(G.PANEL, col, 0.35), a=k)
        G.rrect(cv, cx_ - 14, 422, 28, 30, 2, fill=G.mix(G.PANEL, col, 0.7), a=k)
        G.text(cv, sid, cx_, 470, size=17, c=G.FG, weight=600, kind="mono", a=k, align="center")
        G.text(cv, "trained · 6 weeks" if not delayed else "trained later", cx_, 500, size=15, c=col, kind="mono", a=k, align="center")
        if delayed:
            G.text(cv, "the comparison site", cx_, 524, size=13.5, c=G.DIM, kind="mono", a=k, align="center")
    k2 = a * after(sh, t, "d", 0.6, 0.6)
    y = 600
    G.rrect(cv, IX0, y, IX1 - IX0, 120, 12, fill=(13, 18, 26), fa=0.96, stroke=G.EDGE, sw=1.3, a=k2)
    G.text(cv, "Did the training change how supervisors handle incidents —", IX0 + 22, y + 22, size=19, c=G.FG, a=k2)
    G.text(cv, "or did opportunity, equipment and weather change the numbers?", IX0 + 22, y + 52, size=19, c=G.FG, a=k2)
    G.text(cv, "all people, sites and records in this task are synthetic", IX0 + 22, y + 86, size=13.5, c=G.DIM, kind="mono", a=k2)


def draw_packages(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, d.get("title", "The task"), d.get("sub", ""), title_c=G.BRAND)
    wps = [("SYN-WP-A", "训练准备与交付", "Training preparation and delivery", "244,800"),
           ("SYN-WP-B", "学习保持与岗位转化证据", "Learning retention and on-the-job transfer", "367,200"),
           ("SYN-WP-C", "运营验证与结项关闭", "Operational validation and close-out", "204,000")]
    cw = (IX1 - IX0 - 2 * 20) / 3
    for j, (wid, zh, en, amt) in enumerate(wps):
        x = IX0 + j * (cw + 20)
        at = cue(sh, "wp") + j * 0.25
        k = a * G.ease(G.seg(t, at, at + 0.45))
        G.rrect(cv, x, 330, cw, 250, 14, fill=(13, 18, 26), fa=0.96, stroke=G.EDGE, sw=1.4, a=k)
        G.text(cv, wid, x + 18, 348, size=18, c=G.MODEL, weight=700, kind="mono", a=k)
        # v3: English only; the package name from the workbook is shown in English.
        G.text(cv, en, x + 18, 382, size=17, c=G.FG, weight=600, a=k, width=cw - 36, maxlines=2)
        G.text(cv, f"¥ {amt}", x + 18, 470, size=26, c=G.FG, weight=600, a=k)
        cx_ = x + 18
        for lab in ("accept", "pay", "retain"):
            w = U.pill(cv, lab + "?", cx_, 524, G.BRAND, a=k, size=13)
            cx_ += w + 8
    ks = a * after(sh, t, "sum", 0.5)
    y = 612
    G.rrect(cv, IX0, y, IX1 - IX0, 112, 12, fill=G.mix(G.PANEL, G.WARN, 0.06), stroke=G.mix(G.EDGE, G.WARN, 0.8), sw=1.4, a=ks)
    G.text(cv, "¥ 816,000 requested in total", IX0 + 22, y + 18, size=24, c=G.FG, weight=600, a=ks)
    G.text(cv, "训练服务方阶段申请: “材料已上传”为由自评全部通过 — the vendor's own claim only", IX0 + 22, y + 62, size=15, c=G.WARN, a=ks, maxlines=1, width=870)


def draw_edits(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, "Claude Code · tool loop", d.get("sub", ""), d.get("rq", ""), accent=G.WARN, accent_a=0.3)
    T = sh.trace_at(t) or 0
    rows = d["rows"]
    y0 = 320
    rh = 47
    for j, (ts, tool, what, res, step) in enumerate(rows):
        k = a * G.ease(G.seg(T, ts - 0.6, ts + 0.4))
        if k <= 0.01:
            continue
        y = y0 + j * rh
        col = {"Bash": G.SANDBOX, "Read": G.BRAND, "Edit": G.WARN}[tool]
        latest = all(T < r[0] for r in rows[j + 1:])
        RW_ = IX1 - IX0 - 130
        G.rrect(cv, IX0, y, RW_, rh - 7, 8, fill=G.mix((13, 18, 26), col, 0.10 if latest else 0.03), stroke=G.mix(G.EDGE, col, 0.9 if latest else 0.35), sw=1.3, a=k)
        G.text(cv, f"+{ts:05.1f} s", IX0 + 12, y + 11, size=13, c=G.DIM, kind="mono", a=k)
        w = U.pill(cv, tool, IX0 + 100, y + 7, col, a=k, size=13)
        G.text(cv, what, IX0 + 110 + w, y + 10, size=15, c=G.FG, kind="mono", a=k, maxlines=1, width=360)
        G.text(cv, res, IX0 + RW_ - 14, y + 11, size=13, c=col if tool != "Read" else G.DIM, kind="mono", a=k, align="right")
    k2 = a * after(sh, t, "again", 0.5)
    G.text(cv, "next: request 17 runs the same pipeline again →", IX0, y0 + len(rows) * rh + 6, size=15, c=G.SANDBOX, kind="mono", a=k2)


def draw_rerun(cv, sh, t, a, ctx):
    d = sh.d
    frame(cv, a, "Claude Code · tool loop", d.get("sub", ""), d.get("rq", ""), accent=G.PASS, accent_a=0.3)
    w = (IX1 - IX0 - 30) / 2
    kw = after(sh, t, "wpa", 0.5)
    ka = after(sh, t, "amt", 0.5)
    for j, ((lab, status), col, at) in enumerate(((d["before"], G.WARN, 0.0), (d["after"], G.PASS, "same"))):
        x = IX0 + j * (w + 30)
        k = a * after(sh, t, at, 0.5)
        G.kicker(cv, lab.upper(), x, 324, c=col, a=k, size=13)
        hi = kw if j == 1 else 0.0
        if hi > 0.01:
            G.glow(cv, x, 352, w, 260, 12, col, a=0.18 * hi * a, sigma=16)
        G.rrect(cv, x, 352, w, 260, 12, fill=(10, 14, 20), fa=0.98, stroke=G.mix(G.EDGE, col, 0.5 + 0.5 * hi), sw=1.5, a=k)
        yy = 372
        for ln in d["common"]:
            G.text(cv, ln, x + 18, yy, size=13.5, c=(196, 204, 216), kind="mono", a=k, maxlines=1, width=w - 36)
            yy += 30
        G.text(cv, "no traceback · exit 0", x + 18, yy, size=13.5, c=G.SANDBOX, kind="mono", a=k)
        yy += 44
        ss = 20.0  # v3: the English status is longer; shrink to fit the card
        while ss > 13 and G.measure(status, ss, 600, "mono")[0] > w - 36:
            ss -= 0.5
        G.text(cv, status, x + 18, yy + (20 - ss) * 0.5, size=ss, c=col, weight=600, kind="mono", a=k)
        G.text(cv, d["amounts"], x + 18, yy + 40, size=13, c=G.FG if ka > 0.5 else G.DIM, kind="mono", a=k, maxlines=1, width=w - 36)
    if kw > 0.01:
        G.text(cv, "→", IX0 + w + 15, 470, size=30, c=G.PASS, weight=700, a=a * kw, align="center")
    k3 = a * ka
    G.rrect(cv, IX0, 640, IX1 - IX0, 70, 12, fill=G.mix(G.PANEL, G.PASS, 0.08), stroke=G.PASS, sw=1.4, a=k3)
    G.text(cv, "status now matches the 10% held back · same amounts, consistent label", IX0 + 22, 664, size=17, c=G.FG, a=k3)


def draw_wpa(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    k1 = after(sh, t, "fix", 0.5)
    k2 = after(sh, t, "met", 0.5)
    w = (IX1 - IX0 - 30) / 2
    for j, (lab, st, col) in enumerate((("first run · +204.3 s", "验收通过", G.WARN), ("after the edits · +283.5 s", "附条件验收", G.PASS))):
        x = IX0 + j * (w + 30)
        G.kicker(cv, lab.upper(), x, 324, c=col, a=a * k1, size=13)
        G.rrect(cv, x, 352, w, 120, 12, fill=(13, 18, 26), fa=0.96, stroke=col, sw=1.5, a=a * k1)
        G.text(cv, "SYN-WP-A · 训练准备与交付", x + 20, 370, size=15, c=G.DIM, a=a * k1)
        G.text(cv, st, x + 20, 400, size=30, c=col, weight=600, a=a * k1)
    G.text(cv, "workbook 阶段门与金额复算: 合同金额 244,800 · 建议提交 220,320 · 保留 24,480", IX0, 500, size=15, c=G.DIM, a=a * k1, maxlines=1, width=916)
    verdict(cv, a, IX0, 552, "R20", "WP-A judged a conditional acceptance: sessions done, three sign-outs pending · weight 7", "met", "pass", k2)
    G.text(cv, "the separate amounts criterion for WP-A (R23) is still not met", IX0, 650, size=14, c=G.DIM, kind="mono", a=a * k2, maxlines=1, width=916)


def draw_pooled(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    k1 = after(sh, t, "pool", 0.5)
    k2 = after(sh, t, "idx", 0.5)
    w = (IX1 - IX0 - 30) / 2
    G.kicker(cv, "WORKBOOK · 运营对照 (POOLED)", IX0, 324, c=G.WARN, a=a * k1, size=13)
    G.rrect(cv, IX0, 352, w, 150, 12, fill=(13, 18, 26), stroke=G.WARN, sw=1.4, a=a * k1)
    for j, ln in enumerate(["trained (3 sites) vs control", "response_sla_rate   DiD +0.0433", "isolation_complete  DiD +0.0553"]):
        G.text(cv, ln, IX0 + 18, 370 + j * 34, size=15, c=G.FG, kind="mono", a=a * k1)
    x2 = IX0 + w + 30
    G.kicker(cv, "RUBRIC EXPECTS · EACH SITE VS SYN-HUB-04", x2, 324, c=G.SCORER, a=a * k1, size=13)
    G.rrect(cv, x2, 352, w, 150, 12, fill=(13, 18, 26), stroke=G.SCORER, sw=1.4, a=a * k1)
    for j, ln in enumerate(["SYN-HUB-01   SLA ≈ +6.5 pp", "SYN-HUB-02   SLA ≈ +4.5 pp", "SYN-HUB-03   SLA ≈ +2.0 pp"]):
        G.text(cv, ln, x2 + 18, 370 + j * 34, size=15, c=G.FG, kind="mono", a=a * k1)
    verdict(cv, a, IX0, 524, "R14–16", "Net change of each trained site against the delayed site · 3 criteria", "not met", "fail", k1)
    # sheet list without a source index
    y = 616
    G.text(cv, "9 sheets · no 来源索引 (source index)", IX0, y, size=14, c=G.DIM, kind="mono", a=a * k2)
    names = ["封面与口径", "有效样本核定", "学习保持分析", "机会与行为", "带教辅导", "运营对照", "阶段门与金额复算", "测验汇总", "机会行为个人汇总"]
    # v3: the English sheet names are wider, so the chips wrap onto a second row.
    x, yy = IX0, y + 26
    for nm in names + ["来源索引"]:
        tw, _ = G.measure(nm, 13.5, 500)
        if x + tw + 20 > IX1:
            x, yy = IX0, yy + 36
        if nm == "来源索引":
            G.rrect(cv, x, yy, tw + 20, 30, 7, stroke=G.FAIL, sw=1.4, a=a * k2, dash=(5, 4))
            G.text(cv, nm, x + 10, yy + 6, size=13.5, c=G.FAIL, a=a * k2)
        else:
            G.rrect(cv, x, yy, tw + 20, 30, 7, fill=(18, 23, 32), stroke=G.EDGE, sw=1.1, a=a * k2)
            G.text(cv, nm, x + 10, yy + 6, size=13.5, c=G.FG, a=a * k2)
        x += tw + 28
    verdict(cv, a, IX0, max(690, yy + 44), "R1 · R19", "Workbook includes a source index with checkable key chains", "not met", "fail", k2)


def draw_r32(cv, sh, t, a, ctx):
    d = sh.d
    check_frame(cv, a, "Independent scorer", d.get("sub", ""))
    k1 = after(sh, t, "pen", 0.5)
    k2 = after(sh, t, "ten", 0.5)
    k3 = after(sh, t, "why", 0.5)
    G.kicker(cv, "WORKBOOK · 机会与行为", IX0, 324, c=G.SANDBOX, a=a * k1, size=13)
    G.rrect(cv, IX0, 352, 430, 100, 12, fill=(13, 18, 26), stroke=G.EDGE, sw=1.3, a=a * k1)
    G.text(cv, "机会充足 (≥2 次)", IX0 + 18, 368, size=16, c=G.FG, a=a * k1)
    G.text(cv, "73", IX0 + 412, 364, size=24, c=G.FG, weight=600, a=a * k1, align="right")
    G.text(cv, "机会不足", IX0 + 18, 408, size=16, c=G.FG, a=a * k1)
    G.text(cv, "10", IX0 + 412, 404, size=24, c=G.WARN, weight=600, a=a * k1, align="right")
    x2 = IX0 + 460
    G.kicker(cv, "WORKBOOK · 机会行为个人汇总", x2, 324, c=G.FAIL, a=a * k2, size=13)
    G.rrect(cv, x2, 352, IX1 - x2, 100, 12, fill=G.mix(G.PANEL, G.FAIL, 0.08), stroke=G.FAIL, sw=1.5, a=a * k2)
    G.text(cv, "机会充足 = 否  →  行为达标 = 否", x2 + 18, 368, size=18, c=G.FG, weight=600, a=a * k2)
    G.text(cv, "for all 10 people with too few chances", x2 + 18, 408, size=15, c=G.DIM, kind="mono", a=a * k2)
    # people glyphs
    for j in range(10):
        x = IX0 + 30 + j * 88
        G.circle(cv, x + 20, 498, 11, fill=G.mix(G.FAINT, G.WARN, k2), a=a * k2)
        G.rrect(cv, x + 4, 512, 32, 26, 10, fill=G.mix(G.FAINT, G.WARN, k2), a=a * k2)
        G.icon_cross(cv, x + 48, 500, G.FAIL, a=a * k2, s=6, sw=2.4)
    G.rrect(cv, IX0, 560, IX1 - IX0, 70, 12, fill=(13, 18, 26), stroke=G.SCORER, sw=1.4, a=a * k3)
    G.text(cv, "Rubric: insufficient opportunity must stay 'not evaluable' — it is not a behaviour failure.", IX0 + 20, 584, size=16.5, c=G.FG, a=a * k3, maxlines=1, width=880)
    verdict(cv, a, IX0, 650, "R32", "Penalty: people with too little opportunity judged as failing · weight 7", "−7", "fail", k3)


SCENES.update({
    "sites": draw_sites, "packages": draw_packages, "edits": draw_edits, "rerun": draw_rerun,
    "wpa": draw_wpa, "pooled": draw_pooled, "r32": draw_r32,
})

SCENES.update({
    "task": draw_task, "limits": draw_limits, "io": draw_io, "sealed": draw_sealed,
    "fanout": draw_fanout, "montage": draw_montage, "valobs": draw_valobs, "notsaved": draw_notsaved,
    "moveon": draw_moveon, "trace": draw_trace, "context": draw_context, "handoff": draw_handoff,
    "judges": draw_judges, "dv01": draw_dv01, "d02": draw_d02, "formulas": draw_formulas,
    "tally": draw_tally, "reward": draw_reward,
})
FULL.add("reward")
