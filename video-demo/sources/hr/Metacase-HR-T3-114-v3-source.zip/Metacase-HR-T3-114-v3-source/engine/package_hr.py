"""Package the HR Metacase v3 edition with its reconstructed source and validation records.

usage: python engine/package_hr.py
Requires the full build/hr/hr.mp4, its render receipt and font-selection sidecar.

The HR v2 source was never archived. story/hr.py and data/hr.json were rebuilt from the
published v2 film, so unlike engine/package.py there is no MANIFEST baseline to compare:
the provenance states what was reconstructed and how it was checked.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import compose  # noqa: E402
import rundata  # noqa: E402
from package import (CHAPTERS, FFMPEG, portable_font_record, probe, read_json, reference_details,  # noqa: E402
                     relative, run_checked, runtime_versions, sha, write_json)
from timeline import FPS, TAIL  # noqa: E402

RUN = "hr"
VERSION = "hr-metacase-v3"
NAME, DOC = "hr-agent-replay", "hr"
POSTER_TRACE = 283.0  # the v2 poster: h13 with the agent clock at +283.0 s


def main():
    ctx = compose.Ctx(RUN)
    tl = ctx.tl
    build = os.path.join(ROOT, "build", RUN)
    source_mp4 = os.path.join(build, f"{RUN}.mp4")
    source_fonts = os.path.join(build, f"{RUN}.font-selection.json")
    source_receipt = os.path.join(build, f"{RUN}.render-receipt.json")
    for required in (source_mp4, source_fonts, source_receipt):
        if not os.path.isfile(required):
            raise FileNotFoundError(f"Full render artifact is missing: {required}")
    receipt = read_json(source_receipt)
    if receipt["output_sha256"] != sha(source_mp4):
        raise RuntimeError("Full video does not match its render receipt")
    for path, expected in receipt["inputs"]["source_sha256"].items():
        if sha(Path(ROOT, path)) != expected:
            raise RuntimeError(f"Rendered input changed before packaging: {path}")
    fonts = read_json(source_fonts)["fonts"]
    if set(receipt["inputs"]["font_sha256"]) != set(fonts):
        raise RuntimeError("Font selections do not match the render receipt")
    from render import verify_video
    verify_video(source_mp4, tl.nframes)

    src_files = sorted(Path(ROOT, "engine").glob("*.py"))
    src_files += [Path(ROOT, "story", "hr.py"), Path(ROOT, "story", "hr_en.py"), Path(ROOT, "story", "fin_en.py"),
                  Path(ROOT, "data", "hr.json"), Path(ROOT, "data", "hr.requests.jsonl"),
                  Path(ROOT, "README-hr-v3.md"), Path(ROOT, "requirements-render.txt"),
                  Path(ROOT, "robot", "sprites", "sprites.json"), Path(ROOT, "fonts", "SpaceMono-400.ttf")]
    src_files += sorted(Path(ROOT, "brand").glob("*"))
    src_files += sorted(Path(ROOT, "reconstruction").glob("*"))
    source_hashes = {relative(f): sha(f) for f in src_files}

    from check_guide import audit
    qa = audit(RUN)
    qa["source_snapshot_sha256"] = source_hashes
    qa["source_snapshot_phase"] = "packaging"
    qa_path = os.path.join(build, "guide-geometry-qa.json")
    write_json(qa_path, qa)
    if not qa["passed"]:
        raise RuntimeError(f"Guide geometry audit failed; inspect {relative(qa_path)}")

    out_v = os.path.join(ROOT, "deliver", "assets", "video")
    out_d = os.path.join(ROOT, "deliver", "docs", "video", DOC)
    os.makedirs(out_v, exist_ok=True)
    os.makedirs(out_d, exist_ok=True)
    mp4 = os.path.join(out_v, f"{NAME}.mp4")
    shutil.copyfile(source_mp4, mp4)
    sh = next(s for s in tl.shots if s.id == "h13")
    t0, t1 = sh.d["trace"]
    a, b = sh.lead, sh.dur - TAIL
    png = os.path.join(build, "poster.png")
    compose.render_still(ctx, sh.start + a + (b - a) * (POSTER_TRACE - t0) / (t1 - t0), png)
    poster = os.path.join(out_v, f"{NAME}-poster.jpg")
    run_checked([FFMPEG, "-v", "error", "-y", "-i", png, "-q:v", "2", poster])
    shutil.copyfile(os.path.join(build, "captions.en.srt"), os.path.join(out_d, "captions.en.srt"))
    shutil.copyfile(qa_path, os.path.join(out_d, "guide-geometry-qa.json"))
    shutil.copyfile(source_receipt, os.path.join(out_d, "render-receipt.json"))
    write_json(os.path.join(out_d, "font-selection.json"), portable_font_record(source_fonts))
    shutil.copyfile(os.path.join(ROOT, "README-hr-v3.md"), os.path.join(out_d, "README.md"))
    cjk = os.path.join(build, "cjk-onscreen.json")
    if os.path.isfile(cjk):
        shutil.copyfile(cjk, os.path.join(out_d, "cjk-onscreen.json"))

    run_data = rundata.load(RUN)
    data_path, log_path = rundata.SOURCES[RUN]
    p = probe(mp4)
    hr_en = __import__("story.hr_en", fromlist=["GLOSSARY"])
    prov = {
        "version": VERSION,
        "task_id": ctx.conf["task_id"],
        "run": RUN,
        "status": "approved for publication",
        "model": "qwen3.7-max", "harness": "Claude Code 2.1.114", "runner": "Harbor 0.20.0",
        "judge_model": ctx.conf["chips"][3][1],
        "recorded_agent_seconds": run_data.duration,
        "model_requests": len(run_data.requests), "tool_calls": len(run_data.tool_steps),
        "reward": run_data.result["reward"],
        "duration_seconds": round(float(p["format"]["duration"]), 3),
        "frames": tl.nframes, "fps": f"{FPS}/1", "resolution": [1920, 1080],
        "streams": p["streams"],
        "voice": "en-US-AriaNeural, rate +12% (the v2 voice and rate; 27 of 28 clips re-synthesised with the v2 timing to within 0.011 s)",
        "audio_is_synthetic": True,
        "audio_processing": "per-shot neural TTS clips placed on the shot timeline, loudnorm I=-16.5 LUFS, AAC 48 kHz mono",
        "burned_captions": ["en"],
        "renderer": "offline Skia (skia-python) frame renderer; no browser, no CDP; H.264 High via libx264",
        "runtime": runtime_versions(),
        "guide_alignment": reference_details(),
        "guide_character": {
            "character": "the homepage robot (mc-kit.js robot(0xf7f5f0, 0x8ff6ff)) holding the arena's Claude Code blaster (Kenney blaster-e.glb, CC0)",
            "renderer": "robot/sprite.html (three.js, homepage lights) -> 362 transparent sprites, -90..+90 degrees aim in 1-degree steps, eyes open and mid-blink",
            "sprites_index": {"path": "robot/sprites/sprites.json", "sha256": sha(os.path.join(ROOT, "robot", "sprites", "sprites.json"))},
            "pointer": "a sight laser from the muzzle to the cue target; hidden in the parked pose",
            "routes_and_cues": f"{len(ctx.guide.events)} cues at the v2 targets (engine/guide_targets.py, HR section)",
        },
        "english_only": {
            "captions": "English only; no Chinese captions are burned in or delivered",
            "on_screen_text": "Chinese source strings are shown by English names via story/hr_en.py GLOSSARY; numbers, codes, statuses' meaning and amounts unchanged",
            "glossary": [{"zh": zh, "en": en} for zh, en in hr_en.GLOSSARY],
            "check": "work/cjk_scan.py drew every 5th frame: 0 strings with Chinese characters reach the screen (cjk-onscreen.json)",
            "not_drawn": ["task-card Chinese subtitle", "the Chinese duplicate of each work-package name"],
        },
        "brand": {
            "mark_and_wordmark": "Metacase mark (.lg-anim timing) and 'Metacase Challenge' wordmark from the website homepage",
            "institutions": "NTU, HKU, SUFE and Tsinghua crests as on the homepage hero; 'Hosted by NTU GIFTS with HKU, SUFE and Tsinghua PBCSF'",
            "site": "easonai-5589.github.io/metacase-challenge",
            "attribution": "brand/ATTRIBUTION.txt",
        },
        "reconstruction": {
            "why": "The v2 HR source (story/hr.py, data/hr.json, hr.requests.jsonl, voice cache) was not archived with the published film.",
            "inputs": ["v2 film assets/video/hr-agent-replay.mp4 (frames and audio)",
                       "v2 docs/video/hr/provenance.json (shot ids, kinds, timings, narration, captions)"],
            "method": [
                "Shot list, chapters, kinds, narration and status lines copied from the v2 provenance and frames.",
                "Per-request output tokens, prompt tokens, tool calls and plan states read from the run ledger, "
                "trace and context panels frame by frame (reconstruction/build_hr_data.py).",
                "Card text, file names, statuses and amounts transcribed from the frames.",
                "Narration re-synthesised with the v2 voice and rate; shot boundaries match v2 to within 0.011 s "
                "(h26 is 0.2 s shorter because it now names the Metacase Challenge site).",
            ],
            "checks": [
                "21 ledger readings sampled across the v2 film (requests, tool calls, output tokens, latest prompt, "
                "files opened) reproduced within 2 tokens.",
                "v3 stills at 35/70/95 % of every shot compared side by side with the v2 frames (84 pairs).",
            ],
            "exact": "request count 28, tool calls 44 by tool, step times shown on cards, 12 prompt-token values printed on screen, "
                     "final output-token total 33,040, criteria results, reward, deliverable sizes",
            "approximate": "the other 16 prompt-token values (read from the context chart, bias-corrected) and the per-request "
                           "split of output tokens between sampled ledger readings",
            "unknown": "two Word input files whose names never appear on screen (shown nowhere in v3 either); "
                       "criterion weights other than R20 and R32",
            "label_corrections": ["h14 stage label 'Bash ×8 · TodoWrite' -> 'Bash ×7 · TodoWrite' (the v2 ledger shows 7 Bash calls and 1 TodoWrite in steps 39–46)"],
        },
        "validation": {
            "geometry_report": f"docs/video/{DOC}/guide-geometry-qa.json",
            "font_selection": f"docs/video/{DOC}/font-selection.json",
            "render_receipt": f"docs/video/{DOC}/render-receipt.json",
            "render_input_fingerprint": receipt["input_fingerprint"],
            "geometry_passed": qa["passed"],
            "frames_checked": qa["frames_checked"],
            "cue_boundaries_checked": qa["cues_checked"],
            "video_checks": "Full render frame count, frame rate and dimensions verified with ffprobe before packaging.",
            "review_scope": "Automated geometry, text and asset checks plus side-by-side stills; these records do not claim full human viewing or listening.",
        },
        "chapters": [{"name": CHAPTERS[i], "start_seconds": round(a_, 3), "end_seconds": round(b_, 3)}
                     for i, (a_, b_) in enumerate(tl.chapters)],
        "shots": [{"id": s.id, "chapter": CHAPTERS[s.ch], "kind": s.kind, "start_seconds": round(s.start, 3),
                   "end_seconds": round(s.end, 3), "narration_en": s.en, "trace_seconds": s.d.get("trace")}
                  for s in tl.shots],
        "files": {
            f"assets/video/{NAME}.mp4": {"bytes": os.path.getsize(mp4), "sha256": sha(mp4)},
            f"assets/video/{NAME}-poster.jpg": {"bytes": os.path.getsize(poster), "sha256": sha(poster)},
            **{f"docs/video/{DOC}/{fn}": {"bytes": os.path.getsize(os.path.join(out_d, fn)), "sha256": sha(os.path.join(out_d, fn))}
               for fn in sorted(os.listdir(out_d)) if fn != "provenance.json"},
        },
        "sources": {
            "run_export": {"path": relative(data_path), "sha256": sha(data_path), "note": "reconstructed; see reconstruction"},
            "request_metadata": {"path": relative(log_path), "sha256": sha(log_path), "note": "reconstructed; usage and tool names only"},
            "voice_cache_index": {"path": f"build/{RUN}/voice.json", "sha256": sha(os.path.join(build, "voice.json"))},
        },
        "editable_source": {
            "directory": ".",
            "files_sha256": source_hashes,
            "requirements": "requirements-render.txt",
            "instructions": "README-hr-v3.md",
            "rebuild": [f"python -X utf8 engine/render.py {RUN} --workers 2",
                        "python -X utf8 engine/package_hr.py"],
            "offline": "Uses the 28 cached narration MP3 clips and build/hr/voice.json; do not run voice.py for this rebuild.",
        },
        "boundaries": [
            "Editorial replay of an existing recorded pilot run; no new agent run, no re-scoring.",
            "The run data are a reconstruction from the published v2 film, not the original run export.",
            "Claude Code and Bash run inside the task's Docker container; the model is reached through an API.",
            "The rubric and tests are absent during the agent run; Harbor copies tests into the same container afterwards.",
            "Judge sessions are separate per criterion; scores never feed back into the recorded agent run.",
        ],
    }
    if source_hashes != {relative(f): sha(f) for f in src_files}:
        raise RuntimeError("Editable source changed during packaging; run packaging again after edits finish")
    write_json(os.path.join(out_d, "provenance.json"), prov)
    print(json.dumps({"mp4": mp4, "duration": prov["duration_seconds"],
                      "sha256": prov["files"][f"assets/video/{NAME}.mp4"]["sha256"], "poster": poster}, indent=1))


if __name__ == "__main__":
    main()
