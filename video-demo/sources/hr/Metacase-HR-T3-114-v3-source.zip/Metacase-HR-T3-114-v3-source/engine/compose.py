"""Frame compositor: background, header, columns, centre scene, guide, captions, progress.

usage (preview stills):  python engine/compose.py fin f05:3.5 f09:6 ...  -> build/<run>/preview/*.png
"""
from __future__ import annotations

import importlib
import math
import os
import sys

import skia

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import gfx as G  # noqa: E402
import ui as U  # noqa: E402
import panels as P  # noqa: E402
import scenes as S  # noqa: E402
import scenes_x  # noqa: E402,F401
import rundata  # noqa: E402
from timeline import Timeline, FPS  # noqa: E402
from guide import Guide  # noqa: E402
from reference_bookends import draw_open, draw_outro  # noqa: E402

XFADE = 0.42


def stage_alpha(T, duration):
    """Reference whole-stage fades, including header, guide and captions."""
    return min(G.ease(T / 0.35), G.ease((duration - T) / 0.65))


class Ctx:
    def __init__(self, run_key):
        self.key = run_key
        G.set_run(run_key)
        self.tl = Timeline(run_key)
        self.story = self.tl.story
        self.conf = self.story.CONF
        self.run = rundata.load(run_key)
        self.scenes = dict(S.SCENES)
        extra = getattr(self.story, "SCENES", None)
        if extra:
            self.scenes.update(extra)
        self.scenes.update(open=draw_open, outro=draw_outro)
        self._pet_track = None
        self.guide = Guide(self)

    # ------------------------------------------------------------------ guide track
    def pet_track(self):
        if self._pet_track is not None:
            return self._pet_track
        keys = []
        for sh in self.tl.shots:
            for c, tgt in sh.d.get("pet", []):
                tc = sh.start + sh.cue(c)
                keys.append((tc, anchor(tgt, sh)))
        keys.sort(key=lambda k: k[0])
        self._pet_track = keys
        return keys


def anchor(tgt, sh):
    full = sh.kind in S.FULL
    if isinstance(tgt, tuple) and len(tgt) == 2 and not isinstance(tgt[0], str):
        tip = tgt
    elif isinstance(tgt, str) and tgt.startswith("card"):
        i = int(tgt[4])
        tip = (U.CARD_X[i] + U.CARD_W / 2, U.CARD_Y + U.CARD_H + 2)
    elif isinstance(tgt, str) and tgt.startswith("stage"):
        i = int(tgt[5])
        tip = (U.STAGE_X[i] + U.STAGE_W / 2, U.STAGE_Y + U.STAGE_H + 30)
    elif tgt == "route":
        tip = (960, U.STAGE_Y + U.STAGE_H + 56)
    elif tgt == "plan":
        tip = (U.LX + U.LW + 2, 640)
    elif tgt == "task":
        tip = (U.LX + U.LW + 2, 300)
    elif tgt == "ledger":
        tip = (U.RX - 2, 300)
    elif tgt == "found":
        tip = (U.RX - 2, 580)
    elif tgt == "output":
        tip = (U.RX - 2, 800)
    elif tgt == "rest":
        tip = None
    else:
        tip = None
    if full:
        lane = 800
        px = 250 if tip is None else max(200, min(1720, tip[0] - 150))
    else:
        lane = U.PET_LANE
        px = 1330 if tip is None else max(530, min(1395, tip[0] - 70))
        if tip is not None and tip[0] >= U.RX - 4:
            px = 1390
        if tip is not None and tip[0] <= U.LX + U.LW + 4:
            px = 540
        if isinstance(tgt, tuple) and tip is not None and tip[1] < U.CARD_Y and U.CX < tip[0] < U.CX + U.CW:
            px = max(530, min(1395, tip[0] - 45))  # hand right below the tip: a vertical stick through a gap
    return dict(tip=tip, x=px, lane=lane)


def pet_state(ctx, T):
    keys = ctx.pet_track()
    if not keys:
        return None
    prev = keys[0]
    cur = keys[0]
    tcur = keys[0][0]
    for i, (tk, an) in enumerate(keys):
        if tk <= T:
            prev = keys[i - 1] if i > 0 else keys[0]
            cur = (tk, an)
            tcur = tk
        else:
            break
    if T < keys[0][0]:
        an = keys[0][1]
        return dict(x=an["x"] - 260 * (1 - G.ease(G.seg(T, 0, 1.2))), lane=an["lane"], tip=None, walking=T < 1.2, tipk=0)
    pa, ca = prev[1], cur[1]
    dx = ca["x"] - pa["x"]
    dur = min(1.3, abs(dx) / 520 + 0.25)
    f = G.seg(T, tcur - 0.15, tcur - 0.15 + dur)
    x = G.lerp(pa["x"], ca["x"], G.ease_in_out(f))
    lane = G.lerp(pa["lane"], ca["lane"], G.ease_in_out(f))
    walking = abs(dx) > 20 and 0 < f < 1
    tipk = G.ease(G.seg(T, tcur + 0.05, tcur + 0.5))
    tip_from = pa["tip"]
    tip_to = ca["tip"]
    return dict(x=x, lane=lane, walking=walking, tip_from=tip_from, tip_to=tip_to, tipk=tipk)


def draw_pet(cv, ctx, T, a=1.0):
    st = pet_state(ctx, T)
    if st is None:
        return
    blink = (T % 3.7) < 0.12
    hand = G.pet(cv, st["x"], st["lane"], u=6.0, t=T, walking=st["walking"], a=a, blink=blink)
    tf, tt, k = st.get("tip_from"), st.get("tip_to"), st.get("tipk", 0)
    if tt is None and tf is None:
        return
    if tt is None:
        tip, pa = tf, 1 - k
    elif tf is None:
        tip, pa = tt, k
    else:
        tip = (G.lerp(tf[0], tt[0], G.ease_in_out(k)), G.lerp(tf[1], tt[1], G.ease_in_out(k)))
        pa = 1.0
    if pa > 0.01:
        G.pointer(cv, hand, tip, a=a * pa)


# ------------------------------------------------------------------ persistent state
def chips_values(ctx, sh, t):
    vals = list(ctx.conf["chips"])
    judge_open = sh.ch >= 3 or (sh.kind == "handoff" and t >= sh.cue("tests"))
    if not judge_open:
        vals[3] = ("JUDGE", "sealed")
    return vals


def default_state(ctx, sh, t):
    T = sh.trace_at(t)
    st = dict(T=T, active=None, track=None, plan_flash=None, self_tag=0.0, found_extra=None,
              files=ctx.story.outputs(T if T is not None else (-1 if sh.ch < 1 else ctx.run.duration)),
              out_hi=0.0, out_kind=None, ledger_hi=None, task_hi=0.0, plan_hi=0.0, found_hi=None)
    if T is None and sh.ch >= 2:
        st["T"] = ctx.run.duration
        st["files"] = ctx.story.outputs(ctx.run.duration)
    beats = []
    for p in sh.d.get("phases", []):
        beats += p.get("beats", [])
    if beats:
        act, pkt = S._stage_state(sh, t, beats)
        if act:
            best = max(act.items(), key=lambda kv: kv[1])
            role = {0: "model", 1: "harness", 2: "sandbox", 3: "model"}[best[0]]
            st["active"] = {role: best[1]}
            st["track"] = ({0: 0, 1: 1, 2: 2, 3: 0}[best[0]] if pkt is None else min(2.0, pkt), role)
    if sh.ch >= 3:
        st["active"] = {"scorer": 1.0}
        st["track"] = (3, "scorer")
    for k, v in sh.d.get("state", {}).items():
        st[k] = v
    fn = getattr(ctx.story, "STATE", {}).get(sh.id) or getattr(S, "STATE", {}).get(sh.kind)
    if fn:
        fn(ctx, sh, t, st)
    return st


def draw_columns(cv, ctx, sh, t, st, a=1.0):
    conf = ctx.conf
    T = st["T"]
    P.task_card(cv, conf, a=a, hi=st.get("task_hi", 0.0))
    todos = ctx.run.plan(T) if T is not None else None
    # The reference pet leaves its opening dock across the plan's footnote.
    # Reveal that one line once the pet has cleared it; the panel enters normally.
    footer_a = G.ease((t - 0.65) / 0.2) if sh.id == "f01" else 1.0
    P.plan_card(cv, conf, todos, a=a, hi=st.get("plan_hi", 0.0), flash=st.get("plan_flash"),
                self_tag=st.get("self_tag", 0.0), reveal=st.get("plan_reveal", 1.0),
                n_slots=conf.get("plan_slots", 9), footer_a=footer_a)
    P.ledger_card(cv, conf, ctx.run, T, a=a, hi=st.get("ledger_hi"))
    P.found_card(cv, conf, ctx.run, T, a=a, extra=st.get("found_extra"), hi_label=st.get("found_label"), hi=st.get("found_hi") or 0.0)
    P.output_card(cv, conf, st["files"], a=a, hi=st.get("out_hi", 0.0), hi_kind=st.get("out_kind"))
    U.chips(cv, chips_values(ctx, sh, t), active=st.get("active"), a=a, track_pos=st.get("track"),
            dims=st.get("chip_dims"))


def draw_scene(cv, ctx, sh, t, a):
    fn = ctx.scenes.get(sh.kind) or ctx.scenes.get(sh.d.get("as", ""))
    if fn is None:
        U.panel(cv, U.CX, U.PANEL_Y, U.CW, U.BOT - U.PANEL_Y, a=a)
        G.text(cv, f"[{sh.kind}]", 960, 520, size=30, c=G.DIM, a=a, align="center")
        return
    fn(cv, sh, t, a, ctx)


def frame(cv, ctx, T):
    tl = ctx.tl
    sh, t, idx = tl.locate(T)
    prev = tl.shots[idx - 1] if idx > 0 else None
    # Match #stage opacity from task0001 enhancement.js. The body page color
    # stays underneath, while every stage pixel (including captions/header)
    # participates in the 0.35s entrance and final 0.65s exit.
    alpha = stage_alpha(T, tl.nframes / FPS)
    cv.clear(G.color(G.PAGE))
    if alpha < 1:
        stage_paint = skia.Paint()
        stage_paint.setAlphaf(alpha)
        cv.saveLayer(None, stage_paint)
    else:
        cv.save()
    U.background(cv)
    st = default_state(ctx, sh, t)
    if st["T"] is not None and sh.ch >= 1 and sh.d.get("trace") is not None:
        clock = ("agent run", f"+{st['T']:05.1f} s")
    elif sh.ch == 0:
        clock = ("agent run", "+000.0 s")
    else:
        clock = ("agent run", f"{ctx.run.duration:.1f} s · ended")
    if sh.kind not in ("open", "outro"):
        U.header(cv, sh.ch, tl.chapter_progress(sh.ch, T), clock)
    kin = G.ease(G.seg(t, 0.0, XFADE)) if prev is not None else 1.0
    outgoing = 1 - kin
    if prev is not None and sh.kind == "outro":
        # The approved reference removes the result foreground before the
        # closing foreground appears; their glyphs never crossfade together.
        outgoing = 1 - G.ease(t / 0.32)
        kin = G.ease((t - 0.34) / 0.34)
    full = sh.kind in S.FULL
    pfull = prev.kind in S.FULL if prev is not None else full
    # columns: fade when switching between panel and full-frame modes
    col_a = 0.0 if full else 1.0
    if prev is not None and pfull != full:
        col_a = kin if not full else (1 - kin)
    if col_a > 0.01:
        stc = st if not full else default_state(ctx, prev, prev.dur)
        shc = sh if not full else prev
        draw_columns(cv, ctx, shc, t if not full else prev.dur, stc, a=col_a)
    if prev is not None and outgoing > 0:
        draw_scene(cv, ctx, prev, prev.dur, outgoing)
    draw_scene(cv, ctx, sh, t, kin)
    ctx.guide.draw(cv, T)
    # captions: in from the first word, out at the shot end
    ca = G.ease(G.seg(t, sh.lead - 0.22, sh.lead + 0.05)) * (1 - G.ease(G.seg(t, sh.dur - 0.12, sh.dur + 0.02)))
    U.captions(cv, sh.en, None, sh.d.get("st"), a=ca)  # v3: English captions only
    U.progress(cv, T / tl.duration)
    cv.restore()


def render_still(ctx, T, path):
    surf = skia.Surface(G.W, G.H)
    cv = surf.getCanvas()
    frame(cv, ctx, T)
    surf.makeImageSnapshot().save(path, skia.kPNG)


if __name__ == "__main__":
    run = sys.argv[1]
    ctx = Ctx(run)
    out = os.path.join(ROOT, "build", run, "preview")
    os.makedirs(out, exist_ok=True)
    for spec in sys.argv[2:]:
        sid, tt = spec.split(":")
        sh = next(s for s in ctx.tl.shots if s.id == sid)
        tt = sh.cue(tt) + 0.6 if not tt.replace(".", "").isdigit() else float(tt)
        p = os.path.join(out, f"{sid}_{tt:05.2f}.png")
        render_still(ctx, sh.start + tt, p)
        print(p)
