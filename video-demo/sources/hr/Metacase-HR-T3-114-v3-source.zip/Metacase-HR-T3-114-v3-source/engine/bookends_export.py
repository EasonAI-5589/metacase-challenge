"""Standalone Metacase opening (3.6 s) and closing (6.0 s) titles for the SFF booth loop.

Brand only: no guide robot, no captions, no task chips. Same frame size, rate,
H.264 settings and BT.709 tagging as the film, with a silent AAC track so the
clips concatenate with the SFF loop. The closing title reuses the film's outro
drawing (engine/reference_bookends.py) on its own clock.

usage: python -X utf8 engine/bookends_export.py fin
outputs: build/<run>/finance-intro.mp4, build/<run>/finance-outro.mp4
"""
from __future__ import annotations

import os
import subprocess
import sys
from types import SimpleNamespace

import skia

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
sys.path[:0] = [HERE, ROOT]

import gfx as G  # noqa: E402
import brand as B  # noqa: E402
import compose  # noqa: E402
from reference_bookends import _spotlight, _text, draw_outro  # noqa: E402
from render import COLOR, FFMPEG, FPS, HEIGHT, WIDTH, verify_video  # noqa: E402

INTRO_SECONDS = 3.6
OUTRO_SECONDS = 6.0


def draw_intro(cv, T):
    """The brand lockup on the opening spotlight, on a millisecond clock."""
    ms = T * 1000
    a = G.ease(T / 0.35)
    cv.clear(G.color(G.PAGE))
    _spotlight(cv, "open", a)
    cv.save()
    cv.scale(1.5, 1.5)
    B.draw_mark(cv, 640, 236, 72, ms=ms - 150, a=a)
    rise = (1 - G.ease_out((ms - 700) / 600)) * 10
    B.wordmark(cv, 640, 288 + rise, 60, a=a * G.clamp((ms - 700) / 450), align="center")
    _text(cv, "GLOBAL METACASE INITIATIVE", 368, 13, G.DIM, a * G.clamp((ms - 1000) / 450),
          kind="brandmono", weight=400, ls=3.2)
    B.crests(cv, 640, 404, slot=52, gap=14,
             alphas=[a * G.clamp((ms - 1300 - j * 90) / 400) for j in range(4)])
    _text(cv, B.HOSTED.upper(), 474, 12, G.DIM, a * G.clamp((ms - 1800) / 450),
          kind="brandmono", weight=400, ls=1.1)
    cv.restore()


def draw_closing(cv, ctx, T):
    """The film's outro foreground, without the guide or captions."""
    cv.clear(G.color(G.PAGE))
    fade = min(G.ease(T / 0.35), G.ease((OUTRO_SECONDS - T) / 0.65))
    layer = skia.Paint()
    layer.setAlphaf(fade)
    cv.saveLayer(None, layer)
    # draw_outro maps its shot onto 5.2 reference seconds; play them 1:1, then hold.
    draw_outro(cv, SimpleNamespace(dur=5.2), min(T, 5.2), 1.0, ctx)
    cv.restore()


def export(path, seconds, draw):
    frames = round(seconds * FPS)
    surf = skia.Surface(WIDTH, HEIGHT)
    cv = surf.getCanvas()
    pix = "bgra" if surf.imageInfo().colorType() == skia.kBGRA_8888_ColorType else "rgba"
    enc = subprocess.Popen(
        [FFMPEG, "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", pix, "-s", f"{WIDTH}x{HEIGHT}",
         "-r", str(FPS), "-i", "-", "-f", "lavfi", "-i", "anullsrc=channel_layout=mono:sample_rate=48000",
         "-vf", "scale=out_color_matrix=bt709:out_range=tv:flags=lanczos,format=yuv420p",
         "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-profile:v", "high",
         "-c:a", "aac", "-b:a", "96k", "-shortest", "-t", f"{frames / FPS:.6f}",
         *COLOR, "-movflags", "+faststart", path],
        stdin=subprocess.PIPE)
    for i in range(frames):
        draw(cv, i / FPS)
        enc.stdin.write(surf.makeImageSnapshot().tobytes())
    enc.stdin.close()
    if enc.wait():
        raise RuntimeError(f"FFmpeg failed for {path}")
    verify_video(path, frames)
    return path


def main(run):
    ctx = compose.Ctx(run)
    out = os.path.join(ROOT, "build", run)
    os.makedirs(out, exist_ok=True)
    intro = export(os.path.join(out, "finance-intro.mp4"), INTRO_SECONDS, draw_intro)
    outro = export(os.path.join(out, "finance-outro.mp4"), OUTRO_SECONDS,
                   lambda cv, T: draw_closing(cv, ctx, T))
    print("wrote", intro, outro)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "fin")
