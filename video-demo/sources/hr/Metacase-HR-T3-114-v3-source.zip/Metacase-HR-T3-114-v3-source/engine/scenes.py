"""Scene drawing. Each kind draws the centre panel (or the full frame) for one shot.

All timing inside a shot is keyed to narration cues (word times), so motion follows the voice.
"""
from __future__ import annotations

import math

import gfx as G
import ui as U
import panels as P

FULL = {"open", "chapter", "reward", "outro"}


def cue(sh, name, default=None):
    return sh.cue(name, default)


def after(sh, t, name, d=0.45, delay=0.0):
    """Eased 0..1 progress starting at cue `name` (a continuing shot treats missing cues as past)."""
    c = cue(sh, name, -10.0 if sh.d.get("cont") else None)
    return G.ease(G.seg(t, c + delay, c + delay + d))


def phase_index(sh, t, phases):
    idx = 0
    for i, ph in enumerate(phases):
        if t >= cue(sh, ph.get("at", 0.0)) - 0.05:
            idx = i
    return idx


# ============================================================================ loop scenes
def loop_frame(cv, a, title, sub, rq, accent=None, accent_a=0.0, sub_a=1.0):
    U.panel(cv, U.CX, U.PANEL_Y, U.CW, U.BOT - U.PANEL_Y, a=a, accent=accent, accent_a=accent_a)
    G.text(cv, title, 502, 226, size=31, c=G.HARNESS, weight=600, a=a, ls=-0.4)
    G.text(cv, sub, 502, 270, size=19.5, c=G.FG, a=a * sub_a, maxlines=1, width=760)
    if rq:
        G.text(cv, rq, 1418, 238, size=16, c=G.FG, kind="mono", a=a, align="right", ls=1.0)


def _stage_state(sh, t, beats):
    """beats: list of (cue, stage) -> highlight weights and travelling packet position."""
    act = {}
    pkt = None
    pts = [(cue(sh, c), s) for c, s in beats]
    for j, (tc, s) in enumerate(pts):
        nxt = pts[j + 1][0] if j + 1 < len(pts) else 1e9
        k = G.ease(G.seg(t, tc, tc + 0.35)) * (1 - G.ease(G.seg(t, nxt + 0.25, nxt + 0.6)))
        if s >= 0:
            act[s] = max(act.get(s, 0.0), k)
        if j > 0 and pts[j - 1][1] >= 0 and s >= 0 and s > pts[j - 1][1]:
            f = G.seg(t, tc - 0.55, tc)
            if 0 < f < 1:
                pkt = pts[j - 1][1] + (s - pts[j - 1][1]) * G.ease_in_out(f)
    return act, pkt


def draw_loop(cv, sh, t, a, ctx):
    phases = sh.d["phases"]
    i = phase_index(sh, t, phases)
    ph = phases[i]
    k_in = G.ease(G.seg(t, cue(sh, ph.get("at", 0.0)) - 0.05, cue(sh, ph.get("at", 0.0)) + 0.3)) if i > 0 else 1.0
    title = sh.d.get("title", "Claude Code · tool loop")
    loop_frame(cv, a, title, ph.get("sub", sh.d.get("sub", "")), ph.get("rq", ""),
               accent=G.ROLE.get(sh.d.get("accent", "sandbox")), accent_a=0.35)
    beats = []
    for p in phases:
        beats += p.get("beats", [])
    act, pkt = _stage_state(sh, t, beats)
    fail = max((after(sh, t, p["fail"], 0.3) for p in phases if p.get("fail")), default=0.0)
    U.stage_boxes(cv, ph.get("stages", ["qwen3.7-max", "Bash", "/app", "next request"]), act=act, a=a,
                  fail=fail, labels=ph.get("labels", sh.d.get("labels")), container=sh.d.get("container", 1.0),
                  dim=ph.get("dim"))
    route = [p["route"] for p in phases if p.get("route")]
    rprog, rhi = None, 0.0
    for rc in route:
        f = G.seg(t, cue(sh, rc), cue(sh, rc) + 1.1)
        if 0 < f < 1:
            rprog = G.ease_in_out(f)
        rhi = max(rhi, G.fade_io(t, cue(sh, rc), cue(sh, rc) + 2.2, 0.35))
    U.return_route(cv, a=a, hi=rhi, prog=rprog, label=sh.d.get("route_label", "results return to the model in the next request"))
    if pkt is not None:
        U.forward_packet(cv, pkt, G.ROLE["model"] if pkt < 1 else (G.HARNESS if pkt < 2 else G.SANDBOX), a=a)
    # cards (cross-fade between phases)
    for j in (i - 1, i):
        if j < 0:
            continue
        pa = a * (k_in if j == i else (1 - k_in))
        if pa <= 0.01:
            continue
        _cards(cv, sh, t, pa, phases[j])
    foot = ph.get("foot") or sh.d.get("foot")
    if foot:
        # The fixed right hand points beside the first card at x798. Wrapping
        # here keeps every original word left of that lane without truncation.
        foot_width = 270
        G.text(cv, foot, 502, 724, size=15, c=G.DIM, kind="mono",
               a=a * k_in, maxlines=None, width=foot_width)
    if ph.get("foot2"):
        G.text(cv, ph["foot2"], 502, 750, size=14, c=G.FAINT if not ph.get("foot2c") else G.ROLE[ph["foot2c"]], kind="mono", a=a * k_in, maxlines=1, width=916)
    extra = sh.d.get("overlay")
    if extra:
        OVERLAYS[extra](cv, sh, t, a, ctx)


def _cards(cv, sh, t, a, ph):
    for ci, cd in enumerate(ph.get("cards", [])):
        if cd is None:
            continue
        ca = a * after(sh, t, cd.get("at", ph.get("at", 0.0)), 0.35, cd.get("delay", 0.0))
        if ca <= 0.01:
            continue
        rev = 1.0
        if cd.get("reveal"):
            r0 = cue(sh, cd["reveal"][0])
            r1 = cue(sh, cd["reveal"][1]) if isinstance(cd["reveal"][1], str) else r0 + cd["reveal"][1]
            rev = G.seg(t, r0, r1)
        act = 0.0
        for hc in cd.get("hi", []):
            end = cue(sh, hc[1]) if isinstance(hc[1], (str, tuple, list)) else cue(sh, hc[0]) + hc[1]
            act = max(act, G.fade_io(t, cue(sh, hc[0]), end, 0.3))
        if cd.get("hold_hi"):
            act = max(act, after(sh, t, cd["hold_hi"], 0.35))
        line_a = None
        if cd.get("line_at"):
            line_a = [G.ease(G.seg(t, cue(sh, c), cue(sh, c) + 0.3)) for c in cd["line_at"]]
        U.detail_card(cv, ci if cd.get("slot") is None else cd["slot"], cd["kick"], cd.get("title"), cd.get("lines", []),
                      role=cd.get("role", "brand"),
                      act=act, a=ca, mono=cd.get("mono", False), size=cd.get("size"), reveal=rev,
                      line_cols=[G.ROLE.get(c) if isinstance(c, str) else c for c in cd.get("cols", [])] or None,
                      x=cd.get("x"), w=cd.get("w"), title_c=G.ROLE.get(cd["title_c"]) if cd.get("title_c") else None,
                      line_a=line_a, span=cd.get("span", 1), gap=cd.get("gap"), maxl=cd.get("maxl", 3))


# ============================================================================ overlays (extra layers on loop shots)
def ov_binary(cv, sh, t, a, ctx):
    """f07: the docx letter returns zip bytes — show them garbled inside the observation card."""
    k = after(sh, t, "bin", 0.4)
    if k <= 0.01:
        return
    x, y, w = U.CARD_X[1] + 18, U.CARD_Y + 172, U.CARD_W * 2 + 23 - 36
    G.rrect(cv, x - 8, y - 6, w + 16, 56, 8, fill=(40, 20, 24), stroke=G.FAIL, sw=1.2, a=a * k * 0.9)
    G.text(cv, "step 4 · 60_…委托.docx →", x, y, size=13, c=G.FAIL, kind="mono", a=a * k)
    G.text(cv, "PK␃␄ [Content_Types].xml ��MO�@����/> {C��p(p,�D���8Y�/�L���:�U�", x, y + 22, size=13.5, c=(226, 150, 150), kind="mono", a=a * k, width=w, maxlines=1)


def ov_docx_text(cv, sh, t, a, ctx):
    pass


OVERLAYS = {"binary": ov_binary, "docx_text": ov_docx_text}


# ============================================================================ full-frame scenes
def draw_open(cv, sh, t, a, ctx):
    conf = ctx.conf
    k = G.ease(G.seg(t, 0.0, 0.9))
    G.rrect(cv, 960 - 34, 300, 68, 68, 16, fill=(25, 25, 25), stroke=(58, 67, 82), sw=1.6, a=a * k)
    G.text(cv, "N", 960, 305, size=50, c=G.WHITE, kind="serif", a=a * k, align="center")
    w1, _ = G.measure("Inference", 88, 600, ls=-3)
    w2, _ = G.measure("Net", 88, 600, ls=-3)
    x0 = 960 - (w1 + w2) / 2
    G.text(cv, "Inference", x0, 392, size=88, c=G.WHITE, weight=600, a=a * k, ls=-3)
    G.text(cv, "Net", x0 + w1, 392, size=88, c=G.BRAND, weight=600, a=a * k, ls=-3)
    G.text(cv, "PROFESSIONAL TASKS", 960, 506, size=16, c=G.DIM, kind="mono", a=a * k, align="center", ls=7)
    ka = after(sh, t, "a", 0.5)
    names = [(r, v) for r, (kk, v) in zip(U.ROLE_KEYS, conf["chips"])]
    names[3] = ("scorer", "independent judge")
    widths = [G.measure(v, 18, 500, "mono")[0] + 64 for _, v in names]
    gap = 22
    x = 960 - (sum(widths) + gap * 3) / 2
    for j, ((role, v), wv) in enumerate(zip(names, widths)):
        kj = a * G.ease(G.seg(t, cue(sh, "a") + j * 0.18, cue(sh, "a") + j * 0.18 + 0.45))
        rc = G.ROLE[role]
        G.rrect(cv, x, 572 + (1 - kj) * 14, wv, 48, 24, fill=G.mix(G.PANEL, rc, 0.12), stroke=rc, sw=1.5, a=kj)
        G.icon_role(cv, role, x + 26, 596 + (1 - kj) * 14, rc, a=kj, s=8)
        G.text(cv, v, x + 44, 583 + (1 - kj) * 14, size=18, c=G.FG, kind="mono", a=kj)
        x += wv + gap
    kb = after(sh, t, "b", 0.5)
    G.text(cv, f"{conf['task_id']}  ·  {conf['title']}", 960, 660, size=22, c=G.FG, weight=500, a=a * kb, align="center")
    # v3 (English only): the Chinese subtitle is not drawn.


def draw_chapter(cv, sh, t, a, ctx):
    k = G.ease(G.seg(t, 0.0, 0.7))
    for r, al in ((150, 0.10), (110, 0.16), (72, 0.25)):
        G.circle(cv, 960, 330, r * (0.85 + 0.15 * k), stroke=G.SCORER, sw=1.5, a=a * al * k)
    G.icon_role(cv, "scorer", 960, 330, G.SCORER, a=a * k, s=26)
    G.text(cv, f"CHAPTER 0{sh.ch + 1}", 960, 432, size=15, c=G.DIM, kind="mono", a=a * k, align="center", ls=6)
    G.text(cv, sh.d["title"], 960, 466, size=64, c=G.WHITE, weight=600, a=a * k, align="center", ls=-1.5)
    G.text(cv, sh.d["sub"], 960, 556, size=22, c=G.DIM, a=a * G.ease(G.seg(t, 0.4, 1.1)), align="center")


def draw_outro(cv, sh, t, a, ctx):
    k = G.ease(G.seg(t, 0.0, 0.8))
    G.rrect(cv, 960 - 30, 250, 60, 60, 14, fill=(25, 25, 25), stroke=(58, 67, 82), sw=1.6, a=a * k)
    G.text(cv, "N", 960, 254, size=44, c=G.WHITE, kind="serif", a=a * k, align="center")
    w1, _ = G.measure("Inference", 72, 600, ls=-2.5)
    w2, _ = G.measure("Net", 72, 600, ls=-2.5)
    x0 = 960 - (w1 + w2) / 2
    G.text(cv, "Inference", x0, 330, size=72, c=G.WHITE, weight=600, a=a * k, ls=-2.5)
    G.text(cv, "Net", x0 + w1, 330, size=72, c=G.BRAND, weight=600, a=a * k, ls=-2.5)
    G.text(cv, "CHALLENGE · PROFESSIONAL TASKS", 960, 430, size=15, c=G.DIM, kind="mono", a=a * k, align="center", ls=5)
    k2 = G.ease(G.seg(t, 0.8, 1.6))
    G.text(cv, ctx.conf.get("outro_q", "Finance and HR tasks with expert rubrics"), 960, 494, size=34, c=G.FG, weight=600, a=a * k2, align="center")
    k3 = after(sh, t, "site", 0.5)
    url = "easonai-5589.github.io/inferencenet-challenge"
    tw, _ = G.measure(url, 19, 500, "mono")
    G.rrect(cv, 960 - tw / 2 - 26, 566, tw + 52, 46, 23, fill=G.BRAND_TINT, stroke=G.BRAND, sw=1.5, a=a * k3)
    G.text(cv, url, 960, 577, size=19, c=G.BRAND, kind="mono", a=a * k3, align="center")
    G.text(cv, "Scenarios contributed by Shanghai University of Finance and Economics", 960, 640, size=17, c=G.DIM, a=a * k3, align="center")


SCENES = {
    "loop": draw_loop,
    "open": draw_open,
    "chapter": draw_chapter,
    "outro": draw_outro,
}
