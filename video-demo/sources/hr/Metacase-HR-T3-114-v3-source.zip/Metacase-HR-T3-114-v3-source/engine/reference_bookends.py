"""Task0001 v3.2 bookends, with the existing finance copy and shot durations.

Reference: reference/task0001-v3.2/index.html, OPEN_PTC/renderOpen/renderEnd
(lines 684–743 and 900–908), plus enhancement.css #stage. The original HTML
SHA-256 is d229957a3c3b48d3369d817d33427d2845a47e4011e07dff9d103d0bf83a93d7.
Only the presentation clock is remapped: 5,000 / 5,200 reference milliseconds
span the existing opening / ending shot. Narration and timeline are untouched.
"""
from __future__ import annotations

import math
from functools import lru_cache

import skia

import gfx as G
import brand as B

REFERENCE_INDEX_SHA256 = "d229957a3c3b48d3369d817d33427d2845a47e4011e07dff9d103d0bf83a93d7"
ROLES = ("model", "harness", "sandbox", "scorer")
PALETTE = (G.MODEL, G.HARNESS, G.SANDBOX, G.SCORER, G.BRAND)


def _mulberry32(seed):
    """Preserve the original JS uint32 generator and random-call order."""
    while True:
        seed = (seed + 0x6D2B79F5) & 0xFFFFFFFF
        x = ((seed ^ (seed >> 15)) * (1 | seed)) & 0xFFFFFFFF
        x = ((x + (((x ^ (x >> 7)) * (61 | x)) & 0xFFFFFFFF)) & 0xFFFFFFFF) ^ x
        yield ((x ^ (x >> 14)) & 0xFFFFFFFF) / 4294967296.0


@lru_cache(maxsize=1)
def particles():
    rnd = _mulberry32(20261018)
    out = []
    for i in range(84):
        color = PALETTE[int(next(rnd) * len(PALETTE))]
        choice = next(rnd)
        size = 14 + next(rnd) * 8 if i % 3 == 0 else 12 + next(rnd) * 16
        size = round(size, 1) if i % 3 == 0 else math.floor(size + 0.5)
        ang, rad = next(rnd) * math.tau, 260 + next(rnd) * 300
        out.append(dict(
            color=color, text=i % 3 == 0, choice=choice, size=size,
            x0=640 + math.cos(ang) * rad * 1.25,
            y0=300 + math.sin(ang) * rad * 0.62,
            x1=640 + (next(rnd) - 0.5) * 26,
            y1=236 + (next(rnd) - 0.5) * 20,
            delay=next(rnd) * 600, curve=(next(rnd) - 0.5) * 240,
            spin=(next(rnd) - 0.5) * 260,
            dx=(next(rnd) - 0.5) * 36, dy=(next(rnd) - 0.5) * 36,
        ))
    return tuple(out)


def particle_state(q, milliseconds):
    k = G.clamp((milliseconds - 500 - q["delay"]) / 1900)
    e = G.ease_in_out(k)
    ox = q["x0"] + q["dx"] * milliseconds / 1000
    oy = q["y0"] + q["dy"] * milliseconds / 1000
    nx, ny = -(q["y1"] - oy), q["x1"] - ox
    length = math.hypot(nx, ny) or 1.0
    bend = math.sin(math.pi * e) * q["curve"]
    return dict(
        x=round(G.lerp(ox, q["x1"], e) + nx / length * bend, 1),
        y=round(G.lerp(oy, q["y1"], e) + ny / length * bend, 1),
        rotation=round(q["spin"] * e, 1),
        scale=round(1 - 0.5 * e, 3),
        alpha=round(G.clamp((milliseconds - q["delay"] * 0.4) / 450)
                    * (1 - G.clamp((k - 0.8) / 0.2)) * 0.9, 3),
    )


def _icon(cv, kind, size, color, a):
    """Original 24×24 SVG geometry, including centred SVG stroke widths."""
    cv.save()
    cv.scale(size / 24, size / 24)
    cv.translate(-12, -12)
    if kind == "model":
        G.poly(cv, [(12, 2.5), (21.5, 12), (12, 21.5), (2.5, 12)], color, a)
    elif kind == "harness":
        pts = [(12, 2.5), (20.5, 7.25), (20.5, 16.75), (12, 21.5), (3.5, 16.75), (3.5, 7.25)]
        G.line(cv, pts + [pts[0]], color, sw=2.4, a=a)
        G.circle(cv, 12, 12, 2.6, fill=color, a=a)
    elif kind == "sandbox":
        cv.drawRoundRect(skia.Rect.MakeXYWH(3.5, 3.5, 17, 17), 3, 3,
                         G.paint(color, a, stroke=2.4))
        cv.drawRoundRect(skia.Rect.MakeXYWH(8.5, 8.5, 7, 7), 1.2, 1.2, G.paint(color, a))
    else:
        G.circle(cv, 12, 12, 8.8, stroke=color, sw=2.4, a=a)
        G.circle(cv, 12, 12, 3.6, fill=color, a=a)
    cv.restore()


@lru_cache(maxsize=2)
def _background(kind):
    # Cache the original CSS elliptical gradients at output resolution.
    surface = skia.Surface(G.W, G.H)
    cv = surface.getCanvas()
    cv.scale(1.5, 1.5)
    if kind == "open":
        cx, cy = 1280 * 0.08, 720 * 0.65
        rx, ry = max(cx, 1280 - cx) * math.sqrt(2), max(cy, 720 - cy) * math.sqrt(2)
        colors, stops = [(39, 33, 30), (17, 25, 35), (11, 16, 23)], [0.0, 0.46, 0.85]
    else:
        cx, cy, rx, ry = 640, 720 * 0.45, 1280 * 0.7, 720 * 0.6
        colors, stops = [(15, 22, 33), (7, 10, 15)], [0.0, 0.75]
    cv.translate(cx, cy)
    cv.scale(rx, ry)
    shader = skia.GradientShader.MakeRadial((0, 0), 1, [G.color(c) for c in colors], stops)
    cv.drawPaint(skia.Paint(Shader=shader))
    return surface.makeImageSnapshot()


def _spotlight(cv, kind, a):
    paint = skia.Paint(Alphaf=G.clamp(a))
    cv.drawImage(_background(kind), 0, 0, paint=paint)


def _text(cv, text, y, size, color, a, *, kind="sans", weight=500, ls=0, max_width=1160):
    # Keep the complete finance wording; fit a long task title instead of truncating.
    width, _ = G.measure(text, size, weight, kind, ls=ls)
    fitted = size * min(1.0, max_width / max(width, 1.0))
    G.text(cv, text, 640, y, size=fitted, c=color, weight=weight, kind=kind,
           a=a, align="center", ls=ls)


def _mark(cv, y, a):
    G.rrect(cv, 610, y, 60, 60, 14, fill=(25, 25, 25), stroke=(58, 67, 82), sw=1, a=a)
    h = G.line_height(42, 400, "serif")
    G.text(cv, "N", 640, y + (58 - h) / 2, size=42, weight=400, kind="serif",
           c=G.WHITE, a=a, align="center")


def _wordmark(cv, y, a):
    size, spacing = 58, -58 * 0.035
    w1, _ = G.measure("Inference", size, 600, ls=spacing)
    w2, _ = G.measure("Net", size, 600, ls=spacing)
    x = 640 - (w1 + w2) / 2
    offset = (66 - G.line_height(size, 600, "sans")) / 2
    G.text(cv, "Inference", x, y + offset, size=size, c=G.WHITE, weight=600, a=a, ls=spacing)
    G.text(cv, "Net", x + w1, y + offset, size=size, c=G.BRAND, weight=600, a=a, ls=spacing)


def _scaled(cv, centre_y, scale, fn):
    cv.save()
    cv.translate(640, centre_y)
    cv.scale(scale, scale)
    cv.translate(-640, -centre_y)
    fn()
    cv.restore()


def draw_open(cv, sh, t, a, ctx):
    ms = 5000 * G.clamp(t / sh.dur)
    # Reference open overlay fades over its final 600 reference milliseconds.
    content = a * (1 - G.clamp((ms - 4400) / 600))
    _spotlight(cv, "open", a)
    cv.save()
    cv.scale(1.5, 1.5)
    # Task-specific labels come from the storyboard; the default is the Finance set.
    words = tuple(ctx.conf.get("particle_words", ("¥", "%", "Δ", "D01", "D06", "Word", "Excel", "28", "54", "414.7", "{ }"))) + (ctx.conf["task_id"],)
    cv.save()
    # enhancement.css places its caption band above this decorative particle
    # layer at y=601. Keep that reserved reading area clear in the Skia port.
    cv.clipRect(skia.Rect.MakeXYWH(0, 0, 1280, 601))
    for q in particles():
        st = particle_state(q, ms)
        alpha = content * st["alpha"]
        if alpha <= 0.003:
            continue
        cv.save()
        cv.translate(st["x"], st["y"])
        cv.rotate(st["rotation"])
        cv.scale(st["scale"], st["scale"])
        if q["text"]:
            text = words[int(q["choice"] * len(words))]
            height = G.line_height(q["size"], 400, "mono")
            G.text(cv, text, 0, -height / 2, size=q["size"], c=q["color"],
                   kind="mono", weight=400, a=alpha, align="center")
        else:
            _icon(cv, ROLES[int(q["choice"] * len(ROLES))], q["size"], q["color"], alpha)
        cv.restore()
    cv.restore()
    # v3: the homepage's Metacase mark, wordmark and institution row replace the
    # InferenceNet lockup; the reference clock and particle convergence are kept.
    logo_alpha = content * G.clamp((ms - 2050) / 450)
    logo_scale = 0.86 + 0.14 * G.back_out((ms - 2050) / 650, s=1.70158)
    B.draw_mark(cv, 640, 226, 62, ms=ms - 2050, a=content)
    _scaled(cv, 292, logo_scale, lambda: B.wordmark(cv, 640, 266, 52, a=logo_alpha, align="center"))
    _text(cv, "GLOBAL METACASE INITIATIVE", 336, 12, G.DIM, logo_alpha, kind="brandmono", weight=400, ls=3.0)
    B.crests(cv, 640, 362, slot=46, gap=12,
             alphas=[content * G.clamp((ms - 2700 - j * 90) / 400) for j in range(4)])
    host_alpha = content * G.clamp((ms - 3050) / 450)
    _text(cv, B.HOSTED.upper(), 420, 11, G.DIM, host_alpha, kind="brandmono", weight=400, ls=1.0)
    title_alpha = content * G.clamp((ms - 3200) / 500)
    rise = (1 - G.ease_out((ms - 3200) / 600)) * 12
    _text(cv, f"{ctx.conf['task_id']}  ·  {ctx.conf['title']}", 452 + rise, 24, G.WHITE, title_alpha)
    sub_alpha = content * G.clamp((ms - 3500) / 500)
    names = [(role, value) for role, (_, value) in zip(ROLES, ctx.conf["chips"])]
    names[3] = ("scorer", "independent judge")
    widths = [G.measure(value, 12, 500, "mono")[0] + 43 for _, value in names]
    gap = 15
    x = 640 - (sum(widths) + 3 * gap) / 2
    for j, ((role, value), width) in enumerate(zip(names, widths)):
        alpha = sub_alpha * G.clamp((ms - 3500 - j * 90) / 400)
        color = G.ROLE[role]
        G.rrect(cv, x, 500, width, 32, 16, fill=G.mix(G.PANEL, color, 0.12), stroke=color, sw=1, a=alpha)
        cv.save()
        cv.translate(x + 17, 516)
        _icon(cv, role, 15, color, alpha)
        cv.restore()
        G.text(cv, value, x + 29, 507, size=12, c=G.FG, kind="mono", a=alpha)
        x += width + gap
    cv.restore()


def draw_outro(cv, sh, t, a, ctx):
    ms = 5200 * G.clamp(t / sh.dur)
    # The compositor supplies enhancement.js's mutual exclusion with the result.
    _spotlight(cv, "outro", a)
    alpha = lambda at: a * G.clamp((ms - at) / 400)
    cv.save()
    cv.scale(1.5, 1.5)
    B.draw_mark(cv, 640, 132, 56, ms=ms - 150, a=a)
    B.wordmark(cv, 640, 170, 50, a=alpha(300), align="center")
    _text(cv, "GLOBAL METACASE INITIATIVE", 238, 12, G.DIM, alpha(380), kind="brandmono", weight=400, ls=3.0)
    B.crests(cv, 640, 262, slot=42, gap=12, alphas=[alpha(460 + j * 80) for j in range(4)])
    _text(cv, B.HOSTED.upper(), 314, 11, G.DIM, alpha(700), kind="brandmono", weight=400, ls=1.0)
    G.line(cv, [(500, 346), (780, 346)], G.FAINT, sw=1, a=alpha(760))
    rise = (1 - G.ease_out((ms - 900) / 500)) * 12
    _text(cv, ctx.conf.get("outro_q", "Finance and HR tasks with expert rubrics"),
          366 + rise, 30, G.WHITE, alpha(900), weight=600)
    url = B.SITE_URL
    width, _ = G.measure(url, 15, 400, "brandmono")
    G.rrect(cv, 640 - width / 2 - 20, 422, width + 40, 38, 19,
            fill=G.BRAND_TINT, stroke=B.T1, sw=1, a=alpha(1200))
    G.text(cv, url, 640, 430, size=15, c=B.T1, kind="brandmono", weight=400,
           a=alpha(1200), align="center")
    _text(cv, "Scenarios contributed by Shanghai University of Finance and Economics",
          482, 13, G.DIM, alpha(1400), kind="brandmono", weight=400)
    cv.restore()
