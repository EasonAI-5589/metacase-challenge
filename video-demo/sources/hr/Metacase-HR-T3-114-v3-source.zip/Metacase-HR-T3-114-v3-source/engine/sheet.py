"""Contact sheet: python engine/sheet.py out.png a.png b.png c.png d.png  (2x2 at half size)"""
import sys
from PIL import Image, ImageDraw
out, files = sys.argv[1], sys.argv[2:]
cols = 2
rows = (len(files) + 1) // 2
sheet = Image.new("RGB", (1920, 540 * rows), "black")
for i, f in enumerate(files):
    im = Image.open(f).convert("RGB").resize((960, 540), Image.LANCZOS)
    x, y = (i % cols) * 960, (i // cols) * 540
    sheet.paste(im, (x, y))
    d = ImageDraw.Draw(sheet)
    d.rectangle([x, y, x + 200, y + 18], fill="black")
    d.text((x + 4, y + 3), f.split("/")[-1], fill="yellow")
sheet.save(out)
print(out)
