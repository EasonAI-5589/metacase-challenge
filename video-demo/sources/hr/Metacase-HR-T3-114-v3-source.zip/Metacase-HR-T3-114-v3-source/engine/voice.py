"""Narration with en-US-AriaNeural, the voice of the approved PR #27 replay.

PR #27 sped its narration up by 1.12 with pitch preserved; here the same pace is
requested from the voice itself (rate +12%). Every shot is synthesised on its own
and the service's word boundaries are kept, so captions and visual cues can be
timed to the spoken words. Cached by text/voice/rate.

usage: python engine/voice.py fin|hr
"""
from __future__ import annotations

import asyncio
import hashlib
import importlib
import json
import os
import re
import subprocess
import sys

import edge_tts

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
VOICE = "en-US-AriaNeural"
RATE = "+12%"
MARK = re.compile(r"\{([a-z0-9_]+)\}")


def strip(text: str) -> tuple[str, dict[str, int]]:
    """Remove {key} markers and return the clean text plus each marker's char offset."""
    out, marks, pos = [], {}, 0
    for m in MARK.finditer(text):
        out.append(text[pos:m.start()])
        marks[m.group(1)] = len("".join(out))
        pos = m.end()
    out.append(text[pos:])
    clean = re.sub(r"\s+", " ", "".join(out)).strip()
    # Offsets were measured before whitespace normalisation; recompute robustly.
    fixed = {}
    for k, off in marks.items():
        prefix = re.sub(r"\s+", " ", "".join(out)[:off]).lstrip()
        fixed[k] = len(prefix)
    return clean, fixed


async def synth(text: str, mp3: str) -> list[dict]:
    comm = edge_tts.Communicate(text, VOICE, rate=RATE, boundary="WordBoundary")
    words = []
    with open(mp3, "wb") as f:
        async for ch in comm.stream():
            if ch["type"] == "audio":
                f.write(ch["data"])
            elif ch["type"] == "WordBoundary":
                words.append({"t0": ch["offset"] / 1e7, "t1": (ch["offset"] + ch["duration"]) / 1e7,
                              "w": ch["text"]})
    return words


def align(clean: str, words: list[dict]) -> None:
    pos = 0
    for w in words:
        i = clean.find(w["w"], pos)
        if i < 0:
            i = clean.lower().find(w["w"].lower(), pos)
        w["c"] = i if i >= 0 else pos
        if i >= 0:
            pos = i + len(w["w"])


def duration(path: str) -> float:
    out = subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                   "-of", "csv=p=0", path])
    return float(out.decode().strip())


async def build(run: str) -> list[dict]:
    story = importlib.import_module(f"story.{run}")
    outdir = os.path.join(ROOT, "build", run, "voice")
    os.makedirs(outdir, exist_ok=True)
    manifest = []
    for shot in story.SHOTS:
        clean, marks = strip(shot["say"])
        key = hashlib.sha256(f"{VOICE}|{RATE}|{clean}".encode()).hexdigest()[:16]
        mp3 = os.path.join(outdir, f"{shot['id']}-{key}.mp3")
        meta = mp3[:-4] + ".json"
        if os.path.exists(mp3) and os.path.exists(meta):
            words = json.load(open(meta))["words"]
        else:
            for attempt in range(4):
                try:
                    words = await synth(clean, mp3)
                    break
                except Exception as e:  # transient network errors
                    print("retry", shot["id"], e)
                    await asyncio.sleep(2 + attempt * 3)
            else:
                raise RuntimeError(f"voice failed for {shot['id']}")
            json.dump({"text": clean, "voice": VOICE, "rate": RATE, "words": words},
                      open(meta, "w"), ensure_ascii=False)
        align(clean, words)
        cues = {}
        for k, off in marks.items():
            nxt = [w for w in words if w["c"] >= off]
            cues[k] = (nxt[0]["t0"] if nxt else (words[-1]["t1"] if words else 0.0))
        dur = duration(mp3)
        manifest.append({"id": shot["id"], "mp3": mp3, "text": clean, "audio_s": dur,
                         "speech_t0": words[0]["t0"] if words else 0.0,
                         "speech_t1": words[-1]["t1"] if words else dur,
                         "cues": cues, "words": words})
        print(f"{shot['id']}: {dur:5.2f}s  words {len(words):2d}  cues {sorted(cues)}")
    json.dump(manifest, open(os.path.join(ROOT, "build", run, "voice.json"), "w"),
              ensure_ascii=False, indent=1)
    total = sum(m["audio_s"] for m in manifest)
    print(f"{run}: {len(manifest)} clips, {total:.1f} s of narration audio")
    return manifest


if __name__ == "__main__":
    sys.path.insert(0, ROOT)
    asyncio.run(build(sys.argv[1]))
