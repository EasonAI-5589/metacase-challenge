"""The homepage robot holding the Claude Code blaster, as the narration guide.

Replaces the task0001 pixel pet (``reference_pet.py``) for the v3 edition.
The robot is the homepage's ``robot()`` from mc-kit.js holding the arena's
Claude Code weapon (Kenney ``blaster-e.glb``), lit like the homepage chapters.
``robot/sprite.html`` pre-renders it with three.js onto transparent sprites,
one per whole degree of aim from -90 (down) to +90 (up), eyes open and mid-blink;
``robot/sprites/sprites.json`` records each sprite's projected muzzle and grip.

The public functions keep the pet's contract so ``guide.py`` routes, cues and
the geometry audit stay unchanged: ``draw_robot`` takes the same pose arguments
as ``draw_pet`` and returns ``hand`` (here: the muzzle), ``body_polygon``,
``bottom``, ``lean``, ``sx``, ``sy`` and ``facing``; ``draw_laser`` replaces the
baton with a sight line from the muzzle to the target.

Placement: the robot's feet stand where the pet's feet stood, (x + 48, y + 86).
When a target is so close that the muzzle would reach it, the robot steps back
to the left just enough to keep the muzzle ``CLEARANCE`` pixels short of it.
"""
from __future__ import annotations

import json
import math
import os
from functools import lru_cache

import skia

HERE = os.path.dirname(os.path.abspath(__file__))
SPRITES = os.path.normpath(os.path.join(HERE, "..", "robot", "sprites"))
SCALE = 0.55           # sprite pixels -> 1920 stage pixels
FEET = (48.0, 86.0)    # the pet's foot point inside its 96 x 88 box
CLEARANCE = 24.0       # the muzzle stops this far short of the target
MAX_STEP_BACK = 90.0
LASER_CORE = (255, 247, 230)


def _clamp(v, lo=0.0, hi=1.0):
    return max(lo, min(hi, float(v)))


def _smooth(v):
    v = _clamp(v)
    return v * v * (3 - 2 * v)


def _rand(n):
    value = math.sin(n * 78.233 + 11.17) * 43758.5453
    return value - math.floor(value)


@lru_cache(maxsize=1)
def _meta():
    with open(os.path.join(SPRITES, "sprites.json"), encoding="utf-8") as f:
        meta = json.load(f)
    by = {}
    for s in meta["sprites"]:
        by[(round(s["aim"]), bool(s["eyesClosed"]))] = s
    body = meta["body"]
    feet = body["feet"]
    # Head-and-body silhouette (no gun, no arms), measured from robot_body.png.
    img = skia.Image.open(os.path.join(SPRITES, body["file"]))
    import numpy as np
    alpha = np.asarray(img.toarray())[:, :, 3]
    ys, xs = np.nonzero(alpha > 8)
    box = (float(xs.min()), float(ys.min()), float(xs.max() + 1), float(ys.max() + 1))
    # Aim pivot: the middle of the two grips at level aim, on the gun axis.
    level = by[(0, False)]
    pivot = ((level["grip"][0] + level["muzzle"][0]) / 2, (level["grip"][1] + level["muzzle"][1]) / 2)
    return dict(by=by, feet=feet, body_box=box, pivot=pivot, size=meta["size"])


@lru_cache(maxsize=None)
def _image(name):
    return skia.Image.open(os.path.join(SPRITES, name)).withDefaultMipmaps()


def _local(p, meta):
    """Sprite pixel -> stage offset from the feet point (before lean)."""
    return ((p[0] - meta["feet"][0]) * SCALE, (p[1] - meta["feet"][1]) * SCALE)


def _aim_for(pivot, tip):
    if tip is None:
        return 18.0
    dx, dy = tip[0] - pivot[0], pivot[1] - tip[1]
    if abs(dx) < 1e-6 and abs(dy) < 1e-6:
        return 18.0
    angle = math.degrees(math.atan2(dy, max(dx, 0.0) if abs(dy) > 1e-6 else max(dx, 1e-6)))
    return max(-90.0, min(90.0, angle))


def draw_robot(cv, x, y, t, flight=0.0, travel_u=1.0, dx=0.0,
               tip=None, focus=0.0, opacity=1.0):
    """Draw the robot and return geometry in 1920-stage pixels (cv=None: geometry only)."""
    x, y, t = float(x), float(y), float(t)
    flight, travel_u = _clamp(flight), _clamp(travel_u)
    opacity = _clamp(opacity)
    if not all(math.isfinite(v) for v in (x, y, t, float(dx))):
        raise ValueError("Robot position, clock, and direction must be finite")
    meta = _meta()
    direction = 1 if dx > 0 else -1 if dx < 0 else 0
    # Hover: a slow idle bob, and small hops while travelling.
    bob = math.sin(t * 2.0) * 1.3 + abs(math.sin(travel_u * math.pi * 3)) * -7.0 * flight
    lean = math.sin(t * 2.2) * 0.8 + direction * flight * 4.0
    fx, fy = x + FEET[0], y + FEET[1] + bob
    piv = _local(meta["pivot"], meta)
    pivot = (fx + piv[0], fy + piv[1])
    # Step back to the left when the target is closer than the muzzle reach.
    step = 0.0
    if tip is not None:
        level = meta["by"][(0, False)]
        mz = _local(level["muzzle"], meta)
        reach = math.hypot(mz[0] - piv[0], mz[1] - piv[1]) + CLEARANCE
        ddx, ddy = tip[0] - pivot[0], tip[1] - pivot[1]
        need = math.sqrt(max(0.0, reach * reach - ddy * ddy)) - ddx
        step = MAX_STEP_BACK * _smooth(max(0.0, need) / MAX_STEP_BACK) if need > 0 else 0.0
    fx -= step
    pivot = (pivot[0] - step, pivot[1])
    aim = _aim_for(pivot, tip)
    block = math.floor(t / 4.6)
    blink_at = 2.7 + _rand(block + 902) * 1.1
    local = t - block * 4.6
    blink = blink_at <= local < blink_at + .145
    sprite = meta["by"][(int(round(aim)), blink)]

    angle = math.radians(lean)
    c, s = math.cos(angle), math.sin(angle)

    def stage(p):
        lx, ly = _local(p, meta)
        return (fx + lx * c - ly * s, fy + lx * s + ly * c)

    muzzle = stage(sprite["muzzle"])
    bx0, by0, bx1, by1 = meta["body_box"]
    body_polygon = [stage(p) for p in ((bx0, by0), (bx1, by0), (bx1, by1), (bx0, by1))]
    size = meta["size"]
    corners = [stage(p) for p in ((0, 0), (size, 0), (size, size), (0, size))]
    # Conservative bottom: feet, muzzle and grip of this pose.
    bottom = max(stage(meta["feet"])[1] + 2.0, muzzle[1] + 3.0, stage(sprite["grip"])[1] + 3.0)
    geometry = {"hand": muzzle, "body_polygon": body_polygon, "bottom": bottom,
                "lean": lean, "sx": 1.0, "sy": 1.0, "facing": 1.0,
                "aim": aim, "step_back": step, "feet": (fx, fy), "corners": corners}
    if cv is None or opacity <= 0:
        return geometry

    cv.save()
    paint = skia.Paint()
    paint.setAlphaf(opacity)
    cv.saveLayer(None, paint)
    cv.translate(fx, fy)
    cv.rotate(lean)
    ox, oy = meta["feet"]
    dest = skia.Rect.MakeXYWH(-ox * SCALE, -oy * SCALE, size * SCALE, size * SCALE)
    cv.drawImageRect(_image(sprite["file"]), dest,
                     skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear),
                     skia.Paint(AntiAlias=True))
    cv.restore()
    cv.restore()
    return geometry


def _paint(color, opacity, stroke=None, blur=None):
    r, g, b = color[:3]
    p = skia.Paint(AntiAlias=True, Color=skia.Color(r, g, b, round(255 * _clamp(opacity))))
    if stroke is not None:
        p.setStyle(skia.Paint.kStroke_Style)
        p.setStrokeWidth(stroke)
        p.setStrokeCap(skia.Paint.kRound_Cap)
    if blur:
        p.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, blur))
    return p


def _rgb(color):
    if isinstance(color, str):
        v = color.lstrip("#")
        return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4))
    return tuple(int(v) for v in color[:3])


def draw_laser(cv, muzzle, tip, t, color=(143, 246, 255), glow=0.0,
               flight=0.0, opacity=1.0):
    """A sight line from the muzzle to the target, in the target's colour."""
    hx, hy = map(float, muzzle)
    tx, ty = map(float, tip)
    if not all(math.isfinite(v) for v in (hx, hy, tx, ty, float(t))):
        raise ValueError("Laser endpoints and clock must be finite")
    opacity = _clamp(opacity) * (1 - _clamp(flight) * .35)
    if opacity <= 0:
        return
    col = _rgb(color)
    length = math.hypot(tx - hx, ty - hy)
    cv.save()
    layer = skia.Paint()
    layer.setAlphaf(opacity)
    cv.saveLayer(None, layer)
    if length > 1.0:
        cv.drawLine(hx, hy, tx, ty, _paint(col, 0.30, stroke=7.0, blur=3.0))
        cv.drawLine(hx, hy, tx, ty, _paint(col, 0.95, stroke=2.4))
        cv.drawLine(hx, hy, tx, ty, _paint(LASER_CORE, 0.85, stroke=1.0))
        # Light travelling along the beam.
        u = (t * 1.6) % 1.0
        px, py = hx + (tx - hx) * u, hy + (ty - hy) * u
        cv.drawCircle(px, py, 2.6, _paint(LASER_CORE, 0.8 * math.sin(u * math.pi)))
    # Muzzle glow and the dot on the target.
    cv.drawCircle(hx, hy, 4.5, _paint(col, 0.55, blur=3.0))
    cv.drawCircle(tx, ty, 7.5, _paint(col, 0.35, blur=4.0))
    cv.drawCircle(tx, ty, 3.4, _paint(LASER_CORE, 0.95))
    cv.drawCircle(tx, ty, 6.0 + .75 * math.sin(float(t) * 2), _paint(col, .35 + _clamp(glow) * .55, stroke=1.8))
    cv.restore()
    cv.restore()
