"""Render a run to MP4: parallel frame workers -> H.264 segments -> concat + narration mix.

usage: python engine/render.py fin [--workers 2] [--crf 17]
outputs: build/<run>/<run>.mp4, narration.wav, captions.{en,zh,bilingual}.srt, poster.jpg
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import multiprocessing as mp
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

COLOR = ["-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv"]
FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
FFPROBE = os.environ.get("FFPROBE", "ffprobe")
WIDTH, HEIGHT, FPS = 1920, 1080, 30


def encoder(path, crf, pix, stderr):
    return subprocess.Popen(
        [FFMPEG, "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", pix, "-s", f"{WIDTH}x{HEIGHT}", "-r", str(FPS), "-i", "-",
         "-filter_threads", "1",
         "-vf", "scale=out_color_matrix=bt709:out_range=tv:flags=lanczos,format=yuv420p",
         "-c:v", "libx264", "-preset", "medium", "-crf", str(crf), "-profile:v", "high", "-threads", "2",
         "-x264-params", "keyint=60:min-keyint=30:scenecut=0", *COLOR, path],
        stdin=subprocess.PIPE, stderr=stderr)


def checked_command(command):
    completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if completed.returncode:
        raise RuntimeError(
            f"Command failed ({completed.returncode}): {command!r}\n"
            + completed.stderr.decode("utf-8", errors="replace"))
    return completed.stdout


def verify_video(path, expected_frames):
    raw = checked_command([
        FFPROBE, "-v", "error", "-threads", "1", "-select_streams", "v:0", "-count_frames",
        "-show_entries", "stream=width,height,r_frame_rate,nb_read_frames", "-of", "json", path])
    streams = json.loads(raw)["streams"]
    if len(streams) != 1:
        raise RuntimeError(f"Expected one selected video stream in {path}, got {streams!r}")
    stream = streams[0]
    if (stream.get("width"), stream.get("height"), stream.get("r_frame_rate"),
            int(stream.get("nb_read_frames", -1))) != (WIDTH, HEIGHT, f"{FPS}/1", expected_frames):
        raise RuntimeError(f"Encoded video metadata/frame count mismatch: {stream!r}; expected {expected_frames} frames")


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    temporary = Path(str(path) + ".partial")
    temporary.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
                         encoding="utf-8")
    os.replace(temporary, path)


def cache_static_background(compose_module, skia_module):
    """Rasterize the unchanged opaque background once per worker, at native size."""
    original = compose_module.U.background
    if getattr(original, "_offline_cached", False):
        return
    surface = skia_module.Surface(WIDTH, HEIGHT)
    original(surface.getCanvas())
    background = surface.makeImageSnapshot()

    def cached(canvas):
        canvas.drawImage(background, 0, 0)

    cached._offline_cached = True
    compose_module.U.background = cached


def source_hashes(run):
    paths = []
    root = Path(ROOT)
    for directory in ("engine", "story", "data", "fonts", "reference"):
        paths.extend(p for p in (root / directory).rglob("*")
                     if p.is_file() and "__pycache__" not in p.parts
                     and p.suffix not in (".pyc", ".pyo"))
    paths.append(root / "build" / run / "voice.json")
    paths.extend(p for p in (root / "build" / run / "voice").rglob("*") if p.is_file())
    return {p.relative_to(root).as_posix(): file_sha256(p) for p in sorted(paths)}


def segment_valid(job):
    run, index, f0, f1, output, crf = job
    path = Path(output)
    try:
        receipt = json.loads(path.with_suffix(".receipt.json").read_text(encoding="utf-8"))
        if (receipt["run"], receipt["frame_start"], receipt["frame_end"], receipt["crf"]) != (run, f0, f1, crf):
            return False
        if receipt["sha256"] != file_sha256(path):
            return False
        verify_video(str(path), f1 - f0)
        return True
    except (OSError, ValueError, KeyError, RuntimeError):
        return False


def work(args):
    run, idx, f0, f1, out, crf = args
    import skia
    import compose
    cache_static_background(compose, skia)
    ctx = compose.Ctx(run)
    if not 0 <= f0 < f1 <= ctx.tl.nframes:
        raise ValueError(f"Invalid frame interval [{f0}, {f1}) for {ctx.tl.nframes} frames")
    surf = skia.Surface(WIDTH, HEIGHT)
    if surf is None:
        raise RuntimeError("Skia could not allocate the 1920x1080 frame surface")
    cv = surf.getCanvas()
    ct = surf.imageInfo().colorType()
    if ct not in (skia.kBGRA_8888_ColorType, skia.kRGBA_8888_ColorType):
        raise RuntimeError(f"Unsupported Skia frame color type: {ct}")
    pix = "bgra" if ct == skia.kBGRA_8888_ColorType else "rgba"
    t0 = time.time()
    # A file avoids a full stderr pipe deadlocking a worker after an encoder failure.
    with tempfile.TemporaryFile() as errors:
        partial = str(Path(out).with_suffix(".partial.mp4"))
        enc = encoder(partial, crf, pix, errors)
        try:
            for i in range(f0, f1):
                compose.frame(cv, ctx, i / FPS)
                frame = surf.makeImageSnapshot().tobytes()
                if len(frame) != WIDTH * HEIGHT * 4:
                    raise RuntimeError(f"Frame {i} has {len(frame)} bytes; expected {WIDTH * HEIGHT * 4}")
                enc.stdin.write(frame)
            enc.stdin.close()
            code = enc.wait()
        except BaseException as exc:
            if enc.poll() is None:
                enc.kill()
            enc.wait()
            try:
                enc.stdin.close()
            except OSError:
                pass  # Preserve the worker's original error and captured encoder stderr.
            errors.seek(0)
            detail = errors.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Frame worker {idx} failed while producing {out}: {detail}") from exc
        errors.seek(0)
        detail = errors.read().decode("utf-8", errors="replace")
        if code:
            raise RuntimeError(f"FFmpeg segment {idx} exited with {code}: {detail}")
    verify_video(partial, f1 - f0)
    os.replace(partial, out)
    write_json(Path(out).with_suffix(".receipt.json"), {
        "run": run, "frame_start": f0, "frame_end": f1, "frames": f1 - f0,
        "crf": crf, "sha256": file_sha256(out),
    })
    return idx, f1 - f0, time.time() - t0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--crf", type=int, default=17)
    ap.add_argument("--segment-frames", type=int, default=400,
                    help="Frames per resumable segment (1..400); workers are recycled after each segment")
    ap.add_argument("--resume-dir", help="Explicit segment directory; its input/settings manifest must match")
    ap.add_argument("--output", help="Output MP4 path; defaults to build/<run>/<run>.mp4")
    ap.add_argument("--preview-range", metavar="START:END",
                    help="Render this range of the existing timeline in seconds, rounded to frame boundaries")
    a = ap.parse_args()
    if a.workers < 1:
        ap.error("--workers must be at least 1")
    if not 1 <= a.segment_frames <= 400:
        ap.error("--segment-frames must be between 1 and 400")
    import compose
    from fonts import font_manifest
    ctx = compose.Ctx(a.run)
    tl = ctx.tl
    outdir = os.path.join(ROOT, "build", a.run)
    os.makedirs(outdir, exist_ok=True)
    f0, f1 = 0, tl.nframes
    if a.preview_range:
        try:
            start, end = map(float, a.preview_range.split(":"))
        except ValueError:
            ap.error("--preview-range must be START:END in seconds")
        if not (math.isfinite(start) and math.isfinite(end) and 0 <= start < end <= tl.nframes / FPS):
            ap.error("--preview-range must lie within the original timeline")
        f0, f1 = round(start * FPS), round(end * FPS)
    n = f1 - f0
    if n <= 0:
        ap.error("The requested range contains no frames")
    stem = f"{a.run}-preview-{f0}-{f1}" if a.preview_range else a.run
    out = os.path.abspath(a.output) if a.output else os.path.join(outdir, f"{stem}.mp4")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    fonts = font_manifest()
    write_json(os.path.join(os.path.dirname(out), f"{Path(out).stem}.font-selection.json"), fonts)
    inputs = {
        "format_version": "bounded-segments-v2",
        "run": a.run, "frame_start": f0, "frame_end": f1, "fps": FPS,
        "width": WIDTH, "height": HEIGHT, "crf": a.crf,
        "segment_frames": a.segment_frames, "filter_threads": 1, "encoder_threads": 2,
        "preset": "medium", "background_cache": True,
        "source_sha256": source_hashes(a.run),
        "font_sha256": {name: file_sha256(face["source"])
                        for name, face in fonts["fonts"].items() if os.path.isfile(face["source"])},
        "skia_python": importlib.metadata.version("skia-python"),
        "numpy": importlib.metadata.version("numpy"),
        "ffmpeg": checked_command([FFMPEG, "-version"]).decode("utf-8", errors="replace").splitlines()[0],
    }
    fingerprint = hashlib.sha256(json.dumps(inputs, sort_keys=True).encode("utf-8")).hexdigest()
    segdir = (os.path.abspath(a.resume_dir) if a.resume_dir else
              os.path.join(outdir, f"segments-{a.run}-{f0}-{f1}-{fingerprint[:16]}"))
    os.makedirs(segdir, exist_ok=True)
    manifest_path = Path(segdir) / "render-inputs.json"
    if manifest_path.exists():
        if json.loads(manifest_path.read_text(encoding="utf-8")) != inputs:
            raise RuntimeError("Resume directory belongs to different source, fonts or render settings")
    elif any(Path(segdir).iterdir()):
        raise RuntimeError("Resume directory has files but no input manifest; refusing unverified reuse")
    else:
        write_json(manifest_path, inputs)
    count = math.ceil(n / a.segment_frames)
    bounds = [f0 + round(n * i / count) for i in range(count + 1)]
    jobs = [(a.run, i, bounds[i], bounds[i + 1], os.path.join(segdir, f"seg_{i:03d}.mp4"), a.crf)
            for i in range(len(bounds) - 1)]
    t0 = time.time()
    pending, reused = [], []
    for job in jobs:
        (reused if segment_valid(job) else pending).append(job)
    if len(pending) > 1:
        pending = pending[:1] + pending[-1:] + pending[1:-1]
    rendered = sum(job[3] - job[2] for job in reused)
    print(f"Reusing {len(reused)} verified segments; rendering {len(pending)} segments "
          f"with {a.workers} workers; cache: {segdir}", flush=True)
    if pending:
        # Skia text/layout caches and encoder buffers are released between bounded segments.
        with mp.get_context("spawn").Pool(a.workers, maxtasksperchild=1) as pool:
            for idx, nf, dt in pool.imap_unordered(work, pending):
                rendered += nf
                print(f"segment {idx:03d}: {nf} frames in {dt:.1f}s", flush=True)
    if rendered != n:
        raise RuntimeError(f"Workers rendered {rendered} frames; expected {n}")
    if source_hashes(a.run) != inputs["source_sha256"]:
        raise RuntimeError("Source changed during rendering; refusing to assemble mixed-source frames")
    print(f"frames rendered in {time.time() - t0:.1f}s")
    lst = os.path.join(segdir, "list.txt")
    with open(lst, "w", encoding="utf-8", newline="\n") as f:
        for j in jobs:
            # FFmpeg's concat parser treats backslashes as escapes, including on Windows.
            escaped_path = Path(j[4]).resolve().as_posix().replace("'", "'\\''")
            f.write(f"file '{escaped_path}'\n")
    wav = tl.mix(os.path.join(outdir, "narration.wav"))
    checked_command([FFMPEG, "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst,
                     "-ss", f"{f0 / FPS:.9f}", "-i", wav,
                     "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "144k", "-ar", "48000",
                     "-ac", "1", "-t", f"{n / FPS:.9f}", *COLOR, "-movflags", "+faststart", out])
    verify_video(out, n)
    if not a.preview_range:
        tl.write_srt(os.path.join(outdir, "captions"))
    write_json(Path(out).with_suffix(".render-receipt.json"), {
        "input_fingerprint": fingerprint, "inputs": inputs,
        "output_sha256": file_sha256(out), "frames": n,
        "workers": a.workers, "segment_frames": a.segment_frames,
        "reused_segments": [job[1] for job in reused],
        "rendered_segments": [job[1] for job in pending],
        "seconds": time.time() - t0,
        "segment_directory": Path(segdir).relative_to(Path(ROOT)).as_posix()
        if Path(segdir).is_relative_to(Path(ROOT)) else Path(segdir).as_posix(),
    })
    print("wrote", out, f"{n / FPS:.3f}s", n, "frames", f"source frames [{f0}, {f1})")


if __name__ == "__main__":
    main()
