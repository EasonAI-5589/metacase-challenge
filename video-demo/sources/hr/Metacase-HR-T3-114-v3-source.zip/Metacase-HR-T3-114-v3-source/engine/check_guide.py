"""Audit guide geometry and source preservation without drawing or changing data."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(HERE), str(ROOT)]

from compose import Ctx
from timeline import FPS


CUE_EPSILON_SECONDS = 1e-6
CONTINUITY_TOLERANCE = 1e-3
POLYGON_EDGE_EPSILON_PX = 0.01
BOTTOM_LIMIT_PX = 892.5
VISIBLE_POINTER_OPACITY = 0.1


def interior_interval(hand, tip, polygon):
    """Clip a segment against the strict interior of a convex body polygon.

    Normalized half-plane distances leave a 0.01 px boundary allowance, so a
    fingertip on an edge is not a collision. A reflected polygon can have
    either winding; a fully edge-on pose has no polygon interior.
    """
    area2 = sum(a[0] * b[1] - b[0] * a[1]
                for a, b in zip(polygon, polygon[1:] + polygon[:1]))
    if abs(area2) < 1e-8:
        return None
    orientation = 1 if area2 > 0 else -1
    low, high = 1e-9, 1.0
    for a, b in zip(polygon, polygon[1:] + polygon[:1]):
        ex, ey = b[0] - a[0], b[1] - a[1]
        length = math.hypot(ex, ey)
        if length < 1e-12:
            continue

        def distance(p):
            return orientation * (ex * (p[1] - a[1]) - ey * (p[0] - a[0])) / length

        d0 = distance(hand) - POLYGON_EDGE_EPSILON_PX
        change = distance(tip) - distance(hand)
        if abs(change) < 1e-12:
            if d0 <= 0:
                return None
            continue
        crossing = -d0 / change
        if change > 0:
            low = max(low, crossing)
        else:
            high = min(high, crossing)
        if low >= high:
            return None
    return (low, high) if low < high else None


def numbers(obj):
    if isinstance(obj, dict):
        for value in obj.values():
            yield from numbers(value)
    elif isinstance(obj, (tuple, list)):
        for value in obj:
            yield from numbers(value)
    elif isinstance(obj, (int, float)) and not isinstance(obj, bool):
        yield float(obj)


def location(state, t):
    return {
        "time_seconds": t,
        "shot": state["event"]["shot"],
        "target": state["event"]["target"],
        "cue_time_seconds": state["event"]["time"],
    }


def pose_difference(a, b):
    return {name: abs(a["geometry"][name] - b["geometry"][name])
            for name in ("lean", "sx", "sy", "facing")}


def srt_bytes(timeline, language):
    def timestamp(seconds):
        ms = round(seconds * 1000)
        hours, ms = divmod(ms, 3600000)
        minutes, ms = divmod(ms, 60000)
        seconds, ms = divmod(ms, 1000)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d},{ms:03d}"

    lines = []
    for index, (start, end, en, zh) in enumerate(timeline.cues(), 1):
        body = en if language == "en" else zh if language == "zh" else f"{en}\n{zh}"
        lines.append(f"{index}\n{timestamp(start)} --> {timestamp(end)}\n{body}\n")
    return "\n".join(lines).encode("utf-8")


# v3 (Metacase, English only): the protected files that change on purpose.
# story/fin.py is checked exactly: undoing the f33 edit must restore its v2 bytes.
V3_F33_V2 = (
    '''         say="A professional task, an agent run, and an independent check. {site}Explore more on the Inference Net Challenge site.",
         en="A professional task, an agent run, and an independent check. Explore more on the InferenceNet Challenge site.",
         zh="专业任务、Agent 运行、独立检验。更多内容见 InferenceNet Challenge 网站。",
         st=("brand", "easonai-5589.github.io/inferencenet-challenge")),''')
V3_F33_V3 = (
    '''         say="A professional task, an agent run, and an independent check. {site}Explore more on the Metacase Challenge site.",
         en="A professional task, an agent run, and an independent check. Explore more on the Metacase Challenge site.",
         zh="专业任务、Agent 运行、独立检验。更多内容见 Metacase Challenge 网站。",
         st=("brand", "easonai-5589.github.io/metacase-challenge")),''')
V3_INTENTIONAL = {
    "story/fin.py": "f33 narration, caption and site URL now name the Metacase Challenge",
    "build/fin/voice.json": "f33 re-voiced with the same voice and rate; the other 33 clips are reused",
    "build/fin/voice/f33-47bec1253638f99c.json": "replaced by the re-voiced f33 clip",
    "build/fin/voice/f33-47bec1253638f99c.mp3": "replaced by the re-voiced f33 clip",
    "docs/captions.en.srt": "regenerated; cue 34 names the Metacase Challenge site",
    "docs/captions.zh.srt": "not delivered: the v3 edition is English only",
    "docs/captions.bilingual.srt": "not delivered: the v3 edition is English only",
}


def _v3_story_restores(expected_sha256):
    text = (ROOT / "story" / "fin.py").read_text(encoding="utf-8")
    if text.count(V3_F33_V3) != 1:
        return False
    restored = text.replace(V3_F33_V3, V3_F33_V2).encode("utf-8")
    return hashlib.sha256(restored).hexdigest() == expected_sha256


def check_sources(timeline):
    manifest = json.loads((ROOT / "MANIFEST.json").read_text(encoding="utf-8"))
    protected, altered_engine, intentional = [], [], []
    for relative, expected in manifest.items():
        path = ROOT / relative
        actual = None if not path.is_file() else hashlib.sha256(path.read_bytes()).hexdigest()
        row = {"path": relative, "expected_sha256": expected["sha256"],
               "actual_sha256": actual, "unchanged": actual == expected["sha256"]}
        if relative.startswith("engine/"):
            if not row["unchanged"]:
                altered_engine.append(row)
        elif not row["unchanged"] and relative in V3_INTENTIONAL:
            row["v3_reason"] = V3_INTENTIONAL[relative]
            if relative == "story/fin.py":
                row["only_f33_changed"] = _v3_story_restores(expected["sha256"])
                if not row["only_f33_changed"]:
                    protected.append(row)
                    continue
            intentional.append(row)
        else:
            protected.append(row)
    captions = []
    for language in ("en",):  # v3 delivers English captions only
        path = ROOT / "docs" / f"captions.{language}.srt"
        generated = srt_bytes(timeline, language)
        original = path.read_bytes()
        captions.append({
            "language": language,
            "matches_docs_bytes": generated == original,
            "generated_sha256": hashlib.sha256(generated).hexdigest(),
            "docs_sha256": hashlib.sha256(original).hexdigest(),
            "cue_count": len(timeline.cues()),
        })
    return {
        "baseline": "Supplied source archive MANIFEST.json",
        "manifest_sha256": hashlib.sha256((ROOT / "MANIFEST.json").read_bytes()).hexdigest(),
        "protected_files_checked": len(protected),
        "protected_files_unchanged": sum(row["unchanged"] for row in protected),
        "protected_file_mismatches": [row for row in protected if not row["unchanged"]],
        "modified_existing_engine_files": altered_engine,
        "v3_intentional_changes": intentional,
        "captions": captions,
    }


def audit(run="fin"):
    ctx = Ctx(run)
    failures = []
    failure_count = 0

    def fail(kind, details):
        nonlocal failure_count
        failure_count += 1
        if len(failures) < 50:
            failures.append({"kind": kind, **details})

    # v3: the re-voiced f33 clip is 0.192 s shorter, so 8846 -> 8840 frames.
    # HR (reconstructed in v3) has no archived baseline: its frame and cue counts are
    # reported, not compared, and its sources are not checked against a MANIFEST.
    if run == "fin" and (ctx.tl.nframes != 8840 or FPS != 30):
        fail("unexpected_timeline", {"nframes": ctx.tl.nframes, "fps": FPS})
    if run == "fin" and len(ctx.guide.events) != 93:
        fail("unexpected_cue_count", {"actual": len(ctx.guide.events), "expected": 93})

    max_bottom = {"value_px": -math.inf}
    maximum_steps = {key: {"value_px": -math.inf}
                     for key in ("anchor", "hand", "tip", "body_vertex")}
    visible_pointer_frames = 0
    collision_frames = 0
    previous = None
    for frame in range(ctx.tl.nframes):
        t = frame / FPS
        state = ctx.guide.state(t)
        if state is None:
            fail("missing_state", {"frame": frame, "time_seconds": t})
            continue
        if not all(math.isfinite(value) for value in numbers(state)):
            fail("non_finite_geometry", {"frame": frame, **location(state, t)})
            continue
        geometry = state["geometry"]
        if geometry["facing"] != 1.0 or geometry["sx"] <= 0:
            fail("unexpected_turn_or_mirror", {
                "frame": frame, **location(state, t),
                "facing": geometry["facing"], "sx": geometry["sx"],
            })
        if geometry["bottom"] > max_bottom["value_px"]:
            max_bottom = {"value_px": geometry["bottom"], "frame": frame, **location(state, t)}
        if geometry["bottom"] > BOTTOM_LIMIT_PX + 1e-6:
            fail("footer_overlap", {"frame": frame, "bottom": geometry["bottom"], **location(state, t)})
        pointer_opacity = state.get("pointer_opacity")
        if pointer_opacity is not None and pointer_opacity >= VISIBLE_POINTER_OPACITY:
            visible_pointer_frames += 1
            overlap = interior_interval(geometry["hand"], state["tip"], geometry["body_polygon"])
            if overlap is not None:
                collision_frames += 1
                fail("baton_body_collision", {
                    "frame": frame, **location(state, t),
                    "pointer_opacity": pointer_opacity,
                    "hand": geometry["hand"], "tip": state["tip"],
                    "body_polygon": geometry["body_polygon"],
                    "interior_segment_fraction": overlap,
                })
        if previous is not None:
            steps = {
                "anchor": math.dist((previous["x"], previous["y"]), (state["x"], state["y"])),
                "hand": math.dist(previous["geometry"]["hand"], geometry["hand"]),
                "tip": math.dist(previous["tip"], state["tip"]),
                "body_vertex": max(math.dist(a, b) for a, b in
                                   zip(previous["geometry"]["body_polygon"], geometry["body_polygon"])),
            }
            for key, value in steps.items():
                if value > maximum_steps[key]["value_px"]:
                    maximum_steps[key] = {"value_px": value, "frame": frame, **location(state, t)}
        previous = state

    continuity = []
    for event in ctx.guide.events:
        t = event["time"]
        before, after = (ctx.guide.state(t + delta)
                         for delta in (-CUE_EPSILON_SECONDS, CUE_EPSILON_SECONDS))
        differences = {
            "anchor_px": math.dist((before["x"], before["y"]), (after["x"], after["y"])),
            "hand_px": math.dist(before["geometry"]["hand"], after["geometry"]["hand"]),
            "tip_px": math.dist(before["tip"], after["tip"]),
            "body_vertex_px": max(math.dist(a, b) for a, b in
                                  zip(before["geometry"]["body_polygon"], after["geometry"]["body_polygon"])),
            **pose_difference(before, after),
            "pointer_opacity": abs(before.get("pointer_opacity", 0) - after.get("pointer_opacity", 0)),
        }
        passed = all(math.isfinite(v) and v <= CONTINUITY_TOLERANCE for v in differences.values())
        row = {"shot": event["shot"], "target": event["target"], "time_seconds": t,
               "passed": passed, "differences": differences}
        continuity.append(row)
        if not passed:
            fail("cue_discontinuity", row)

    source = check_sources(ctx.tl) if run == "fin" else {
        "baseline": "none: the HR v2 source was not archived; story/hr.py and data/hr.json were "
                    "reconstructed from the published film (see docs provenance)",
        "protected_file_mismatches": [], "captions": []}
    for row in source["protected_file_mismatches"]:
        fail("source_changed", row)
    for row in source["captions"]:
        if not row["matches_docs_bytes"]:
            fail("caption_changed", row)
    # Check the actual guide/whole-frame envelopes against the reference
    # timings rather than accepting an arbitrary fade or an offscreen exit.
    from compose import stage_alpha
    entrance = []
    for t, alpha in ((0.45, 0.0), (0.675, 0.5), (0.90, 1.0)):
        actual = ctx.guide.state(t)["opacity"]
        row = {"time_seconds": t, "expected_opacity": alpha, "actual_opacity": actual}
        entrance.append(row)
        if abs(actual - alpha) > 1e-8:
            fail("reference_entrance_opacity", row)
    start = ctx.guide.state(0.0)
    arrived = ctx.guide.state(0.65)
    for state, dock in ((start, (240.0, 798.0)), (arrived, (288.0, 798.0))):
        if abs(state["x"] - dock[0]) > 1e-6:
            fail("reference_entrance_position", {"expected_x": dock[0], "actual_x": state["x"]})
    outro = ctx.tl.shots[-1]
    settled = ctx.guide.state(outro.start + 3.2)
    if abs(settled["x"] - 1596.0) > 1e-6:
        fail("reference_outro_position", {"expected_x": 1596.0, "actual_x": settled["x"]})
    stage_duration = ctx.tl.nframes / FPS
    envelope = []
    for t, expected in ((0.0, 0.0), (0.175, 0.5), (0.35, 1.0),
                        (stage_duration - 0.65, 1.0),
                        (stage_duration - 0.325, 0.5), (stage_duration, 0.0)):
        actual = stage_alpha(t, stage_duration)
        row = {"time_seconds": t, "expected_opacity": expected, "actual_opacity": actual}
        envelope.append(row)
        if abs(actual - expected) > 1e-8:
            fail("reference_stage_envelope", row)
    return {
        "passed": failure_count == 0,
        "frames_checked": ctx.tl.nframes,
        "fps": FPS,
        "duration_seconds": ctx.tl.nframes / FPS,
        "method": "Pure guide.state(t), draw_pet(cv=None); no raster frames or new agent execution",
        "thresholds": {
            "body_bottom_limit_px": BOTTOM_LIMIT_PX,
            "body_edge_epsilon_px": POLYGON_EDGE_EPSILON_PX,
            "pointer_opacity_minimum": VISIBLE_POINTER_OPACITY,
            "cue_epsilon_seconds": CUE_EPSILON_SECONDS,
            "continuity_tolerance": CONTINUITY_TOLERANCE,
        },
        "maximum_body_bottom": max_bottom,
        "visible_pointer_frames_checked": visible_pointer_frames,
        "baton_body_collision_frames": collision_frames,
        "maximum_per_frame_displacement": maximum_steps,
        "cues_checked": len(continuity),
        "fixed_right_facing_frames_checked": ctx.tl.nframes,
        "reference_entrance": entrance,
        "reference_outro": {
            "start_seconds": outro.start, "travel_seconds": 3.2,
            "settled_x": settled["x"], "stays_in_frame": True,
        },
        "reference_stage_envelope": envelope,
        "cue_checks": continuity,
        "source_preservation": source,
        "failure_count": failure_count,
        "failures": failures,
        "failure_details_truncated": failure_count > len(failures),
        "limitations": [
            "Geometry checks centerline penetration into the conservative body polygon, not the baton stroke radius.",
            "Per-frame displacement is reported as a diagnostic, with no arbitrary speed pass/fail threshold.",
            "Geometry and glyph-independent checks do not replace visual inspection of rendered text, focus boxes or scene content.",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run", nargs="?", default="fin")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    args.output = args.output or ROOT / "build" / args.run / "guide-geometry-qa.json"
    result = audit(args.run)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "passed": result["passed"], "frames": result["frames_checked"],
        "cues": result["cues_checked"], "failure_count": result["failure_count"],
        "maximum_body_bottom": result["maximum_body_bottom"],
        "maximum_per_frame_displacement": result["maximum_per_frame_displacement"],
        "output": str(args.output),
    }, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
