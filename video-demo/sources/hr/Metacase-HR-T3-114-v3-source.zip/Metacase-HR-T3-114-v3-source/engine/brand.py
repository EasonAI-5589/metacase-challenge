"""Metacase Challenge brand elements, matching the website's homepage (v3 edition).

- The mark: index.html ``.v2-mark`` (32-unit viewBox), dark-theme colours from
  v2.css (--logo-t1 oklch(80% .12 195), --logo-t2 oklch(82% .14 75), node #F1F5FA,
  edge gradients to #EEF2F7) and its ``.lg-anim`` timing: dots pop, the two
  edges draw, the top node pops, then a halo ring expands and fades.
- The wordmark: "Metacase " in white and "Challenge" in the 100-degree t1 -> t2
  gradient (v2.css ``.wordmark .net``), Inter.
- The institution row: index.html ``.mc-host-crests`` — NTU shield window,
  HKU crest, SUFE seal and Tsinghua crest on white discs, original files from
  assets/institutions/ (bytes unchanged; see brand/ATTRIBUTION.txt).
"""
from __future__ import annotations

import math
import os
from functools import lru_cache

import skia

import gfx as G

HERE = os.path.dirname(os.path.abspath(__file__))
BRAND_DIR = os.path.normpath(os.path.join(HERE, "..", "brand"))

T1 = (68, 214, 214)      # oklch(80% 0.12 195)
T2 = (249, 182, 79)      # oklch(82% 0.14 75)
NODE = (241, 245, 250)   # #F1F5FA
EDGE_END = (238, 242, 247)
HOSTED = "Hosted by NTU GIFTS with HKU, SUFE and Tsinghua PBCSF"
SITE_URL = "easonai-5589.github.io/metacase-challenge"


def _bezier(p1x, p1y, p2x, p2y):
    """CSS cubic-bezier timing function."""
    def sample(t, a, b):
        return 3 * a * (1 - t) ** 2 * t + 3 * b * (1 - t) * t ** 2 + t ** 3

    def f(x):
        x = G.clamp(x)
        lo, hi = 0.0, 1.0
        for _ in range(28):
            mid = (lo + hi) / 2
            if sample(mid, p1x, p2x) < x:
                lo = mid
            else:
                hi = mid
        return sample((lo + hi) / 2, p1y, p2y)
    return f


EASE_STANDARD = _bezier(0.2, 0, 0, 1)
EASE_EMPHASIZED = _bezier(0.05, 0.7, 0.1, 1)


def _pop(ms, start, duration):
    """@keyframes pop: scale 0 -> 1.18 at 70% -> 1, with the emphasized ease."""
    if ms <= start:
        return 0.0
    u = EASE_EMPHASIZED((ms - start) / duration)
    return 1.18 * u / 0.7 if u < 0.7 else 1.18 + (1 - 1.18) * (u - 0.7) / 0.3


def _shader(p0, p1, c0, c1):
    return skia.GradientShader.MakeLinear([skia.Point(*p0), skia.Point(*p1)],
                                          [G.color(c0), G.color(c1)])


def draw_mark(cv, cx, cy, size, ms=None, a=1.0):
    """The Metacase mark centred at (cx, cy), ``size`` px square.

    ``ms`` is the .lg-anim clock in milliseconds since the animation began;
    None draws the settled mark (the header)."""
    if a <= 0.003:
        return
    settled = ms is None
    ms = 10_000.0 if settled else float(ms)
    k = size / 32.0
    cv.save()
    cv.translate(cx - 16 * k, cy - 16 * k)
    cv.scale(k, k)
    layer = skia.Paint()
    layer.setAlphaf(G.clamp(a))
    cv.saveLayer(None, layer)

    def dot(x, y, r, color, scale):
        if scale <= 0:
            return
        cv.drawCircle(x, y, r * scale, skia.Paint(AntiAlias=True, Color=G.color(color)))

    def edge(x0, y0, x1, y1, c0, progress):
        if progress <= 0:
            return
        p = skia.Paint(AntiAlias=True, Shader=_shader((x0, y0), (x1, y1), c0, EDGE_END))
        p.setStyle(skia.Paint.kStroke_Style)
        p.setStrokeWidth(2)
        p.setStrokeCap(skia.Paint.kRound_Cap)
        cv.drawLine(x0, y0, x0 + (x1 - x0) * progress, y0 + (y1 - y0) * progress, p)

    edge(7.6, 24.5, 16, 9.9, T1, EASE_STANDARD((ms - 380) / 450))
    edge(24.4, 24.5, 16, 9.9, T2, EASE_STANDARD((ms - 460) / 450))
    dot(7.6, 24.5, 3.0, T1, _pop(ms, 0, 500))
    dot(24.4, 24.5, 4.2, T2, _pop(ms, 120, 500))
    dot(16, 9.9, 5.4, NODE, _pop(ms, 820, 550))
    if not settled and 1050 <= ms <= 2150:
        u = EASE_STANDARD((ms - 1050) / 1100)
        ring = skia.Paint(AntiAlias=True, Color=G.color(NODE, 0.9 * (1 - u)))
        ring.setStyle(skia.Paint.kStroke_Style)
        ring.setStrokeWidth(1.0)
        cv.drawCircle(16, 9.9, 5.4 * (1 + 2.2 * u), ring)
    cv.restore()
    cv.restore()


def gradient_text(cv, s, x, y, size, weight=650, a=1.0, ls=0.0, kind="sans"):
    """Text filled with the wordmark's 100-degree t1 -> t2 gradient. Returns (w, h)."""
    w, h = G.measure(s, size, weight, kind, ls=ls)
    if a <= 0.003:
        return w, h
    bounds = skia.Rect.MakeXYWH(x - 2, y - 2, w + 4, h + 4)
    cv.saveLayer(bounds, None)
    G.text(cv, s, x, y, size=size, c=G.WHITE, weight=weight, kind=kind, ls=ls)
    angle = math.radians(100 - 90)   # CSS 100deg: towards the right, slightly down
    dx, dy = math.cos(angle) * w / 2, math.sin(angle) * w / 2
    cx, cy = x + w / 2, y + h / 2
    p = skia.Paint(Shader=_shader((cx - dx, cy - dy), (cx + dx, cy + dy), T1, T2))
    p.setBlendMode(skia.BlendMode.kSrcIn)
    cv.drawRect(bounds, p)
    cv.restore()
    if a < 0.997:
        # Fade by redrawing through an alpha layer is costly; callers pass a=1 inside an alpha layer.
        pass
    return w, h


def wordmark(cv, x, y, size, a=1.0, align="left", weight=650):
    """"Metacase Challenge" with "Challenge" in the gradient. Returns total width."""
    ls = -size * 0.02
    # A paragraph drops trailing spaces, so the word gap is added explicitly.
    w1 = G.measure("Metacase", size, weight, ls=ls)[0] + size * 0.26
    w2, _ = G.measure("Challenge", size, weight, ls=ls)
    total = w1 + w2
    x0 = x - total / 2 if align == "center" else x
    layer = skia.Paint()
    layer.setAlphaf(G.clamp(a))
    cv.saveLayer(None, layer)
    G.text(cv, "Metacase", x0, y, size=size, c=G.WHITE, weight=weight, ls=ls)
    gradient_text(cv, "Challenge", x0 + w1, y, size, weight=weight, ls=ls)
    cv.restore()
    return total


@lru_cache(maxsize=None)
def _image(name):
    return skia.Image.open(os.path.join(BRAND_DIR, name)).withDefaultMipmaps()


SAMPLING = skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear)


def crests(cv, cx, y, slot=64.0, gap=16.0, alphas=(1, 1, 1, 1)):
    """The homepage hero crest row, centred on cx, slots of ``slot`` px (CSS 64px)."""
    k = slot / 64.0
    img_h = 56 * k
    total = 4 * slot + 3 * gap
    x = cx - total / 2
    for i, a in enumerate(alphas):
        if a > 0.003:
            layer = skia.Paint()
            layer.setAlphaf(G.clamp(a))
            cv.saveLayer(None, layer)
            sx, sy = x + i * (slot + gap), y
            mx, my = sx + slot / 2, sy + slot / 2
            if i == 0:
                # .ntu-crest: a 44 x 56 window on the left of the full NTU logo.
                img = _image("ntu-university-official.png")
                w = img.width() * img_h / img.height()
                cv.save()
                cv.clipRect(skia.Rect.MakeXYWH(mx - 22 * k, my - img_h / 2, 44 * k, img_h))
                cv.drawImageRect(img, skia.Rect.MakeXYWH(mx - 22 * k, my - img_h / 2, w, img_h), SAMPLING)
                cv.restore()
            elif i == 1:
                img = _image("hku-university-crest.png")
                cv.drawImageRect(img, skia.Rect.MakeXYWH(mx - img_h / 2, my - img_h / 2, img_h, img_h), SAMPLING)
            else:
                # .sufe-crest: a 56px white disc with 2px padding, image contained.
                name = "sufe-university-official.png" if i == 2 else "tsinghua-university-crest.png"
                cv.drawCircle(mx, my, img_h / 2, skia.Paint(AntiAlias=True, Color=skia.ColorWHITE))
                cv.save()
                path = skia.Path()
                path.addCircle(mx, my, img_h / 2)
                cv.clipPath(path, doAntiAlias=True)
                img = _image(name)
                inner = img_h - 4 * k
                s = min(inner / img.width(), inner / img.height())
                w, h = img.width() * s, img.height() * s
                cv.drawImageRect(img, skia.Rect.MakeXYWH(mx - w / 2, my - h / 2, w, h), SAMPLING)
                cv.restore()
            cv.restore()
    return total
