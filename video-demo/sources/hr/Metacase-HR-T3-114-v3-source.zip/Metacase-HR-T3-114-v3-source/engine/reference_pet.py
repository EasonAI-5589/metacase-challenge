"""Exact task0001 v3.2 SVG pet, translated to deterministic Skia drawing.

Source: replay-deepagents-v3-2/site/original-guide.js, ``petMarkup`` and
``render``; source SHA-256:
9246340ec582e46bdc2339a8824deba064ec2fa30dbb3be9c6839ee815b95e68.
The SVG paths and hexadecimal colors below are copied literally from that
reference. Its 64 x 58.6667 CSS-pixel pet is enlarged 1.5 times: one unit of
the original 24 x 22 SVG equals four output pixels.

All pose animation is a pure function of the supplied clock. ``x, y`` are
the untransformed pet's top-left anchor; the caller owns route movement,
vertical travel lift, shadow, and keeping the pet outside caption bounds.
"""
from __future__ import annotations

import math
import re
from functools import lru_cache

import skia


SVG_UNIT = 4.0
REFERENCE_SCALE = 1.5
WIDTH, HEIGHT = 96.0, 88.0
ORIGIN = (48.0, 79.2)  # Original CSS transform-origin: (32, 52.8).

_TAIL = ("M4 13H1v-2h-2V9h2v2h3Z", "#c98a6c")
_FEET = (
    (("M5 15h4v6H5Z", "#805143"), ("M6 16h2v4H6Z", "#db9878")),
    (("M11 15h4v6h-4Z", "#805143"), ("M12 16h2v4h-2Z", "#db9878")),
    (("M17 15h4v6h-4Z", "#805143"), ("M18 16h2v4h-2Z", "#db9878")),
)
_BODY = (
    ("M5 4h3V2h3v2h6V2h3v3h2v3h2v9H2V8h3Z", "#7f5142"),
    ("M5 5h4V3h2v2h6V3h2v3h2v3h2v7H3V9h2Z", "#eda67d"),
    ("M6 5h3V3h2v2h6V3h2v3h2v3H5V7h1Z", "#ffc69a"),
    ("M5 9h16v6H5Z", "#f7b78d"),
    ("M3 14h20v2H3Z", "#ca8469"),
)
_CHEEKS = ("M6 13h2v1H6Zm14 0h2v1h-2Z", "#e9997a")
_IDLE_MOUTH = "M12 13h1v1h2v-1h1v2h-4Z"
_MOVING_MOUTH = "M12 13h3v2h-3Z"
_SVG_TOKEN = re.compile(r"[MmLlHhVvZz]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?")


def _clamp(value, low=0.0, high=1.0):
    return max(low, min(high, float(value)))


def _rand(n):
    value = math.sin(n * 78.233 + 11.17) * 43758.5453
    return value - math.floor(value)


def _rgb(color):
    if isinstance(color, str):
        value = color.lstrip("#")
        if len(value) != 6:
            raise ValueError("Expected a six-digit hexadecimal color")
        return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))
    if len(color) < 3:
        raise ValueError("Expected an RGB tuple")
    return tuple(int(v) for v in color[:3])


def _paint(color, opacity=1.0, stroke=None, aa=False):
    r, g, b = _rgb(color)
    paint = skia.Paint(
        AntiAlias=aa,
        Color=skia.Color(r, g, b, round(255 * _clamp(opacity))),
    )
    if stroke is not None:
        paint.setStyle(skia.Paint.kStroke_Style)
        paint.setStrokeWidth(stroke)
        paint.setStrokeCap(skia.Paint.kRound_Cap)
        paint.setStrokeJoin(skia.Paint.kRound_Join)
    return paint


@lru_cache(maxsize=None)
def _svg_path(data):
    """Parse only the literal polygon commands used by the reference SVG."""
    tokens = _SVG_TOKEN.findall(data)
    residue = _SVG_TOKEN.sub("", data)
    if residue.strip(" ,\t\r\n"):
        raise ValueError(f"Unsupported SVG path syntax: {data}")
    path = skia.Path()
    cursor = 0
    command = None
    x = y = start_x = start_y = 0.0
    while cursor < len(tokens):
        if tokens[cursor].isalpha():
            command = tokens[cursor]
            cursor += 1
            if command in "Zz":
                path.close()
                x, y = start_x, start_y
                command = None
                continue
        if command is None:
            raise ValueError(f"SVG path is missing a command: {data}")
        relative = command.islower()
        kind = command.upper()
        if kind in ("M", "L"):
            nx, ny = float(tokens[cursor]), float(tokens[cursor + 1])
            cursor += 2
            if relative:
                nx, ny = x + nx, y + ny
            x, y = nx, ny
            if kind == "M":
                path.moveTo(x, y)
                start_x, start_y = x, y
                command = "l" if relative else "L"
            else:
                path.lineTo(x, y)
        elif kind == "H":
            nx = float(tokens[cursor])
            cursor += 1
            x = x + nx if relative else nx
            path.lineTo(x, y)
        elif kind == "V":
            ny = float(tokens[cursor])
            cursor += 1
            y = y + ny if relative else ny
            path.lineTo(x, y)
        else:
            raise ValueError(f"Unsupported SVG command {command}")
    return path


def _paths(cv, elements):
    for data, color in elements:
        cv.drawPath(_svg_path(data), _paint(color))


def _rect(cv, x, y, width, height, color):
    cv.drawRect(skia.Rect.MakeXYWH(x, y, width, height), _paint(color))


def draw_pet(cv, x, y, t, flight=0.0, travel_u=1.0, dx=0.0,
             tip=None, focus=0.0, opacity=1.0):
    """Draw the reference pet and return geometry in 1920-stage pixels.

    ``t`` is the absolute clock in seconds. ``flight`` is the route's smooth
    movement weight, not a binary movement flag, and ``travel_u`` is its
    0..1 travel progress. ``tip`` is an optional pointer target in output
    coordinates. Keep these values continuous across shot boundaries.
    The original SVG always faces right; it is never mirrored or turned.
    ``cv=None`` returns geometry without any drawing.

    The body polygon and conservative bottom match the reference geometry
    audit, including its full-pose safety envelope. The pointing fingertips
    extend beyond the 96-pixel nominal width, just as in the original SVG.
    """
    x, y, t = float(x), float(y), float(t)
    flight, travel_u = _clamp(flight), _clamp(travel_u)
    focus, opacity = _clamp(focus), _clamp(opacity)
    if not all(math.isfinite(v) for v in (x, y, t, float(dx))):
        raise ValueError("Pet position, clock, and direction must be finite")

    # Literal reference pose equations; all trigonometric clocks are global.
    squash = .009 * math.sin(t * 3.1) + flight * .025 * math.cos(travel_u * math.pi * 2)
    sx, sy = 1 + squash - flight * .025, 1 - squash * 1.1 + flight * .045
    direction = 1 if dx > 0 else -1 if dx < 0 else 0
    lean = math.sin(t * 2.2) * .8 + direction * flight * 5
    angle = math.radians(lean)
    cosine, sine = math.cos(angle), math.sin(angle)
    ox, oy = ORIGIN

    def transform(px, py):
        px, py = (px - ox) * sx, (py - oy) * sy
        return (x + ox + px * cosine - py * sine,
                y + oy + px * sine + py * cosine)

    # Use the original CSS-local points, including the source's rounded
    # body polygon, enlarged by 1.5 exactly like the rendered SVG.
    hand = transform(68 * REFERENCE_SCALE, 27.2 * REFERENCE_SCALE)
    body_polygon = [
        transform(px * REFERENCE_SCALE, py * REFERENCE_SCALE)
        for px, py in ((5.333, 5.333), (64, 5.333),
                       (64, 45.333), (5.333, 45.333))
    ]
    bottom = max(
        transform(px * REFERENCE_SCALE, py * REFERENCE_SCALE)[1]
        for px, py in ((-2, -4), (74, -4), (74, 64), (-2, 64))
    )
    geometry = {"hand": hand, "body_polygon": body_polygon, "bottom": bottom,
                "lean": lean, "sx": sx, "sy": sy, "facing": 1.0}
    if cv is None or opacity <= 0:
        return geometry

    stride = math.sin(t * 2) * 1.3 + math.sin(travel_u * math.pi * 6) * 12 * flight
    block = math.floor(t / 4.6)
    blink_at = 2.7 + _rand(block + 902) * 1.1
    local = t - block * 4.6
    blink = blink_at <= local < blink_at + .145
    tip_x = float(tip[0]) if tip is not None else x + 150
    gaze = _clamp((tip_x - (x + 32 * REFERENCE_SCALE)) /
                  (120 * REFERENCE_SCALE), -.4, .4)

    # Composite opacity once, as CSS opacity applies to the entire SVG group.
    cv.save()
    alpha = skia.Paint()
    alpha.setAlphaf(opacity)
    cv.saveLayer(None, alpha)
    cv.translate(x + ox, y + oy)
    cv.rotate(lean)
    cv.scale(sx, sy)
    cv.translate(-ox, -oy)
    cv.scale(SVG_UNIT, SVG_UNIT)

    cv.save()
    cv.rotate(math.sin(t * 5.2) * 12, 3, 13)
    _paths(cv, (_TAIL,))
    cv.restore()

    cv.save()
    cv.rotate(stride, 7, 16)
    _paths(cv, _FEET[0])
    cv.restore()
    cv.save()
    cv.translate(0, -abs(stride) * flight / 20)
    _paths(cv, _FEET[1])
    cv.restore()
    cv.save()
    cv.rotate(-stride, 19, 16)
    _paths(cv, _FEET[2])
    cv.restore()

    _paths(cv, _BODY)
    _rect(cv, 8, 5, 2, 1, "#ffe2b5")
    _rect(cv, 13, 7, 4, 1, "#ffd3a4")
    cv.save()
    cv.translate(gaze, 10 if blink else -.2 * focus)
    if blink:
        cv.scale(1, .12)
    _rect(cv, 8, 10, 2, 3, "#46392e")
    _rect(cv, 17, 10, 2, 3, "#46392e")
    _rect(cv, 9, 10, 1, 1, "#fff0d3")
    _rect(cv, 18, 10, 1, 1, "#fff0d3")
    cv.restore()
    _paths(cv, ((_MOVING_MOUTH if flight > .001 else _IDLE_MOUTH, "#965c48"),))
    _paths(cv, (_CHEEKS,))

    cv.save()
    cv.rotate(-stride * 1.5, 3, 11)
    _rect(cv, 1, 10, 3, 3, "#eda67d")
    cv.restore()
    _rect(cv, 22, 10, 2, 3, "#eda67d")
    _rect(cv, 24, 9, 3, 2, "#ffc69a")

    cv.restore()  # SVG opacity layer.
    cv.restore()  # Caller's canvas state.
    return geometry


def draw_pointer(cv, hand, tip, t, color="#f4c79c", glow=0.0,
                 flight=0.0, opacity=1.0):
    """Draw the original round-ended baton at 1.5 times reference scale."""
    hx, hy = map(float, hand)
    tx, ty = map(float, tip)
    if not all(math.isfinite(v) for v in (hx, hy, tx, ty, float(t))):
        raise ValueError("Pointer endpoints and clock must be finite")
    opacity = _clamp(opacity) * (1 - _clamp(flight) * .35)
    if opacity <= 0:
        return
    distance = max(REFERENCE_SCALE, math.hypot(tx - hx, ty - hy))
    ux, uy = (tx - hx) / distance, (ty - hy) / distance
    end = 9 * REFERENCE_SCALE
    cv.save()
    alpha = skia.Paint()
    alpha.setAlphaf(opacity)
    cv.saveLayer(None, alpha)
    cv.drawLine(hx, hy, tx, ty, _paint("#151d25", stroke=5 * REFERENCE_SCALE, aa=True))
    cv.drawLine(hx, hy, tx, ty, _paint("#dfb68d", stroke=3 * REFERENCE_SCALE, aa=True))
    cv.drawLine(hx, hy, hx + ux * end, hy + uy * end,
                _paint("#845a43", stroke=4 * REFERENCE_SCALE, aa=True))
    cv.drawLine(tx - ux * end, ty - uy * end, tx, ty,
                _paint("#fff0c8", stroke=3 * REFERENCE_SCALE, aa=True))
    cv.drawCircle(tx, ty, (4 + .5 * math.sin(float(t) * 2)) * REFERENCE_SCALE,
                  _paint(color, _clamp(glow) * .7, stroke=1.2 * REFERENCE_SCALE, aa=True))
    cv.restore()
    cv.restore()
