"""English display names for the Chinese source material shown on screen in HR-T3-114 (v3).

Same rule as story/fin_en.py: the recorded run, its 17 input files and the agent's
two deliverables are in Chinese; every on-screen string passes through ``english()``
(engine/gfx.py) before layout. Codes (SYN-HUB-01, SYN-WP-A, RULE-A1, R20), numbers,
amounts and percentages are never changed. File names keep their extension and are
shown as snake_case names; the same phrase without an extension (a document title
quoted from the file itself) is shown as an English title.
"""
from __future__ import annotations

from story.fin_en import _CJK, _PUNCT

# (Chinese original, English shown on screen). Longer phrases are applied first.
GLOSSARY = [
    # ---- input files (as named in /app/input_files) ----
    ("三时点情境测验答题明细.csv", "scenario_test_answers_3_points.csv"),
    ("中心月度运营指标.csv", "hub_monthly_operations.csv"),
    ("主管范围与轮班花名册.csv", "supervisor_scope_shift_roster.csv"),
    ("任务授权、伦理边界与决策权限.docx", "task_authority_ethics_decision_rights.docx"),
    ("到课、补训与豁免事件.csv", "attendance_makeup_waivers.csv"),
    ("历史基准与同期参照.xlsx", "historical_baseline_reference.xlsx"),
    ("学习数据最小使用规范.docx", "learning_data_minimum_use.docx"),
    ("带教约谈与行动承诺.csv", "coaching_talks_commitments.csv"),
    ("异常处置机会暴露日志.csv", "incident_opportunity_log.csv"),
    ("异常工单生命周期.csv", "incident_ticket_lifecycle.csv"),
    ("现场处置行为编码.xlsx", "field_behaviour_coding.xlsx"),
    ("训练单元和教学场次账.xlsx", "training_units_sessions.xlsx"),
    ("设备、气象和货型扰动.csv", "equipment_weather_cargo_disruptions.csv"),
    ("证据完整性复核清单.xlsx", "evidence_completeness_checklist.xlsx"),
    ("采购工作包与结算规则.xlsx", "procurement_work_packages_settlement.xlsx"),
    # ---- the agent's two deliverables ----
    ("项目验收与整改决策备忘录.docx", "project_acceptance_remediation_memo.docx"),
    ("训练成效与验收决策工作簿.xlsx", "training_impact_acceptance_workbook.xlsx"),
    # ---- document titles and rule lines quoted from the Word files (step 19) ----
    ("任务授权、伦理边界与决策权限", "Task authority, ethical boundaries and decision rights"),
    ("学习数据最小使用规范", "learning-data minimum-use rules"),
    ("昇川温控运营（虚构）｜冰链应变训练", "Jichuan Cold-Chain Operations (fictional) | cold-chain response training"),
    ("全部主体、人员、客户、交易及业务数据均为虚构合成，仅用于基准测试。",
     "All entities, people, customers, transactions and business data are synthetic, for benchmarking only."),
    ("个人测验、观察和辅导仅用于项目评估、支持性辅导与采购验收。",
     "Individual tests, observations and coaching are used only for evaluation, supportive coaching and acceptance."),
    # ---- the agent's script (request 7) ----
    ("冰链应变训练: 训练成效与验收", "Cold-chain response training: impact and"),
    ("决策分析流水线", "acceptance decision pipeline"),
    # ---- workbook sheets (steps 40 and 54 of the agent's own read-back) ----
    ("机会行为个人汇总", "Opportunity-behaviour by person"),
    ("阶段门与金额复算", "Stage gates & amounts"),
    ("学习保持分析", "Learning retention"),
    ("有效样本核定", "Valid sample"),
    ("封面与口径", "Cover & definitions"),
    ("机会与行为", "Opportunity & behaviour"),
    ("带教辅导", "Coaching"),
    ("运营对照", "Operations comparison"),
    ("测验汇总", "Test summary"),
    ("no 来源索引 (source index)", "no source-index sheet"),
    ("来源索引", "Source index"),
    # ---- statuses and rule names printed by the agent's script ----
    ("附条件验收", "conditional acceptance"),
    ("验收通过", "accepted"),
    ("部分验收(", "partial acceptance ("),
    ("单元)", " units)"),
    ("交付率", "delivery rate"),
    ("时长达标率", "hours-met rate"),
    ("纳入 81 · 观察受限 2 · 排除 1", "included 81 · obs.-limited 2 · excluded 1"),
    # ---- work packages (采购工作包与结算规则.xlsx) ----
    ("训练准备与交付", "Training preparation and delivery"),
    ("学习保持与岗位转化证据", "Learning retention and on-the-job transfer"),
    ("运营验证与结项关闭", "Operational validation and close-out"),
    ("训练服务方阶段申请: “材料已上传”为由自评全部通过", "Vendor stage claim: all passed because “materials uploaded”"),
    ("合同金额", "contract"),
    ("建议提交", "to approve"),
    ("保留", "retained"),
    # ---- the opportunity sheets (R32) ----
    ("机会充足 (≥2 次)", "Enough opportunity (≥2)"),
    ("机会充足 = 否", "Enough opportunity = no"),
    ("行为达标 = 否", "Behaviour met = no"),
    ("机会不足", "Too little opportunity"),
]

_ORDERED = sorted(GLOSSARY, key=lambda kv: len(kv[0]), reverse=True)


def english(s):
    """Return the on-screen English form of ``s`` (unchanged when it has no Chinese)."""
    if not s or not _CJK.search(s):
        return s
    for zh, en in _ORDERED:
        if zh in s:
            s = s.replace(zh, en)
    for zh, en in _PUNCT.items():
        s = s.replace(zh, en)
    return s


def untranslated(s):
    """Chinese characters that would still reach the screen."""
    return _CJK.findall(english(s) or "")
