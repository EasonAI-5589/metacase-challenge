"""English display names for the Chinese source material shown on screen (v3 edition).

The recorded run, its 55 input files and the agent's two deliverables are in
Chinese. The v3 film is English only: every on-screen string passes through
``english()`` before it is laid out (engine/gfx.py), which replaces each Chinese
phrase below with its English rendering. Numbers, codes (D01, HR-01, IRS-2026-0031,
HKSub, USSub, DV01), dates and amounts are never translated or changed, so each
figure still traces to the original file. ``GLOSSARY`` is the table recorded in
provenance; file names keep their number prefix and date suffix.
"""
from __future__ import annotations

import re

# (Chinese original, English shown on screen). Longer phrases are applied first.
GLOSSARY = [
    # ---- input files (number prefix kept) ----
    ("60_七月结账专项复核委托", "60_July_close_review_brief"),
    ("61_七月待入账意见登记", "61_July_pending_entries"),
    ("62_期初结存", "62_opening_balances"),
    ("63_复核工时安排", "63_review_hours"),
    ("12_衍生品交易与逐日估值明细", "12_derivatives_daily_MTM"),
    ("15_套期指定与再平衡台账", "15_hedge_designation_ledger"),
    ("16_中后台估值底稿", "16_middle_office_valuation"),
    ("17_对手方估值单", "17_counterparty_valuation"),
    ("18_合并折算底稿", "18_consolidation_translation"),
    ("20_境外子公司权益变动明细台账", "20_subsidiary_equity_ledger"),
    ("22_外币财务报表折算差额勾稽底稿_复核前草稿", "22_FX_translation_recon_draft"),
    ("24_境外子公司汇率来源核对单", "24_FX_rate_source_check"),
    ("31_内部会计政策_版本", "31_internal_policy_v"),
    ("32_套期关系指定文档", "32_hedge_designation_doc"),
    ("34_外债合同摘录", "34_foreign_debt_contract"),
    ("35_中后台估值说明", "35_middle_office_valuation_note"),
    ("36_规则条文摘录_会计准则部分", "36_rules_accounting_standards"),
    ("38_规则条文摘录_套期有效性定量门槛沿革", "38_rules_effectiveness_history"),
    ("39_规则条文摘录_净投资套期工具持有主体补充", "39_rules_NIH_holder_supplement"),
    ("40_风险管理委员会决议", "40_risk_committee_resolution"),
    ("42_再平衡备忘稿", "42_rebalancing_memo_draft"),
    ("44_境外子公司往来函件_HKSub折算口径疑问来函", "44_HKSub_translation_query"),
    ("45_集团财务部复函_HKSub折算口径统一说明", "45_group_reply_HKSub_translation"),
    ("46_境外子公司请示函_USSub部分处置股权", "46_USSub_disposal_request"),
    ("47_集团财务部批复_USSub部分处置股权", "47_USSub_disposal_approval"),
    ("48_套期关系文件完整性排查清单", "48_hedge_docs_checklist"),
    ("49_套期关系正式指定文档", "49_hedge_formal_designation"),
    ("53_规则条文摘录_外币折算功能货币判断与净资产构成补充", "53_rules_functional_currency"),
    # ---- the agent's two deliverables ----
    ("FIN-T1-003_月结调整与复核底稿", "FIN-T1-003_month-end_workpapers"),
    ("FIN-T1-003_七月结账整改与复核安排", "FIN-T1-003_July_close_review_plan"),
    ("月结调整与复核底稿", "month-end_workpapers"),
    ("七月结账整改与复核安排", "July_close_review_plan"),
    # ---- shortened file names drawn by the storyboard ----
    ("60_…委托", "60_…brief"),
    ("…底稿", "…workpapers"),
    # ---- task card and engagement letter ----
    ("集团七月结账整改与复核安排", "Group July close: corrections and review plan"),
    ("7月账务8月5日18:00锁账，共享中心已提交一批待入账意见",
     "July books lock at 18:00 on 5 Aug; the shared-service centre has submitted pending entries"),
    ("逐项处理待入账意见，算清金额与报表影响，形成可批准的替换分录",
     "Resolve each pending entry: amounts, statement effects, approvable replacement entries"),
    ("同步更正HKSub 6月比较信息；为USSub股权转让做交割前预演",
     "Correct HKSub's June comparatives; rehearse the USSub equity transfer before closing"),
    ("只有1名独立复核人，8月4日、5日每日最多6小时",
     "One independent reviewer only: at most 6 hours a day on 4 and 5 Aug"),
    ("不得把建议或计划写成已获批准或已经执行",
     "Never present a proposal or plan as approved or carried out"),
    ("七月结账专项复核委托及适用范围", "July close special review: engagement and scope"),
    ("发文日期：2026-08-03，经财务负责人签批", "Issued 2026-08-03, signed off by the head of finance"),
    ("7月结账锁账时间为 2026-08-05 18:00", "July close: the books lock at 2026-08-05 18:00"),
    ("61号 D01 至 D06 均为待入账意见，全部尚未过账", "No. 61: D01 to D06 are all pending entries; none is posted"),
    # ---- pending-entry register rows (file 61) ----
    ("互换继续按原关系计入现金流量套期储备", "swap stays in CF hedge reserve under original hedge"),
    ("美元借款7月汇兑损失计入现金流量套期储备", "July FX loss on USD loan to CF hedge reserve"),
    ("套期关系终止应把期初储备一次转损益", "hedge ended: recycle opening reserve to P&L at once"),
    ("仅更新22号资产负债精度，18号权益和利润金额不动…", "update No. 22 BS precision only; No. 18 equity/profit unchanged…"),
    ("按归母累计折算差额乘15/70预提处置收益", "accrue disposal gain: parent's cum. translation diff. × 15/70"),
    ("以17号对手方估值替换16号采用值，差额全部作为…", "replace No. 16 value with No. 17 counterparty value; full diff. as…"),
    ("未过账", "unposted"),
    # ---- workbook sheets, journal lines and report headings ----
    ("套期关系指定", "Hedge designations"),
    ("有效性评估", "Effectiveness tests"),
    ("折算与储备", "Translation & reserves"),
    ("调整分录", "Adjusting entries"),
    ("复核排程", "Review schedule"),
    ("借：其他综合收益——现金流量套期储备", "Dr: OCI — cash flow hedge reserve"),
    ("借：其他综合收益——净投资套期储备", "Dr: OCI — net investment hedge reserve"),
    ("借：公允价值变动损益", "Dr: Fair value gains and losses"),
    ("贷：外币借款", "Cr: Foreign-currency borrowings"),
    ("净投资套期储备", "net investment hedge reserve"),
    ("接受作为暂行处理意见，科目名称修正为：", "Accepted as an interim treatment, with the account renamed:"),
    ("三、各项意见处置详情", "3. Disposition of each pending entry"),
    ("七月结账专项整改完成", "July close remediation complete"),
    ("16号估值底稿", "No. 16 valuation workpaper"),
    # ---- column names read by the agent's code ----
    ("交易编号", "trade_id"),
    ("估值日", "valuation_date"),
    ("当日MTM_元", "daily_MTM_CNY"),
    ("DV01_元", "DV01_CNY"),
]

_ORDERED = sorted(GLOSSARY, key=lambda kv: len(kv[0]), reverse=True)
_CJK = re.compile(r"[　-〿一-鿿＀-￯]")
_PUNCT = {"：": ": ", "，": ", ", "、": ", ", "；": "; ", "（": " (", "）": ")", "。": ". "}


def english(s):
    """Return the on-screen English form of ``s`` (unchanged when it has no Chinese)."""
    if not s or not _CJK.search(s):
        return s
    for zh, en in _ORDERED:
        if zh in s:
            s = s.replace(zh, en)
    for zh, en in _PUNCT.items():
        s = s.replace(zh, en)
    return s


def untranslated(s):
    """Chinese characters that would still reach the screen."""
    return _CJK.findall(english(s) or "")
