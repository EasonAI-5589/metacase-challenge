"""HR-T3-114 storyboard (one narration cue per shot), reconstructed for the v3 edition.

The v2 HR source (story/hr.py, data/hr.json, hr.requests.jsonl) was not checked in.
This file was rebuilt from the published v2 film (assets/video/hr-agent-replay.mp4,
docs/video/hr/provenance.json): shot order, kinds, chapters, narration, the status
lines and every on-screen value were read back from the frames. Card text that the
film shows in Chinese is kept here in Chinese and drawn in English through
story/hr_en.py. Requests and steps refer to the reconstructed data/hr.json, whose
ledger readings match the film at every sampled time.

say : narration sent to the voice; {key} marks the start of the next word and becomes a
      visual cue time. en : caption (defaults to say without markers).
trace: agent-run seconds swept by the header clock during the shot.
"""

RUN = "hr"

SHOTS = [
    # ------------------------------------------------------------------ 01 TASK
    dict(id="h00", ch=0, kind="open",
         say="One model, one harness, one training review. {a}Follow how the agent works inside Claude Code, {b}and how its files are checked.",
         st=("brand", "HR-T3-114 · human resources · fictional task · recorded pilot run")),
    dict(id="h01", ch=0, kind="sites",
         say="A fictional cold-chain operator trained supervisors at three sites for six weeks. {d}A fourth site, trained later, is the comparison.",
         st=("brand", "all people, sites and records are synthetic")),
    dict(id="h02", ch=0, kind="packages",
         say="The agent must judge what the training changed, then decide acceptance and payment for {wp}three vendor work packages, {sum}worth eight hundred sixteen thousand yuan.",
         en="The agent must judge what the training changed, then decide acceptance and payment for three vendor work packages, worth 816,000 yuan.",
         st=("brand", "the vendor's own claim: all three packages passed")),
    dict(id="h03", ch=0, kind="io",
         say="{kinds}Seventeen files go in: rosters, attendance, tests, field observations, work orders and procurement rules. {out}A workbook and a decision memo must come out.",
         en="17 files go in: rosters, attendance, tests, field observations, work orders and procurement rules. A workbook and a decision memo must come out.",
         st=("sandbox", "/app/input_files · 17 read-only  →  /app/output")),
    dict(id="h04", ch=0, kind="sealed",
         say="The scoring rubric is not in the container. {lock}The agent works without seeing how it will be judged.",
         st=("scorer", "tests/ and solution/ absent during the agent run")),

    # ------------------------------------------------------------------ 02 AGENT
    dict(id="h05", ch=1, kind="loop_intro",
         say="Claude Code runs the loop. {m}The model chooses an action, {h}Claude Code turns it into a tool call, {s}the call runs inside the container, {o}and the result returns to the model.",
         st=("harness", "harness · claude --print · cwd /app"), trace=(0.0, 7.1)),
    dict(id="h06", ch=1, kind="fanout",
         say="{list}After listing the inputs, {one}the second request sends {n}eight tool calls at once, one preview per data ledger. {back}All eight results come back together.",
         en="After listing the inputs, the second request sends eight tool calls at once, one preview per data ledger. All eight results come back together.",
         st=("harness", "request 2 · 8 parallel Bash calls · steps 3–10"), trace=(7.1, 16.5)),
    dict(id="h07", ch=1, kind="plan",
         say="{tw}Request three writes a plan with To-do Write: {items}validate the samples, analyze learning and behavior, compare the sites, {pay}and compute the payments.",
         en="Request three writes a plan with TodoWrite: validate the samples, analyze learning and behavior, compare the sites, and compute the payments.",
         st=("harness", "TodoWrite · handled by Claude Code · no Bash"), trace=(23.5, 25.4)),
    dict(id="h08", ch=1, kind="rules",
         say="{rd}Then it reads the workbooks and Word files. {rule}One rule matters: individual learning data may only be used for assessment, support and acceptance.",
         st=("sandbox", "requests 4–5 · steps 13–22 · openpyxl and python-docx"), trace=(31.5, 52.0)),
    dict(id="h09", ch=1, kind="write",
         say="{gen}Then comes one long response. For over two minutes the model writes a single analysis script, {save}and Claude Code's Write tool saves it in the container.",
         st=("model", "request 7 · 19,223 output tokens · 1,336-line script"), trace=(67.2, 199.9)),
    dict(id="h10", ch=1, kind="run",
         say="{run}Bash runs the script. {load}It loads every ledger and writes both files. {wpa}Work package A comes out as accepted, {ten}yet ten percent of its payment is held back.",
         en="Bash runs the script. It loads every ledger and writes both files. Work package A comes out as accepted, yet 10% of its payment is held back.",
         st=("sandbox", "request 8 · step 26 · exit 0 · +204.3 s"), trace=(204.0, 206.0)),
    dict(id="h11", ch=1, kind="notice",
         say="{ok}The run succeeded, with no error. {q}But after reading its own output, the model reports problems in the W P A status logic and the sample filter.",
         en="The run succeeded, with no error. But after reading its own output, the model reports problems in the WP-A status logic and the sample filter.",
         st=("model", "request 9 · recorded assistant text · +222.1 s"), trace=(206.0, 222.1)),
    dict(id="h12", ch=1, kind="edits",
         say="{scope}It checks the scope: eighty-one people included, two observation-limited, one excluded. {edit}Then it reads the script, edits it four times, {again}and runs it again.",
         en="It checks the scope: 81 people included, 2 observation-limited, 1 excluded. Then it reads the script, edits it four times, and runs it again.",
         st=("harness", "requests 9–17 · Read ×2 · Edit ×4 · Bash"), trace=(221.8, 282.4)),
    dict(id="h13", ch=1, kind="rerun",
         say="{same}Same script, still no error. {wpa}This time WPA is a conditional acceptance: {amt}220,320 yuan to approve, 24,480 retained.",
         en="Same script, still no error. This time WP-A is a conditional acceptance: 220,320 yuan to approve, 24,480 retained.",
         st=("sandbox", "request 17 · step 38 · +283.5 s"), trace=(282.2, 283.5)),
    dict(id="h14", ch=1, kind="verify",
         say="{chk}It checks the nine-sheet workbook {memo}and the memo, {ls}and confirms that only the two required files are in the output folder.",
         st=("sandbox", "requests 18–24 · steps 39–46"), trace=(287.4, 319.0)),
    dict(id="h15", ch=1, kind="finish",
         say="{fin}The plan is ticked off and the agent stops: {tot}twenty-eight requests, forty-four tool calls, about six minutes. {ok}Not one tool call failed.",
         en="The plan is ticked off and the agent stops: 28 requests, 44 tool calls, about six minutes. Not one tool call failed.",
         st=("model", "agent trace 364.9 s · 33,040 output tokens"), trace=(325.6, 364.9)),

    # ------------------------------------------------------------------ 03 HARNESS
    dict(id="h16", ch=2, kind="trace",
         say="Here is the whole run. {calls}Thirty-three Bash, four To-do Write, one Write, two Read and four Edit calls. {turn}The turning point was not a crash; it came from the model reading its own results.",
         en="Here is the whole run. 33 Bash, 4 TodoWrite, 1 Write, 2 Read and 4 Edit calls. The turning point was not a crash; it came from the model reading its own results.",
         st=("harness", "44 tool calls · 28 requests · 364.9 s"), trace=(364.9, 364.9)),
    dict(id="h17", ch=2, kind="context",
         say="{grow}Each result is added to the model's context. {end}By the last request, the prompt has grown from about twenty-five thousand to about eighty-nine thousand tokens.",
         en="Each result is added to the model's context. By the last request, the prompt has grown from about 25 thousand to about 89 thousand tokens.",
         st=("model", "prompt tokens per request · 25,021 → 89,340"), trace=(364.9, 364.9)),
    dict(id="h18", ch=2, kind="handoff",
         say="{stop}When the agent stops, {tests}Harbor copies the tests into the same container. {score}Only then does scoring begin.",
         st=("scorer", "same container · tests/ copied in · judge runs as root"), trace=(364.9, 364.9)),

    # ------------------------------------------------------------------ 04 CHECK
    dict(id="h19", ch=3, kind="chapter",
         say="An independent check now takes over.",
         title="Independent check", sub="The two submitted files are scored, one criterion at a time.",
         st=("scorer", "RewardKit 0.1.7 · Claude Code judge sessions")),
    dict(id="h20", ch=3, kind="judges",
         say="{rk}Reward Kit opens one judge session for each of thirty-four criteria. {jm}The judge model is Qwen three point seven Plus, a different model from the agent. {nf}Nothing flows back to the agent.",
         en="RewardKit opens one judge session for each of 34 criteria. The judge model is qwen3.7-plus, a different model from the agent. Nothing flows back to the agent.",
         st=("scorer", "28 positive + 6 penalty criteria · 303 judge API requests")),
    dict(id="h21", ch=3, kind="wpa",
         say="{fix}The W P A fix holds up: {met}the judge accepts the conditional acceptance status.",
         en="The WP-A fix holds up: the judge accepts the conditional-acceptance status.",
         st=("pass", "R20 · met · weight 7")),
    dict(id="h22", ch=3, kind="pooled",
         say="{pool}Other parts fall short. The workbook pools the three trained sites instead of comparing each one with the delayed site, {idx}and it has no source-index sheet.",
         st=("fail", "R14–R16 · not met   R1, R19 · not met")),
    dict(id="h23", ch=3, kind="r32",
         say="{pen}And one penalty applies. {ten}Ten people had too few chances to show the behavior, yet the workbook marks them as not meeting the standard.",
         st=("fail", "R32 · penalty criterion · weight 7")),
    dict(id="h23b", ch=3, kind="r32",
         say="{why}Too little opportunity is not evidence of low ability, so seven weighted points are deducted.",
         st=("fail", "R32 · penalty triggered · −7 raw weighted points")),

    # ------------------------------------------------------------------ 05 RESULT
    dict(id="h24", ch=4, kind="tally",
         say="{pos}Of twenty-eight positive criteria, six are met and twenty-two are not. {pen}One of six penalties applies, and this task has no red-line criteria.",
         en="Of 28 positive criteria, 6 are met and 22 are not. One of six penalties applies, and this task has no red-line criteria.",
         st=("scorer", "positive weight 106 · passed weight 29 · penalty 7")),
    dict(id="h25", ch=4, kind="reward",
         say="{rw}The recorded reward is zero point two zero eight: {w}twenty-nine points, minus seven, over one hundred six. {pilot}One pilot run on a fictional task, not a ranking.",
         en="The recorded reward is 0.208: 29 points, minus 7, over 106. One pilot run on a fictional task, not a ranking.",
         st=("scorer", "reward 0.207547 · verifier_error 0")),
    dict(id="h26", ch=4, kind="outro",
         say="A professional task, an agent run, and an independent check. {site}Explore more on the Metacase Challenge site.",
         st=("brand", "easonai-5589.github.io/metacase-challenge")),
]

# ---------------------------------------------------------------------------- persistent panels
_PLAN = ["Read all source files", "Validate the samples", "Build the analysis pipeline",
         "Learning · opportunity · behaviour", "Trained vs delayed sites", "Package status and payments",
         "Excel workbook", "Word decision memo", "Validate the output files"]

CONF = dict(
    task_id="HR-T3-114", domain="HR · fictional", version="",
    title="Cold-chain supervisor training: impact review and vendor acceptance",
    title_zh="冷链仓储一线主管异常处置训练成效与服务采购验收",
    role="Joint lead · learning impact and procurement acceptance",
    meta="17 input files · Excel + Word · A2 / C4",
    chips=[("MODEL", "qwen3.7-max"), ("HARNESS", "Claude Code 2.1.114"),
           ("SANDBOX", "Docker · Bash"), ("JUDGE", "qwen3.7-plus")],
    total_tools=44, total_requests=28, inputs=17, plan_slots=8,
    plan_labels=[(p, p) for p in _PLAN],
    # (trace s, label, value, colour) — values exactly as the film shows them
    found=[
        (16.5, "ledgers previewed", "8 CSV", "fg"),
        (206.0, "roster", "84 people", "fg"),
        (206.0, "WP-A status", "验收通过", "model"),
        (223.8, "scope check", "81 · 2 · 1", "fg"),
        (283.5, "WP-A status", "附条件验收", "model"),
    ],
    files_opened_label="materials opened",
    # decorative labels in the opening particle cloud: codes and totals of this run
    particle_words=("¥", "%", "Δ", "WP-A", "R32", "Word", "Excel", "28", "44", "364.9", "{ }"),
    xlsx="训练成效与验收决策工作簿.xlsx",
    docx="项目验收与整改决策备忘录.docx",
)


def outputs(T):
    """State of /app/output at trace time T (from recorded tool results)."""
    out = []
    if T >= 205.0:
        by = "rebuilt by the re-run" if T >= 282.7 else "written by build_deliverables.py"
        docx, xlsx = by, by
        dsize = xsize = ""
        if T >= 292.8:
            xlsx, xsize = "9 sheets", "23,842 B"
        if T >= 296.6:
            docx, dsize = "73 ¶ · 3 tables", "41,290 B"
        out.append(dict(kind="docx", name=CONF["docx"], meta=docx, size=dsize, state="ok"))
        out.append(dict(kind="xlsx", name=CONF["xlsx"], meta=xlsx, size=xsize, state="ok"))
    return out


# ---------------------------------------------------------------------------- shot payloads (visuals)
_CSV = ["三时点情境测验答题明细", "中心月度运营指标", "主管范围与轮班花名册", "到课、补训与豁免事件",
        "带教约谈与行动承诺", "异常处置机会暴露日志", "异常工单生命周期", "设备、气象和货型扰动"]
_T = [13.1, 13.4, 13.8, 14.1, 14.5, 14.9, 15.3, 16.5]

PAY = {
    "h00": dict(pet=[(0.0, (720, 530)), ("a", (560, 622)), ("b", (640, 690))]),
    "h05": dict(as_="loop", accent="harness", phases=[dict(
        at=0.0, rq="", sub="Model → Claude Code → Docker → back to the model",
        stages=["qwen3.7-max", "Claude Code", "Bash · python3", "next request"],
        labels=["MODEL", "HARNESS", "DOCKER · BASH", "OBSERVATION"],
        beats=[("m", 0), ("h", 1), ("s", 2), ("o", 3)], route="o",
        cards=[dict(kick="MODEL · REMOTE API", title="Chooses the next action", role="model", at="m", hi=[("m", "h")],
                    lines=["Reads the task and every result so far", "Replies with text and tool calls", "Served through Alibaba Cloud Bailian"]),
               dict(kick="HARNESS · IN THE CONTAINER", title="Claude Code runs the loop", role="harness", at="h", hi=[("h", "s")],
                    lines=["Dispatches each tool call", "Bash, TodoWrite, Write, Read, Edit", "Sends results back with the next request"]),
               dict(kick="SANDBOX · DOCKER", title="Work happens in /app", role="sandbox", at="s", hi=[("s", "o")],
                    lines=["python3 with pandas and openpyxl", "Reads /app/input_files (read-only)", "Writes /app/output"])],
        foot="Harbor runs:  claude --print --output-format=stream-json --permission-mode=bypassPermissions")],
        pet=[("m", "card0"), ("h", "card1"), ("s", "card2"), ("o", (803, 470))]),
    "h07": dict(as_="loop", accent="harness", tk=[("tw", 23.5), ("items", 25.4)], phases=[dict(
        at=0.0, rq="REQUEST 3 / 28", sub="TodoWrite: the plan is kept by Claude Code, not by Bash",
        stages=["qwen3.7-max", "TodoWrite", "no shell", "tool result"], dim=[2],
        beats=[("tw", 0), (("tw", 1.0), 1), ("pay", 3)], route="pay",
        cards=[dict(kick="REQUEST · 1 tool call", title="TodoWrite · 7 items", role="model", at="tw", hi=[("tw", "items")],
                    lines=["Read all source files · in progress", "Samples · learning · site comparison", "Payments · workbook · memo"]),
               dict(kick="HANDLED BY CLAUDE CODE", title="No command runs", role="harness", at=("tw", 0.9),
                    hi=[(("tw", 0.9), "pay")], lines=["The list lives in the session", "Docker is not involved"]),
               dict(kick="OBSERVATION", role="brand", mono=True, size=14, at="pay",
                    lines=["Todos have been modified", "successfully."])],
        foot="step 11 · TodoWrite · +25.4 s")],
        pet=[("tw", "card0"), ("items", "plan"), ("pay", "card2")]),
    "h08": dict(as_="loop", tk=[("rd", 31.5), ("rule", 49.0), (("rule", 4.0), 52.0)], phases=[dict(
        at=0.0, rq="REQUESTS 4–5", sub="Read the workbooks and the Word rules",
        stages=["qwen3.7-max", "Bash ×9", "openpyxl · docx", "text"],
        beats=[("rd", 0), (("rd", 0.9), 1), (("rd", 1.6), 2), ("rule", 3)], route=("rule", 1.0),
        cards=[dict(kick="REQUESTS 4–5 · 9 tool calls", role="model", mono=True, size=12.5, at="rd", maxl=1,
                    lines=["openpyxl: 采购工作包与结算规则.xlsx", "openpyxl: 历史基准与同期参照.xlsx",
                           "openpyxl: 训练单元和教学场次账.xlsx", "openpyxl: 现场处置行为编码.xlsx",
                           "openpyxl: 证据完整性复核清单.xlsx", "docx: 任务授权、伦理边界与决策权限",
                           "docx: 学习数据最小使用规范 · + 2 more"]),
               dict(kick="OBSERVATION · step 19", role="brand", size=14, at="rule", span=2, gap=4, maxl=2,
                    hi=[("rule", 4.0)], cols=[None, None, None, "model"],
                    lines=["任务授权、伦理边界与决策权限",
                           "昇川温控运营（虚构）｜冰链应变训练",
                           "全部主体、人员、客户、交易及业务数据均为虚构合成，仅用于基准测试。",
                           "个人测验、观察和辅导仅用于项目评估、支持性辅导与采购验收。"]),
               None],
        foot="steps 13–22 · exit 0 · all 17 materials appear in recorded commands")],
        pet=[("rd", "card0"), ("rule", "card1")]),
    "h09": dict(as_="loop", accent="model", tk=[("gen", 69.5), (("save", -0.2), 199.8), (("save", 1.0), 199.9)], phases=[dict(
        at=0.0, rq="REQUEST 7 / 28", sub="One response writes /app/build_deliverables.py",
        stages=["19,223 tokens", "Write", "file system", "file created"],
        labels=["MODEL", "TOOL CALL", "CONTAINER · FILE", "OBSERVATION"],
        beats=[("gen", 0), ("save", 1), (("save", 0.6), 2), (("save", 1.2), 3)], route=("save", 1.2),
        cards=[dict(kick="REQUEST · Write", role="model", mono=True, size=13, at="gen", hi=[("gen", "save")], maxl=1,
                    lines=["#!/usr/bin/env python3", '"""冰链应变训练: 训练成效与验收', '决策分析流水线 Generate: …"""',
                           "import pandas as pd", "import openpyxl …"]),
               dict(kick="HANDLED BY CLAUDE CODE", title="Write, not Bash", role="harness", at="save",
                    hi=[("save", 2.5)], lines=["1,336 lines · 55,292 characters", "saved to /app", "about 130 s of generation"]),
               dict(kick="OBSERVATION", role="brand", mono=True, size=14, at=("save", 1.2),
                    lines=["File created successfully at:", "/app/build_deliverables.py"])],
        foot="request 7 · +69.5 → +199.8 s · the longest response of the run")],
        pet=[("gen", "card0"), ("save", "card1"), (("save", 1.3), "card2")]),
    "h10": dict(as_="loop", tk=[("run", 204.3), ("load", 205.0), ("wpa", 205.6), ("ten", 206.0)], phases=[dict(
        at=0.0, rq="REQUEST 8 / 28", sub="Run the pipeline",
        stages=["qwen3.7-max", "Bash", "python3", "9,609 chars"],
        beats=[("run", 0), (("run", 0.5), 1), (("run", 1.0), 2), ("load", 3)], route="wpa",
        cards=[dict(kick="REQUEST · step 26", role="model", mono=True, size=14, at="run",
                    lines=["python3 build_deliverables.py", "2>&1"]),
               dict(kick="OBSERVATION · step 26 · exit 0", role="brand", mono=True, size=12.5, at="load", span=2, gap=3, maxl=1,
                    hi=[("wpa", 4.0)], cols=[None, None, None, None, "model", "sandbox"],
                    line_at=["load", ("load", 0.15), ("load", 0.3), ("load", 0.45), "wpa", ("load", 0.9)],
                    lines=["Roster: 84 persons · Attendance events: 755",
                           "Test answer rows: 4940 · Coaching records: 191",
                           "Opportunity records: 341 · Incident records: 720",
                           "Observation records: 1145",
                           "WP-A: status=验收通过, amount=244800, recommended=220320.0, retained=24…",
                           "Workbook saved. · Memo saved. · Deliverables in /app/output/"]),
               None],
        foot="step 26 · +204.3 → +206.0 s · both files written")],
        state=dict(out_kind="xlsx"),
        pet=[("run", "card0"), ("load", "card1"), ("wpa", "found"), ("ten", "card1")]),
    "h11": dict(as_="loop", overlay="quote", tk=[("ok", 206.0), ("q", 222.1)], phases=[
        dict(at=0.0, rq="REQUEST 8 / 28", sub="The pipeline ran without an error",
             stages=["qwen3.7-max", "Bash", "python3", "exit 0"],
             beats=[("ok", 3)],
             cards=[dict(kick="REQUEST · step 26", role="model", mono=True, size=14, at=0.0,
                         lines=["python3 build_deliverables.py", "2>&1"]),
                    dict(kick="RESULT · step 26", title="exit 0 · no traceback", role="sandbox", at="ok",
                         lines=["Workbook saved.", "Memo saved."]),
                    None]),
        dict(at="q", rq="REQUEST 9 / 28", sub="The model reviews what it produced",
             stages=["qwen3.7-max", "Bash", "python3", "exit 0"], beats=[("q", 0)],
             cards=[None, None, None])],
        quote=("The pipeline executed. Let me verify the output and fix a few issues I noticed in the WP-A status logic and sample filtering.",
               "recorded assistant text · request 9 · +222.1 s"),
        pet=[("ok", "card1"), ("q", (960, 640))]),
    "h14": dict(as_="loop", tk=[("chk", 292.1), ("memo", 296.6), ("ls", 318.6), (("ls", 1.5), 319.0)], phases=[dict(
        at=0.0, rq="REQUESTS 18–24", sub="Check both files, then the output folder",
        stages=["qwen3.7-max", "Bash ×7 · TodoWrite", "openpyxl · docx · ls", "structure"],
        beats=[("chk", 0), (("chk", 0.6), 1), (("chk", 1.2), 2), (("chk", 1.8), 3)],
        cards=[dict(kick="OBSERVATION · step 40", role="brand", mono=True, size=12.5, at="chk", maxl=1,
                    lines=["封面与口径 · 有效样本核定", "学习保持分析 · 机会与行为", "带教辅导 · 运营对照",
                           "阶段门与金额复算 · 测验汇总", "机会行为个人汇总 · 9 sheets"]),
               dict(kick="OBSERVATION · steps 41–42", role="brand", mono=True, size=12.5, at="memo", maxl=1,
                    cols=[None, "pass", None, None, None],
                    lines=["memo: 73 paragraphs · 3 tables", "SYN-WP-A 附条件验收", "  220,320 / 24,480",
                           "SYN-WP-B 部分验收(2/4单元)", "SYN-WP-C 部分验收(1/2单元)"]),
               dict(kick="OBSERVATION · step 46", role="sandbox", mono=True, size=12.5, at="ls", maxl=1,
                    hi=[("ls", 3.0)],
                    lines=["ls -la /app/output/", "训练成效与验收决策工作簿.xlsx", "  23,842 bytes",
                           "项目验收与整改决策备忘录.docx", "  41,290 bytes"])],
        foot="steps 39–46 · the folder holds exactly the two required files")],
        pet=[("chk", "card0"), ("memo", "card1"), ("ls", "card2"), (("ls", 1.6), "output")]),
    "h15": dict(as_="loop", tk=[("fin", 325.6), ("tot", 364.9)], phases=[dict(
        at=0.0, rq="REQUEST 28 / 28", sub="Last checks, plan complete, final reply",
        stages=["qwen3.7-max", "Bash · TodoWrite", "checks", "done"],
        beats=[("fin", 0), (("fin", 0.9), 1), (("fin", 1.5), 2), ("tot", 0)],
        cards=[dict(kick="REQUESTS 25–28", role="model", at="fin",
                    lines=["SYN-HUB-04 persons in opportunities: 0", "TodoWrite: all 8 items completed", "Final reply: summary of findings"]),
               dict(kick="RUN TOTALS", title="28 requests · 44 tool calls", role="harness", at="tot", hi=[("tot", "ok")],
                    lines=["33 Bash · 4 TodoWrite · 1 Write", "2 Read · 4 Edit", "agent trace 364.9 s"]),
               dict(kick="TOOL ERRORS", title="0 of 44", role="pass", at="ok", hi=[("ok", 3.0)],
                    lines=["no result marked is_error", "every change came from", "the model's own review"])],
        foot="+364.9 s · the agent session ends here")],
        pet=[("fin", "card0"), ("tot", "card1"), ("ok", "card2")]),
}

for _s in SHOTS:
    _p = PAY.get(_s["id"])
    if _p:
        _p = dict(_p)
        if "as_" in _p:
            _p["as"] = _p.pop("as_")
        _s.update(_p)

CONF.update(
    deliverables=[("xlsx", "Decision workbook"), ("docx", "Decision memo")],
    tests_lines=["rubric · 34 criteria", "reference outputs", "judge prompt"],
    outro_q="Finance and HR tasks, judged against expert rubrics",
)

PAY2 = {
    "h01": dict(title="The setting", sub="Jichuan cold-chain operations (fictional) · supervisor training",
                pet=[(0.0, (592, 445)), ("d", (1311, 445))]),
    "h02": dict(title="The task", sub="Judge the training, then accept and pay three vendor work packages",
                pet=[(0.0, (960, 380)), ("wp", (960, 455)), ("sum", (960, 668))]),
    "h03": dict(title="The environment", sub="Harbor builds one Docker container for this run",
                files_at="kinds", out_at="out", cols=9, tw=62,
                pet=[(0.0, (700, 380)), ("kinds", (760, 450)), ("out", (900, 620))]),
    "h04": dict(title="The environment", sub="What the agent can and cannot see",
                pet=[(0.0, (900, 836)), ("lock", (1310, 692))]),
    "h06": dict(rq="REQUEST 2 / 28", sub="One response, eight tool calls", c_one="one", c_n="n", c_back="back",
                tk=[("list", 7.1), ("one", 12.5), (("n", 2.6), 16.5)],
                lanes=[dict(step=3 + j, cmd=f'head -{5 if j == 0 else 10} ../{nm}.csv', t0=t0, t1=min(16.5, t0 + 0.4))
                       for j, (nm, t0) in enumerate(zip(_CSV, _T))],
                merge="8 results go back together with request 3",
                foot="steps 3–10 · started +13.1 to +16.5 s",
                pet=[("list", (597, 432)), ("n", (1060, 630)), ("back", (1060, 702))]),
    "h12": dict(rq="REQUESTS 9–16", sub="Check, read, edit — no tool call fails",
                rows=[(223.8, "Bash", "scope check", "纳入 81 · 观察受限 2 · 排除 1", 27),
                      (227.1, "Bash", "rating distribution", "2.5–3.0: 5 · 3.0–3.5: 78 · mean 3.136", 28),
                      (244.4, "Read", "build_deliverables.py · lines 180–229", "file tool · no shell", 29),
                      (252.4, "Edit", "# Filter to authorized persons only", "updated successfully", 30),
                      (259.7, "Edit", "Domain-level retention (authorized on…", "updated successfully", 31),
                      (265.4, "Edit", "WP-A verdict · sign-off gap → 附条件验收", "updated successfully", 32),
                      (268.7, "Bash", 'grep -n "wp_a_amount"', "424: wp_a_recommended = wp_a_amount …", 33),
                      (271.8, "Read", "build_deliverables.py · lines 410–439", "file tool · no shell", 34),
                      (275.3, "Edit", "define has_signoff_gap · wp_a_amount", "updated successfully", 35)],
                pet=[("scope", (1000, 340)), ("edit", (1000, 480)), ("again", (1000, 740))]),
    "h13": dict(rq="REQUEST 17 / 28", sub="The same pipeline, run again",
                before=("first run · step 26 · +204.3 s", "WP-A: status=验收通过"),
                after=("re-run · step 38 · +282.4 s", "WP-A: status=附条件验收"),
                common=["WP-A RULE-A1 (交付率=100%) → PASS", "WP-A RULE-A2 (时长达标率>=90%): 98.8% → PASS"],
                amounts="amount=244800 · recommended=220320.0 · retained=24480.0",
                pet=[("same", (723, 480)), ("wpa", (1196, 480)), ("amt", (960, 675))]),
    "h16": dict(title="The whole run", sub="28 requests · 44 tool calls · 364.9 s",
                phases_=[(0, 66, "read & plan"), (67, 200, "write the script"), (203, 221, "run"),
                         (222, 283, "review & edit"), (287, 365, "verify")],
                marks=[(222.1, "issues named", "warn", "turn"), (282.4, "re-run", "sandbox", "turn")],
                counts=[("Bash", 33, "sandbox"), ("TodoWrite", 4, "harness"), ("Write", 1, "warn"),
                        ("Read", 2, "warn"), ("Edit", 4, "warn")],
                count_at="calls", foot="no tool result was an error · the long gap is one 19,223-token response",
                pet=[(0.0, (960, 640)), ("calls", (594, 762)), ("turn", (1050, 560))]),
    "h17": dict(title="What the model sees", sub="Prompt tokens of each of the 28 requests",
                grow_at="grow", end_at="end",
                note="Each request carries the conversation so far: the task, the model's earlier replies and every tool result.",
                foot="input + cached tokens of each request · from the Claude Code session log",
                pet=[("grow", (1484, 425)), ("end", (1484, 425))]),
    "h18": dict(sub="Harbor ends the agent phase and starts scoring",
                pet=[("stop", (712, 520)), ("tests", (1240, 640)), ("score", (1150, 806))]),
    "h19": dict(pet=[(0.0, (960, 594))]),
    "h20": dict(sub="One judge session per criterion", rk_at="rk", jm_at="jm", nf_at="nf",
                grid_note="28 positive + 6 penalty criteria · no red lines",
                judge_note="a different model from the agent · 303 judge API requests",
                pet=[("rk", (900, 600)), ("jm", (800, 716)), ("nf", (700, 796))]),
    "h21": dict(sub="R20 · status of work package A",
                pet=[("fix", (960, 412)), ("met", (960, 587))]),
    "h22": dict(sub="R14–R16 · site comparisons   R1, R19 · source index",
                pet=[("pool", (960, 413)), ("idx", (960, 680))]),
    "h23": dict(sub="R32 · a penalty criterion",
                pet=[("pen", (960, 388)), ("ten", (960, 514))]),
    "h23b": dict(sub="R32 · a penalty criterion",
                 pet=[(0.0, (960, 514)), ("why", (960, 685))]),
    "h24": dict(sub="34 criteria · each judged on its own",
                labels=[("Positive criteria · 28", "pos", "6 met · 22 not met"),
                        ("Penalties · 6", "pen", "1 triggered: R32")],
                foot="binary criteria · weights differ between criteria",
                pet=[("pos", (700, 412)), ("pen", (700, 565))]),
    "h25": dict(value="0.208", formula="(29 − 7) / 106 = 0.207547",
                line1="qwen3.7-max  +  Claude Code 2.1.114  ·  HR-T3-114",
                line2="28 model requests · 44 tool calls · 364.9 s agent run",
                line3="judge qwen3.7-plus · 34 criterion sessions",
                note="One pilot run on a fictional task — not accuracy, not a ranking.",
                note2="the penalty subtracts 7 raw weighted points before normalisation",
                pet=[("rw", (560, 600)), ("pilot", (690, 712))]),
    "h26": dict(pet=[(0.0, (560, 600)), ("site", (690, 594))]),
}

for _s in SHOTS:
    if _s["id"] in PAY2:
        _s.update(PAY2[_s["id"]])

# The HR film reuses the general loop layout for these kinds; captions are English only.
for _s in SHOTS:
    _s.setdefault("zh", "")
    if _s["kind"] in ("loop_intro", "plan", "rules", "write", "run", "notice", "verify", "finish"):
        _s.setdefault("as", "loop")


def _h07(ctx, sh, t, st):
    import gfx as G
    st["plan_reveal"] = G.seg(t, sh.cue("items") - 0.4, sh.cue("items") + 1.8)
    st["plan_hi"] = G.fade_io(t, sh.cue("tw"), sh.dur, 0.4)


def _out(name, kind="xlsx"):
    def f(ctx, sh, t, st):
        import gfx as G
        st["out_hi"] = G.ease(G.seg(t, sh.cue(name), sh.cue(name) + 0.5))
        st["out_kind"] = kind
    return f


def _found(name, label):
    def f(ctx, sh, t, st):
        import gfx as G
        st["found_hi"] = G.fade_io(t, sh.cue(name), sh.dur, 0.4)
        st["found_label"] = label
    return f


def _h15(ctx, sh, t, st):
    import gfx as G
    st["ledger_hi"] = {"req": G.fade_io(t, sh.cue("tot"), sh.dur, 0.3)}


def _h10(ctx, sh, t, st):
    _out("load")(ctx, sh, t, st)
    _found("wpa", "WP-A status")(ctx, sh, t, st)


STATE = {"h07": _h07, "h10": _h10, "h13": _found("wpa", "WP-A status"), "h14": _out("ls"),
         "h15": _h15, "h06": _found("back", "ledgers previewed"), "h12": _found("scope", "scope check")}
