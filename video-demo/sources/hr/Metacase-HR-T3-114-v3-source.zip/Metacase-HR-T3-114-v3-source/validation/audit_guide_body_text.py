"""Check settled main-body polygons against captured visible text rectangles."""
from pathlib import Path
import json
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE / "source"
sys.path[:0] = [str(ROOT / "engine"), str(ROOT)]
import compose


def overlaps(poly, rect):
    x, y, w, h = rect
    square = [(x,y), (x+w,y), (x+w,y+h), (x,y+h)]
    for vertices in (poly, square):
        for a, b in zip(vertices, vertices[1:] + vertices[:1]):
            axis = (a[1]-b[1], b[0]-a[0])
            p = [v[0]*axis[0] + v[1]*axis[1] for v in poly]
            q = [v[0]*axis[0] + v[1]*axis[1] for v in square]
            if max(p) <= min(q) or max(q) <= min(p):
                return False
    return True


ctx = compose.Ctx("fin")
settled = json.loads((BASE / "guide-text-audit.json").read_text(encoding="utf-8"))
report = []
for record in settled:
    state = ctx.guide.state(record["at"])
    poly = list(state["geometry"]["body_polygon"])
    hits = [text for text in record["texts"]
            if text["alpha"] >= .15 and not text.get("decorative")
            and overlaps(poly, text["rect"])]
    report.append(dict(shot=record["shot"], cue=record["cue"], at=record["at"],
                       local=record["local"], body_polygon=poly, hits=hits))
    if hits:
        print(record["shot"], record["cue"], record["local"], hits)
out = BASE / "guide-body-text-audit.json"
out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"{sum(bool(row['hits']) for row in report)}/{len(report)} settled main-body/text intersections; {out}")
