"""Record 465 transition samples and check visible baton/text intersections.

This uses one Skia PictureRecorder at a time, not raster surfaces, so the audit
does not compete with the final renderer for raster/encoding work.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import time

ARTIFACT_ROOT = Path(__file__).resolve().parent
ROOT = ARTIFACT_ROOT / "source"
sys.path[:0] = [str(ROOT / "engine"), str(ROOT)]
import compose
import gfx as G
import skia


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def crossing(a, b, rect, padding=3):
    x, y, w, h = rect
    lo, hi = 0.0, 1.0
    for pos, delta, low, high in ((a[0], b[0]-a[0], x-padding, x+w+padding),
                                   (a[1], b[1]-a[1], y-padding, y+h+padding)):
        if abs(delta) < 1e-9:
            if not low <= pos <= high:
                return None
        else:
            p, q = sorted(((low-pos)/delta, (high-pos)/delta))
            lo, hi = max(lo,p), min(hi,q)
            if lo > hi:
                return None
    return lo, hi


def inside(pt, box):
    return bool(box and box[0] <= pt[0] <= box[0]+box[2]
                and box[1] <= pt[1] <= box[1]+box[3])


def overlaps(poly, rect):
    x, y, w, h = rect
    square = [(x,y), (x+w,y), (x+w,y+h), (x,y+h)]
    for vertices in (poly, square):
        for a, b in zip(vertices, vertices[1:] + vertices[:1]):
            axis = (a[1]-b[1], b[0]-a[0])
            p = [v[0]*axis[0] + v[1]*axis[1] for v in poly]
            q = [v[0]*axis[0] + v[1]*axis[1] for v in square]
            if max(p) <= min(q) or max(q) <= min(p):
                return False
    return True


tracked = [ROOT / "engine" / name for name in
           ("guide.py", "guide_targets.py", "reference_pet.py", "scenes.py", "scenes_x.py",
            "compose.py", "panels.py", "reference_bookends.py")]
before = {str(p.relative_to(ROOT)):sha(p) for p in tracked}
ctx = compose.Ctx("fin")
original_text = G.text
texts = []


def capture_text(cv, s, x, y, *args, **kw):
    caller = sys._getframe(1).f_code
    decorative = (Path(caller.co_filename).name == "reference_bookends.py"
                  and caller.co_name == "draw_open" and x == 0)
    result = original_text(cv, s, x, y, *args, **kw)
    alpha = kw.get("a", 1.0)
    if not s or alpha < .05:
        return result
    size = args[0] if args else kw.get("size", 18)
    align, width = kw.get("align", "left"), kw.get("width")
    p = G._para(s, size, tuple(kw.get("c", G.FG)[:3]),
                kw.get("weight", 500), kw.get("kind", "sans"),
                width if width is not None else 4000.0,
                "left" if width is None else align,
                kw.get("ls", 0.0), kw.get("lh"), kw.get("maxlines"))
    w, h = float(p.LongestLine), float(result[1])
    if width is None:
        x -= w / 2 if align == "center" else w if align == "right" else 0
    else:
        x += (width-w) / 2 if align == "center" else width-w if align == "right" else 0
    bounds = cv.getTotalMatrix().mapRect(skia.Rect.MakeXYWH(x,y,w,h))
    texts.append(dict(text=s, rect=(bounds.left(),bounds.top(),bounds.width(),bounds.height()),
                      alpha=alpha, decorative=decorative))
    return result


G.text = capture_text
start = time.monotonic()
report = []
for i, event in enumerate(ctx.guide.events):
    for fraction in (.1, .3, .5, .7, .9):
        T = event["time"] + event["duration"] * fraction
        texts.clear()
        recorder = skia.PictureRecorder()
        cv = recorder.beginRecording(skia.Rect.MakeWH(G.W,G.H))
        compose.frame(cv, ctx, T)
        picture = recorder.finishRecordingAsPicture()
        state = ctx.guide.state(T)
        a, b = state["geometry"]["hand"], state["tip"]
        focus, prior_focus = state["descriptor"]["box"], event["prior"]["box"]
        effective_alpha = state["pointer_opacity"]
        hits, prior_hits = [], []
        raw_body_hits = [text for text in texts if text["alpha"] >= .15
                     and state["opacity"] >= .15
                     and overlaps(list(state["geometry"]["body_polygon"]), text["rect"])]
        body_hits = [text for text in raw_body_hits if not text["decorative"]]
        decoration_hits = [text for text in raw_body_hits if text["decorative"]]
        if effective_alpha > .05:
            for text in texts:
                if text["decorative"]:
                    continue
                interval = crossing(a,b,text["rect"])
                if interval is None:
                    continue
                p, q = interval
                centre = (a[0]+(b[0]-a[0])*(p+q)/2, a[1]+(b[1]-a[1])*(p+q)/2)
                if inside(centre,focus):
                    continue
                found = dict(text, pointer_alpha=effective_alpha, crossing=centre)
                if inside(centre,prior_focus):
                    prior_hits.append(found)
                else:
                    hits.append(found)
        local = T-next(s.start for s in ctx.tl.shots if s.id==event["shot"])
        record = dict(index=i, shot=event["shot"], cue=event["target"], u=fraction,
                      at=T, local=local, duration=event["duration"],
                      id=state["descriptor"]["id"], hand=a, tip=b,
                      pointer_alpha=effective_alpha, box=focus, prior_box=prior_focus,
                      prior_id=event["prior"]["id"], turning=event.get("turning"),
                      direct_edge=event.get("direct_edge"), text_count=len(texts),
                      hits=hits, prior_target_hits=prior_hits, body_text_hits=body_hits,
                      body_decoration_hits=decoration_hits)
        report.append(record)
        if hits:
            print(f"{event['shot']} {event['target']} u={fraction:.1f} local={local:.3f}"
                  f" alpha={effective_alpha:.2f} HITS {len(hits)}",flush=True)
            for hit in hits:
                print(" ", tuple(round(v,1) for v in hit["rect"]),hit["text"],flush=True)
        if body_hits:
            print(f"{event['shot']} {event['target']} u={fraction:.1f} local={local:.3f}"
                  f" BODY/TEXT {len(body_hits)}",flush=True)
            for hit in body_hits:
                print(" ", tuple(round(v,1) for v in hit["rect"]),hit["text"],flush=True)
        del picture, recorder
after = {str(p.relative_to(ROOT)):sha(p) for p in tracked}
summary = dict(samples=len(report), events=len(ctx.guide.events),
               samples_with_hits=sum(bool(r["hits"]) for r in report),
               hit_count=sum(len(r["hits"]) for r in report),
               body_text_samples_with_hits=sum(bool(r["body_text_hits"]) for r in report),
               body_decoration_hit_count=sum(len(r["body_decoration_hits"]) for r in report),
               strong_samples_with_hits=sum(any(h["alpha"]>=.15 and h["pointer_alpha"]>=.15
                                                for h in r["hits"]) for r in report),
               changed_sources=[p for p in before if before[p] != after[p]],
               elapsed_seconds=round(time.monotonic()-start,3),
               source_sha256=before,
               recording="Skia PictureRecorder; one process; no raster output",
               decoration_policy="Reference opening particle words are decorative; collisions retained separately, not narrative-text failures",
               fractions=[.1,.3,.5,.7,.9])
path = ARTIFACT_ROOT / "guide-dynamic-text-audit.json"
path.write_text(json.dumps(dict(summary=summary,samples=report),ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(summary,ensure_ascii=False),flush=True)
print(path,flush=True)
