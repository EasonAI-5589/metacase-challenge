# Validation evidence

These files record the checks performed during production of the finance guide
alignment. They are retained as review evidence with their original bytes.

- `render-input-snapshot.json`: inputs recorded when the full render began.
  The finalizer checks every entry in its `files` mapping against the source.
  The manifest explicitly records any change to the post-render packaging CLI;
  it is not imported by the renderer. All frame, audio and data inputs must match.
- `source-verification.json`: verification of the originally supplied source.
- `build/fin/fin.render-receipt.json` records current input hashes, settings,
  output hash and native bounded-segment resumption. No v1 recovery script is used.
- `render-profile-30.json` / `background-cache-validation.json`: representative
  frame profiling and raw-pixel equality checks for static background caching.
- `encoded-video-qa.json`: full audio/video decode, stream checks, audio signal
  levels and locations of encoded keyframes selected for visual inspection.
- `audit_guide_text.py` / `guide-text-audit.json`: static text-layout review.
- `audit_guide_dynamic_text.py` / `guide-dynamic-text-audit.json`: sampled dynamic
  text-layout review. Consult the report for its actual sample scope.
- `packaged-provenance.json`: provenance generated for the finished video.
- `packaged-font-selection.json`: font selection with portable logical paths.

The two audit scripts were authored in the production artifact folder, next to
a `source/` directory. Their original path assumptions are preserved. Merely
placing them in this `validation/` directory does not make them runnable against
the extracted source root; recreate the original parent/source layout or review
the path configuration before reusing them. They are not advertised as
one-command post-extraction tests.

For the supported portable geometry check, run `engine/check_guide.py` from the
source root. Its current report is in `build/fin/guide-geometry-qa.json`.
