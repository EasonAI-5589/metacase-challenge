"""Decode the finished audio/video and retain representative encoded frames."""
from pathlib import Path
import json
import os
import re
import subprocess

ROOT = Path(__file__).resolve().parent
VIDEO = ROOT / "source/build/fin/fin.mp4"
FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
FFPROBE = os.environ.get("FFPROBE", "ffprobe")


def run(command):
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode:
        raise RuntimeError(result.stderr)
    return result


def main():
    info = json.loads(run([FFPROBE, "-v", "error", "-show_streams", "-show_format",
                           "-of", "json", str(VIDEO)]).stdout)
    video = next(s for s in info["streams"] if s["codec_type"] == "video")
    audio = next(s for s in info["streams"] if s["codec_type"] == "audio")
    assert (video["width"], video["height"], video["r_frame_rate"], int(video["nb_frames"])) == (1920, 1080, "30/1", 8846)
    assert audio["sample_rate"] == "48000" and audio["channels"] == 1
    assert abs(float(audio["duration"]) - 8846 / 30) < .05
    frames = [0, 20, 30, 1500, 3825, 4791, 5099, 6426, 7350, 8380,
              8610, 8640, 8704, 8836, 8845]
    folder = ROOT / "encoded-review"
    folder.mkdir(exist_ok=True)
    select = "+".join(f"eq(n,{n})" for n in frames)
    decoded = run([
        FFMPEG, "-hide_banner", "-v", "info", "-xerror", "-y", "-threads", "2",
        "-filter_threads", "1", "-i", str(VIDEO),
        "-map", "0:v", "-vf", f"select='{select}'", "-fps_mode", "vfr",
        "-threads", "1", str(folder / "frame-%02d.png"),
        "-map", "0:a", "-af", "volumedetect", "-f", "null", os.devnull])
    mean = float(re.search(r"mean_volume:\s*([-\d.]+) dB", decoded.stderr).group(1))
    peak = float(re.search(r"max_volume:\s*([-\d.]+) dB", decoded.stderr).group(1))
    assert mean > -40 and -20 < peak <= 0, (mean, peak)
    outputs = sorted(folder.glob("frame-*.png"))
    assert len(outputs) == len(frames)
    (folder / "decode.log").write_text(decoded.stderr, encoding="utf-8")
    result = {"passed": True, "full_audio_video_decode": True,
              "frames": 8846, "duration_seconds": float(info["format"]["duration"]),
              "resolution": [1920, 1080], "fps": "30/1",
              "audio": {"codec": audio["codec_name"], "sample_rate": 48000,
                        "channels": 1, "mean_db": mean, "peak_db": peak},
              "encoded_keyframes": [
                  {"frame": n, "seconds": n / 30, "file": p.relative_to(ROOT).as_posix()}
                  for n, p in zip(frames, outputs)]}
    (ROOT / "encoded-video-qa.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
