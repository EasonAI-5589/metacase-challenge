"""Render one settled instant per FIN guide cue and audit text intersections."""
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent / "source"
sys.path[:0] = [str(ROOT / "engine"), str(ROOT)]
import compose
import gfx as G
import skia


def crossing(a, b, rect, padding=3):
    x, y, w, h = rect
    lo, hi = 0.0, 1.0
    for pos, delta, low, high in ((a[0], b[0]-a[0], x-padding, x+w+padding),
                                   (a[1], b[1]-a[1], y-padding, y+h+padding)):
        if abs(delta) < 1e-9:
            if not low <= pos <= high:
                return None
        else:
            p, q = sorted(((low-pos)/delta, (high-pos)/delta))
            lo, hi = max(lo,p), min(hi,q)
            if lo > hi:
                return None
    return (lo, hi)


def inside(pt, box):
    return bool(box and box[0] <= pt[0] <= box[0]+box[2]
                and box[1] <= pt[1] <= box[1]+box[3])


ctx = compose.Ctx("fin")
original_text = G.text
texts = []


def capture_text(cv, s, x, y, *args, **kw):
    caller = sys._getframe(1).f_code
    decorative = (Path(caller.co_filename).name == "reference_bookends.py"
                  and caller.co_name == "draw_open" and x == 0)
    result = original_text(cv, s, x, y, *args, **kw)
    if not s or kw.get("a", 1.0) < .05:
        return result
    size = args[0] if args else kw.get("size", 18)
    align, width = kw.get("align", "left"), kw.get("width")
    p = G._para(s, size, tuple(kw.get("c", G.FG)[:3]),
                kw.get("weight", 500), kw.get("kind", "sans"),
                width if width is not None else 4000.0,
                "left" if width is None else align,
                kw.get("ls", 0.0), kw.get("lh"), kw.get("maxlines"))
    # LongestLine bounds visible glyph runs more tightly than the layout width
    # returned by text() for a maxlines=1 paragraph.
    w, h = float(p.LongestLine), float(result[1])
    if width is None:
        x -= w / 2 if align == "center" else w if align == "right" else 0
    else:
        x += (width-w) / 2 if align == "center" else width-w if align == "right" else 0
    bounds = cv.getTotalMatrix().mapRect(skia.Rect.MakeXYWH(x,y,w,h))
    texts.append(dict(text=s, rect=(bounds.left(),bounds.top(),bounds.width(),bounds.height()),
                      alpha=kw.get("a",1), decorative=decorative))
    return result


G.text = capture_text
report = []
for i, event in enumerate(ctx.guide.events):
    arrival = event["time"] + event["duration"]
    until = min(event["end"],
                ctx.guide.events[i+1]["time"] if i+1<len(ctx.guide.events) else event["end"])
    T = max(arrival + .001, until - min(.16, max(.01,(until-arrival)*.35)))
    T = min(T, until-.001)
    texts.clear()
    recorder = skia.PictureRecorder()
    cv = recorder.beginRecording(skia.Rect.MakeWH(G.W,G.H))
    compose.frame(cv, ctx, T)
    picture = recorder.finishRecordingAsPicture()
    state = ctx.guide.state(T)
    a, b = state["geometry"]["hand"], state["tip"]
    focus = state["descriptor"]["box"]
    hits = []
    if state["pointer_opacity"] > .05:
        for text in texts:
            if text["decorative"]:
                continue
            interval = crossing(a,b,text["rect"])
            if interval is None:
                continue
            p, q = interval
            centre = (a[0]+(b[0]-a[0])*(p+q)/2, a[1]+(b[1]-a[1])*(p+q)/2)
            if inside(centre,focus):
                continue
            hits.append(text)
    record = dict(index=i,shot=event["shot"],cue=event["target"],
                  at=round(T,3),local=round(T-next(s.start for s in ctx.tl.shots if s.id==event["shot"]),3),
                  id=state["descriptor"]["id"],hand=a,tip=b,focus=focus,
                  descriptor=state["descriptor"],hits=hits,texts=list(texts))
    report.append(record)
    del picture, recorder
    if hits:
        print(event["shot"],event["target"],"at",record["local"],"HITS",len(hits))
        for hit in hits:
            print(" ", tuple(round(v,1) for v in hit["rect"]),hit["text"])
path = Path(__file__).resolve().parent / "guide-text-audit.json"
path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
print(f"{sum(bool(r['hits']) for r in report)}/{len(report)} settled cues intersect visible non-target text; {path}")
