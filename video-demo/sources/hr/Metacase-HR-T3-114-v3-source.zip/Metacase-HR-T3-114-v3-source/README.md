# InferenceNet 第二个视频源码：Finance FIN-T1-003

本包来自 `research/sufe-video-claude-relay-20261018/`，对应 34 镜头的 Finance 接力版。网站仓只保存成片和说明，原制作工程在本机研究目录。

## 文件与编辑入口

- `story/fin.py`：分镜、英文旁白、中文字幕、逐词提示点和画面数据。
- `engine/`：Skia 绘制、时间轴、渲染、配音与打包源码。
- `data/fin.json`：原制作工程使用的运行导出。
- `data/fin.requests.jsonl`：只保留基准时间、assistant message ID、usage、tool 名称的派生元数据；不含原始聊天文字、工具输入或凭据。
- `build/fin/voice/` 与 `voice.json`：34 段现成配音和词级时间，便于复用配音。
- `fonts/`：Inter 字体及 OFL 许可；没有复制 macOS 系统字体。
- `original-source/`：未修改的原始源码快照。原网站接入脚本仅留作参考，不作为本包的执行步骤。
- `PORTABILITY.patch`：交接副本的路径变更；原制作工程没有改动。

## 环境

原工程按 macOS 排版，依赖 SF Mono/Menlo、PingFang SC、Apple Symbols、Georgia。Linux/Windows 需先适配 `engine/fonts.py`；本包不承诺这些平台直接运行或同样排版。

安装 Python 依赖后即可使用缓存进行离线渲染。FFmpeg 与 ffprobe 需位于 PATH，FFmpeg 需支持 libx264、AAC 和 loudnorm。没有打包 Python 环境、安装包或 FFmpeg。

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

以下命令均从本包根目录运行：

```bash
# 单帧检查
.venv/bin/python engine/compose.py fin f00:1.0

# 使用现有配音缓存重建视频，无需先运行 voice.py
.venv/bin/python engine/render.py fin --workers 4
.venv/bin/python engine/package.py fin
```

渲染产物在 `build/fin/fin.mp4`，网站可用成品在 `deliver/`。本包没有附重复的成片或中间视频片段。

修改英文旁白后，如需重新生成配音：

```bash
.venv/bin/python engine/voice.py fin
```

`voice.py` 缓存未命中时会通过 edge-tts 将旁白发送给微软在线 TTS 服务；它不是离线命令。修改旁白后再渲染前应先更新配音和时间轴。

本包只包含 Finance 的运行数据与配音，不包含 HR 的运行依赖。不需要启动模型、重跑 benchmark 或重新评分。
