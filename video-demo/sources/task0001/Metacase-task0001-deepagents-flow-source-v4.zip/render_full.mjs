// Deterministic export of the local, generated video artifact. No user browser profile is used.
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {existsSync,mkdirSync,mkdtempSync,readFileSync,writeFileSync,renameSync,rmSync,openSync,closeSync,unlinkSync,realpathSync} from 'node:fs';
import {join,dirname,resolve,sep} from 'node:path';
import {fileURLToPath} from 'node:url';

const ROOT=dirname(fileURLToPath(import.meta.url));
const CHROME=process.env.CHROME || 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const URL=process.env.RENDER_URL || 'http://127.0.0.1:18791/site/index.html?pause&capture';
const args=process.argv.slice(2);
const value=name=>{const i=args.indexOf(name);return i<0?undefined:args[i+1];};
const stills=args.includes('--stills'),probe=args.includes('--probe'),resume=args.includes('--resume'),exportSvg=args.includes('--export-svg');
const partText=value('--part')||'1/1';
const partMatch=/^(\d+)\/(\d+)$/.exec(partText);
if(!partMatch)throw new Error('--part must be 1-based i/n, for example 1/3');
const part=Number(partMatch[1]),parts=Number(partMatch[2]);
if(part<1||part>parts||parts>16)throw new Error('Invalid part range');
if(stills&&parts!==1)throw new Error('Stills use one browser, without --part');
const manifestPath=resolve(ROOT,value('--manifest')||(stills?(exportSvg?'render-svg-stills-manifest.json':'render-stills-manifest.json'):'render-manifest.json'));
const manifest=probe?null:JSON.parse(readFileSync(manifestPath,'utf8'));
const timeline=JSON.parse(readFileSync(join(ROOT,'site','timeline.json'),'utf8'));
const expectedMs=Number(timeline.total_ms??Number(timeline.duration)*1000);
if(!Number.isFinite(expectedMs)||expectedMs<=0)throw new Error('timeline.json must contain positive total_ms or duration');
if(timeline.total_ms!=null&&timeline.duration!=null&&Math.abs(timeline.total_ms-timeline.duration*1000)>.5)throw new Error('Timeline total_ms and duration disagree');
if(timeline.fps!=null&&Number(timeline.fps)!==30)throw new Error('This export requires a 30 fps timeline');
const FPS=30,totalFrames=Math.ceil(expectedMs*FPS/1000);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
function verifySources(){
  if(!manifest)return;
  if(manifest.total_ms!==expectedMs||manifest.fps!==FPS||manifest.total_frames!==totalFrames||manifest.width!==1920||manifest.height!==1080||manifest.jpeg_quality!==92||manifest.url!==URL||manifest.engine!==(exportSvg?'svg-canvas':'cdp-screenshot'))throw new Error('Render manifest parameters do not match this renderer/timeline');
  for(const item of manifest.sources){
    const path=resolve(ROOT,item.path),allowed=resolve(ROOT,'site')+sep;
    if(!path.toLowerCase().startsWith(allowed.toLowerCase()))throw new Error('Source manifest contains a path outside site/');
    const bytes=readFileSync(path);
    if(bytes.length!==item.bytes||sha(bytes)!==item.sha256)throw new Error(`Source changed since manifest creation: ${item.path}`);
  }
}
function jpegSize(bytes){
  if(bytes[0]!==255||bytes[1]!==216||bytes.at(-2)!==255||bytes.at(-1)!==217)throw new Error('Incomplete JPEG');
  for(let pos=2;pos<bytes.length-9;){
    if(bytes[pos++]!==255)throw new Error('Invalid JPEG marker');
    while(bytes[pos]===255)pos++;
    const marker=bytes[pos++];
    if(marker===0xD9||marker===0xDA)break;
    if(marker===0x01||(marker>=0xD0&&marker<=0xD7))continue;
    const len=bytes.readUInt16BE(pos);
    if(len<2||pos+len>bytes.length)throw new Error('Invalid JPEG segment');
    if([0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF].includes(marker))return {width:bytes.readUInt16BE(pos+5),height:bytes.readUInt16BE(pos+3)};
    pos+=len;
  }
  throw new Error('JPEG frame dimensions not found');
}
function verifyImage(bytes,png=false){
  const size=png?{width:bytes.readUInt32BE(16),height:bytes.readUInt32BE(20)}:jpegSize(bytes);
  if(size.width!==1920||size.height!==1080)throw new Error(`Expected 1920x1080 image, got ${size.width}x${size.height}`);
  return size;
}
function atomicJson(path,data){const tmp=path+`.${process.pid}.tmp`;writeFileSync(tmp,JSON.stringify(data,null,2)+'\n');renameSync(tmp,path);}
function stillTimes(){
  const times=new Set();
  const add=sec=>{if(Number.isFinite(sec))times.add(Math.round(Math.max(0,Math.min(expectedMs-1,sec*1000))));};
  for(const shot of timeline.shots||[]){
    const a=Number(shot.start),b=Number(shot.end);
    if(!Number.isFinite(a)||!Number.isFinite(b)||b<=a)throw new Error('Every timeline shot needs valid start/end seconds');
    add(Math.min(b-.1,Math.max(a+.1,Number(shot.audio_start??a)+1.8)));
    if(['type','output','score'].includes(shot.old_kind))add(b-.7);
    if(a>.1){add(a-.15);add(a+.15);}
  }
  if(!times.size)throw new Error('No timeline shots available for stills');
  return [...times].sort((a,b)=>a-b);
}
// Runs inside only the local artifact page. All assets are embedded before image decoding;
// each frame is cloned synchronously, so concurrent rasterization cannot see later seeks.
async function installSvgExporter(){
  const encode=bytes=>{let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return btoa(binary);};
  const assets=new Map();
  const inline=async url=>{
    if(/^(data:|#)/i.test(url))return url;
    const resolved=new URL(url,document.baseURI);
    if(resolved.origin!==location.origin)throw new Error(`SVG export refuses nonlocal asset: ${resolved.origin}`);
    if(!assets.has(resolved.href))assets.set(resolved.href,(async()=>{
      const response=await fetch(resolved.href);if(!response.ok)throw new Error(`Asset HTTP ${response.status}: ${resolved.pathname}`);
      const bytes=new Uint8Array(await response.arrayBuffer());
      const mime=resolved.pathname.endsWith('.woff2')?'font/woff2':response.headers.get('Content-Type')||'application/octet-stream';
      return `data:${mime};base64,${encode(bytes)}`;
    })());
    return assets.get(resolved.href);
  };
  let css='';
  for(const element of document.querySelectorAll('style,link[rel="stylesheet"]')){
    const base=element.tagName==='LINK'?element.href:document.baseURI;
    let source;
    if(element.tagName==='LINK'){
      const response=await fetch(element.href);if(!response.ok)throw new Error(`Stylesheet HTTP ${response.status}`);source=await response.text();
    }else source=element.textContent;
    const references=[...source.matchAll(/url\(\s*(['"]?)(.*?)\1\s*\)/g)];
    for(const reference of references){
      const target=reference[2].trim();
      if(!target||target.startsWith('#')||target.startsWith('data:'))continue;
      const data=await inline(new URL(target,base).href);source=source.replace(reference[0],`url("${data}")`);
    }
    if(/@import\b/i.test(source))throw new Error('SVG exporter requires stylesheets without unresolved @import');
    css+=source+'\n';
  }
  const imageAssets=new Map();
  for(const img of document.querySelectorAll('#stage img'))imageAssets.set(img.src,await inline(img.src));
  if(document.querySelector('#stage canvas,#stage video,#stage iframe'))throw new Error('SVG exporter cannot safely clone live canvas/video/iframe content; use CDP');
  const snapshot=async ms=>{
    await window.replay.seek(ms);
    const stage=document.getElementById('stage');if(!stage)throw new Error('SVG exporter needs #stage');
    const clone=stage.cloneNode(true);
    for(const node of clone.querySelectorAll('[data-preload]'))node.remove(); // v4: hidden sprite preloads are inlined once, not per frame
    Object.assign(clone.style,{transform:'none',left:'0px',top:'0px',margin:'0px',width:'1280px',height:'720px'});
    for(const image of clone.querySelectorAll('img')){const embedded=imageAssets.get(image.src);if(embedded)image.src=embedded;image.removeAttribute('srcset');}
    for(const script of clone.querySelectorAll('script'))script.remove();
    const wrapper=document.createElementNS('http://www.w3.org/1999/xhtml','div');
    wrapper.setAttribute('style','position:relative;width:1280px;height:720px;overflow:hidden;');
    const style=document.createElementNS('http://www.w3.org/1999/xhtml','style');style.textContent=css;
    wrapper.append(style,clone);
    return `<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720"><foreignObject x="0" y="0" width="1280" height="720">${new XMLSerializer().serializeToString(wrapper)}</foreignObject></svg>`;
  };
  const rasterize=async(svg,png)=>{
    const image=new Image();image.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);await image.decode();
    const canvas=document.createElement('canvas');canvas.width=1920;canvas.height=1080;
    const ctx=canvas.getContext('2d',{alpha:false});ctx.fillStyle='#10151c';ctx.fillRect(0,0,1920,1080);ctx.scale(1.5,1.5);ctx.drawImage(image,0,0);
    const blob=await new Promise((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error('Canvas encoding failed')),png?'image/png':'image/jpeg',.92));
    const bytes=new Uint8Array(await blob.arrayBuffer());canvas.width=canvas.height=1;return encode(bytes);
  };
  window.__artifactSvgBatch=async(times,png=false)=>{
    const images=[];
    for(const time of times){const svg=await snapshot(time);images.push(rasterize(svg,png));}
    return Promise.all(images);
  };
  return {stylesBytes:css.length,embeddedAssets:assets.size};
}
verifySources();
const startFrame=Math.floor(totalFrames*(part-1)/parts),endFrame=Math.floor(totalFrames*part/parts);
const out=join(ROOT,stills?(exportSvg?'stills-svg':'stills'):'frames');
if(!probe)mkdirSync(out,{recursive:true});
const reportPath=join(ROOT,stills?(exportSvg?'render-svg-qa.json':'render-qa.json'):`render-part-${part}.json`);
const lockPath=join(ROOT,stills?'.render-stills.lock':`.render-part-${part}.lock`);
let lock;
if(!probe){
  lock=openSync(lockPath,'wx');
  writeFileSync(lock,JSON.stringify({pid:process.pid,part,parts,manifest:manifest.fingerprint,started:new Date().toISOString()}));
}
const profiles=join(ROOT,'.render-profiles');mkdirSync(profiles,{recursive:true});
const profile=mkdtempSync(join(profiles,`full-${probe?'probe':stills?'stills':part}-`));
const chrome=spawn(CHROME,['--headless=new','--remote-debugging-port=0',`--user-data-dir=${profile}`,'--no-first-run','--no-default-browser-check','--hide-scrollbars','--mute-audio','--disable-background-timer-throttling','--disable-renderer-backgrounding','--window-size=1280,720','about:blank'],{stdio:'ignore',windowsHide:true});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let spawnError,ws,send,stopped=false,sourceVersion,rendered=0,skipped=0;
chrome.on('error',error=>{spawnError=error;});
process.on('SIGINT',()=>{stopped=true;});process.on('SIGTERM',()=>{stopped=true;});
const errors=[],checks=[],started=Date.now();
try{
  let port;
  for(let n=0;n<200;n++){
    if(spawnError)throw spawnError;
    if(chrome.exitCode!==null)throw new Error(`Headless Chrome exited before startup: ${chrome.exitCode}`);
    if(stopped)throw new Error('Export interrupted');
    const active=join(profile,'DevToolsActivePort');
    if(existsSync(active)){port=readFileSync(active,'utf8').split('\n')[0].trim();break;}
    await sleep(100);
  }
  if(!port)throw new Error('Headless browser did not start within 20 seconds');
  const response=await fetch(`http://127.0.0.1:${port}/json/new?about:blank`,{method:'PUT',signal:AbortSignal.timeout(10000)});
  if(!response.ok)throw new Error(`CDP target HTTP ${response.status}`);
  const target=await response.json();ws=new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('CDP connection timeout')),10000);ws.onopen=()=>{clearTimeout(timer);resolve();};ws.onerror=e=>{clearTimeout(timer);reject(new Error(e.message||'CDP connection failed'));};});
  let seq=0;const pending=new Map();
  ws.onmessage=e=>{
    const m=JSON.parse(e.data);
    if(m.id&&pending.has(m.id)){const p=pending.get(m.id);pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(new Error(m.error.message)):p.resolve(m.result);}
    else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);
  };
  ws.onclose=()=>{for(const p of pending.values()){clearTimeout(p.timer);p.reject(new Error('CDP connection closed'));}pending.clear();};
  send=(method,params={},timeout=45000)=>new Promise((resolve,reject)=>{const id=++seq;const timer=setTimeout(()=>{pending.delete(id);reject(new Error(`${method} timed out`));},timeout);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});
  const evaluate=async(expression,timeout=45000)=>{const r=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true},timeout);if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
  await send('Page.enable');await send('Runtime.enable');
  await send('Emulation.setDeviceMetricsOverride',{width:1280,height:720,deviceScaleFactor:1.5,mobile:false});
  // A new target can still be committing its initial about:blank navigation. In
  // parallel Chrome startup that may abort the first Page.navigate. Poll the actual
  // document/replay readiness, rather than leaving an unobserved load-event promise.
  let meta,lastNavigationError;
  const navigationAttempts=[];
  await sleep(200);
  for(let attempt=1;attempt<=3&&!meta;attempt++){
    if(stopped)throw new Error('Export interrupted before navigation');
    let navigationError;
    try{
      await send('Page.stopLoading',{},5000);
      if(attempt>1)await sleep(attempt*350);
      const navigation=await send('Page.navigate',{url:URL},20000);
      navigationError=navigation.errorText;
    }catch(error){navigationError=String(error.message||error);}
    // An ERR_ABORTED response can race with a successful commit; check for that
    // document briefly before retrying. Otherwise allow a normal local load 20 s.
    const deadline=Date.now()+(navigationError?2500:20000);
    let state;
    while(Date.now()<deadline&&!stopped){
      try{
        state=await evaluate(`({url:location.href,ready:document.readyState,replay:typeof window.replay?.seek==='function',total:window.replay?.total,sourceVersion:window.replay?.sourceVersion,title:document.title,fonts:document.fonts.status})`,5000);
        if(state.url===URL&&state.ready==='complete'&&state.replay&&state.fonts==='loaded'){
          meta={...state,seek:'function'};break;
        }
      }catch(error){lastNavigationError=String(error.message||error);}
      await sleep(150);
    }
    navigationAttempts.push({attempt,error:navigationError||null,lastState:state||null,ready:Boolean(meta)});
    if(!meta){
      lastNavigationError=navigationError||lastNavigationError||'Document/replay/fonts readiness timeout';
      console.warn(JSON.stringify({part,navigationAttempt:attempt,error:lastNavigationError,lastState:state}));
    }
  }
  if(!meta)throw new Error(`Local artifact navigation failed after 3 attempts: ${JSON.stringify(navigationAttempts)}; last error: ${lastNavigationError}`);
  if(navigationAttempts.length>1)console.log(JSON.stringify({part,navigationRecovered:true,attempts:navigationAttempts.length}));
  if(meta.seek!=='function'||!Number.isFinite(meta.total)||Math.abs(meta.total-expectedMs)>.5)throw new Error(`HTML replay duration/API does not match timeline: ${JSON.stringify(meta)}; expected ${expectedMs} ms`);
  if(!meta.sourceVersion)throw new Error('window.replay.sourceVersion is required');
  sourceVersion=meta.sourceVersion;
  if(exportSvg&&!probe)console.log(JSON.stringify({part,svgReady:await evaluate(`(${installSvgExporter.toString()})()`)}));
  if(probe){console.log(JSON.stringify({...meta,totalFrames,fps:FPS,width:1920,height:1080}));}
  else{
    const times=stills?stillTimes():Array.from({length:endFrame-startFrame},(_,i)=>(startFrame+i)*1000/FPS);
    for(let i=0;i<times.length;i++){
      if(stopped)throw new Error('Export interrupted');
      if(errors.length)throw new Error('Page raised a JavaScript exception');
      const t=times[i],index=startFrame+i;
      const name=stills?`shot-${String(t).padStart(7,'0')}.png`:`frame_${String(index).padStart(5,'0')}.jpg`;
      const path=join(out,name);
      if(exportSvg&&!stills){
        const batchEnd=Math.min(times.length,i+6),jobs=[];
        for(let cursor=i;cursor<batchEnd;cursor++){
          const frameIndex=startFrame+cursor,file=join(out,`frame_${String(frameIndex).padStart(5,'0')}.jpg`);
          if(existsSync(file)){
            if(!resume)throw new Error(`Existing output requires explicit --resume: ${file}`);
            verifyImage(readFileSync(file));skipped++;
          }else jobs.push({file,time:times[cursor]});
        }
        if(jobs.length){
          const images=await evaluate(`window.__artifactSvgBatch(${JSON.stringify(jobs.map(job=>job.time))})`);
          if(images.length!==jobs.length)throw new Error('SVG batch returned an unexpected frame count');
          images.forEach((base64,j)=>{const bytes=Buffer.from(base64,'base64');verifyImage(bytes);const temp=jobs[j].file+`.${process.pid}.tmp`;writeFileSync(temp,bytes);renameSync(temp,jobs[j].file);rendered++;});
        }
        if(i===0||batchEnd%120===0||batchEnd===times.length)console.log(JSON.stringify({part,parts,engine:'svg-canvas',done:batchEnd,assigned:times.length,rendered,skipped,secondsElapsed:Math.round((Date.now()-started)/1000)}));
        i=batchEnd-1;continue;
      }
      if(existsSync(path)){
        if(!resume)throw new Error(`Existing output requires explicit --resume and unchanged manifest: ${name}`);
        verifyImage(readFileSync(path),stills);skipped++;
        // Stills still seek for fresh QA; video resumes skip deterministic verified frames entirely.
        if(!stills)continue;
      }
      await evaluate(`Promise.resolve(window.replay.seek(${t})).then(()=>new Promise(resolve=>requestAnimationFrame(resolve)))`);
      if(stills){
        checks.push(await evaluate(`(()=>{const qa=typeof window.replay.qa==='function'?window.replay.qa():window.replay.qa??window.QA??null;const guide=window.guideTour?.last??null;return JSON.parse(JSON.stringify({time:${t},sourceVersion:window.replay.sourceVersion,qa,guide}));})()`));
      }
      if(!existsSync(path)){
        let base64;
        if(exportSvg)base64=(await evaluate(`window.__artifactSvgBatch([${t}],true)`))[0];
        else{
          const params={format:stills?'png':'jpeg',clip:{x:0,y:0,width:1280,height:720,scale:1},captureBeyondViewport:false,fromSurface:true};
          if(!stills)params.quality=92;
          base64=(await send('Page.captureScreenshot',params)).data;
        }
        const bytes=Buffer.from(base64,'base64');
        verifyImage(bytes,stills);
        const temporary=path+`.${process.pid}.tmp`;writeFileSync(temporary,bytes);renameSync(temporary,path);rendered++;
      }
      if(i===0||(i+1)%120===0||i===times.length-1)console.log(JSON.stringify({part,parts,done:i+1,assigned:times.length,rendered,skipped,secondsElapsed:Math.round((Date.now()-started)/1000)}));
    }
    verifySources();
    if(errors.length)throw new Error('Page raised JavaScript exceptions during export');
    const report={status:'complete',mode:stills?'stills':'frames',engine:exportSvg?'svg-canvas':'cdp-screenshot',manifest:manifest.fingerprint,part,parts,sourceVersion,total_ms:expectedMs,fps:FPS,width:1920,height:1080,total_frames:totalFrames,start_frame:stills?null:startFrame,end_frame_exclusive:stills?null:endFrame,assigned:times.length,rendered,skipped,elapsed_seconds:(Date.now()-started)/1000,completed_at:new Date().toISOString(),errors,checks};
    atomicJson(reportPath,report);console.log(JSON.stringify({report:reportPath,status:'complete',rendered,skipped}));
  }
}catch(error){
  if(!probe)atomicJson(reportPath,{status:'failed',manifest:manifest.fingerprint,part,parts,sourceVersion,rendered,skipped,elapsed_seconds:(Date.now()-started)/1000,error:String(error.stack||error),errors});
  console.error(error.stack||String(error));process.exitCode=1;
}finally{
  if(send)await send('Browser.close',{},2000).catch(()=>{});
  if(ws)ws.close();chrome.kill();await sleep(350);
  const actual=realpathSync(profile),allowed=realpathSync(profiles)+sep;
  if(!actual.toLowerCase().startsWith(allowed.toLowerCase()))throw new Error('Refusing recursive cleanup outside this export profile directory');
  try{rmSync(actual,{recursive:true,force:true,maxRetries:3,retryDelay:200});}catch{console.warn(`Temporary isolated render profile retained: ${actual}`);}
  if(lock!==undefined){closeSync(lock);unlinkSync(lockPath);}
}
