/* Add an expressive guide to the original 71.4-second dashboard without replacing it.
 * Input: originalGuide.render({oldMs, phase, p, shot, seconds, index}).
 * All animation is a pure function of that clock; seeking and offline export match.
 */
(() => {
  'use strict';
  const stage=document.querySelector('#stage');
  if(!stage)throw new Error('The original #stage must exist before loading the guide');
  const layer=document.createElement('div');layer.id='original-guide-overlay';
  layer.innerHTML='<div id="og-shadow"></div><div id="og-pet"></div><svg id="og-effects" viewBox="0 0 1280 600"><defs><filter id="og-soft" x="-20%" y="-40%" width="140%" height="180%"><feGaussianBlur stdDeviation="3"/></filter><clipPath id="og-safe"><rect x="0" y="58" width="1280" height="538"/></clipPath></defs><g clip-path="url(#og-safe)"><g id="og-focus"><rect id="og-halo" rx="7" fill="none" stroke-width="5" opacity=".22" filter="url(#og-soft)"/><rect id="og-wash" rx="7" opacity=".025"/><rect id="og-edge" rx="7" fill="none" stroke-width="1.3"/></g><g id="og-particles"></g></g></svg><svg id="og-baton" viewBox="0 0 1280 600"><defs><filter id="og-laser-soft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2"/></filter></defs><g id="og-stick"><path id="og-laser-glow" fill="none" stroke-width="5" stroke-linecap="round" opacity=".3" filter="url(#og-laser-soft)"/><path id="og-laser-core" fill="none" stroke-width="1.6" stroke-linecap="round" opacity=".95"/><path id="og-laser-white" fill="none" stroke="#fff7e6" stroke-width=".7" stroke-linecap="round" opacity=".85"/><circle id="og-laser-pulse" r="1.7" fill="#fff7e6"/><circle id="og-muzzle" r="3" opacity=".55" filter="url(#og-laser-soft)"/><circle id="og-tip-glow" r="5" opacity=".35" filter="url(#og-laser-soft)"/><circle id="og-tip-dot" r="2.3" fill="#fff7e6" opacity=".95"/><circle id="og-stick-ring" fill="none" stroke-width="1.2"/></g></svg>';
  stage.append(layer);
  const q=id=>layer.querySelector('#'+id);
  // v4: the homepage robot (mc-kit.js robot()) with the Claude Code blaster replaces the pixel pet.
  // Sprites come from the finance v3 renderer (robot/sprite.html), one per degree of aim.
  const RS=window.ROBOT_SPRITES;
  if(!RS)throw new Error('robot/sprites.js must load before original-guide.js');
  const S=108/RS.size;                                  // sprite px -> stage px: a 62 px robot, clear of the panel text above the lane
  const FOOT=[54,57.333];                               // feet placed so a raised muzzle sits where the pet's hand was (x+68)
  const BASE='robot/';
  let shownSprite='';
  // Preload every sprite as a hidden image inside #stage so the SVG/canvas exporter
  // (render_full.mjs) inlines them once; it drops [data-preload] nodes from each frame clone.
  const preload=document.createElement('div');preload.id='og-robot-preload';preload.setAttribute('data-preload','');preload.style.display='none';
  preload.innerHTML=Object.values(RS.sprites).map(v=>`<img src="${BASE}${v.file}" alt="">`).join('');
  layer.append(preload);
  q('og-pet').innerHTML='<img id="og-robot" alt="" decoding="sync">';
  q('og-pet').style.width=q('og-pet').style.height=(RS.size*S)+'px';
  q('og-pet').style.transformOrigin=`${RS.feet[0]*S}px ${RS.feet[1]*S}px`;
  const local=p=>[(p[0]-RS.feet[0])*S,(p[1]-RS.feet[1])*S];
  const level=RS.sprites['0o'];
  const PIVOT=local([(level.grip[0]+level.muzzle[0])/2,(level.grip[1]+level.muzzle[1])/2]);
  const REACH=Math.hypot(local(level.muzzle)[0]-PIVOT[0],local(level.muzzle)[1]-PIVOT[1])+16;
  const clamp=v=>Math.max(0,Math.min(1,v));
  const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
  const mix=(a,b,p)=>a+(b-a)*p;
  const rand=n=>{const x=Math.sin(n*78.233+11.17)*43758.5453;return x-Math.floor(x);};
  const shots=()=>window.TIMELINE?.shots||[];
  const target=(id,box,tip,color)=>({id,box,tip,color});
  function descriptor(shot={},phase={},p=0){
    const kind=shot.old_kind||phase.kind||'open',step=shot.step||phase.step?.n||1;
    phase={...phase,kind,step:window.REPLAY?.steps?.[step-1]||{n:step}};
    const id=shot.id||kind;
    const harnessGuide=window.harnessFlow?.guideFor(shot,phase);
    if(harnessGuide)return harnessGuide;
    if(kind==='open')return {dock:[190,532],focus:null};
    if(kind==='card')return {dock:[350,532],focus:null};
    if(kind==='task'){
      if(id.includes('sealed'))return {dock:[350,532],focus:target('sealed-reference',[454,470,372,80],[453,554],'#8fadd6')};
      if(id.includes('six'))return {dock:[350,532],focus:target('six-original-subproblems',[332,284,616,173],[404,464],'#8fadd6')};
      return {dock:[350,532],focus:null};
    }
    if(kind==='think')return {dock:[732,532],focus:target('original-model-call',[430,329,420,122],[804,458],'#f0925f')};
    if(kind==='type')return {dock:[900,531],focus:target('original-code',[327,195,626,166],[958,367],'#f0925f')};
    if(kind==='run')return {dock:[730,532],focus:target('original-execution-panel',[318,146,644,444],[944,592],'#73d59c')};
    if(kind==='output'){
      const x=348+(step%2)*110;
      return {dock:[x,532],focus:target('original-stdout',[327,382,626,98],[x+62,487],'#73d59c')};
    }
    if(kind==='guard')return {dock:[900,532],focus:target('original-budget-guard',[328,250,624,248],[958,504],'#b9a4f7')};
    if(kind==='score'){
      const row=id.includes('standard')?1:id.includes('p-value')?2:0;
      if(id.includes('comparison'))return {dock:[900,532],focus:target('original-verdict',[328,425,630,82],[960,513],'#73d59c')};
      const top=284+row*42;
      return {dock:[900,532],focus:target('original-score-row-'+row,[332,top,625,34],[962,top+39],'#8fadd6')};
    }
    if(kind==='result')return {dock:[238,532],focus:target('original-run-summary',[326,351,628,99],[334,456],'#73d59c')};
    return {dock:[1060,531],focus:null};
  }
  const smoother=v=>{v=clamp(v);return v*v*v*(v*(v*6-15)+10);};
  const sameFocus=(a,b)=>!!a&&!!b&&a.box.every((v,i)=>v===b.box[i])&&a.tip.every((v,i)=>v===b.tip[i])&&a.color===b.color;
  let plannedTimeline=null,plannedGuide=null,plan=[];
  function makePlan(){
    const timeline=window.TIMELINE,guide=window.harnessFlow?.guideFor;
    if(plannedTimeline===timeline&&plannedGuide===guide)return plan;
    plannedTimeline=timeline;plannedGuide=guide;plan=[];
    let prior={dock:[160,532],focus:null,tip:[260,537]};
    for(const shot of shots()){
      const d=descriptor(shot,{kind:shot.old_kind},0),focus=d.focus;
      // The right-hand baton must leave the pet toward its right, never through its torso.
      const dock=[Math.round(Math.min(d.dock[0],focus?focus.tip[0]-(focus.tip[1]<430?76:84):Infinity)/8)*8,d.dock[1]];
      const tip=focus?[...focus.tip]:[dock[0]+100,dock[1]+5];
      const distance=Math.hypot(dock[0]-prior.dock[0],dock[1]-prior.dock[1]);
      const tipDistance=Math.hypot(tip[0]-prior.tip[0],tip[1]-prior.tip[1]);
      const duration=Number(shot.end)-Number(shot.start);
      const low=478,hasCorner=Math.abs(tip[0]-prior.tip[0])>.01&&(tip[1]<low||prior.tip[1]<low);
      const pathDistance=hasCorner?Math.abs(tip[0]-prior.tip[0])+Math.abs(prior.tip[1]-low)+Math.abs(tip[1]-low):tipDistance;
      const travel=Math.max(distance,tipDistance)<.01?0:Math.min(duration*.75,3.2,Math.max(.65,distance/240,pathDistance/240));
      const item={shot,dock,focus,tip,prior,distance,travel,start:Number(shot.start),end:Number(shot.end)};
      plan.push(item);prior={dock,focus,tip};
    }
    return plan;
  }
  function route(seconds,index){
    const list=makePlan(),item=list[Math.max(0,Math.min(index,list.length-1))];
    if(!item)return{x:160,y:532,dx:0,u:1,moving:false,travel:0,start:0,end:4,tip:[260,537],focus:null,weight:0};
    const {prior,dock,tip,travel,start,end}=item,u=travel?clamp((seconds-start)/travel):1;
    const e=smoother(u),a=prior.tip,b=tip,lane=478;
    let xProgress=e,tx=mix(a[0],b[0],e),ty=mix(a[1],b[1],e);
    // High score-row targets live outside the right edge. Change horizontal position
    // below the cards before raising the tip, so transitions cannot sweep through text.
    if(Math.abs(a[0]-b[0])>.01&&(a[1]<lane||b[1]<lane)){
      if(a[1]<lane&&b[1]>=lane){
        const part=Math.max(.08,Math.min(.8,(lane-a[1])/(Math.abs(b[0]-a[0])+Math.abs(lane-a[1])+Math.abs(b[1]-lane))));
        const v=smoother(u/part),h=smoother((u-part)/(1-part));xProgress=h;
        tx=mix(a[0],b[0],h);ty=u<part?mix(a[1],lane,v):mix(lane,b[1],h);
      }else if(a[1]>=lane&&b[1]<lane){
        const part=Math.max(.2,Math.min(.92,(Math.abs(b[0]-a[0])+Math.abs(a[1]-lane))/(Math.abs(b[0]-a[0])+Math.abs(a[1]-lane)+lane-b[1])));
        const h=smoother(u/part),v=smoother((u-part)/(1-part));xProgress=h;
        tx=mix(a[0],b[0],h);ty=u<part?mix(a[1],lane,h):mix(lane,b[1],v);
      }else{
        const h=smoother((u-.25)/.5);xProgress=h;tx=mix(a[0],b[0],h);
        ty=u<.25?mix(a[1],lane,smoother(u/.25)):u>.75?mix(lane,b[1],smoother((u-.75)/.25)):lane;
      }
    }
    const weight=Math.min(1,item.distance/70)*Math.pow(Math.sin(Math.PI*xProgress),2);
    return {...item,x:mix(prior.dock[0],dock[0],xProgress),y:mix(prior.dock[1],dock[1],e),dx:dock[0]-prior.dock[0],u,moving:weight>.001,weight,xProgress,tip:[tx,ty]};
  }
  function routeAt(seconds){
    const list=shots();let i=list.findIndex(s=>seconds<s.end);if(i<0)i=Math.max(0,list.length-1);
    return route(seconds,i);
  }
  function render(info){
    const sec=Math.max(0,Number(info.seconds||0)),shot=info.shot||{},index=info.index??shots().indexOf(shot);
    const stablePhase={kind:shot.old_kind||info.phase?.kind,step:window.REPLAY?.steps?.[(shot.step||info.phase?.step?.n||1)-1]};
    const desc=descriptor(shot,stablePhase,info.p||0),move=route(sec,index);
    const elapsed=Math.max(0,sec-move.start),flight=move.weight;
    // Pose is a pure function of the continuous trajectory and the global clock.
    const bob=Math.sin(sec*2)*.9-Math.abs(Math.sin(move.u*Math.PI*3))*4.6*flight;
    const lean=Math.sin(sec*2.2)*.8+Math.sign(move.dx)*flight*4;
    const tip=[...move.tip];
    let fx=move.x+FOOT[0],fy=move.y+FOOT[1]+bob;
    // Step back to the left when the target is closer than the muzzle reach.
    const pdx=tip[0]-(fx+PIVOT[0]),pdy=tip[1]-(fy+PIVOT[1]);
    const need=Math.sqrt(Math.max(0,REACH*REACH-pdy*pdy))-pdx;
    const stepBack=need>0?60*smooth(need/60):0;
    fx-=stepBack;
    const px=fx+PIVOT[0],py=fy+PIVOT[1];
    let aim=Math.abs(tip[1]-py)<1e-6&&tip[0]<=px?18:Math.atan2(py-tip[1],Math.max(tip[0]-px,0))*180/Math.PI;
    aim=Math.max(-90,Math.min(90,aim));
    const block=Math.floor(sec/4.6),blinkAt=2.7+rand(block+902)*1.1,localT=sec-block*4.6;
    const blink=localT>=blinkAt&&localT<blinkAt+.145;
    const sp=RS.sprites[Math.round(aim)+(blink?'b':'o')];
    const m0=local(sp.muzzle),g0=local(sp.grip);
    const bottomRel=Math.max(1,m0[1]+2,g0[1]+2);
    fy=Math.min(595-bottomRel,fy);
    const rad=lean*Math.PI/180,rot=p=>[fx+p[0]*Math.cos(rad)-p[1]*Math.sin(rad),fy+p[0]*Math.sin(rad)+p[1]*Math.cos(rad)];
    const opacity=smooth((sec-.45)/.45);
    const img=q('og-robot');
    if(shownSprite!==sp.file){img.setAttribute('src',BASE+sp.file);shownSprite=sp.file;}
    q('og-pet').style.transform=`translate(${(fx-RS.feet[0]*S).toFixed(2)}px,${(fy-RS.feet[1]*S).toFixed(2)}px) rotate(${lean.toFixed(3)}deg)`;
    q('og-pet').style.opacity=opacity;
    q('og-shadow').style.transform=`translate(${(fx-30).toFixed(2)}px,${Math.min(590,move.y+56)}px) scaleX(${1-flight*.25})`;
    q('og-shadow').style.opacity=opacity*.6;
    const focus=desc.focus,next=makePlan()[index+1]?.focus;
    let glow=focus?Math.min(sameFocus(move.prior.focus,focus)?1:smooth((elapsed-move.travel)/.25),sameFocus(focus,next)?1:smooth((move.end-sec)/.25)):0;
    if(shot.id?.includes('six'))glow*=1-smooth(((info.p||0)-.78)/.05);
    if(shot.id?.includes('sealed'))glow*=1-smooth(((info.p||0)-.82)/.05);
    if(shot.old_kind==='card')glow*=smooth((elapsed-1)/.2);
    q('og-focus').style.opacity=glow;
    if(focus){for(const id of ['og-halo','og-wash','og-edge']){const e=q(id);['x','y','width','height'].forEach((a,i)=>e.setAttribute(a,focus.box[i]));e.setAttribute(id==='og-wash'?'fill':'stroke',focus.color);}}
    const hand=rot(m0);
    const wanted=focus?focus.tip:move.tip;
    const line=(a,b)=>`M ${a[0].toFixed(2)} ${a[1].toFixed(2)} L ${b[0].toFixed(2)} ${b[1].toFixed(2)}`;
    const color=focus?.color||'#8ff6ff';
    for(const id of ['og-laser-glow','og-laser-core']){q(id).setAttribute('d',line(hand,tip));q(id).setAttribute('stroke',color);}
    q('og-laser-white').setAttribute('d',line(hand,tip));
    const pu=(sec*1.6)%1;q('og-laser-pulse').setAttribute('cx',(hand[0]+(tip[0]-hand[0])*pu).toFixed(2));q('og-laser-pulse').setAttribute('cy',(hand[1]+(tip[1]-hand[1])*pu).toFixed(2));q('og-laser-pulse').style.opacity=(.8*Math.sin(pu*Math.PI)).toFixed(3);
    q('og-muzzle').setAttribute('cx',hand[0]);q('og-muzzle').setAttribute('cy',hand[1]);q('og-muzzle').setAttribute('fill',color);
    for(const id of ['og-tip-glow','og-tip-dot']){q(id).setAttribute('cx',tip[0]);q(id).setAttribute('cy',tip[1]);}
    q('og-tip-glow').setAttribute('fill',color);
    const ring=q('og-stick-ring');ring.setAttribute('cx',tip[0]);ring.setAttribute('cy',tip[1]);ring.setAttribute('r',4+.5*Math.sin(sec*2));ring.setAttribute('stroke',color);ring.style.opacity=.35+glow*.55;
    // The sight laser shows only while a real target is held (none in the parked pose).
    const aimed=(focus?1:0)*smoother(move.u)+(move.prior.focus?1:0)*(1-smoother(move.u));
    q('og-stick').style.opacity=opacity*(1-flight*.35)*aimed;
    const shapes=[];
    for(let j=0;j<6;j++){
      const t=Math.floor(sec/.14)*.14-j*.14,age=sec-t;if(age<0||age>.6)continue;
      const prior=routeAt(t);if(!prior.moving)continue;
      const seed=Math.floor(t*100),r=rand(seed),dx=prior.x+22-Math.sign(prior.dx)*age*(20+r*17),dy=Math.min(592,prior.y+56)-age*14;
      shapes.push(`<rect x="${dx.toFixed(2)}" y="${dy.toFixed(2)}" width="${2+Math.floor(r*2)}" height="2" fill="#8ff6ff" opacity="${((1-age/.6)*.42).toFixed(3)}"/>`);
    }
    const burstAge=elapsed-move.travel-.3;
    if(focus&&!sameFocus(move.prior.focus,focus)&&burstAge>0&&burstAge<.7){for(let j=0;j<7;j++){const a=j/7*Math.PI*2,r=4+burstAge*(16+rand(j+index)*16),px=tip[0]+Math.cos(a)*r,py=tip[1]+Math.sin(a)*r;shapes.push(`<rect x="${px.toFixed(2)}" y="${py.toFixed(2)}" width="2" height="2" fill="${focus.color}" opacity="${(Math.sin(burstAge/.7*Math.PI)*.65).toFixed(3)}"/>`);}}
    q('og-particles').innerHTML=shapes.join('');
    window.originalGuide.last={sec,oldMs:info.oldMs,kind:stablePhase.kind,shot:shot.id,pet:{x:fx,y:fy,w:RS.size*S,h:RS.size*S,lean,sx:1,sy:1,moving:move.moving,bottom:fy+bottomRel,aim,stepBack,sprite:sp.file},hand,tip,bodyPolygon:[[RS.body[0],RS.body[1]],[RS.body[2],RS.body[1]],[RS.body[2],RS.body[3]],[RS.body[0],RS.body[3]]].map(p=>rot(local(p))),trajectory:{u:move.u,travel:move.travel,weight:move.weight},focus:focus?.id||null,focusOpacity:glow,box:focus?.box||null,targetTip:focus?.tip||null,tipReachError:focus&&glow>.99?Math.hypot(tip[0]-wanted[0],tip[1]-wanted[1]):0,particleCount:shapes.length,globalDimming:false};
  }
  window.originalGuide={render,routeAt,last:null};
  if(window.enhancedReplayInfo)render(window.enhancedReplayInfo);
})();
