/* v4: Metacase institution row in the opening and closing titles.
 * The 11 original render functions stay byte-identical; this additive layer fades the
 * crest row and the "Hosted by" line on the same original clock (info.oldMs) after
 * each guide render. Opening: as op-ch, 400/600 ms later. Closing: between end-ch and end-tag. */
(() => {
  'use strict';
  const guide = window.originalGuide;
  if (!guide) throw new Error('brand.js must load after original-guide.js');
  const clamp = v => Math.max(0, Math.min(1, v));
  const el = id => document.getElementById(id);
  const OUTRO_START = 66200;   // original outro phase start (ms), as renderEnd's OUTRO.start
  const render = guide.render;
  guide.render = info => {
    render(info);
    const t = Number(info.oldMs) || 0;
    el('op-crests').style.opacity = clamp((t - 2450) / 450);
    el('op-host').style.opacity = clamp((t - 2650) / 450);
    const tt = t - OUTRO_START;
    el('end-crests').style.opacity = clamp((tt - 420) / 400);
    el('end-host').style.opacity = clamp((tt - 440) / 400);
  };
  if (window.enhancedReplayInfo) guide.render(window.enhancedReplayInfo);
})();
