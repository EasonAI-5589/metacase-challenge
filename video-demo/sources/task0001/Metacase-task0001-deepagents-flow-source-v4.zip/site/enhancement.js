/* Keep the source renderer intact. Only its clock is remapped for a narrated replay. */
(() => {
  'use strict';
  const original = window.replay;
  window.originalReplay = original;
  const timeline = window.TIMELINE;
  const stage = document.querySelector('#stage');
  if (!original || !timeline || !Array.isArray(timeline.shots)) throw new Error('Original replay and narrated timeline are required.');
  const shots = timeline.shots;
  for (let i = 0; i < shots.length; i++) {
    const shot = shots[i];
    if (!(shot.old_end_ms > shot.old_start_ms) || (i && Math.abs(shot.old_start_ms-shots[i-1].old_end_ms)>0.01)) throw new Error('Source timeline is incomplete or reordered.');
  }
  if (shots[0].old_start_ms !== 0 || Math.abs(shots.at(-1).old_end_ms-original.total)>0.01) throw new Error('The enhanced film must preserve the complete original timeline.');
  const band = document.createElement('div');
  band.id='e-caption-band';band.innerHTML='<div id="e-en" class="e-caption"></div><div id="e-zh" class="e-caption"></div>';
  const progress=document.createElement('div');progress.id='e-progress';stage.append(band,progress);
  const en=band.querySelector('#e-en'),zh=band.querySelector('#e-zh');
  const capture=new URLSearchParams(location.search).has('capture');
  const audio=capture?new Audio():new Audio('../audio/narration-track.wav');
  audio.preload='metadata';
  let current=0,playing=false,last=performance.now(),active=-1;
  const clamp=(value,min=0,max=1)=>Math.max(min,Math.min(max,value));
  const ease=value=>{const q=clamp(value);return q*q*(3-2*q);};
  function renderAt(ms){
    current=clamp(ms,0,timeline.total_ms);
    const seconds=current/1000;
    let index=shots.findIndex(s=>seconds<s.end);
    if(index<0)index=shots.length-1;
    const shot=shots[index];
    const progressInShot=clamp((seconds-shot.start)/shot.duration);
    // Revealing code/output a little earlier provides a stable reading hold at the end,
    // without omitting or jumping over any part of the original animation.
    const reveals=['type','output'].includes(shot.old_kind);
    const oldProgress=reveals?(progressInShot<.7?progressInShot/.7*.94:.94+(progressInShot-.7)/.3*.06):progressInShot;
    // A value infinitesimally below shot.end can round onto the next source
    // phase. Keep both clocks on this shot until the presentation boundary:
    // otherwise the guide can teleport to the next dock for exactly one frame.
    const oldMs=Math.max(shot.old_start_ms,Math.min(shot.old_end_ms-.001,original.total-.001,shot.old_start_ms+(shot.old_end_ms-shot.old_start_ms)*oldProgress));
    original.seek(oldMs);
    const phase=original.phases.find(p=>oldMs<p.end)||original.phases.at(-1);
    const taskStart=shots.find(s=>s.id==='task-paper').start;
    const agentStart=shots.find(s=>s.id==='agent-card').start;
    // The upstream film switches its sidebar visibility at a source-time
    // threshold. Fade the first appearance in presentation time instead.
    const left=document.getElementById('left'),right=document.getElementById('right'),main=document.getElementById('main');
    left.style.opacity=Number(left.style.opacity)*ease((seconds-taskStart)/.55);
    main.style.opacity=Number(main.style.opacity)*ease((seconds-taskStart)/.45);
    right.style.opacity=Number(right.style.opacity)*ease((seconds-agentStart-.7)/.5);
    if(shot.id==='task-paper'){
      const local=seconds-taskStart;
      document.getElementById('sc-task').style.opacity=ease(local/.45);
      document.getElementById('tk-kick').style.opacity=ease(local/.3);
      document.getElementById('tk-q').style.opacity=ease((local-.08)/.32);
      document.getElementById('tk-q').style.transform=`translateY(${(1-ease((local-.08)/.32))*8}px)`;
      document.getElementById('tk-src').style.opacity=ease((local-.18)/.32);
    }
    if(shot.id==='score-coefficient'){
      document.getElementById('sc-score').style.opacity=ease((seconds-shot.start)/.28);
    }
    if(shot.old_kind==='outro'){
      // The source crossfade overlaps its two foreground titles. End the
      // result foreground before revealing the outro, using presentation time.
      const local=seconds-shot.start;
      const result=document.getElementById('ov-result'),end=document.getElementById('ov-end');
      const resultAlpha=1-ease(local/.32),endAlpha=ease((local-.34)/.34);
      result.style.opacity=String(resultAlpha);
      result.style.visibility=resultAlpha>.001?'visible':'hidden';
      end.style.opacity=String(endAlpha);
      end.style.visibility=endAlpha>.001?'visible':'hidden';
    }
    // Source-caption fades were tuned for the 71-second film; keep the technical
    // line readable throughout the longer hold, and hide it on chapter cards.
    const technicalActive=original.captions.some(c=>oldMs>=c.from&&oldMs<c.to);
    document.getElementById('cap-sub').style.opacity=technicalActive?'1':'0';
    const info={oldMs,phase,p:clamp((oldMs-phase.start)/phase.ms),shot,seconds,index};
    window.enhancedReplayInfo=info;
    if(active!==index){en.textContent=shot.en||'';zh.textContent='';active=index;} // v4: English captions only
    const cue=shot.cue_start!==null&&seconds>=shot.cue_start&&seconds<=shot.cue_end;
    const alpha=cue?Math.min(ease((seconds-shot.cue_start)/.18),ease((shot.cue_end-seconds)/.18)):0;
    en.style.opacity=zh.style.opacity=String(alpha);
    band.style.opacity=shot.en?'1':'0';
    progress.style.width=`${clamp(current/timeline.total_ms)*1280}px`;
    stage.style.opacity=String(Math.min(ease(seconds/.35),ease((timeline.duration-seconds)/.65)));
    if(window.harnessFlow)window.harnessFlow.render(info);
    if(window.originalGuide)window.originalGuide.render(info);
    return info;
  }
  function qa(){
    const info=window.enhancedReplayInfo;
    const texts=['e-en','e-zh','cap-sub'].map(id=>{const e=document.getElementById(id),r=e.getBoundingClientRect();return{id,text:e.textContent,overflow:e.scrollWidth>e.clientWidth+2||e.scrollHeight>e.clientHeight+2,height:r.height};});
    const flowOverflow=window.harnessFlow?.last?.active?[...document.querySelectorAll('.hf-info,.hf-node,.hf-node-v,#hf-tools,#hf-heading,#hf-evidence,#hf-return-label')].filter(e=>e.scrollWidth>e.clientWidth+2||e.scrollHeight>e.clientHeight+2).map(e=>({id:e.id||e.className,text:e.textContent,width:e.clientWidth,height:e.clientHeight,scrollWidth:e.scrollWidth,scrollHeight:e.scrollHeight})):[];
    return {seconds:current/1000,oldMs:info?.oldMs,phase:info?.phase.kind,step:info?.phase.step?.n,shot:info?.shot.id,texts,guide:window.originalGuide?.last||null,harnessFlow:window.harnessFlow?.last||null,flowOverflow,originalSceneIds:['sc-task','sc-model','sc-code','sc-guard','sc-score'],originalCode:document.querySelector('#cd-code').textContent,originalOutput:document.querySelector('#cd-out').textContent,technicalCaption:document.querySelector('#cap-sub').textContent};
  }
  function seek(ms){playing=false;audio.pause();renderAt(ms);return qa();}
  function play(){if(current>=timeline.total_ms)current=0;audio.currentTime=current/1000;playing=true;last=performance.now();audio.play().catch(()=>{playing=false;});}
  function pause(){playing=false;audio.pause();}
  function tick(now){
    if(playing){current=audio.readyState>=2&&!audio.paused?audio.currentTime*1000:current+Math.min(100,now-last);renderAt(current);if(current>=timeline.total_ms)pause();}
    last=now;requestAnimationFrame(tick);
  }
  addEventListener('keydown',event=>{if(event.code==='Space'){event.preventDefault();playing?pause():play();}if(event.code==='ArrowRight')seek(current+5000);if(event.code==='ArrowLeft')seek(current-5000);});
  if(!capture)stage.addEventListener('click',()=>playing?pause():play());
  window.replay={total:timeline.total_ms,sourceVersion:'deepagents-flow-v3.2@884e89e',renderAt,seek,play,pause,qa,originalTotal:original.total,phases:original.phases};
  renderAt(Math.max(0,Number(new URLSearchParams(location.search).get('t')||0))*1000);
  requestAnimationFrame(tick);
})();
