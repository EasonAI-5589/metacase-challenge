Metacase Challenge · task0001 · DeepAgents 执行结构回放 v4

v4 改动（在 v3.2 上增量修改，旁白、节奏、37 个镜头和全部数字不变）
  引导角色：像素宠物换成首页的机器人（mc-kit.js robot()）手持 Claude Code 对应的枪（blaster-e.glb），
    素材来自 finance v3 的 robot/sprite.html（site/robot/，每 1° 一张，240 px）；指挥棒换成枪口瞄准激光，
    停靠时不显示。路线、目标与时钟沿用 v3.2；audit_guide_continuity.cjs 全部 8,558 帧通过。
  品牌：标头、开场和片尾换成 Metacase 标识与字标，开场和片尾加入首页 Hero 的四个校徽和
    "Hosted by NTU GIFTS with HKU, SUFE and Tsinghua PBCSF"（site/brand/，字节未改，见 ATTRIBUTION.txt），
    片尾网址改为 easonai-5589.github.io/metacase-challenge。11 个原始渲染函数保持逐字节不变，
    校徽行由 site/brand.js 按原时钟淡入。
  执行流程层中评测基础设施的名称由 InferenceNet 改为中性的 "Challenge"。
  字幕：只烧录英文，只交付 captions.en.srt。

交付文件：Metacase-task0001-deepagents-flow-v4.mp4
时长：4:45.27（285.266666667 秒）
视频：1920 × 1080，30 fps，8,558 帧，H.264 / yuv420p / BT.709。
声音：英文合成旁白 en-US-AriaNeural，原始片段 -5% 语速，最终混音保音高提速 1.120004674 倍，AAC 48 kHz 单声道。
字幕：英文烧录字幕，另附英文 SRT。
结构：原版五章、37 个讲解段，完整保留原 32 个阶段，包含机器人向导、瞄准激光、同步高光及粒子。

本版动画修复
  保留 v3.1 已批准的 285.266667 秒节奏、讲稿与字幕，按新时间轴直接生成全部 8,558 帧；没有对旧 MP4 抽帧提速。
  将原时间限制在各镜头结束前，消除循环末尾单帧误入下一状态导致的宠物闪跳。
  宠物和指挥棒使用连续轨迹，流程光点沿文字外的圆角通道返回，各阶段共享端点。
  首次侧栏、章节切换及换卡内容连续淡入淡出，保持流程外框稳定。

来源与事实边界
  GitHub: EasonAI-5589/inferencenet-challenge, branch codex/video-demo
  固定提交：884e89e58f62a185cd06572979fbd1548ea67e4b
  源码位置：video-demo/task0001
  任务：0001；模型：GPT-5.6 Sol；Harness：DeepAgents。
  真实运行 ID：sol-deepagents-full1000-20260911-chain-03。
  replay-data.js 与收到的原始源码快照逐字节一致。原始私人 trace 不在此包内，
  本片依据的是随源码提供的派生快照及 provenance；没有重新执行模型评测。
  保留原版五章、三栏、六项子问题、用量、真实输出数值、预算拦截和评分解锁。中栏改为 DeepAgents 执行结构；原代码摘录在交互预览中可辅助展开。
  原 renderAt 与场景渲染函数未被重写；harness-flow.js 在执行阶段叠加图形结构，enhancement.js 将原 71.4 秒连续映射到新的讲解时间轴。
  原 cap-main 摘要由等义双语旁白替代，原 cap-sub 技术日志迁至底部；原始源码副本保持不变。
  记录中的运行耗时为 121.038 秒，视频时间不表示真实运行耗时。
  4 次交互工具调用与最终评分器运行分开计算；超预算请求没有被表现为第五次执行。
  参考数值采用网站公开的舍入值，不声称额外的原始精度。
  系数和标准误使用相对误差容限，p 值使用绝对误差容限；通过不等于逐位完全相等。
  完整复现结论仅指本题在给定规则下三项通过，不代表整个 benchmark 的结论。
  46,496 是总记录 token 数，不是输出 token 数或费用。
  向导、粒子、光效、声音和较慢展示节奏是演示元素，不是实际运行事件。

查看
  直接打开 MP4，或在此目录启动：
    python serve_preview.py --port 18791
  成片播放器：http://127.0.0.1:18791/preview.html
  可编辑动画：http://127.0.0.1:18791/site/index.html?pause
  播放器不自动播放；点击播放并打开声音。章节按钮可定位到相应位置。
  MP4 与播放器第一章从 0 秒开始，包含片头；画面中的 TASK 章卡在 9.4 秒出现。
  源码 ZIP 不包含 MP4，将 MP4 与解压后的 preview.html 放在同一目录即可观看成片。

编辑与重新导出
  site/：动画、DeepAgents 执行结构、像素向导、字体及原始 replay-data.js。工具/文件访问只表达派生快照能证实的动作；run_python 和预算边界属于本次接入。
  shotlist.json：37 个镜头的中英文讲稿与最短停留时间。
  site/timeline.json / timeline.js：已批准的提速时间轴，直接按每秒30帧渲染。
  audio/：36 段 WAV、最终混音、生成脚本与音频检查证据。
  captions.*.srt：匹配旁白时间轴的独立字幕。
  原始源码保存在 InferenceNet-task0001-source-20261018/ 和 original-source.zip。

  环境：Python 3、Node.js（支持全局 WebSocket）、Chrome、FFmpeg/FFprobe。
  全部命令均从解压目录运行，先启动上面的 localhost 服务：
    python render_all.py --stills --export-svg --resume
    python render_all.py --export-svg --resume
    python finish_full.py
  使用已核验的 SVG/canvas 导出路径，默认三个独立无界面 Chrome worker。
  FFmpeg 使用 CRF 18 / medium。源码包带有当前 manifests，不带已渲染帧，
  因此上面使用 --resume：源码哈希一致时会在空输出目录重新导出全部帧。
  当前 manifests 为 render-manifest.json 和 render-svg-stills-manifest.json。
  需要更改端口时，对 render_all.py 设置 RENDER_URL；Chrome 路径见 render_full.mjs。
  已有渲染证据存在时，只能对完全相同源码使用 --resume。
  修改镜头后应在新的导出目录生成新帧，不要混用旧帧、旧 manifest 或旧时间轴。
  prepare_pacing.py 是本次制作的历史准备脚本，需要相邻 v3/v3.1 工作目录；本包已包含完成后的素材，正常重新渲染无需运行它。
  finish_full.py 只在 render-complete.json 核验通过且连续 8,558 帧齐全时合成；
  如改变总时长/帧数，请同步审阅脚本内 EXPECTED_AUTHORED_FRAMES。
  finish_full.py 保留已经存在的正式 MP4，需要再次合成时请使用新导出目录。

  如需重新生成配音：
    python -m pip install edge-tts==7.3.1 numpy
    python audio/generate_voice.py
  音频生成需要访问 Edge TTS；不使用 API key。重新生成后必须重新渲染时间轴。
  原始语音片段保留为编辑输入；最终 narration-track.wav 已经按1.120004674倍保音高提速。正常重渲染直接使用现有混音。重新生成语音后需同步重新调整时间轴和混音节奏。

验证
  fact-audit.json：派生快照的历史事实核查，不能代替本版全部旁白的审查。
  source-fact-review.json：本版37段中英文与执行结构的事实核对。
  source-preservation.json / harness-evidence.json：原时间顺序、派生快照和实际工具/文件/执行事件的证据边界。
  render-svg-qa.json：当前 SVG/canvas 路径的静帧/布局/脚本错误检查。
  render-svg-stills-manifest.json：当前静帧导出的源码与参数清单。
  render-manifest.json：当前全片导出的源码与参数清单。
  render-complete.json / render-part-*.json：连续帧与 worker 完成回执。
  ffprobe.json：编码参数、帧数、时间轴及内嵌章节。
  decode-check.log：完整音视频解码检查（通过时为空）。
  audio/voice-metadata.json：原 v3 片段和混音的历史生成证据，其中旧总时长不代表本版。
  audio/pacing-metadata.json / source-audio-probe.json：本版保音高处理、混音时长和采样参数。
  audio/transcription-check.json：原讲稿的历史自动可懂度检查，本次未重新转录，不等同于主观试听。
  guide-motion-continuity-review.json：当前逐帧与边界的源代码几何核验，不等同于成片动态审查。
  clock-boundary-review.json / dynamic-visual-review.json / outro-seek-review.json：精确输出时钟与选定连续画面的审查；其详细截图保存在制作工作区的 video-pr-review-v3-2 中。
  delivery.json：最终 MP4、原始数据、时间轴和混音哈希。

源码包排除了渲染帧、MP4、浏览器 profile、依赖目录和音频缓存签名。
此导出脚本只生成本地文件，不会自动发布网站、推送 GitHub 或合并 PR。
