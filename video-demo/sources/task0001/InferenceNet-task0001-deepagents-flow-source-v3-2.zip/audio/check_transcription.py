"""Offline ASR sample of revised narration; not a full listening review."""
import hashlib
import json
import os
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parent
CACHE = Path("D:/learning/music-analysis/attstudio-course/models")
TORCH_DLLS = Path("E:/anaconda3.241215/Lib/site-packages/torch/lib")
if TORCH_DLLS.is_dir():
    os.environ["PATH"] = str(TORCH_DLLS) + os.pathsep + os.environ["PATH"]
    dll_handle = os.add_dll_directory(str(TORCH_DLLS))
from faster_whisper import WhisperModel

selected = ["agent-card", "step1-type", "step1-run", "step3-run", "harness-card", "step5-guard", "step6-type", "step6-run", "outro"]
timeline = json.loads((ROOT.parent / "site/timeline.json").read_text(encoding="utf-8"))
started = time.monotonic()
model = WhisperModel("small", device="cpu", compute_type="int8", cpu_threads=2,
                     download_root=str(CACHE), local_files_only=True)
records = []
for shot in timeline["shots"]:
    if shot["id"] not in selected:
        continue
    path = ROOT / Path(shot["audio_file"]).name
    segments, info = model.transcribe(str(path), language="en", beam_size=5, initial_prompt=None, vad_filter=False)
    transcript = " ".join(s.text.strip() for s in segments)
    record = {"id":shot["id"], "file":path.name, "sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
              "duration_seconds":info.duration, "expected_text":shot["en"], "transcript":transcript}
    records.append(record)
    print(shot["id"] + ": " + transcript, flush=True)
result = {"check_type":"offline sampled automatic intelligibility check; not a full-film listening review",
          "revision":"v3", "model":"small", "local_files_only":True, "device":"cpu", "compute_type":"int8",
          "initial_prompt":None, "sample_count":len(records), "selected_shots":selected,
          "duration_seconds":sum(r["duration_seconds"] for r in records), "samples":records,
          "elapsed_seconds":round(time.monotonic()-started,3)}
(ROOT / "transcription-check.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(f"Sampled {len(records)} clips in {result['elapsed_seconds']:.1f} seconds.", flush=True)
