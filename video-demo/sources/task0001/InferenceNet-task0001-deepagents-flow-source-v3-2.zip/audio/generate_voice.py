"""Generate narration while preserving the original 0..71400 ms phase sequence.

Requires edge-tts==7.3.1, numpy, FFmpeg and FFprobe. Existing cached clips are
reused only if text, voice and rate match. Rendering must use this timeline.
"""
import asyncio
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import subprocess
import sys
import wave
import numpy as np

AUDIO = Path(__file__).resolve().parent
ROOT = AUDIO.parent
DEPS = ROOT.parent / "replay-sample-v1/audio/.deps"
if DEPS.is_dir():
    sys.path.insert(0, str(DEPS))
FPS = 30

def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def measure(path):
    with wave.open(str(path), "rb") as f:
        assert (f.getnchannels(), f.getsampwidth(), f.getframerate()) == (1, 2, 48000)
        samples = np.frombuffer(f.readframes(f.getnframes()), dtype="<i2").astype(np.float64)
    peak, rms = float(abs(samples).max()), float(np.sqrt(np.mean(samples**2)))
    assert 100 < peak < 32767 and rms > 10, f"Bad signal: {path}"
    return {"duration": len(samples)/48000, "peak_dbfs": 20*math.log10(peak/32768),
            "rms_dbfs": 20*math.log10(rms/32768), "clipped_samples": int(np.count_nonzero(abs(samples)>=32767))}

def stamp(t):
    ms = round(t*1000)
    return f"{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}"

async def main():
    import edge_tts
    spec = json.loads((ROOT/"shotlist.json").read_text(encoding="utf-8"))
    shots, voice, rate = spec["shots"], spec["voice"], spec["voice_rate"]
    assert shots[0]["old_start_ms"] == 0 and shots[-1]["old_end_ms"] == 71400
    assert all(a["old_end_ms"] == b["old_start_ms"] for a,b in zip(shots,shots[1:]))
    assert all(s["old_start_ms"] < s["old_end_ms"] for s in shots)
    gate, failures = asyncio.Semaphore(3), []
    reuse = {}
    old_audio = ROOT.parent/"replay-full-v1/audio"
    old_meta = old_audio/"voice-metadata.json"
    if old_meta.exists():
        old = json.loads(old_meta.read_text(encoding="utf-8"))
        if old.get("voice") == voice and old.get("rate") == rate:
            reuse = {c["text"]: old_audio/c["file"] for c in old["clips"]}

    async def one(index, shot):
        if shot["silent"]:
            return {"index":index,"id":shot["id"],"silent":True,"file":None,"duration":0}
        target = AUDIO/f"voice-{index+1:02d}.wav"
        identity = {"text":shot["en"],"voice":voice,"rate":rate}
        signature = hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
        cache = target.with_suffix(".cache.json")
        async with gate:
            cached = target.exists() and cache.exists() and json.loads(cache.read_text())["signature"] == signature
            if not cached:
                if shot["en"] in reuse:
                    target.write_bytes(reuse[shot["en"]].read_bytes())
                else:
                    mp3 = target.with_suffix(".mp3")
                    for attempt in range(1,4):
                        try:
                            await asyncio.wait_for(edge_tts.Communicate(shot["en"],voice,rate=rate).save(str(mp3)),45)
                            break
                        except Exception as exc:
                            failures.append({"id":shot["id"],"attempt":attempt,"error":str(exc)})
                            if attempt == 3:
                                raise
                            await asyncio.sleep(attempt)
                    subprocess.run(["ffmpeg","-hide_banner","-loglevel","error","-y","-i",str(mp3),
                                    "-ac","1","-ar","48000","-c:a","pcm_s16le",str(target)],check=True)
                dump(cache,{"signature":signature,**identity})
            info = {"index":index,"id":shot["id"],"silent":False,"file":target.name,
                    "text":shot["en"],"voice":voice,"rate":rate,**measure(target)}
            print(f"voice {index+1:02}/{len(shots)}: {info['duration']:.3f}s",flush=True)
            return info

    clips = await asyncio.gather(*(one(i,s) for i,s in enumerate(shots)))
    output, cursor = [], 0
    for i,(shot,clip) in enumerate(zip(shots,clips)):
        frames = math.ceil(max(shot["min_seconds"],clip["duration"]+1.1 if not shot["silent"] else 0)*FPS)
        start, end = cursor/FPS,(cursor+frames)/FPS
        audio_start = None if shot["silent"] else start+.55
        audio_end = None if shot["silent"] else audio_start+clip["duration"]
        output.append({**shot,"index":i,"start":start,"end":end,"duration":frames/FPS,
                       "start_frame":cursor,"end_frame":cursor+frames,"audio_start":audio_start,"audio_end":audio_end,
                       "cue_start":None if shot["silent"] else audio_start-.1,
                       "cue_end":None if shot["silent"] else audio_end+.3,
                       "audio_file":None if shot["silent"] else "../audio/"+clip["file"]})
        cursor += frames
    # No extra source-time interval is invented: the last shot's existing
    # end hold is expanded by one second inside the original outro interval.
    cursor += FPS
    output[-1]["end"] = cursor/FPS
    output[-1]["end_frame"] = cursor
    output[-1]["duration"] += 1
    chapters = []
    for i,ch in enumerate(spec["chapters"]):
        group = [s for s in output if s["chapter"]==i]
        chapters.append({**ch,"index":i,"start":group[0]["start"],"end":group[-1]["end"],
                         "old_start_ms":group[0]["old_start_ms"],"old_end_ms":group[-1]["old_end_ms"]})
    timeline = {"status":"ready","title":spec["title"],"task":"0001","source_commit":spec["source_commit"],
                "fps":FPS,"duration":cursor/FPS,"total_ms":cursor/FPS*1000,"total_frames":cursor,
                "old_total_ms":71400,"mapping":spec["sequence_policy"],
                "chapters":chapters,"shots":output}
    voiced = [s for s in output if not s["silent"]]
    assert all(a["audio_end"] < b["audio_start"] and a["cue_end"] < b["cue_start"] for a,b in zip(voiced,voiced[1:]))
    assert all(s["start"]<=s["cue_start"]<s["audio_start"]<s["audio_end"]<s["cue_end"]<=s["end"] for s in voiced)
    dump(ROOT/"site/timeline.json",timeline)
    dump(ROOT/"narration-timeline.json",timeline)
    (ROOT/"site/timeline.js").write_text("window.TIMELINE = "+json.dumps(timeline,ensure_ascii=False,indent=2)+";\n",encoding="utf-8")
    for lang in ["en","zh","bilingual"]:
        blocks = []
        for n,s in enumerate(voiced,1):
            text = s["en"]+"\n"+s["zh"] if lang=="bilingual" else s[lang]
            blocks.append(f"{n}\n{stamp(s['cue_start'])} --> {stamp(s['cue_end'])}\n{text}\n")
        (ROOT/f"captions.{lang}.srt").write_text("\n".join(blocks),encoding="utf-8")
    print(f"TIMELINE READY: {cursor/FPS:.6f}s, {cursor} frames",flush=True)
    inputs, filters, labels = [], [], []
    for i,s in enumerate(voiced):
        inputs += ["-i",str(AUDIO/clips[s["index"]]["file"])]
        # Sample-accurate delays avoid millisecond rounding of frame boundaries.
        filters.append(f"[{i}:a]adelay={round(s['audio_start']*48000)}S:all=1[a{i}]")
        labels.append(f"[a{i}]")
    filters.append("".join(labels)+f"amix=inputs={len(voiced)}:normalize=0,apad,atrim=duration={cursor/FPS:.9f},loudnorm=I=-16:TP=-1.5:LRA=9[mix]")
    filterfile = AUDIO/"mix-filter.txt"
    filterfile.write_text(";\n".join(filters),encoding="utf-8")
    track = AUDIO/"narration-track.wav"
    subprocess.run(["ffmpeg","-hide_banner","-loglevel","error","-y",*inputs,"-filter_complex_script",str(filterfile),
                    "-map","[mix]","-ar","48000","-ac","1","-c:a","pcm_s16le",str(track)],check=True)
    signal = measure(track)
    assert abs(signal["duration"]-cursor/FPS)<.001
    dump(AUDIO/"voice-metadata.json",{"engine":"edge-tts","engine_version":importlib.metadata.version("edge-tts"),
         "voice":voice,"rate":rate,"shots":len(output),"voiced_shots":len(voiced),"silent_shots":len(output)-len(voiced),
         "duration":cursor/FPS,"frames":cursor,"fps":FPS,"clips":clips,"failed_attempts":failures,
         "track_signal":signal,"quality_note":"Timing and signal checked; human listening not claimed."})
    dump(AUDIO/"signal-check.json",signal)
    print(json.dumps({"status":"complete","duration":cursor/FPS,"frames":cursor,"signal":signal}),flush=True)

if __name__ == "__main__":
    asyncio.run(main())
