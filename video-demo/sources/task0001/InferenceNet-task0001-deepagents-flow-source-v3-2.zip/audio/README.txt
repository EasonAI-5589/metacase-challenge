InferenceNet DeepAgents execution walkthrough v3 — narration and timeline

This version preserves the original 0..71,400 ms source sequence and chapter
order TASK → AGENT → HARNESS → CHECK → RESULT. It does not reorder the scenes.
There are 37 consecutive mapped intervals: 36 voiced and 1 silent (task-card).

The original task phase is split into paper/question, six subproblems, and
sealed reference. Each of the four tool rounds retains think/type/run/output.
Each interactive run now has a narrated 9–10-second execution/observation path.
The score phase is split into
coefficient, standard error, p-value, and the complete comparison/verdict.
The fifth tool request is blocked. The final evaluator execution is distinct
from the four interactive executions. Original source facts are not edited.

Duration: 319.5 s (5:19.50), 9,585 frames at 30 fps.
Voice: en-US-AriaNeural through edge-tts 7.3.1, uniformly -5% rate.
Format: 48 kHz mono PCM 16-bit narration-track.wav, no background music.
No voice cloning, API keys, or paid model calls were used.

Timeline fields
  old_start_ms / old_end_ms: exact, contiguous original source interval.
  start / end: expanded video time in seconds, aligned to 30 fps frames.
  old_kind / step: original phase kind and tool/model step where applicable.
  audio_start / audio_end: actual speech cue times, null for silent intervals.
  cue_start / cue_end: subtitle times, null for silent intervals.
  audio_file: clip path relative to site/, null for silent intervals.

Source time is remapped monotonically. For type/output, the first 70% of new
phase time covers 94% of the original phase, and the final 30% covers the
remaining 6% to provide a reading hold; other phases remain linear. Do not
treat the 319.5-second explanatory timeline as the recorded 121.038-second run time.
Long spoken lines extend their own interval; no clip is sped up to fit.

Generation
  Install Python dependencies if needed:
    python -m pip install edge-tts==7.3.1 numpy
  Ensure FFmpeg and FFprobe are on PATH, then run from the project folder:
    python audio/generate_voice.py
  The script can reuse the existing replay-sample-v1/audio/.deps installation.
  Existing local clips are reused only when text, voice, and rate match their
  cache signatures. Exact same sentences may be reused from replay-full-v1.
  Network is needed only for new clips. All WAVs and the final mix are supplied.
  Do not regenerate narration after rendering without also rerendering frames:
  speech durations determine the entire presentation timeline.

Validation
  - Original interval coverage is continuous and strictly increasing.
  - Every spoken subtitle fits entirely inside its mapped shot.
  - No overlapping speech clips or subtitle cues; silent phases have no cues.
  - All voiced clips and final mix have nonzero signal and no clipped samples.
  - Mix measured -16.4 LUFS integrated, 5.9 LU range, -1.5 dBFS true peak.
  - check_voice_v3.py verifies timing, source coverage, output-narration
    preservation, and signal, using the packaged v2-timeline-baseline.json.
  - check_transcription.py samples nine revised clips using the cached Whisper
    small model. Its result is explicitly a sampled ASR check, not a complete
    subjective listening review. The cache path can be changed for a new host.

Narrative boundaries
  The four real interactive executions use run_python. Reading the Stata file
  occurs inside that tool through pandas/StataReader; no read_file, write_file,
  execute, task, or subagent invocation is asserted. DeepAgents routes requests
  and returns observations. The 4-call guard is this evaluation's configuration,
  not a claimed native DeepAgents default. The fifth request does not execute.
  Model call six submits main.py containing JSON-writing logic. The independent
  evaluator later executes the program and creates /output/1_result.json.
  This single workflow is not presented as evidence of harness superiority.

Revision evidence
  voice-revision-check.json: 19 changed narration segments and preserved output
  explanations; phase-coverage-check.json: all source intervals and frame counts;
  signal-check.json and loudness-summary.txt: actual mixed-audio measurements;
  transcription-check.json: sampled automatic transcription of revised clips.

No images, original index.html, source trace, guide, or renderer are edited by
these audio scripts. The separate visual adapter maps the original renderer
using old_start_ms/old_end_ms and adds presentation elements around it.
