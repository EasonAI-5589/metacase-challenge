"""Apply the evidence-bounded DeepAgents narration to the preserved shot sequence."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent.parent
path = root / "shotlist.json"
spec = json.loads(path.read_text(encoding="utf-8"))
updates = {
    "open": (
        "A model, a harness, and a research task. Follow how GPT five point six Sol and DeepAgents reach a checked result.",
        "一个模型、一套 Harness、一个研究任务。看 GPT-5.6 Sol 与 DeepAgents 如何得到可核验的结果。", 10),
    "agent-card": (
        "DeepAgents connects each model request to a tool, then brings observations back.",
        "DeepAgents 将模型请求交给工具，再把真实观察带回模型。", 6.5),
    "step1-think": (
        "The model first asks to inspect the household panel.",
        "模型首先提出请求：检查这份家庭面板数据。", 4.5),
    "step1-type": (
        "DeepAgents routes that request through run Python, the tool used for this recorded run.",
        "DeepAgents 将请求路由到 run_python，这是本次记录中实际使用的工具。", 8),
    "step1-run": (
        "The sandbox reads the Stata file. Shape, columns, and household counts flow back to the model.",
        "沙箱读取 Stata 数据文件；数据形状、列名和家庭数量作为观察返回模型。", 10),
    "step2-think": (
        "Using that observation, the model asks what packages and samples are available.",
        "基于刚才的观察，模型继续询问：哪些软件包和样本可用？", 5.5),
    "step2-type": (
        "DeepAgents routes another run Python request, carrying the next data and environment checks.",
        "DeepAgents 路由下一次 run_python 请求，继续检查数据与运行环境。", 7.5),
    "step2-run": (
        "The sandbox checks installed packages, missing values, and observations per household, then returns the findings.",
        "沙箱检查已安装的软件包、缺失值和各家庭观测数量，再返回检查结果。", 8),
    "step3-think": (
        "The next request compares regression methods and standard errors.",
        "下一次请求要比较不同回归方法及其标准误。", 4.5),
    "step3-type": (
        "The request includes fixed effects, composition-by-quarter controls, and household-clustered errors.",
        "请求包含固定效应、家庭构成与季度交互控制项，以及按家庭聚类的标准误。", 8),
    "step3-run": (
        "Run Python evaluates the variants in the sandbox. Their outputs become evidence for the next model decision.",
        "run_python 在沙箱中运行这些方案，输出结果成为模型下一步决策的依据。", 9),
    "step4-think": (
        "The model follows up by asking for variable labels.",
        "模型根据已有观察，继续请求核查变量标签。", 4.5),
    "step4-type": (
        "DeepAgents routes this fourth run Python request to inspect the Stata metadata.",
        "DeepAgents 路由第 4 次 run_python 请求，检查 Stata 元数据。", 7),
    "step4-run": (
        "Pandas inspects labels and notes in the same data file. The tool brings these observations back to the model.",
        "pandas 检查同一数据文件的标签与备注，工具再将这些观察返回模型。", 9),
    "harness-card": (
        "The harness routed every earlier step. Now this evaluation's tool budget is reached.",
        "Harness 参与了前面每一轮路由；现在达到的是本次评测设置的工具预算。", 7),
    "step5-guard": (
        "All four allowed tool calls are used. This evaluation's budget guard rejects the fifth request and asks for the final program.",
        "允许的 4 次工具调用已用完；本次评测的预算守卫拒绝第 5 次请求，要求提交最终程序。", 10.5),
    "step6-type": (
        "The submitted main dot py contains demeaning, regression, clustered correction, and JSON-writing logic. It has not run yet.",
        "提交的 main.py 包含去均值、回归、聚类校正和 JSON 输出逻辑；此时尚未执行。", 11),
    "step6-run": (
        "The independent evaluator runs main dot py. This execution writes the required result JSON.",
        "独立评分器运行 main.py，这次执行才生成 /output/1_result.json。", 8),
    "outro": (
        "DeepAgents connects decisions, tools, and observations. The evaluator checks the result. This trace shows one complete workflow, not a ranking of harnesses.",
        "DeepAgents 串联决策、工具和观察，评分器核验结果。这是一条完整运行流程，并非 Harness 排名。", 12),
}
old_intervals = [(s["id"], s["old_start_ms"], s["old_end_ms"]) for s in spec["shots"]]
for shot in spec["shots"]:
    if shot["id"] in updates:
        shot["en"], shot["zh"], shot["min_seconds"] = updates[shot["id"]]
        shot["silent"] = False
assert old_intervals == [(s["id"], s["old_start_ms"], s["old_end_ms"]) for s in spec["shots"]]
spec["title"] = "InferenceNet · DeepAgents execution walkthrough"
spec["narration_scope"] = {
    "revision": "v3",
    "tool_used": "run_python",
    "executed_interactive_tool_calls": 4,
    "fifth_request": "rejected by the evaluation's 4-call budget; not executed",
    "sixth_model_call": "submits final program; evaluator later executes it separately",
    "file_reads": "pandas/StataReader inside run_python; no read_file tool usage asserted",
    "final_artifact": "main.py submission contains output logic; /output/1_result.json is generated at evaluator execution",
    "not_asserted": ["read_file/write_file/execute/task tool usage", "subagent use", "budget is a native DeepAgents default", "harness performance superiority"],
}
path.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Updated {len(updates)} shots; all {len(old_intervals)} IDs and source intervals preserved.")
