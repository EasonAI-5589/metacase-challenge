"""Validate the v3 narration, source-time coverage, and final mix signal."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

audio = Path(__file__).resolve().parent
root = audio.parent
timeline = json.loads((root / "site/timeline.json").read_text(encoding="utf-8"))
shots = timeline["shots"]
previous = json.loads((audio / "v2-timeline-baseline.json").read_text(encoding="utf-8"))
def dump(name, data):
    (audio / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

assert len(shots) == len(previous["shots"]) == 37
assert [(s["id"], s["old_start_ms"], s["old_end_ms"]) for s in shots] == [(s["id"], s["old_start_ms"], s["old_end_ms"]) for s in previous["shots"]]
assert shots[0]["old_start_ms"] == 0 and shots[-1]["old_end_ms"] == 71400
assert all(a["old_end_ms"] == b["old_start_ms"] for a,b in zip(shots, shots[1:]))
assert all(a["end_frame"] == b["start_frame"] for a,b in zip(shots, shots[1:]))
assert all(s["duration"] >= (s["old_end_ms"] - s["old_start_ms"])/1000 for s in shots)
assert shots[0]["start_frame"] == 0 and shots[-1]["end_frame"] == timeline["total_frames"]
voiced = [s for s in shots if not s["silent"]]
assert all(a["audio_end"] < b["audio_start"] and a["cue_end"] < b["cue_start"] for a,b in zip(voiced, voiced[1:]))
assert all(s["start"] <= s["cue_start"] < s["audio_start"] < s["audio_end"] < s["cue_end"] <= s["end"] for s in voiced)
oldbyid = {s["id"]: s for s in previous["shots"]}
all_outputs = [s for s in shots if s["old_kind"] == "output"]
assert all((s["en"], s["zh"]) == (oldbyid[s["id"]]["en"], oldbyid[s["id"]]["zh"]) for s in all_outputs)
changed = [s["id"] for s in shots if (s["en"], s["zh"]) != (oldbyid[s["id"]]["en"], oldbyid[s["id"]]["zh"])]
dump("phase-coverage-check.json", {
    "status": "pass", "revision": "v3", "old_coverage_ms": [0,71400], "shot_count": len(shots),
    "same_shot_ids_and_source_intervals_as_v2": True, "strictly_contiguous": True,
    "new_timeline_contiguous": True, "all_intervals_slowed": True,
    "chapter_sequence": [c["en"] for c in timeline["chapters"]],
    "silent_shots": [s["id"] for s in shots if s["silent"]],
    "interactive_run_intervals": [{"id":s["id"], "seconds":s["duration"], "voiced":not s["silent"]} for s in shots if s["id"] in [f"step{i}-run" for i in range(1,5)]],
    "old_total_ms": 71400, "new_total_seconds": timeline["duration"], "frames": timeline["total_frames"]})

command = ["ffmpeg", "-hide_banner", "-nostats", "-i", str(audio / "narration-track.wav"), "-af", "ebur128=peak=true", "-f", "null", "-"]
result = subprocess.run(command, capture_output=True, text=True, check=True)
summary = result.stderr.rsplit("Summary:",1)[-1]
(audio / "loudness-summary.txt").write_text(summary.strip() + "\n", encoding="utf-8")
measurements = {
    "integrated_lufs": float(re.search(r"I:\s+(-?[\d.]+) LUFS", summary)[1]),
    "loudness_range_lu": float(re.search(r"LRA:\s+([\d.]+) LU", summary)[1]),
    "true_peak_dbfs": float(re.search(r"Peak:\s+(-?[\d.]+) dBFS", summary)[1]),
}
assert -18 <= measurements["integrated_lufs"] <= -14
assert measurements["true_peak_dbfs"] <= -1.0
track = audio / "narration-track.wav"
dump("voice-revision-check.json", {
    "status": "pass", "revision": "v3", "duration_seconds": timeline["duration"], "frames": timeline["total_frames"],
    "changed_shot_ids": changed, "changed_shot_count": len(changed),
    "output_narration_preserved": [s["id"] for s in all_outputs],
    "all_voice_and_subtitle_cues_in_shots": True, "no_overlap": True,
    "voice": "en-US-AriaNeural", "rate": "-5%", "track_sha256": hashlib.sha256(track.read_bytes()).hexdigest(),
    "loudness": measurements,
    "evidence_boundaries": [
        "Only run_python is asserted as an executed tool in this replay.",
        "Four interactive calls executed; the fifth request is rejected without execution.",
        "Budget belongs to this evaluation; not described as a native DeepAgents default.",
        "Sixth model call submits a final program; the independent evaluator executes it later.",
        "JSON output is associated with evaluator execution, not submission time.",
        "No subagent or read_file/write_file/execute/task usage is invented.",
        "No harness superiority is inferred from this single run."],
    "review_scope": "Automated timing/signal/sequence checks and separate sampled ASR; no subjective full-film listening claimed."})
print(json.dumps({"status":"pass", "duration": timeline["duration"], "frames": timeline["total_frames"], "changed":len(changed), "loudness":measurements}))
