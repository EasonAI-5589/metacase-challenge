/* Add an expressive guide to the original 71.4-second dashboard without replacing it.
 * Input: originalGuide.render({oldMs, phase, p, shot, seconds, index}).
 * All animation is a pure function of that clock; seeking and offline export match.
 */
(() => {
  'use strict';
  const stage=document.querySelector('#stage');
  if(!stage)throw new Error('The original #stage must exist before loading the guide');
  const layer=document.createElement('div');layer.id='original-guide-overlay';
  layer.innerHTML='<div id="og-shadow"></div><div id="og-pet"></div><svg id="og-effects" viewBox="0 0 1280 600"><defs><filter id="og-soft" x="-20%" y="-40%" width="140%" height="180%"><feGaussianBlur stdDeviation="3"/></filter><clipPath id="og-safe"><rect x="0" y="58" width="1280" height="538"/></clipPath></defs><g clip-path="url(#og-safe)"><g id="og-focus"><rect id="og-halo" rx="7" fill="none" stroke-width="5" opacity=".22" filter="url(#og-soft)"/><rect id="og-wash" rx="7" opacity=".025"/><rect id="og-edge" rx="7" fill="none" stroke-width="1.3"/></g><g id="og-particles"></g></g></svg><svg id="og-baton" viewBox="0 0 1280 600"><g id="og-stick"><path id="og-stick-outline" fill="none" stroke="#151d25" stroke-width="5" stroke-linecap="round"/><path id="og-stick-shaft" fill="none" stroke="#dfb68d" stroke-width="3" stroke-linecap="round"/><path id="og-stick-handle" fill="none" stroke="#845a43" stroke-width="4" stroke-linecap="round"/><path id="og-stick-tip" fill="none" stroke="#fff0c8" stroke-width="3" stroke-linecap="round"/><circle id="og-stick-ring" fill="none" stroke-width="1.2"/></g></svg>';
  stage.append(layer);
  const q=id=>layer.querySelector('#'+id);
  const petMarkup="<svg viewBox=\"0 0 24 22\"><g id=\"og-tail\"><path d=\"M4 13H1v-2h-2V9h2v2h3Z\" fill=\"#c98a6c\"/></g><g id=\"og-left-foot\"><path d=\"M5 15h4v6H5Z\" fill=\"#805143\"/><path d=\"M6 16h2v4H6Z\" fill=\"#db9878\"/></g><g id=\"og-mid-foot\"><path d=\"M11 15h4v6h-4Z\" fill=\"#805143\"/><path d=\"M12 16h2v4h-2Z\" fill=\"#db9878\"/></g><g id=\"og-right-foot\"><path d=\"M17 15h4v6h-4Z\" fill=\"#805143\"/><path d=\"M18 16h2v4h-2Z\" fill=\"#db9878\"/></g><g id=\"og-body\"><path fill=\"#7f5142\" d=\"M5 4h3V2h3v2h6V2h3v3h2v3h2v9H2V8h3Z\"/><path fill=\"#eda67d\" d=\"M5 5h4V3h2v2h6V3h2v3h2v3h2v7H3V9h2Z\"/><path fill=\"#ffc69a\" d=\"M6 5h3V3h2v2h6V3h2v3h2v3H5V7h1Z\"/><path fill=\"#f7b78d\" d=\"M5 9h16v6H5Z\"/><path fill=\"#ca8469\" d=\"M3 14h20v2H3Z\"/><rect x=\"8\" y=\"5\" width=\"2\" height=\"1\" fill=\"#ffe2b5\"/><rect x=\"13\" y=\"7\" width=\"4\" height=\"1\" fill=\"#ffd3a4\"/><g id=\"og-eyes\"><rect x=\"8\" y=\"10\" width=\"2\" height=\"3\" fill=\"#46392e\"/><rect x=\"17\" y=\"10\" width=\"2\" height=\"3\" fill=\"#46392e\"/><rect x=\"9\" y=\"10\" width=\"1\" height=\"1\" fill=\"#fff0d3\"/><rect x=\"18\" y=\"10\" width=\"1\" height=\"1\" fill=\"#fff0d3\"/></g><path id=\"og-mouth\" d=\"M12 13h1v1h2v-1h1v2h-4Z\" fill=\"#965c48\"/><path fill=\"#e9997a\" d=\"M6 13h2v1H6Zm14 0h2v1h-2Z\"/></g><g id=\"og-left-arm\"><rect x=\"1\" y=\"10\" width=\"3\" height=\"3\" fill=\"#eda67d\"/></g><g id=\"og-point\"><rect x=\"22\" y=\"10\" width=\"2\" height=\"3\" fill=\"#eda67d\"/><rect x=\"24\" y=\"9\" width=\"3\" height=\"2\" fill=\"#ffc69a\"/></g></svg>";
  q('og-pet').innerHTML=petMarkup;
  const clamp=v=>Math.max(0,Math.min(1,v));
  const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
  const mix=(a,b,p)=>a+(b-a)*p;
  const rand=n=>{const x=Math.sin(n*78.233+11.17)*43758.5453;return x-Math.floor(x);};
  const shots=()=>window.TIMELINE?.shots||[];
  const target=(id,box,tip,color)=>({id,box,tip,color});
  function descriptor(shot={},phase={},p=0){
    const kind=shot.old_kind||phase.kind||'open',step=shot.step||phase.step?.n||1;
    phase={...phase,kind,step:window.REPLAY?.steps?.[step-1]||{n:step}};
    const id=shot.id||kind;
    const harnessGuide=window.harnessFlow?.guideFor(shot,phase);
    if(harnessGuide)return harnessGuide;
    if(kind==='open')return {dock:[190,532],focus:null};
    if(kind==='card')return {dock:[350,532],focus:null};
    if(kind==='task'){
      if(id.includes('sealed'))return {dock:[350,532],focus:target('sealed-reference',[454,470,372,80],[453,554],'#8fadd6')};
      if(id.includes('six'))return {dock:[350,532],focus:target('six-original-subproblems',[332,284,616,173],[404,464],'#8fadd6')};
      return {dock:[350,532],focus:null};
    }
    if(kind==='think')return {dock:[732,532],focus:target('original-model-call',[430,329,420,122],[804,458],'#f0925f')};
    if(kind==='type')return {dock:[900,531],focus:target('original-code',[327,195,626,166],[958,367],'#f0925f')};
    if(kind==='run')return {dock:[730,532],focus:target('original-execution-panel',[318,146,644,444],[944,592],'#73d59c')};
    if(kind==='output'){
      const x=348+(step%2)*110;
      return {dock:[x,532],focus:target('original-stdout',[327,382,626,98],[x+62,487],'#73d59c')};
    }
    if(kind==='guard')return {dock:[900,532],focus:target('original-budget-guard',[328,250,624,248],[958,504],'#b9a4f7')};
    if(kind==='score'){
      const row=id.includes('standard')?1:id.includes('p-value')?2:0;
      if(id.includes('comparison'))return {dock:[900,532],focus:target('original-verdict',[328,425,630,82],[960,513],'#73d59c')};
      const top=284+row*42;
      return {dock:[900,532],focus:target('original-score-row-'+row,[332,top,625,34],[962,top+39],'#8fadd6')};
    }
    if(kind==='result')return {dock:[238,532],focus:target('original-run-summary',[326,351,628,99],[334,456],'#73d59c')};
    return {dock:[1060,531],focus:null};
  }
  const smoother=v=>{v=clamp(v);return v*v*v*(v*(v*6-15)+10);};
  const sameFocus=(a,b)=>!!a&&!!b&&a.box.every((v,i)=>v===b.box[i])&&a.tip.every((v,i)=>v===b.tip[i])&&a.color===b.color;
  let plannedTimeline=null,plannedGuide=null,plan=[];
  function makePlan(){
    const timeline=window.TIMELINE,guide=window.harnessFlow?.guideFor;
    if(plannedTimeline===timeline&&plannedGuide===guide)return plan;
    plannedTimeline=timeline;plannedGuide=guide;plan=[];
    let prior={dock:[160,532],focus:null,tip:[260,537]};
    for(const shot of shots()){
      const d=descriptor(shot,{kind:shot.old_kind},0),focus=d.focus;
      // The right-hand baton must leave the pet toward its right, never through its torso.
      const dock=[Math.round(Math.min(d.dock[0],focus?focus.tip[0]-(focus.tip[1]<430?76:84):Infinity)/8)*8,d.dock[1]];
      const tip=focus?[...focus.tip]:[dock[0]+100,dock[1]+5];
      const distance=Math.hypot(dock[0]-prior.dock[0],dock[1]-prior.dock[1]);
      const tipDistance=Math.hypot(tip[0]-prior.tip[0],tip[1]-prior.tip[1]);
      const duration=Number(shot.end)-Number(shot.start);
      const low=478,hasCorner=Math.abs(tip[0]-prior.tip[0])>.01&&(tip[1]<low||prior.tip[1]<low);
      const pathDistance=hasCorner?Math.abs(tip[0]-prior.tip[0])+Math.abs(prior.tip[1]-low)+Math.abs(tip[1]-low):tipDistance;
      const travel=Math.max(distance,tipDistance)<.01?0:Math.min(duration*.75,3.2,Math.max(.65,distance/240,pathDistance/240));
      const item={shot,dock,focus,tip,prior,distance,travel,start:Number(shot.start),end:Number(shot.end)};
      plan.push(item);prior={dock,focus,tip};
    }
    return plan;
  }
  function route(seconds,index){
    const list=makePlan(),item=list[Math.max(0,Math.min(index,list.length-1))];
    if(!item)return{x:160,y:532,dx:0,u:1,moving:false,travel:0,start:0,end:4,tip:[260,537],focus:null,weight:0};
    const {prior,dock,tip,travel,start,end}=item,u=travel?clamp((seconds-start)/travel):1;
    const e=smoother(u),a=prior.tip,b=tip,lane=478;
    let xProgress=e,tx=mix(a[0],b[0],e),ty=mix(a[1],b[1],e);
    // High score-row targets live outside the right edge. Change horizontal position
    // below the cards before raising the tip, so transitions cannot sweep through text.
    if(Math.abs(a[0]-b[0])>.01&&(a[1]<lane||b[1]<lane)){
      if(a[1]<lane&&b[1]>=lane){
        const part=Math.max(.08,Math.min(.8,(lane-a[1])/(Math.abs(b[0]-a[0])+Math.abs(lane-a[1])+Math.abs(b[1]-lane))));
        const v=smoother(u/part),h=smoother((u-part)/(1-part));xProgress=h;
        tx=mix(a[0],b[0],h);ty=u<part?mix(a[1],lane,v):mix(lane,b[1],h);
      }else if(a[1]>=lane&&b[1]<lane){
        const part=Math.max(.2,Math.min(.92,(Math.abs(b[0]-a[0])+Math.abs(a[1]-lane))/(Math.abs(b[0]-a[0])+Math.abs(a[1]-lane)+lane-b[1])));
        const h=smoother(u/part),v=smoother((u-part)/(1-part));xProgress=h;
        tx=mix(a[0],b[0],h);ty=u<part?mix(a[1],lane,h):mix(lane,b[1],v);
      }else{
        const h=smoother((u-.25)/.5);xProgress=h;tx=mix(a[0],b[0],h);
        ty=u<.25?mix(a[1],lane,smoother(u/.25)):u>.75?mix(lane,b[1],smoother((u-.75)/.25)):lane;
      }
    }
    const weight=Math.min(1,item.distance/70)*Math.pow(Math.sin(Math.PI*xProgress),2);
    return {...item,x:mix(prior.dock[0],dock[0],xProgress),y:mix(prior.dock[1],dock[1],e),dx:dock[0]-prior.dock[0],u,moving:weight>.001,weight,xProgress,tip:[tx,ty]};
  }
  function routeAt(seconds){
    const list=shots();let i=list.findIndex(s=>seconds<s.end);if(i<0)i=Math.max(0,list.length-1);
    return route(seconds,i);
  }
  function render(info){
    const sec=Math.max(0,Number(info.seconds||0)),shot=info.shot||{},index=info.index??shots().indexOf(shot);
    const stablePhase={kind:shot.old_kind||info.phase?.kind,step:window.REPLAY?.steps?.[(shot.step||info.phase?.step?.n||1)-1]};
    const desc=descriptor(shot,stablePhase,info.p||0),move=route(sec,index);
    const elapsed=Math.max(0,sec-move.start),flight=move.weight;
    // Pose uses the continuous trajectory and a global idle clock. No shot-local
    // landing, anticipation or aim reset can introduce a one-frame posture jump.
    const squash=.009*Math.sin(sec*3.1)+flight*.025*Math.cos(move.u*Math.PI*2);
    const sx=1+squash-flight*.025,sy=1-squash*1.1+flight*.045;
    const lean=Math.sin(sec*2.2)*.8+Math.sign(move.dx)*flight*5;
    const angle=lean*Math.PI/180,ox=32,oy=52.8;
    const transform=(x,y)=>[ox+(x-ox)*sx*Math.cos(angle)-(y-oy)*sy*Math.sin(angle),oy+(x-ox)*sx*Math.sin(angle)+(y-oy)*sy*Math.cos(angle)];
    const corners=[[-2,-4],[74,-4],[74,64],[-2,64]].map(([x,y])=>transform(x,y));
    const localBottom=Math.max(...corners.map(c=>c[1]));
    const x=move.x,y=Math.min(595-localBottom,move.y-flight*8+Math.sin(sec*2.1)*.7);
    const opacity=smooth((sec-.45)/.45);
    q('og-pet').style.transform=`translate(${x}px,${y}px) rotate(${lean}deg) scale(${sx},${sy})`;
    q('og-pet').style.opacity=opacity;
    q('og-shadow').style.transform=`translate(${x+4}px,${Math.min(590,move.y+56)}px) scaleX(${1-flight*.25})`;
    q('og-shadow').style.opacity=opacity*.6;
    const stride=Math.sin(sec*2)*1.3+Math.sin(move.u*Math.PI*6)*12*flight;
    q('og-left-foot').setAttribute('transform',`rotate(${stride} 7 16)`);
    q('og-right-foot').setAttribute('transform',`rotate(${-stride} 19 16)`);
    q('og-mid-foot').setAttribute('transform',`translate(0 ${-Math.abs(stride)*flight/20})`);
    q('og-left-arm').setAttribute('transform',`rotate(${-stride*1.5} 3 11)`);
    q('og-tail').setAttribute('transform',`rotate(${Math.sin(sec*5.2)*12} 3 13)`);
    const focus=desc.focus,next=makePlan()[index+1]?.focus;
    let glow=focus?Math.min(sameFocus(move.prior.focus,focus)?1:smooth((elapsed-move.travel)/.25),sameFocus(focus,next)?1:smooth((move.end-sec)/.25)):0;
    if(shot.id?.includes('six'))glow*=1-smooth(((info.p||0)-.78)/.05);
    if(shot.id?.includes('sealed'))glow*=1-smooth(((info.p||0)-.82)/.05);
    if(shot.old_kind==='card')glow*=smooth((elapsed-1)/.2);
    q('og-focus').style.opacity=glow;
    if(focus){for(const id of ['og-halo','og-wash','og-edge']){const e=q(id);['x','y','width','height'].forEach((a,i)=>e.setAttribute(a,focus.box[i]));e.setAttribute(id==='og-wash'?'fill':'stroke',focus.color);}}
    const handLocal=transform(68,27.2),hand=[x+handLocal[0],y+handLocal[1]];
    const wanted=focus?focus.tip:move.tip,tip=[...move.tip];
    const d=Math.max(1,Math.hypot(tip[0]-hand[0],tip[1]-hand[1])),ux=(tip[0]-hand[0])/d,uy=(tip[1]-hand[1])/d;
    const line=(a,b)=>`M ${a[0].toFixed(2)} ${a[1].toFixed(2)} L ${b[0].toFixed(2)} ${b[1].toFixed(2)}`;
    for(const id of ['og-stick-outline','og-stick-shaft'])q(id).setAttribute('d',line(hand,tip));
    q('og-stick-handle').setAttribute('d',line(hand,[hand[0]+ux*9,hand[1]+uy*9]));
    q('og-stick-tip').setAttribute('d',line([tip[0]-ux*9,tip[1]-uy*9],tip));
    const ring=q('og-stick-ring');ring.setAttribute('cx',tip[0]);ring.setAttribute('cy',tip[1]);ring.setAttribute('r',4+.5*Math.sin(sec*2));ring.setAttribute('stroke',focus?.color||'#f4c79c');ring.style.opacity=glow*.7;
    q('og-stick').style.opacity=opacity*(1-flight*.35);
    const block=Math.floor(sec/4.6),blinkAt=2.7+rand(block+902)*1.1,local=sec-block*4.6;
    const blink=local>=blinkAt&&local<blinkAt+.145,gaze=Math.max(-.4,Math.min(.4,(tip[0]-(x+32))/120));
    q('og-eyes').setAttribute('transform',blink?`translate(${gaze} 10) scale(1 .12)`:`translate(${gaze} ${-.2*glow})`);
    q('og-mouth').setAttribute('d',move.moving?'M12 13h3v2h-3Z':'M12 13h1v1h2v-1h1v2h-4Z');
    const shapes=[];
    for(let j=0;j<6;j++){
      const t=Math.floor(sec/.14)*.14-j*.14,age=sec-t;if(age<0||age>.6)continue;
      const prior=routeAt(t);if(!prior.moving)continue;
      const seed=Math.floor(t*100),r=rand(seed),px=prior.x+25-Math.sign(prior.dx)*age*(20+r*17),py=Math.min(592,prior.y+56)-age*14;
      shapes.push(`<rect x="${px.toFixed(2)}" y="${py.toFixed(2)}" width="${2+Math.floor(r*2)}" height="2" fill="#e7ad84" opacity="${((1-age/.6)*.42).toFixed(3)}"/>`);
    }
    const burstAge=elapsed-move.travel-.3;
    if(focus&&!sameFocus(move.prior.focus,focus)&&burstAge>0&&burstAge<.7){for(let j=0;j<7;j++){const a=j/7*Math.PI*2,r=4+burstAge*(16+rand(j+index)*16),px=tip[0]+Math.cos(a)*r,py=tip[1]+Math.sin(a)*r;shapes.push(`<rect x="${px.toFixed(2)}" y="${py.toFixed(2)}" width="2" height="2" fill="${focus.color}" opacity="${(Math.sin(burstAge/.7*Math.PI)*.65).toFixed(3)}"/>`);}}
    q('og-particles').innerHTML=shapes.join('');
    window.originalGuide.last={sec,oldMs:info.oldMs,kind:stablePhase.kind,shot:shot.id,pet:{x,y,w:64,h:58.667,lean,sx,sy,moving:move.moving,bottom:y+localBottom},hand,tip,bodyPolygon:[[5.333,5.333],[64,5.333],[64,45.333],[5.333,45.333]].map(([a,b])=>{const v=transform(a,b);return[x+v[0],y+v[1]];}),trajectory:{u:move.u,travel:move.travel,weight:move.weight},focus:focus?.id||null,focusOpacity:glow,box:focus?.box||null,targetTip:focus?.tip||null,tipReachError:focus&&glow>.99?Math.hypot(tip[0]-wanted[0],tip[1]-wanted[1]):0,particleCount:shapes.length,globalDimming:false};
  }
  window.originalGuide={render,routeAt,last:null};
  if(window.enhancedReplayInfo)render(window.enhancedReplayInfo);
})();
