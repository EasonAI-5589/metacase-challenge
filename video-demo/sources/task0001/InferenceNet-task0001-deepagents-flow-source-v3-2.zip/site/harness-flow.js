/* A factual view of task0001's custom tool loop; no unrecorded file-tool calls are invented.
 * The final program's execution belongs to the independent evaluator, outside the agent loop.
 * All motion is derived from the supplied replay clock, including deterministic export.
 */
(() => {
  'use strict';
  const stage=document.getElementById('stage'),R=window.REPLAY;
  if(!stage||!R)throw new Error('Recorded replay data and stage are required for the harness view.');
  const capture=new URLSearchParams(location.search).has('capture');
  const layer=document.createElement('div');layer.id='harness-flow';
  layer.innerHTML='<div id="hf-independent-route"><span><strong>FINAL SUBMISSION</strong>DeepAgents → complete program</span><i>→</i><span><strong>INDEPENDENT EVALUATOR</strong>separate execution · not a tool call</span><i>→</i><span><strong>SEALED REFERENCE</strong>opened only during scoring</span></div><div id="hf-panel"><div id="hf-heading"></div><div id="hf-round"></div><div id="hf-subheading"></div><svg id="hf-diagram" viewBox="0 0 644 160"><defs><marker id="hf-arrow" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0 0L6 3L0 6Z" fill="#536676"/></marker></defs><g id="hf-edges"></g><path id="hf-return" d="M554 124V141H87V124" fill="none" stroke="#39564a" stroke-width="1.5" marker-end="url(#hf-arrow)"/><circle id="hf-signal-glow" r="9" fill="#a1dfb7" opacity=".13"/><circle id="hf-signal" r="3.5" fill="#a1dfb7"/></svg><div id="hf-flow-nodes"></div><div id="hf-return-label"></div><div id="hf-cards"><div class="hf-info" id="hf-input"></div><div class="hf-info" id="hf-operation"></div><div class="hf-info" id="hf-result"></div></div><div id="hf-evidence"></div><div id="hf-tools"><b>Configured note tools</b><span>ls</span><span>read_file</span><span>write_file</span><span>edit_file</span><span>glob</span><span>grep</span><em>no calls shown in this replay</em></div><div id="hf-stamp">NOT EXECUTED</div></div><button id="hf-code-button" type="button">Recorded code ↗</button><pre id="hf-code-evidence"></pre>';
  stage.append(layer);
  const $=id=>document.getElementById(id),clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x);};
  // This palette is documented by the historical adapter diagram, not by task0001 tool-call evidence.
  $('hf-tools').querySelector('b').textContent='Historical setup';
  $('hf-tools').querySelector('em').textContent='note tools · no calls shown';
  const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const colors=['#f0925f','#b9a4f7','#73d59c','#8fadd6'];
  const xs=[20,176,332,488],cx=xs.map(x=>x+67);
  const nodes=xs.map((x,i)=>{const e=document.createElement('div');e.className='hf-node';e.style.left=x+'px';e.style.setProperty('--hf-color',colors[i]);e.innerHTML='<div class="hf-node-k"></div><div class="hf-node-v"></div>';$('hf-flow-nodes').append(e);return e;});
  // The transport lane stays outside node text. A lower, rounded lane carries
  // feedback back to the model without passing through its caption.
  $('hf-edges').innerHTML=`<path d="M${cx[0]} 126H${cx[3]}" stroke="#536676" stroke-width="1.5" fill="none" marker-end="url(#hf-arrow)"/>`+cx.map(x=>`<path d="M${x} 116V126" stroke="#536676" stroke-width="1.2"/><circle cx="${x}" cy="126" r="2.2" fill="#536676"/>`).join('');
  $('hf-return').setAttribute('d',`M${cx[3]} 126C${cx[3]+20} 126 ${cx[3]+20} 150 ${cx[3]} 150H${cx[0]}C${cx[0]-20} 150 ${cx[0]-20} 126 ${cx[0]} 126`);
  $('hf-signal-glow').setAttribute('r','4.5');
  $('hf-signal').setAttribute('r','3');
  let codeOpen=false,lastKey='';
  const codeButton=$('hf-code-button');codeButton.style.display=capture?'none':'block';
  codeButton.addEventListener('click',e=>{e.stopPropagation();codeOpen=!codeOpen;$('hf-code-evidence').style.display=codeOpen?'block':'none';codeButton.textContent=codeOpen?'Close code evidence ×':'Recorded code ↗';});
  $('hf-code-evidence').addEventListener('click',e=>e.stopPropagation());
  const card=(kick,title,body)=>`<div class="hf-info-k">${kick}</div>${title?`<div class="hf-info-title">${title}</div>`:''}<div class="hf-info-body">${body}</div>`;
  const row=(label,value,extra='')=>`<div class="hf-row"><span>${label}</span><b class="${extra}">${value}</b></div>`;
  const list=items=>'<div class="hf-list">'+items.map(x=>'<div>'+x+'</div>').join('')+'</div>';
  const steps={
    1:{title:'Inspect the household panel',input:card('FILE INPUT','Data_reg.dta','<div class="hf-path">/data/0001/data/</div><br>Stata household panel<br>Accessed inside Python'),operation:card('REQUESTED ACTION','Inspect data',list(['Read the Stata file','Check rows and columns','Inspect quarter values','Find household IDs'])),result:card('RETURNED OBSERVATION','Panel structure',row('rows','1,880')+row('columns','63')+row('quarters','4')+row('households','237'))},
    2:{title:'Check packages and usable observations',input:card('INPUTS','Environment + data',list(['Python packages','Data_reg.dta','11 model variables','Grouped by household'])),operation:card('REQUESTED ACTION','Check readiness',list(['Discover installed packages','Count missing values','Keep complete rows','Count observations per ID'])),result:card('RETURNED OBSERVATION','Ready to estimate','<div class="hf-small">linearmodels · statsmodels · scipy ✓<br>pyreadstat unavailable</div>'+row('missing values','0')+row('complete rows','1,880')+row('obs / household','7.93'))},
    3:{title:'Compare regression and standard-error implementations',input:card('MODEL INPUTS','Household panel',list(['Outcome: lnexpenditure','Exposure: lndispinc','Household + month-year','Composition × quarter'])),operation:card('REQUESTED ACTION','Fit and compare',list(['Household fixed effects','Month-year fixed effects','Household-clustered S.E.','Compare S.E. variants'])),result:card('RETURNED OBSERVATION','Four S.E. variants','<div class="hf-small">coefficient ≈ 0.391865 in all variants</div>'+row('LSDV','0.040413')+row('within · SM','0.037725')+row('PanelOLS','0.037594')+row('Stata nested','0.037664'))},
    4:{title:'Read the Stata variable metadata',input:card('FILE INPUT','Data_reg.dta','<div class="hf-path">/data/0001/data/</div><br>StataReader metadata<br>Accessed inside Python'),operation:card('REQUESTED ACTION','Read labels',list(['Data label','Value labels','Variable labels','Look for notes'])),result:card('RETURNED OBSERVATION','Variable definitions','<div class="hf-small">hid → Household ID<br>tfe → Year-month count<br>quarter: 191906–09 → 1<br>191910–12 → 2 · 192001–03 → 3<br>192004–06 → 4<br>dispinc → Disposable income (yen)</div>')},
    5:{title:'Another tool request reaches the evaluation budget limit',input:card('MODEL REQUEST','One more check',list(['PanelOLS fit','Household-clustered S.E.','Group adjustment','Requested run_python #5'])),operation:card('INFERENCENET GUARD','Tool budget: 4 / 4','<div class="hf-list">Four interactive executions<br>have already been used.</div><div class="hf-badge guard">Gate before execution</div>'),result:card('RETURNED FEEDBACK','Submit the final program','<div class="hf-path">tool_calls_exhausted</div><br><div class="hf-small">“Submit your final complete<br>program now.”</div>')},
    6:{title:'Package the final program for independent evaluation',input:card('FINAL MODEL RESPONSE','Complete program','<div class="hf-path">main.py · submitted program</div><br>Contains the complete<br>replication procedure'),operation:card('PROGRAM CONTENT','Replication logic',list(['Read data + add controls','Demean by household','Solve the regression','Correct cluster covariance'])),result:card('OUTPUT CONTRACT','Three JSON values',list(['coefficient','standard_error','p_value'])+'<div class="hf-path">/output/1_result.json</div><div class="hf-small">Created when evaluator runs it</div>')}
  };
  const independentCards=()=>({
    input:card('SUBMITTED ARTIFACT','main.py','<div class="hf-small">Final complete program from<br>model call 6</div><br><div class="hf-badge">Not interactive tool run #5</div>'),
    operation:card('INDEPENDENT EXECUTION','Evaluator',list(['Run submitted program','Read the required data','Compute the final estimate','Write the JSON prediction'])),
    result:card('SAVED PREDICTION','','<div class="hf-values">coefficient<br>0.3918654804181631<br>standard_error<br>0.037663551234012826<br>p_value<br>4.1182397947928995e-21</div>')
  });
  function sequence(kind,p,independent,guard){
    // Adjacent phases share exact endpoints: type 0→1, run 1→2,
    // output 2→3→4 (4 is the same physical model port as 0).
    if(independent)return kind==='run'?1+ease(p):2+ease(p);
    if(kind==='think')return 0;
    if(kind==='type')return ease(p);
    if(kind==='run')return 1+ease(p);
    if(kind==='guard')return p<.2?1+.55*ease(p/.2):p<.4?1.55-.55*ease((p-.2)/.2):1-ease((p-.4)/.6);
    if(kind==='output')return arcPosition(2,4,ease(p));
    return 0;
  }
  const cubic=(a,b,c,d,t)=>{const u=1-t;return u*u*u*a+3*u*u*t*b+3*u*t*t*c+t*t*t*d;};
  function routePoint(pos){
    if(pos<=3){const i=Math.min(2,Math.max(0,Math.floor(pos))),q=clamp(pos-i);return {x:cx[i]+(cx[i+1]-cx[i])*q,y:126};}
    const q=clamp(pos-3),bend=5/49;
    if(q<bend){const t=q/bend;return {x:cubic(cx[3],cx[3]+20,cx[3]+20,cx[3],t),y:cubic(126,126,150,150,t)};}
    if(q<1-bend)return {x:cx[3]+(cx[0]-cx[3])*(q-bend)/(1-2*bend),y:150};
    const t=(q-(1-bend))/bend;return {x:cubic(cx[0],cx[0]-20,cx[0]-20,cx[0],t),y:cubic(150,150,126,126,t)};
  }
  // Uniform distance sampling prevents the long feedback leg from suddenly
  // moving several times faster than the short forward links at a route join.
  const arc=[];let arcLength=0,priorPoint=null;
  for(let i=0;i<=2048;i++){
    const pos=i/512,point=routePoint(pos);
    if(priorPoint)arcLength+=Math.hypot(point.x-priorPoint.x,point.y-priorPoint.y);
    arc.push({pos,distance:arcLength});priorPoint=point;
  }
  function distanceAt(pos){const i=Math.min(2047,Math.floor(clamp(pos/4)*2048)),q=clamp((pos-arc[i].pos)*512);return arc[i].distance+(arc[i+1].distance-arc[i].distance)*q;}
  function arcPosition(from,to,p){
    const a=distanceAt(from),wanted=a+(distanceAt(to)-a)*clamp(p);let lo=0,hi=arc.length-1;
    while(hi-lo>1){const mid=(lo+hi)>>1;if(arc[mid].distance<wanted)lo=mid;else hi=mid;}
    const span=arc[hi].distance-arc[lo].distance,q=span?(wanted-arc[lo].distance)/span:0;
    return arc[lo].pos+(arc[hi].pos-arc[lo].pos)*q;
  }
  const waitingCard=()=>card('OBSERVATION','Awaiting tool result','<div class="hf-quiet">The result returns here<br>after execution.</div>');
  function stateForShot(shot,guardReady=true){
    if(!shot)return null;
    const overview=['agent-card','harness-card'].includes(shot.id),kind=overview?'overview':shot.old_kind,n=overview?(shot.id==='agent-card'?1:5):Number(shot.step||0);
    if(!n||!['think','type','run','output','guard','overview'].includes(kind))return null;
    const independent=n===6&&['run','output'].includes(kind),data=steps[n];
    const cards={...(independent?independentCards():data)};
    let dimResult=kind!=='output'&&kind!=='guard'&&n!==6;
    if(dimResult)cards.result=waitingCard();
    if(kind==='guard'&&!guardReady){cards.result=card('BUDGET CHECK','Request at the gate','<div class="hf-quiet">Checking the remaining<br>interactive tool budget.</div>');dimResult=true;}
    if(independent&&kind==='run')cards.result=card('OUTPUT FILE','Pending prediction','<div class="hf-path">/output/1_result.json</div><div class="hf-quiet">Written by the program<br>during evaluator execution</div>');
    if(overview){
      cards.input=card('MODEL CONTEXT','Task + observations',list(['Task instructions','Accessible task data','Previous tool results','Next decision by the model']));
      cards.operation=n===1?card('INFERENCENET ADAPTER','run_python',list(['Receives Python code','Executes in sandbox','Captures stdout + exit','Returns observations'])):data.operation;
      cards.result=n===1?card('RETURN PATH','Observation → model','<div class="hf-list">The model uses execution<br>results to choose its next<br>request or final response.</div>'):card('RECORDED SO FAR','Four completed calls',list(['1 · Inspect data','2 · Check environment','3 · Compare estimators','4 · Read variable labels']));
      dimResult=false;
    }
    return {n,kind,overview,independent,cards,dimResult};
  }
  function paintCard(id,current,prior,elapsed,currentDim=false,priorDim=false){
    const e=$('hf-'+id),changed=prior!==current;
    // Content changes in two short stages. Old and new glyphs never overlap,
    // while the enclosing card and the execution graph stay continuously visible.
    const oldVisible=changed&&prior&&elapsed<.16;
    const html=oldVisible?prior:current;
    const alpha=changed?(oldVisible?1-ease(elapsed/.16):ease((elapsed-(prior ? .16 : 0))/.22)):1;
    if(e.dataset?.content!==html){e.innerHTML='<div class="hf-card-copy">'+html+'</div>';if(e.dataset)e.dataset.content=html;}
    const copy=e.firstElementChild;
    const dim=oldVisible?priorDim:currentDim;
    if(copy){copy.style.opacity=String(alpha*(dim ? .38 : 1));copy.style.transform=`translateY(${(oldVisible?-2*(1-alpha):2*(1-alpha)).toFixed(3)}px)`;}
    e.style.opacity='1';
  }
  function guideFor(shot={},phase={}){
    let kind=shot.old_kind||phase.kind;const n=shot.step||phase.step?.n||1;
    if(kind==='card'&&['agent-card','harness-card'].includes(shot.id))kind='think';
    if(!['think','type','run','output','guard'].includes(kind))return null;
    const independent=n===6&&['run','output'].includes(kind);
    const mk=(id,box,tip,color)=>({id,box,tip,color});
    if(kind==='think')return {dock:[350,532],focus:mk('deepagents-input-context',[330,305,192,169],[427,478],colors[0])};
    if(kind==='type')return {dock:[535,532],focus:mk('deepagents-operation',[528,305,192,169],[621,478],colors[1])};
    if(kind==='run')return {dock:[560,532],focus:mk(independent?'independent-evaluator-execution':'custom-run-python-execution',[528,305,192,169],[623,478],independent?colors[3]:colors[2])};
    if(kind==='guard')return {dock:[560,532],focus:mk('evaluation-budget-before-execution',[528,305,192,169],[623,478],colors[1])};
    return {dock:[840,532],focus:mk(independent?'evaluator-saved-json':'tool-observation-return',[724,305,224,169],[851,478],colors[2])};
  }
  function render(info){
    const ph=info.phase||{},shot=info.shot||{},originalKind=shot.old_kind||ph.kind;
    const sec=Number(info.seconds||0),elapsed=sec-Number(shot.start||0),duration=Math.max(.001,Number(shot.duration||shot.end-shot.start||1));
    const shotIndex=Number.isInteger(info.index)?info.index:window.TIMELINE.shots.indexOf(shot),previousShot=window.TIMELINE.shots[shotIndex-1];
    const managedCard=originalKind==='card'&&['agent-card','harness-card','check-card'].includes(shot.id);
    const outgoing=managedCard&&elapsed<.28&&stateForShot(previousShot);
    const overview=originalKind==='card'&&['agent-card','harness-card'].includes(shot.id)&&elapsed>=.85;
    const displayShot=outgoing?previousShot:shot;
    const kind=outgoing?previousShot.old_kind:overview?'overview':originalKind,n=outgoing?Number(previousShot.step):overview?(shot.id==='agent-card'?1:5):(shot.step||ph.step?.n||0);
    const on=n>=1&&n<=6&&['think','type','run','output','guard','overview'].includes(kind);
    stage.classList.toggle('hf-active',on);layer.style.display=on?'block':'none';
    stage.classList.toggle('hf-overview',overview);
    if(managedCard){
      const chapter=$('ov-card'),fadeOut=shot.id==='check-card'?ease((duration-elapsed)/.28):1-ease((elapsed-.85)/.28);
      chapter.style.opacity=String(ease(elapsed/.2)*fadeOut);
      $('cc-t').style.opacity=String(ease((elapsed-.12)/.2));$('cc-s').style.opacity=String(ease((elapsed-.2)/.2));
      $('cc-t').style.transform=`translateY(${8*(1-ease(elapsed/.45))}px)`;
      $('cc-s').style.transform=`translateY(${10*(1-ease(elapsed/.45))}px)`;
      $('cc-ic').style.transform=`scale(${.9+.1*ease(elapsed/.45)})`;
    }
    const independent=on&&n===6&&['run','output'].includes(kind);stage.classList.toggle('hf-independent',independent);
    if(!on){codeOpen=false;$('hf-code-evidence').style.display='none';window.harnessFlow.last={active:false,shot:shot.id};return;}
    const st=R.steps[n-1],p=outgoing?1:clamp(elapsed/duration),data=steps[n],guard=n===5;
    const key=[n,independent,overview].join('/');
    if(key!==lastKey){
      codeOpen=false;$('hf-code-evidence').style.display='none';codeButton.textContent='Recorded code ↗';lastKey=key;
      $('hf-code-evidence').textContent=st.code.map(([line,text])=>String(line).padStart(3)+'  '+text).join('\n')+'\n\nRECORDED OUTPUT\n'+(st.output||[st.guard?.error||'']).join('\n');
    }
    $('hf-heading').textContent=independent?'Independent evaluator':'DeepAgents · tool loop';
    $('hf-round').textContent=independent?'SEPARATE FROM AGENT TOOLS':overview?(n===1?'CUSTOM TOOL · run_python':'4 / 4 TOOL RUNS USED'):`MODEL ${n} / ${R.limits.model_calls}`;
    $('hf-subheading').textContent=independent?'Final program executes outside the interactive tool budget.':overview?(n===1?'Model decision → custom tool → observation → next model decision':'The same tool loop now reaches the evaluation budget boundary.'):data.title;
    let labels;
    if(independent)labels=[['SUBMISSION','Complete program'],['EXECUTION','Evaluator'],['OUTPUT FILE','1_result.json'],['NEXT','Reference check']];
    else if(n===6)labels=[['MODEL','GPT-5.6 Sol'],['FINAL RESPONSE','Complete program'],['HANDOFF','Evaluator next'],['TOOL BUDGET','Still 4 / 4']];
    else labels=[['MODEL','GPT-5.6 Sol'],['TOOL REQUEST',`run_python #${n}`],[guard?'BUDGET GATE':'SANDBOX EXECUTION',guard?'InferenceNet guard':'run_python'],['FEEDBACK',guard?'Final instruction':'Return to model']];
    const pos=overview?arcPosition(0,4,ease((elapsed-1.13)/Math.max(.001,duration-1.13))):sequence(kind,p,independent,guard);
    let active=kind==='think'?0:kind==='type'?1:kind==='guard'?2:kind==='run'?(independent?1:2):3;
    if(n===6&&!independent)active=kind==='think'?0:1;
    if(kind==='output'&&!independent&&pos>3.6)active=0;
    if(overview)active=pos>3.5?0:Math.min(3,Math.floor(pos+.5));
    nodes.forEach((node,i)=>{node.children[0].textContent=labels[i][0];node.children[1].textContent=labels[i][1];node.classList.toggle('is-active',i===active);node.classList.toggle('is-muted',n===6&&!independent&&i>1);node.style.transform=i===active?`scale(${1+.006*Math.sin(sec*4)})`:'none';});
    const guardReady=kind==='guard'&&p>=.28;
    const currentState=stateForShot(displayShot,guardReady);
    const priorState=outgoing?currentState:guardReady?stateForShot(shot,false):stateForShot(previousShot);
    const contentElapsed=outgoing?1:guardReady?elapsed-duration*.28:overview?elapsed-1.13:elapsed;
    for(const id of ['input','operation','result'])paintCard(id,currentState.cards[id],priorState?.cards[id],Math.max(0,contentElapsed),id==='result'&&currentState.dimResult,id==='result'&&priorState?.dimResult);
    $('hf-tools').style.visibility=independent?'hidden':'visible';
    $('hf-return').style.opacity=independent||n===6?'0':'.8';
    $('hf-return-label').textContent=independent?'Independent execution → output → scoring':n===6?'Final response crosses the evaluator boundary':guard?'Guard feedback returns to the model':'Tool results return to model context';
    $('hf-return-label').style.color=guard?colors[1]:independent?colors[3]:'#95b6a3';
    const {x:sx,y:sy}=routePoint(pos);
    for(const id of ['hf-signal','hf-signal-glow']){$(id).setAttribute('cx',sx);$(id).setAttribute('cy',sy);$(id).setAttribute('fill',guard?colors[1]:colors[active]);}
    const stamp=kind==='guard'?ease((p-.25)/.13):0;$('hf-stamp').style.opacity=stamp;$('hf-stamp').style.transform=`rotate(-7deg) scale(${1+(1-stamp)*.4})`;
    const used=overview?(n===1?0:4):Math.min(4,n-(kind==='think'||kind==='type'?1:0));
    $('hf-evidence').textContent=independent?(kind==='output'?`Evaluator · exit ${st.tool.exit} · ${st.tool.seconds.toFixed(3)} s recorded · valid prediction ✓`:'Evaluator runs the final program · interactive tool count remains 4 / 4'):n===6?'Final complete program submitted · execution happens in the next chapter':guard?(kind==='guard'?'Rejected before execution · tool_calls_exhausted · no new tool run':'Requested run_python #5 · four previous interactive executions used'):kind==='output'?`run_python #${n} · exit ${st.tool.exit} · ${st.tool.seconds.toFixed(3)} s recorded · tool budget ${n} / 4`:`InferenceNet custom run_python adapter · interactive budget ${Math.max(0,used)} / 4`;
    if(overview)$('hf-evidence').textContent=n===1?'DeepAgents manages the loop · InferenceNet supplies sandbox + tool budget':'InferenceNet evaluation limit: 4 interactive tool runs · not a native DeepAgents limit';
    const entering=previousShot&&!stateForShot(previousShot);
    const transition=outgoing?1-ease(elapsed/.28):overview?ease((elapsed-1.13)/.28):entering?ease(elapsed/.28):1;layer.style.opacity=String(transition);
    window.harnessFlow.last={active:true,shot:shot.id,step:n,kind,independent,activeNode:active,signal:{x:sx+318,y:sy+146},routePosition:pos,budgetUsed:independent?4:used,guide:guideFor(shot,ph),factsVisible:kind==='output'||guardReady||n===6,chapterOutgoing:!!outgoing,contentTransition:clamp(contentElapsed/.38),configuredToolsNotActive:['ls','read_file','write_file','edit_file','glob','grep']};
  }
  window.harnessFlow={render,guideFor,sequence,routePoint,last:null};
})();
