# Task 0001 · 16:9 replay source

After extracting, enter this directory (the one containing index.html).

## Preview

```sh
python3 -m http.server 4198 --bind 127.0.0.1
```

Open http://127.0.0.1:4198/index.html. Reuse or coordinate any existing service
on that port before starting another one.

Edit index.html for layout, captions and animation; replay-data.js holds the
recorded trajectory and values. Source-file hashes are in provenance.json.

## Export

Terminal one, in this directory:

```sh
python3 export_server.py 18779
```

Terminal two, in the same directory:

```sh
node capture.mjs
ffmpeg -framerate 30 -i frames/frame_%05d.jpg \
  -vf "scale=in_range=pc:out_range=tv,format=yuv420p" \
  -color_range tv -colorspace bt709 -color_primaries bt709 -color_trc bt709 \
  -c:v libx264 -preset slow -crf 18 -movflags +faststart \
  InferenceNet-task0001-agent-replay-16x9.mp4
```

The current timeline has 2142 frames at 30 fps (71.4 seconds).

## Requirements and scope

This is the editable animation source, with its recorded data snapshot,
fonts, font licence and export scripts. The finished MP4 is supplied separately.
Preview requires Python 3 and a browser; no API key or private data is needed.
Space pauses/resumes; arrow keys seek. Add ?t=30&pause to hold at 30 seconds.

Export requires Python 3, Node.js 22+, Chrome/Chromium and ffmpeg.
Set CHROME to your browser executable if it is not at the standard macOS path.
Capture uses a separate temporary browser profile. A Chinese system font
(such as Noto Sans CJK) is needed for Chinese text.

The data represents a historical run, with a compressed timeline. This source
package does not contain private raw task files, model credentials or tools
for rebuilding the original research run.

Verify the extracted files: `shasum -a 256 -c SHA256SUMS`.
