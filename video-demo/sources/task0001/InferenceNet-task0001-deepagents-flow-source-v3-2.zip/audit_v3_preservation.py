"""Read-only source/fact audit with an explicit final report write after source freeze."""
import argparse, hashlib, json, math, re, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT/'InferenceNet-task0001-source-20261018'
NAMES=['renderRings','renderOpen','renderCard','renderTask','renderModel','renderCode','renderGuard','renderScore','renderResult','renderEnd','renderAt']
def sha(b): return hashlib.sha256(b).hexdigest()
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def function(s,name):
    m=re.search(r'^function '+name+r'\([^\n]*\{[\s\S]*?^\}',s,re.M)
    if not m: raise AssertionError('Missing function '+name)
    return m.group()
def main():
    args=argparse.ArgumentParser();args.add_argument('--final',action='store_true');a=args.parse_args()
    old=(ORIGINAL/'index.html').read_text(encoding='utf-8'); new=(ROOT/'site/index.html').read_text(encoding='utf-8')
    data=(ROOT/'site/replay-data.js').read_bytes(); snap=json.loads(data.decode('utf-8').split('window.REPLAY = ',1)[1].strip().rstrip(';'))
    timeline=load(ROOT/'site/timeline.json'); shots=timeline['shots']; narration=load(ROOT/'narration-timeline.json')
    functions=[{'name':name,'unchanged':function(old,name)==function(new,name),'sha256':sha(function(old,name).encode())} for name in NAMES]
    # Evaluate only the upstream pure timeline declarations, never any DOM or network code.
    block=old[old.index('const FINAL ='):old.index('const phaseOf =')]
    js="const vm=require('vm');let c={R:JSON.parse(process.argv[1])};vm.createContext(c);vm.runInContext(process.argv[2]+';result={phases:PH,total:TOTAL}',c);process.stdout.write(JSON.stringify(c.result));"
    original=json.loads(subprocess.check_output(['node','-e',js,json.dumps(snap),block],text=True,encoding='utf-8'))
    issues=[];details=[]
    for i,ph in enumerate(original['phases']):
        matched=[s for s in shots if min(s['old_end_ms'],ph['end'])>max(s['old_start_ms'],ph['start'])]
        covered=sum(max(0,min(s['old_end_ms'],ph['end'])-max(s['old_start_ms'],ph['start'])) for s in matched)
        match=all(s['old_kind']==ph['kind'] and s.get('step')==ph.get('step',{}).get('n') for s in matched)
        details.append({'index':i,'kind':ph['kind'],'step':ph.get('step',{}).get('n'),'start_ms':ph['start'],'end_ms':ph['end'],'shot_ids':[s['id'] for s in matched],'covered_ms':covered,'complete':covered==ph['ms'],'kind_and_step_match':match})
    for i,s in enumerate(shots):
        if s['old_end_ms']<=s['old_start_ms']:issues.append(['nonpositive',s['id']])
        if i and abs(s['old_start_ms']-shots[i-1]['old_end_ms'])>1e-8:issues.append(['source_gap_or_overlap',s['id']])
        if i and abs(s['start']-shots[i-1]['end'])>1e-8:issues.append(['video_gap_or_overlap',s['id']])
    if shots[0]['old_start_ms']!=0 or shots[-1]['old_end_ms']!=original['total']:issues.append(['source_endpoints'])
    if not all(x['complete'] and x['kind_and_step_match'] for x in details):issues.append(['phase_coverage'])
    mapped=[];phase_identity_errors=[]
    for f in range(timeline['total_frames']):
        # Match renderer seek(frame * 1000 / fps), then enhancement's ms / 1000.
        # Reordering these divisions changes floating-point values at boundaries.
        sec=(f*1000/timeline['fps'])/1000
        s=next((s for s in shots if sec<s['end']),shots[-1]);p=max(0,min(1,(sec-s['start'])/s['duration']))
        q=(p/.7*.94 if p<.7 else .94+(p-.7)/.3*.06) if s['old_kind'] in ['type','output'] else p
        old_ms=max(s['old_start_ms'],min(s['old_end_ms']-.001,original['total']-.001,s['old_start_ms']+(s['old_end_ms']-s['old_start_ms'])*q))
        mapped.append(old_ms)
        ph=next((ph for ph in original['phases'] if old_ms<ph['end']),original['phases'][-1])
        if ph['kind']!=s['old_kind'] or ph.get('step',{}).get('n')!=s.get('step'):
            phase_identity_errors.append({'frame':f,'seconds':sec,'shot':s['id'],'old_ms':old_ms,'source_kind':ph['kind'],'source_step':ph.get('step',{}).get('n')})
    monotonic=all(b>=a for a,b in zip(mapped,mapped[1:]))
    if phase_identity_errors:issues.append(['shot_source_phase_identity',phase_identity_errors])
    oldids=set(re.findall(r'\bid="([^"]+)"',old));newids=set(re.findall(r'\bid="([^"]+)"',new))
    passed=(all(f['unchanged'] for f in functions) and data==(ORIGINAL/'replay-data.js').read_bytes() and not issues and monotonic and not oldids-newids)
    review=load(ROOT/'source-fact-review.json') if (ROOT/'source-fact-review.json').exists() else {'status':'PENDING'}
    passed=passed and review['status']=='PASS'
    report={'status':'PASS' if passed else 'FAIL_OR_PENDING','review_date_local':'2026-10-18','scope':'Source preservation, chronological interval coverage and source-level bilingual/graph factual review. This is not a rendered-frame, motion or audio-listening review.','source_commit':'884e89e58f62a185cd06572979fbd1548ea67e4b','original_index_sha256':sha(old.encode()),'enhanced_index_sha256':sha(new.encode()),'hash_note':'HTML hashes use Python read_text universal-newline normalization to LF then UTF-8 encoding. Replay-data hash is byte-for-byte.','replay_data_unchanged':data==(ORIGINAL/'replay-data.js').read_bytes(),'replay_data_sha256':sha(data),'original_render_functions':functions,'original_component_ids_preserved':not oldids-newids,'missing_ids':sorted(oldids-newids),'phase_coverage':{'original_phases':len(original['phases']),'enhanced_shots':len(shots),'original_start_ms':0,'original_end_ms':original['total'],'enhanced_duration_seconds':timeline['duration'],'enhanced_frames':timeline['total_frames'],'gaps_or_overlaps':issues,'details':details},'timing_mapping':{'monotonic_at_every_output_frame':monotonic,'formula':'First70% of type/output shot maps to94% of old interval, remaining30% to6%; others linear; finaltime clamped0.001ms below oldend.'},'authorized_visible_changes':['Center-column code/type/output scenes receive an explanatory DeepAgents tool-loop overlay; original source render functions remain unchanged but are not all simultaneously visible.','Recorded code remains available through the browser evidence control; this control is intentionally not visible in the exported video.','Every original source interval is retained in order, while file/execution/feedback events replace code typing as the central narrative.','Pet, narration, bilingual captions and highlights follow the new explanatory overlay.'],'fact_review':review,'source_hashes':{str(p.relative_to(ROOT)).replace('\\','/'):sha(p.read_bytes()) for p in [ROOT/'site/harness-flow.js',ROOT/'site/harness-flow.css',ROOT/'site/original-guide.js',ROOT/'site/enhancement.js',ROOT/'site/timeline.json',ROOT/'shotlist.json']},'blocking_issues':issues+([] if review['status']=='PASS' else ['Source content review pending'])}
    report['timing_mapping']={'monotonic_at_every_output_frame':monotonic,'shot_and_source_phase_identity_at_every_output_frame':not phase_identity_errors,'identity_errors':phase_identity_errors,'render_clock_formula':'seconds = (frame * 1000 / fps) / 1000, matching renderer seek milliseconds and enhancement conversion in that exact arithmetic order.','formula':'First 70% of type/output shot maps to 94% of old interval, remaining 30% to 6%; others linear. oldMs = max(shot.old_start_ms, min(shot.old_end_ms - 0.001, original.total - 0.001, mappedTime)); every shot is clamped independently.'}
    if a.final:
        if not passed:raise AssertionError('Cannot emit final PASS: '+json.dumps(report['blocking_issues']))
        (ROOT/'source-preservation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'written':a.final,'original_phases':len(details),'shots':len(shots),'frames':timeline['total_frames'],'render_functions_unchanged':all(f['unchanged'] for f in functions),'gaps':issues,'monotonic':monotonic,'index_sha256':report['enhanced_index_sha256']},ensure_ascii=False))
if __name__=='__main__':main()
