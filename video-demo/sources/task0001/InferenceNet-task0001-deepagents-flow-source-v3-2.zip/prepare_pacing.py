"""Prepare the approved v3.1 duration for native 30 fps rendering, not frame dropping."""
from pathlib import Path
import json
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'replay-deepagents-v3'
PACED=ROOT.parent/'replay-deepagents-v3-1'
timeline=json.loads((PACED/'presentation-timeline.json').read_text(encoding='utf-8'))
timeline.update(version='deepagents-flow-v3.2',timebase='Native 30 fps presentation clock. Source event timestamps stay unchanged.')
for name in ('timeline.json','timeline.js'):
    text=json.dumps(timeline,ensure_ascii=False,indent=2)+'\n'
    if name.endswith('.js'):text='window.TIMELINE = '+text.rstrip()+';\n'
    (ROOT/'site'/name).write_text(text,encoding='utf-8')
(ROOT/'narration-timeline.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for lang in ('en','zh','bilingual'):
    shutil.copyfile(PACED/f'captions.{lang}.srt',ROOT/f'captions.{lang}.srt')
ffmpeg=shutil.which('ffmpeg') or r'E:/ffmpeg-master-latest-win64-gpl-shared/ffmpeg-master-latest-win64-gpl-shared/bin/ffmpeg.exe'
speed=9585/8558;duration=8558/30
subprocess.run([ffmpeg,'-v','error','-y','-i',str(BASE/'audio/narration-track.wav'),
    '-af',f'atempo={speed:.15f},apad=whole_dur={duration:.12f},atrim=end={duration:.12f},asetpts=PTS-STARTPTS',
    '-ar','48000','-ac','1','-c:a','pcm_s16le',str(ROOT/'audio/narration-track.wav')],check=True)
(ROOT/'audio/pacing-metadata.json').write_text(json.dumps(dict(
    source_mix=str(BASE/'audio/narration-track.wav'),playback_speed=speed,pitch_preserved=True,
    output_seconds=duration,output_samples=round(duration*48000),
    individual_voice_clips='Original v3 clips retained as editable inputs; only the final mix has been retimed.'),indent=2)+'\n',encoding='utf-8')
for filename in ('render_all.py','render_full.mjs','finish_full.py','serve_preview.py'):
    p=ROOT/filename;s=p.read_text(encoding='utf-8')
    s=s.replace('18789','18791').replace('deepagents-flow-v3','deepagents-flow-v3-2').replace('deepagents-flow-source-v3','deepagents-flow-source-v3-2')
    if filename=='finish_full.py':
        s=s.replace('EXPECTED_AUTHORED_FRAMES = 9585','EXPECTED_AUTHORED_FRAMES = 8558').replace('9,585','8,558')
        s=s.replace('实际音频时长对应的帧对齐时间轴','已批准的提速时间轴，直接按每秒30帧渲染')
        s=s.replace('原有 WAV 与混音已经随包提供，正常重渲染不必重新调用 TTS。',
            '原始语音片段保留为编辑输入；最终 narration-track.wav 已经按1.120004674倍保音高提速。正常重渲染直接使用现有混音。重新生成语音后需同步重新调整时间轴和混音节奏。')
    p.write_text(s,encoding='utf-8')
print(json.dumps(dict(status='ready',seconds=duration,frames=8558,speed=speed)))
