"""Render the local replay artifact with three isolated, deterministic Chrome workers.

Usage: python render_all.py --stills | python render_all.py [--resume]
The server must already serve this directory at http://127.0.0.1:18791/.
Frames are preserved on failure. Explicit --resume requires unchanged source hashes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
URL = os.environ.get("RENDER_URL", "http://127.0.0.1:18791/site/index.html?pause&capture")


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path, data):
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def build_manifest(export_svg=False):
    site = ROOT / "site"
    timeline = json.loads((site / "timeline.json").read_text(encoding="utf-8-sig"))
    total = timeline.get("total_ms", float(timeline.get("duration", 0)) * 1000)
    if not isinstance(total, (int, float)) or not math.isfinite(total) or total <= 0:
        raise RuntimeError("Timeline must define a positive total_ms or duration")
    if "duration" in timeline and abs(total - float(timeline["duration"]) * 1000) > .5:
        raise RuntimeError("Timeline total_ms and duration disagree")
    if timeline.get("fps", 30) != 30:
        raise RuntimeError("Timeline fps must be 30")
    sources = []
    for path in sorted(site.rglob("*")):
        if not path.is_file():
            continue
        if not path.resolve().is_relative_to(site.resolve()):
            raise RuntimeError(f"Source link points outside site/: {path}")
        data = path.read_bytes()
        sources.append({"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    manifest = {"schema": 1, "url": URL, "engine": "svg-canvas" if export_svg else "cdp-screenshot", "total_ms": total, "fps": 30,
                "total_frames": math.ceil(total * 30 / 1000), "width": 1920, "height": 1080,
                "stage_width": 1280, "stage_height": 720, "device_scale_factor": 1.5,
                "jpeg_quality": 92, "sources": sources}
    canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    manifest["fingerprint"] = hashlib.sha256(canonical).hexdigest()
    return manifest


def jpeg_size(path):
    data = path.read_bytes()
    if not data.startswith(b"\xff\xd8") or not data.endswith(b"\xff\xd9"):
        raise RuntimeError(f"Incomplete JPEG: {path.name}")
    offset = 2
    sof = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}
    while offset < len(data) - 9:
        if data[offset] != 0xFF:
            raise RuntimeError(f"Invalid JPEG marker: {path.name}")
        offset += 1
        while data[offset] == 0xFF:
            offset += 1
        marker = data[offset]
        offset += 1
        if marker in (0xD9, 0xDA):
            break
        if marker == 1 or 0xD0 <= marker <= 0xD7:
            continue
        length = int.from_bytes(data[offset:offset + 2], "big")
        if length < 2 or offset + length > len(data):
            raise RuntimeError(f"Invalid JPEG segment: {path.name}")
        if marker in sof:
            return int.from_bytes(data[offset + 5:offset + 7], "big"), int.from_bytes(data[offset + 3:offset + 5], "big")
        offset += length
    raise RuntimeError(f"JPEG frame dimensions not found: {path.name}")


def prepare_manifest(path, manifest, resume, stills):
    out = ROOT / (("stills-svg" if manifest["engine"] == "svg-canvas" else "stills") if stills else "frames")
    existing_outputs = list(out.glob("shot-*.png" if stills else "frame_*.jpg")) if out.exists() else []
    if path.exists():
        existing = json.loads(path.read_text(encoding="utf-8"))
        if not resume:
            raise RuntimeError(f"{path.name} already exists; use explicit --resume only for the same source and parameters")
        if existing != manifest:
            raise RuntimeError("Resume refused: source files, timeline or rendering parameters changed; use a new export directory")
    elif existing_outputs:
        raise RuntimeError("Existing frames have no matching manifest; refusing to mix or overwrite them")
    else:
        atomic_json(path, manifest)
    out.mkdir(exist_ok=True)


def run_workers(args, manifest_path):
    node = shutil.which("node")
    if not node:
        raise RuntimeError("node is not available on PATH")
    workers = 1 if args.stills else args.workers
    output = queue.Queue()
    processes, readers = [], []

    def relay(index, stream):
        for line in stream:
            output.put((index, line.rstrip()))
        stream.close()

    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    try:
        for index in range(1, workers + 1):
            command = [node, str(ROOT / "render_full.mjs"), "--manifest", str(manifest_path)]
            command += ["--stills"] if args.stills else ["--part", f"{index}/{workers}"]
            if args.resume:
                command.append("--resume")
            if args.export_svg:
                command.append("--export-svg")
            process = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                       text=True, encoding="utf-8", errors="replace", bufsize=1,
                                       creationflags=creationflags)
            processes.append(process)
            reader = threading.Thread(target=relay, args=(index, process.stdout), daemon=True)
            reader.start()
            readers.append(reader)
            # Only startup is staggered. Rendering remains parallel after each
            # isolated Chrome has had a chance to create its initial target.
            if index < workers:
                time.sleep(.7)
        while any(p.poll() is None for p in processes) or any(t.is_alive() for t in readers) or not output.empty():
            try:
                index, line = output.get(timeout=.25)
                print(f"[worker {index}] {line}", flush=True)
            except queue.Empty:
                pass
        return [p.wait() for p in processes]
    except BaseException:
        # Do not remove any output. Each worker owns its own Chrome profile and cleanup.
        # SIGTERM handlers perform cleanup on supported platforms; Windows hard termination
        # may leave only that isolated temporary profile, never the user's browser profile.
        for process in processes:
            if process.poll() is None:
                process.terminate()
        for process in processes:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
        raise


def verify_completion(args, manifest, elapsed):
    if build_manifest(args.export_svg) != manifest:
        raise RuntimeError("Sources changed during export; final completion receipt withheld")
    if args.stills:
        report_path = ROOT / ("render-svg-qa.json" if args.export_svg else "render-qa.json")
        report = json.loads(report_path.read_text(encoding="utf-8"))
        if report.get("status") != "complete" or report.get("manifest") != manifest["fingerprint"] or report.get("errors"):
            raise RuntimeError("Stills QA receipt is not successful")
        print(json.dumps({"status": "complete", "mode": "stills", "stills": report["assigned"], "report": str(report_path)}))
        return
    receipts = []
    versions = set()
    total = manifest["total_frames"]
    for index in range(1, args.workers + 1):
        receipt = json.loads((ROOT / f"render-part-{index}.json").read_text(encoding="utf-8"))
        start, end = total * (index - 1) // args.workers, total * index // args.workers
        if (receipt.get("status") != "complete" or receipt.get("manifest") != manifest["fingerprint"]
                or receipt.get("part") != index or receipt.get("parts") != args.workers
                or receipt.get("start_frame") != start or receipt.get("end_frame_exclusive") != end
                or receipt.get("assigned") != end - start or receipt.get("errors")
                or receipt.get("rendered", 0) + receipt.get("skipped", 0) != end - start):
            raise RuntimeError(f"Worker {index} receipt failed completion verification")
        versions.add(receipt.get("sourceVersion"))
        receipts.append(receipt)
    if len(versions) != 1 or None in versions:
        raise RuntimeError("Workers loaded inconsistent source versions")
    expected = {f"frame_{i:05d}.jpg" for i in range(total)}
    actual = {p.name for p in (ROOT / "frames").glob("frame_*.jpg")}
    if expected != actual:
        raise RuntimeError(f"Frame continuity failed: missing={len(expected-actual)}, unexpected={len(actual-expected)}")
    byte_count = 0
    for filename in sorted(expected):
        path = ROOT / "frames" / filename
        if jpeg_size(path) != (1920, 1080):
            raise RuntimeError(f"Wrong frame dimensions: {filename}")
        byte_count += path.stat().st_size
    report = {"status": "complete", "engine": manifest["engine"], "manifest": manifest["fingerprint"], "sourceVersion": next(iter(versions)),
              "seconds": manifest["total_ms"] / 1000, "fps": 30, "frames": total, "width": 1920, "height": 1080,
              "workers": args.workers, "frames_contiguous": True, "all_image_dimensions_verified": True,
              "jpeg_bytes": byte_count, "errors": [], "elapsed_seconds": elapsed, "completed_at": utc_now(),
              "parts": [{k: r[k] for k in ("part", "start_frame", "end_frame_exclusive", "rendered", "skipped", "elapsed_seconds")} for r in receipts]}
    atomic_json(ROOT / "render-complete.json", report)
    print(json.dumps({"status": "complete", "frames": total, "elapsed_seconds": round(elapsed, 2), "report": str(ROOT / "render-complete.json")}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stills", action="store_true", help="Export one view per shot and both sides of shot transitions")
    parser.add_argument("--resume", action="store_true", help="Skip existing verified frames only with an exactly matching source manifest")
    parser.add_argument("--export-svg", action="store_true", help="Use optional six-frame SVG/canvas batches; validate stills-svg visually against default screenshots first")
    parser.add_argument("--workers", type=int, default=3, choices=range(1, 9), metavar="1..8")
    args = parser.parse_args()
    lock_path = ROOT / ".render-orchestrator.lock"
    try:
        lock = lock_path.open("x", encoding="utf-8")
    except FileExistsError:
        raise RuntimeError(f"An export lock already exists: {lock_path}. Check its recorded PID before resolving a stale lock.")
    with lock:
        lock.write(json.dumps({"pid": os.getpid(), "started": utc_now(), "stills": args.stills}))
        lock.flush()
        try:
            started = time.monotonic()
            manifest = build_manifest(args.export_svg)
            manifest_path = ROOT / (("render-svg-stills-manifest.json" if args.export_svg else "render-stills-manifest.json") if args.stills else "render-manifest.json")
            prepare_manifest(manifest_path, manifest, args.resume, args.stills)
            print(json.dumps({"seconds": manifest["total_ms"] / 1000, "frames": manifest["total_frames"], "workers": 1 if args.stills else args.workers, "manifest": manifest["fingerprint"]}), flush=True)
            codes = run_workers(args, manifest_path)
            if any(code != 0 for code in codes):
                raise RuntimeError(f"At least one worker failed ({codes}); preserved frames may be resumed explicitly after diagnosis")
            verify_completion(args, manifest, time.monotonic() - started)
        finally:
            lock.close()
            lock_path.unlink(missing_ok=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr, flush=True)
        sys.exit(1)
