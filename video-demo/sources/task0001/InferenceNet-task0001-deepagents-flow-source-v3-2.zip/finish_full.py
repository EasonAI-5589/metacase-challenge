"""Encode and package the full local replay after verified rendering completes.

Run once from any working directory: python /absolute/path/to/finish_full.py
No publishing, network access, API calls, or evaluation execution occurs here.
"""
from __future__ import annotations

from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import html
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
VIDEO = ROOT / "InferenceNet-task0001-deepagents-flow-v3-2.mp4"
BUNDLE = ROOT / "InferenceNet-task0001-deepagents-flow-source-v3-2.zip"
FFMPEG = shutil.which("ffmpeg") or str(Path("E:/ffmpeg-master-latest-win64-gpl-shared/ffmpeg-master-latest-win64-gpl-shared/bin/ffmpeg.exe"))
FFPROBE = shutil.which("ffprobe") or str(Path(FFMPEG).with_name("ffprobe.exe"))
EXPECTED_AUTHORED_FRAMES = 8558


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def run(args: list[str], logfile: str) -> subprocess.CompletedProcess:
    result = subprocess.run(args, cwd=ROOT, capture_output=True, text=True,
                            encoding="utf-8", errors="replace")
    (ROOT / logfile).write_text(result.stdout + result.stderr, encoding="utf-8")
    require(result.returncode == 0, f"{logfile}: command failed ({result.returncode}).")
    return result


def verify_inputs(timeline: dict) -> tuple[dict, dict, dict]:
    duration, frames = float(timeline["duration"]), int(timeline["total_frames"])
    require(timeline["fps"] == 30 and frames == EXPECTED_AUTHORED_FRAMES,
            "This deepagents-flow-v3-2 script expects the authored 8,558-frame, 30 fps timeline.")
    require(abs(duration - frames / 30) < 1e-8, "Timeline duration/frame count disagree.")
    require(abs(float(timeline["total_ms"]) - duration * 1000) < 0.001,
            "Timeline total_ms/duration disagree.")
    require(len(timeline["chapters"]) == 5, "Exactly five chapters are required.")
    require((ROOT / "render-complete.json").is_file(), "Wait for render-complete.json before encoding.")
    receipt = read_json(ROOT / "render-complete.json")
    render_manifest = read_json(ROOT / "render-manifest.json")
    require(receipt.get("status") == "complete" and not receipt.get("errors"),
            "Renderer did not report clean completion.")
    require(receipt.get("frames") == frames and receipt.get("fps") == 30
            and receipt.get("width") == 1920 and receipt.get("height") == 1080
            and receipt.get("frames_contiguous") is True
            and receipt.get("all_image_dimensions_verified") is True,
            "Renderer completion evidence does not match the requested video.")
    require(receipt.get("manifest") == render_manifest.get("fingerprint"),
            "Render completion refers to another source manifest.")
    layout = read_json(ROOT / "render-svg-qa.json")
    require(layout.get("status") == "complete" and not layout.get("errors")
            and layout.get("manifest") == render_manifest.get("fingerprint"),
            "Layout QA must describe the same frozen sources as the full render.")
    require(all(not sample["qa"].get("flowOverflow")
                and not any(text.get("overflow") for text in sample["qa"].get("texts", []))
                for sample in layout.get("checks", [])) and len(layout.get("checks", [])) >= 100,
            "Resolve diagram or caption overflow before encoding the deliverable.")
    require(render_manifest.get("total_frames") == frames
            and abs(float(render_manifest["total_ms"]) / 1000 - duration) < 1e-6,
            "Render manifest and current timeline disagree.")
    expected = {f"frame_{i:05d}.jpg" for i in range(frames)}
    actual = {p.name for p in (ROOT / "frames").glob("frame_*.jpg") if p.is_file()}
    require(actual == expected,
            f"Frame continuity failed: missing={len(expected-actual)}, unexpected={len(actual-expected)}.")
    require(all((ROOT / "frames" / name).stat().st_size > 1000 for name in expected),
            "A rendered frame is empty or suspiciously small.")
    for entry in render_manifest["sources"]:
        source = (ROOT / entry["path"]).resolve()
        require(source.is_relative_to((ROOT / "site").resolve()), "Render source escapes site/.")
        require(source.is_file() and sha256(source) == entry["sha256"],
                f"Source changed after rendering: {entry['path']}")
    original = ROOT / "InferenceNet-task0001-source-20261018"
    source_data = list(original.rglob("replay-data.js"))
    require(len(source_data) == 1, "Preserved upstream replay snapshot must be unambiguous.")
    snapshot = ROOT / "site" / "replay-data.js"
    require(sha256(snapshot) == sha256(source_data[0]), "Replay data differs from preserved upstream source.")
    audit = read_json(ROOT / "fact-audit.json")
    require(audit.get("snapshot_sha256") == sha256(snapshot), "Fact audit refers to another replay snapshot.")
    preservation = read_json(ROOT / "source-preservation.json")
    require(preservation.get("status") == "PASS"
            and preservation.get("replay_data_sha256") == sha256(snapshot)
            and len(preservation.get("original_render_functions", [])) == 11
            and all(item.get("unchanged") is True for item in preservation["original_render_functions"]),
            "The original scene and data preservation audit must pass before delivery.")
    require(hashlib.sha256((ROOT / "site" / "index.html").read_text(encoding="utf-8").encode("utf-8")).hexdigest()
            == preservation.get("enhanced_index_sha256"),
            "Preservation audit does not describe the current enhanced original HTML.")
    audio = ROOT / "audio" / "narration-track.wav"
    info = json.loads(run([FFPROBE, "-v", "error", "-show_format", "-show_streams", "-of", "json", str(audio)],
                          "source-audio-probe.json").stdout)
    stream = next(s for s in info["streams"] if s["codec_type"] == "audio")
    require(stream["sample_rate"] == "48000" and stream["channels"] == 1,
            "Source narration must be 48 kHz mono.")
    require(abs(float(info["format"]["duration"]) - duration) < 0.001,
            "Narration duration does not match timeline.")
    hashes = {"replay_data_sha256": sha256(snapshot), "original_replay_data_sha256": sha256(source_data[0]),
              "audio_sha256": sha256(audio), "timeline_sha256": sha256(ROOT / "site" / "timeline.json")}
    return receipt, render_manifest, hashes


def playback_chapters(timeline: dict) -> list[dict]:
    # MP4 chapter navigation includes the opening in chapter one. The authored
    # TASK card keeps its authored start; no animation or audio timing is changed.
    chapters = [dict(chapter) for chapter in timeline["chapters"]]
    chapters[0]["content_start"] = chapters[0]["start"]
    chapters[0]["start"] = 0.0
    chapters[0]["includes_opening"] = True
    return chapters


def chapter_file(timeline: dict) -> Path:
    def escape(value: str) -> str:
        return value.replace("\\", "\\\\").replace("=", "\\=").replace(";", "\\;").replace("#", "\\#").replace("\n", " ")
    lines = [";FFMETADATA1", "title=InferenceNet · task 0001 · DeepAgents execution flow",
             "comment=Recorded GPT-5.6 Sol + DeepAgents run; presentation timing is edited; English synthetic narration and bilingual captions."]
    for chapter in playback_chapters(timeline):
        lines.extend(["[CHAPTER]", "TIMEBASE=1/1000", f"START={round(chapter['start'] * 1000)}",
                      f"END={round(chapter['end'] * 1000)}", f"title={escape(chapter['zh'] + ' / ' + chapter['en'])}"])
    target = ROOT / "chapters.ffmetadata"
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target


def verify_video(path: Path, timeline: dict) -> dict:
    result = run([FFPROBE, "-v", "error", "-show_format", "-show_streams", "-show_chapters", "-of", "json", str(path)], "ffprobe.json")
    probe = json.loads(result.stdout)
    video = next(s for s in probe["streams"] if s["codec_type"] == "video")
    audio = next(s for s in probe["streams"] if s["codec_type"] == "audio")
    require((video["width"], video["height"]) == (1920, 1080), "Encoded resolution is wrong.")
    require(int(video["nb_frames"]) == timeline["total_frames"], "Encoded frame count is wrong.")
    require(Fraction(video["r_frame_rate"]) == 30 and Fraction(video["avg_frame_rate"]) == 30,
            "Encoded frame rate is not constant 30 fps.")
    require(video["codec_name"] == "h264" and video["pix_fmt"] == "yuv420p", "Video codec/pixel format mismatch.")
    require(all(video.get(key) == "bt709" for key in ["color_space", "color_transfer", "color_primaries"]),
            "BT.709 color tags missing.")
    require(abs(float(probe["format"]["duration"]) - timeline["duration"]) < 0.05,
            "Encoded duration does not match timeline.")
    require(audio["codec_name"] == "aac" and audio["sample_rate"] == "48000" and audio["channels"] == 1,
            "Encoded audio must be mono 48 kHz AAC.")
    require(abs(float(audio["duration"]) - timeline["duration"]) < 0.05, "Encoded narration is truncated.")
    require(len(probe.get("chapters", [])) == 5, "Encoded chapter count is not five.")
    for actual, expected in zip(probe["chapters"], playback_chapters(timeline)):
        require(abs(float(actual["start_time"]) - expected["start"]) < 0.002
                and abs(float(actual["end_time"]) - expected["end"]) < 0.002,
                "Encoded chapter timing does not match timeline.")
    decoded = run([FFMPEG, "-v", "error", "-i", str(path), "-map", "0:v:0", "-map", "0:a:0", "-f", "null", "-"], "decode-check.log")
    require(not decoded.stderr.strip(), "FFmpeg reported decoding errors.")
    run([FFMPEG, "-hide_banner", "-i", str(path), "-vn", "-af", "volumedetect", "-f", "null", "-"], "audio-levels.log")
    return probe


def duration_label(seconds: float) -> str:
    return f"{int(seconds // 60)}:{seconds % 60:05.2f}"


def write_preview(timeline: dict) -> None:
    buttons = []
    for i, chapter in enumerate(playback_chapters(timeline), 1):
        buttons.append(f'<button type="button" data-start="{chapter["start"]:.9f}" data-end="{chapter["end"]:.9f}"><span>{i:02}</span><strong>{html.escape(chapter["zh"])}</strong><small>{int(chapter["start"]//60)}:{int(chapter["start"]%60):02d}</small></button>')
    page = '''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>InferenceNet · DeepAgents 执行结构回放</title><style>
*{box-sizing:border-box}body{margin:0;padding:32px;background:#10161b;color:#e8edef;font:16px/1.65 system-ui,"Microsoft YaHei",sans-serif}main{max-width:1440px;margin:auto}header{display:flex;justify-content:space-between;align-items:end;gap:24px;margin-bottom:20px}.eyebrow{color:#efbd98;font-size:12px;letter-spacing:.14em;margin:0 0 4px}h1{font-size:clamp(24px,3vw,36px);font-weight:650;line-height:1.3;margin:0}.format{color:#bac7ce;white-space:nowrap}video{display:block;width:100%;border-radius:14px;background:#080c11;box-shadow:0 14px 60px #0005}.intro{color:#c0ccd2;max-width:1100px;margin:20px 0}.chapters{display:grid;grid-template-columns:repeat(5,1fr);gap:9px;margin:20px 0}button{display:flex;align-items:center;gap:9px;border:1px solid #34404a;background:#1b242c;border-radius:9px;padding:12px;color:#c8d1d7;font:inherit;text-align:left;cursor:pointer}button:hover,button:focus-visible{border-color:#efbd98;outline:none}button.active{background:#3e3025;border-color:#d4a279;color:#ffe0c6}button span{font-size:12px;color:#deaf8d}button strong{font-size:14px;font-weight:550}button small{font-size:12px;margin-left:auto;color:#a9b6be}a{color:#efbd98;text-underline-offset:3px}.notes{font-size:14px;color:#95a7b3;margin:18px 0}.links{display:flex;flex-wrap:wrap;gap:18px}@media(max-width:850px){body{padding:16px}header{display:block}.format{margin-top:10px}.chapters{grid-template-columns:repeat(2,1fr)}button:last-child{grid-column:span 2}}
</style></head><body><main><header><div><p class="eyebrow">TASK 0001 · GPT-5.6 SOL + DEEPAGENTS</p><h1>InferenceNet · DeepAgents 执行结构回放</h1></div><div class="format">__DURATION__ · 1080p · 30 fps</div></header>
<video id="replay" controls playsinline preload="metadata" poster="poster.jpg"><source src="__VIDEO__" type="video/mp4">浏览器暂不支持此视频，请下载 MP4 播放。</video>
<p class="intro">跟随像素向导，展开每一轮 DeepAgents 执行流程：模型请求如何进入工具、沙箱怎样读取数据和执行计算、观察结果如何返回模型。保留原版三栏、任务细节、实际数值、预算拦截和独立评分，配有英文讲解与中英双语字幕。点击播放并打开声音；下方按钮可跳转到对应章节。</p>
<nav class="chapters" aria-label="跳转章节">__BUTTONS__</nav>
<p class="notes">真实记录耗时 121.038 秒；视频采用放慢后的讲解时间轴。数值来自随源码提供的运行快照，参考值采用网站公开的舍入精度。三项通过表示满足本题评分容限，并非逐位完全相等。4 次交互工具执行与最终评分器执行分别展示。</p>
<p class="links"><a href="__VIDEO__" download>下载完整版 MP4</a><a href="__BUNDLE__" download>下载可编辑源码与配音</a><a href="captions.bilingual.srt" download>下载双语字幕</a><a href="site/index.html?pause">打开可编辑动画预览</a></p>
</main><script>const video=document.querySelector('#replay');const buttons=[...document.querySelectorAll('[data-start]')];for(const button of buttons)button.addEventListener('click',()=>{video.currentTime=Number(button.dataset.start);video.focus();});video.addEventListener('timeupdate',()=>{for(const button of buttons){const t=video.currentTime+.001;const active=t>=Number(button.dataset.start)&&t<Number(button.dataset.end);button.classList.toggle('active',active);button.setAttribute('aria-current',active?'true':'false');}});</script></body></html>'''
    for old, new in [("__DURATION__", duration_label(timeline["duration"])), ("__VIDEO__", VIDEO.name),
                     ("__BUNDLE__", BUNDLE.name), ("__BUTTONS__", "\n".join(buttons))]:
        page = page.replace(old, new)
    (ROOT / "preview.html").write_text(page, encoding="utf-8")


def write_readme(timeline: dict) -> None:
    content = f'''InferenceNet · task0001 · DeepAgents 执行结构回放 v3.2

交付文件：{VIDEO.name}
时长：{duration_label(timeline['duration'])}（{timeline['duration']:.9f} 秒）
视频：1920 × 1080，30 fps，{timeline['total_frames']:,} 帧，H.264 / yuv420p / BT.709。
声音：英文合成旁白 en-US-AriaNeural，原始片段 -5% 语速，最终混音保音高提速 1.120004674 倍，AAC 48 kHz 单声道。
字幕：中英双语烧录字幕，另附英文、中文和双语 SRT。
结构：原版五章、37 个讲解段，完整保留原 32 个阶段，包含可移动像素向导、指挥棒、同步高光及像素粒子。

本版动画修复
  保留 v3.1 已批准的 285.266667 秒节奏、讲稿与字幕，按新时间轴直接生成全部 8,558 帧；没有对旧 MP4 抽帧提速。
  将原时间限制在各镜头结束前，消除循环末尾单帧误入下一状态导致的宠物闪跳。
  宠物和指挥棒使用连续轨迹，流程光点沿文字外的圆角通道返回，各阶段共享端点。
  首次侧栏、章节切换及换卡内容连续淡入淡出，保持流程外框稳定。

来源与事实边界
  GitHub: EasonAI-5589/inferencenet-challenge, branch codex/video-demo
  固定提交：884e89e58f62a185cd06572979fbd1548ea67e4b
  源码位置：video-demo/task0001
  任务：0001；模型：GPT-5.6 Sol；Harness：DeepAgents。
  真实运行 ID：sol-deepagents-full1000-20260911-chain-03。
  replay-data.js 与收到的原始源码快照逐字节一致。原始私人 trace 不在此包内，
  本片依据的是随源码提供的派生快照及 provenance；没有重新执行模型评测。
  保留原版五章、三栏、六项子问题、用量、真实输出数值、预算拦截和评分解锁。中栏改为 DeepAgents 执行结构；原代码摘录在交互预览中可辅助展开。
  原 renderAt 与场景渲染函数未被重写；harness-flow.js 在执行阶段叠加图形结构，enhancement.js 将原 71.4 秒连续映射到新的讲解时间轴。
  原 cap-main 摘要由等义双语旁白替代，原 cap-sub 技术日志迁至底部；原始源码副本保持不变。
  记录中的运行耗时为 121.038 秒，视频时间不表示真实运行耗时。
  4 次交互工具调用与最终评分器运行分开计算；超预算请求没有被表现为第五次执行。
  参考数值采用网站公开的舍入值，不声称额外的原始精度。
  系数和标准误使用相对误差容限，p 值使用绝对误差容限；通过不等于逐位完全相等。
  完整复现结论仅指本题在给定规则下三项通过，不代表整个 benchmark 的结论。
  46,496 是总记录 token 数，不是输出 token 数或费用。
  向导、粒子、光效、声音和较慢展示节奏是演示元素，不是实际运行事件。

查看
  直接打开 MP4，或在此目录启动：
    python serve_preview.py --port 18791
  成片播放器：http://127.0.0.1:18791/preview.html
  可编辑动画：http://127.0.0.1:18791/site/index.html?pause
  播放器不自动播放；点击播放并打开声音。章节按钮可定位到相应位置。
  MP4 与播放器第一章从 0 秒开始，包含片头；画面中的 TASK 章卡在 {timeline['chapters'][0]['start']:.1f} 秒出现。
  源码 ZIP 不包含 MP4，将 MP4 与解压后的 preview.html 放在同一目录即可观看成片。

编辑与重新导出
  site/：动画、DeepAgents 执行结构、像素向导、字体及原始 replay-data.js。工具/文件访问只表达派生快照能证实的动作；run_python 和预算边界属于本次接入。
  shotlist.json：37 个镜头的中英文讲稿与最短停留时间。
  site/timeline.json / timeline.js：已批准的提速时间轴，直接按每秒30帧渲染。
  audio/：36 段 WAV、最终混音、生成脚本与音频检查证据。
  captions.*.srt：匹配旁白时间轴的独立字幕。
  原始源码保存在 InferenceNet-task0001-source-20261018/ 和 original-source.zip。

  环境：Python 3、Node.js（支持全局 WebSocket）、Chrome、FFmpeg/FFprobe。
  全部命令均从解压目录运行，先启动上面的 localhost 服务：
    python render_all.py --stills --export-svg --resume
    python render_all.py --export-svg --resume
    python finish_full.py
  使用已核验的 SVG/canvas 导出路径，默认三个独立无界面 Chrome worker。
  FFmpeg 使用 CRF 18 / medium。源码包带有当前 manifests，不带已渲染帧，
  因此上面使用 --resume：源码哈希一致时会在空输出目录重新导出全部帧。
  当前 manifests 为 render-manifest.json 和 render-svg-stills-manifest.json。
  需要更改端口时，对 render_all.py 设置 RENDER_URL；Chrome 路径见 render_full.mjs。
  已有渲染证据存在时，只能对完全相同源码使用 --resume。
  修改镜头后应在新的导出目录生成新帧，不要混用旧帧、旧 manifest 或旧时间轴。
  prepare_pacing.py 是本次制作的历史准备脚本，需要相邻 v3/v3.1 工作目录；本包已包含完成后的素材，正常重新渲染无需运行它。
  finish_full.py 只在 render-complete.json 核验通过且连续 8,558 帧齐全时合成；
  如改变总时长/帧数，请同步审阅脚本内 EXPECTED_AUTHORED_FRAMES。
  finish_full.py 保留已经存在的正式 MP4，需要再次合成时请使用新导出目录。

  如需重新生成配音：
    python -m pip install edge-tts==7.3.1 numpy
    python audio/generate_voice.py
  音频生成需要访问 Edge TTS；不使用 API key。重新生成后必须重新渲染时间轴。
  原始语音片段保留为编辑输入；最终 narration-track.wav 已经按1.120004674倍保音高提速。正常重渲染直接使用现有混音。重新生成语音后需同步重新调整时间轴和混音节奏。

验证
  fact-audit.json：派生快照的历史事实核查，不能代替本版全部旁白的审查。
  source-fact-review.json：本版37段中英文与执行结构的事实核对。
  source-preservation.json / harness-evidence.json：原时间顺序、派生快照和实际工具/文件/执行事件的证据边界。
  render-svg-qa.json：当前 SVG/canvas 路径的静帧/布局/脚本错误检查。
  render-svg-stills-manifest.json：当前静帧导出的源码与参数清单。
  render-manifest.json：当前全片导出的源码与参数清单。
  render-complete.json / render-part-*.json：连续帧与 worker 完成回执。
  ffprobe.json：编码参数、帧数、时间轴及内嵌章节。
  decode-check.log：完整音视频解码检查（通过时为空）。
  audio/voice-metadata.json：原 v3 片段和混音的历史生成证据，其中旧总时长不代表本版。
  audio/pacing-metadata.json / source-audio-probe.json：本版保音高处理、混音时长和采样参数。
  audio/transcription-check.json：原讲稿的历史自动可懂度检查，本次未重新转录，不等同于主观试听。
  guide-motion-continuity-review.json：当前逐帧与边界的源代码几何核验，不等同于成片动态审查。
  clock-boundary-review.json / dynamic-visual-review.json / outro-seek-review.json：精确输出时钟与选定连续画面的审查；其详细截图保存在制作工作区的 video-pr-review-v3-2 中。
  delivery.json：最终 MP4、原始数据、时间轴和混音哈希。

源码包排除了渲染帧、MP4、浏览器 profile、依赖目录和音频缓存签名。
此导出脚本只生成本地文件，不会自动发布网站、推送 GitHub 或合并 PR。
'''
    (ROOT / "README.txt").write_text(content, encoding="utf-8")


def package_source() -> None:
    files: set[Path] = set()
    # Initial CDP layout evidence predates the final CSS adjustments; do not
    # ship it as if it described the verified final SVG/canvas export.
    excluded_root_names = {"render-stills-manifest.json", "render-qa.json"}
    root_names = {"original-source.zip", "source-download.json", "README.txt", "preview.html", "poster.jpg",
                  "chapters.ffmetadata", "decode-check.log", "audio-levels.log", "encode.log", "poster-export.log"}
    for path in ROOT.iterdir():
        if (path.is_file() and path.name not in excluded_root_names
                and (path.name in root_names or path.suffix in {".py", ".mjs", ".cjs", ".json", ".srt"})):
            files.add(path)
    for folder in [ROOT / "site", ROOT / "InferenceNet-task0001-source-20261018"]:
        for path in folder.rglob("*"):
            if path.is_file() and not any(part.startswith(".") for part in path.relative_to(folder).parts):
                require(path.resolve().is_relative_to(folder.resolve()), "Package source escapes its directory.")
                files.add(path)
    for path in (ROOT / "audio").iterdir():
        if (path.is_file() and path.suffix in {".wav", ".py", ".ps1", ".json", ".txt"}
                and not path.name.endswith(".cache.json")):
            files.add(path)
    with zipfile.ZipFile(BUNDLE, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(files):
            archive.write(path, path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(BUNDLE) as archive:
        require(archive.testzip() is None, "Editable source archive CRC check failed.")
        names = set(archive.namelist())
        require({"site/index.html", "site/timeline.json", "audio/narration-track.wav", "delivery.json",
                 "render_all.py", "render_full.mjs", "finish_full.py", "fact-audit.json",
                 "render-manifest.json", "render-svg-stills-manifest.json", "render-svg-qa.json"}.issubset(names),
                "Editable source archive is missing required files.")
        require(not names.intersection(excluded_root_names), "Archive contains superseded CDP layout evidence.")
        require(not any(name.startswith(("frames/", ".profiles/", ".render-profiles/"))
                        or "/.deps/" in name or name.endswith((".mp4", ".cache.json")) for name in names),
                "Editable source archive contains excluded render/cache files.")


def main() -> None:
    require(not VIDEO.exists(), f"Formal video already exists; preserve it and use a new export directory: {VIDEO}")
    timeline = read_json(ROOT / "site" / "timeline.json")
    receipt, render_manifest, hashes = verify_inputs(timeline)
    metadata = chapter_file(timeline)
    temporary = ROOT / "InferenceNet-task0001-deepagents-flow-v3-2.encoding.mp4"
    print(json.dumps({"stage": "encoding", "frames": timeline["total_frames"], "seconds": timeline["duration"]}), flush=True)
    run([FFMPEG, "-hide_banner", "-y", "-framerate", "30", "-start_number", "0",
         "-i", str(ROOT / "frames" / "frame_%05d.jpg"), "-i", str(ROOT / "audio" / "narration-track.wav"),
         "-f", "ffmetadata", "-i", str(metadata), "-map", "0:v:0", "-map", "1:a:0",
         "-map_metadata", "2", "-map_chapters", "2", "-vf",
         # Browser JPEGs carry an ICC profile. Strip it after converting the
         # matrix/range so MP4 writes explicit BT.709 nclx/VUI color properties
         # instead of letting the inherited ICC profile suppress those tags.
         "scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p,"
         "sidedata=mode=delete:type=ICC_PROFILE,"
         "setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709",
         "-color_range", "tv", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
         "-c:v", "libx264", "-preset", "medium", "-crf", "18",
         "-x264-params", "colorprim=bt709:transfer=bt709:colormatrix=bt709",
         "-c:a", "aac", "-b:a", "192k",
         "-ar", "48000", "-ac", "1", "-t", f"{timeline['duration']:.9f}", "-movflags", "+faststart", str(temporary)], "encode.log")
    print(json.dumps({"stage": "verifying", "file": temporary.name}), flush=True)
    probe = verify_video(temporary, timeline)
    shape = next(shot for shot in timeline["shots"] if shot["id"] == "step1-output")
    poster_time = shape["start"] + shape["duration"] * .8
    run([FFMPEG, "-hide_banner", "-y", "-ss", f"{poster_time:.9f}", "-i", str(temporary),
         "-frames:v", "1", "-q:v", "2", str(ROOT / "poster.jpg")], "poster-export.log")
    temporary.replace(VIDEO)
    # ffprobe inspected these exact bytes before the atomic promotion.
    probe["format"]["filename"] = str(VIDEO)
    write_json(ROOT / "ffprobe.json", probe)
    video = next(s for s in probe["streams"] if s["codec_type"] == "video")
    audio = next(s for s in probe["streams"] if s["codec_type"] == "audio")
    write_preview(timeline)
    write_readme(timeline)
    manifest = {"status": "verified", "created_utc": datetime.now(timezone.utc).isoformat(),
                "file": VIDEO.name, "sha256": sha256(VIDEO), "bytes": VIDEO.stat().st_size,
                "duration_seconds": float(probe["format"]["duration"]), "timeline_seconds": timeline["duration"],
                "frames": int(video["nb_frames"]), "fps": video["r_frame_rate"], "resolution": [1920, 1080],
                "video_codec": video["codec_name"], "pixel_format": video["pix_fmt"], "color_space": "bt709",
                "audio_codec": audio["codec_name"], "audio_sample_rate": audio["sample_rate"], "audio_channels": audio["channels"],
                "audio_is_synthetic": True, "voice": "en-US-AriaNeural", "burned_captions": ["en", "zh"],
                "chapters": playback_chapters(timeline), "authored_chapters": timeline["chapters"],
                "decode_errors": 0, "poster_seconds": poster_time,
                "source_commit": timeline["source_commit"], "render_manifest_fingerprint": render_manifest["fingerprint"],
                "render_workers": receipt["workers"], "replay_data_unchanged": True,
                "scope": "Recorded task0001 sequence preserved; the execution panels show the configured DeepAgents tool loop and observed file operations, with independent evaluator boundaries.",
                "recorded_run_seconds": 121.038, "source_bundle": BUNDLE.name,
                "version": "deepagents-flow-v3.2", "native_render": True,
                "native_render_note": "Every output frame was directly evaluated at frame * 1000 / 30 milliseconds. No retiming or frame dropping of a prior MP4.",
                "pacing_matches_version": "deepagents-flow-v3.1", "pacing_factor_relative_to_v3": 9585 / 8558,
                "pitch_preserved": True, "audio_processing": "Original v3 lossless mix, atempo=1.1200046739892497, padded/trimmed to 13692800 samples at 48 kHz.",
                "shots_preserved": 37, "scene_order_unchanged": True, "caption_text_unchanged": True,
                "motion_changes": ["Per-shot source-time clamp prevents one-frame phase mismatch", "Continuous pet and baton paths", "Signal endpoints and rounded return route", "Smooth initial panes, chapter cards and loop text changes", "Sequential result/outro foregrounds avoid overlapping titles"], **hashes}
    write_json(ROOT / "delivery.json", manifest)
    print(json.dumps({"stage": "packaging", "source_bundle": BUNDLE.name}), flush=True)
    package_source()
    print(json.dumps({"status": "complete", "video": str(VIDEO), "seconds": manifest["duration_seconds"],
                      "frames": manifest["frames"], "video_bytes": manifest["bytes"], "sha256": manifest["sha256"],
                      "source_bundle": str(BUNDLE), "source_bundle_bytes": BUNDLE.stat().st_size,
                      "preview": str(ROOT / "preview.html"), "delivery": str(ROOT / "delivery.json")}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
