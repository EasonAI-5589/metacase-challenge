"""Shot timing from the narration, caption cues, SRT export and the narration mix."""
from __future__ import annotations

import importlib
import json
import os
import re
import subprocess

import numpy as np

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
FPS = 30
SR = 48000
LEAD = 0.32      # silence before each shot's first word
TAIL = 0.62      # breath after the last word
CHAPTER_GAP = 0.45  # extra pause when a new chapter begins
MARK = re.compile(r"\{([a-z0-9_]+)\}")


class Shot:
    def __init__(self, d, v, start):
        self.__dict__.update(d)
        self.d = d
        self.v = v
        self.speech = v["speech_t1"] - v["speech_t0"]
        self.lead = LEAD + d.get("pre", 0.0)
        self.start = start
        self.dur = self.lead + self.speech + TAIL + d.get("hold", 0.0)
        self.end = start + self.dur
        # cue times relative to shot start
        self.cues = {k: self.lead + (t - v["speech_t0"]) for k, t in v["cues"].items()}
        self.cues["_end"] = self.lead + self.speech
        self.en = d.get("en") or MARK.sub("", d["say"]).replace("  ", " ").strip()
        self.words = [dict(w, t0=self.lead + w["t0"] - v["speech_t0"], t1=self.lead + w["t1"] - v["speech_t0"]) for w in v["words"]]

    def cue(self, name, default=None):
        if isinstance(name, (tuple, list)):
            return self.cue(name[0], default) + float(name[1])
        if isinstance(name, (int, float)):
            return float(name)
        if name in self.cues:
            return self.cues[name]
        return self.lead if default is None else default

    def trace_at(self, t):
        tr = self.d.get("trace")
        if tr is None:
            return None
        tk = self.d.get("tk")
        if tk:
            pts = sorted((self.cue(c), float(v)) for c, v in tk)
            if t <= pts[0][0]:
                return pts[0][1]
            for (a, va), (b, vb) in zip(pts, pts[1:]):
                if t <= b:
                    f = 0 if b <= a else (t - a) / (b - a)
                    return va + (vb - va) * f
            return pts[-1][1]
        t0, t1 = tr
        a, b = self.lead, max(self.lead + 0.1, self.dur - TAIL)
        f = min(1.0, max(0.0, (t - a) / (b - a)))
        return t0 + (t1 - t0) * f


class Timeline:
    def __init__(self, run):
        self.run = run
        self.story = importlib.import_module(f"story.{run}")
        with open(os.path.join(ROOT, "build", run, "voice.json"), encoding="utf-8") as f:
            vm = {v["id"]: v for v in json.load(f)}
        # The portable cache stores project-relative audio paths, independent of cwd.
        for v in vm.values():
            if not os.path.isabs(v["mp3"]):
                v["mp3"] = os.path.normpath(os.path.join(ROOT, v["mp3"]))
        self.shots = []
        t = 0.0
        prev_ch = None
        for d in self.story.SHOTS:
            if prev_ch is not None and d["ch"] != prev_ch:
                t += CHAPTER_GAP
            s = Shot(d, vm[d["id"]], t)
            self.shots.append(s)
            t = s.end
            prev_ch = d["ch"]
        self.duration = t + 0.5
        self.nframes = int(round(self.duration * FPS))
        self.chapters = []
        for ch in range(5):
            ss = [s for s in self.shots if s.ch == ch]
            self.chapters.append((ss[0].start, ss[-1].end) if ss else (0, 0))

    def locate(self, T):
        for i, s in enumerate(self.shots):
            if T < s.end or i == len(self.shots) - 1:
                if T < s.start and i > 0:  # inside a chapter gap: hold the previous shot
                    p = self.shots[i - 1]
                    return p, p.dur + (T - p.end), i - 1
                return s, T - s.start, i
        return self.shots[-1], T - self.shots[-1].start, len(self.shots) - 1

    def chapter_progress(self, ch, T):
        a, b = self.chapters[ch]
        return 0.0 if b <= a else min(1.0, max(0.0, (T - a) / (b - a)))

    # ------------------------------------------------------------------ captions
    def cues(self):
        out = []
        for s in self.shots:
            a = s.start + s.lead - 0.05
            b = s.start + s.lead + s.speech + 0.3
            out.append((a, b, s.en, s.zh))
        return out

    def write_srt(self, path_base):
        def ts(x):
            ms = int(round(x * 1000))
            h, ms = divmod(ms, 3600000)
            m, ms = divmod(ms, 60000)
            sec, ms = divmod(ms, 1000)
            return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"
        cues = self.cues()
        for lang in ("en", "zh", "bilingual"):
            lines = []
            for i, (a, b, en, zh) in enumerate(cues, 1):
                body = en if lang == "en" else zh if lang == "zh" else f"{en}\n{zh}"
                lines.append(f"{i}\n{ts(a)} --> {ts(b)}\n{body}\n")
            with open(f"{path_base}.{lang}.srt", "w", encoding="utf-8", newline="\n") as f:
                f.write("\n".join(lines))

    # ------------------------------------------------------------------ audio
    def mix(self, wav_out):
        n = int(round(self.nframes / FPS * SR))
        buf = np.zeros(n, dtype=np.float32)
        for s in self.shots:
            raw = subprocess.check_output([FFMPEG, "-v", "error", "-i", s.v["mp3"], "-f", "f32le", "-ac", "1",
                                           "-ar", str(SR), "-"])
            x = np.frombuffer(raw, dtype=np.float32)
            off = int(round((s.start + s.lead - s.v["speech_t0"]) * SR))
            off = max(0, off)
            end = min(n, off + len(x))
            buf[off:end] += x[: end - off]
        tmp = wav_out + ".raw.f32"
        buf.tofile(tmp)
        subprocess.check_call([FFMPEG, "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", tmp,
                               "-af", "loudnorm=I=-16.5:TP=-1.5:LRA=7", "-ar", str(SR), "-c:a", "pcm_s16le", wav_out])
        os.remove(tmp)
        return wav_out
