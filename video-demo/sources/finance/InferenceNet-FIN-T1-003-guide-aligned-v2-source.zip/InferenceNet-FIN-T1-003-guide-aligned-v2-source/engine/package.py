"""Package the finance guide alignment with its source and validation records.

usage: python engine/package.py fin
Requires the full build/fin/fin.mp4 and its render-time font-selection sidecar.
"""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import compose  # noqa: E402
import rundata  # noqa: E402
from timeline import FPS  # noqa: E402

FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
FFPROBE = os.environ.get("FFPROBE", "ffprobe")
VERSION = "finance-guide-aligned-v2"
REFERENCE_JS = "replay-deepagents-v3-2/site/original-guide.js"
REFERENCE_SHA256 = "9246340ec582e46bdc2339a8824deba064ec2fa30dbb3be9c6839ee815b95e68"
UPSTREAM_ARCHIVE_SHA256 = "0e6576985e25ef5ab8cb512f13b4068f4a13c7680570215d1027a03651befbb7"
UPSTREAM_VIDEO_SHA256 = "d8792c91fa0cc43e107cae89e5be901bb4d19028cba243fc166327d1aa3b65be"
NAMES = {"fin": ("finance-story-demo", "finance")}
POSTER = {"fin": ("f09", ("back", 1.2))}
CHAPTERS = ["TASK", "AGENT", "HARNESS", "CHECK", "RESULT"]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def relative(path):
    """Public source paths are relative to this portable source root."""
    return Path(path).resolve().relative_to(Path(ROOT).resolve()).as_posix()


def write_json(path, value):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def read_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def run_checked(command):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError(
            f"Command failed ({result.returncode}): {command!r}\n"
            + result.stderr.decode("utf-8", errors="replace"))
    return result.stdout


def probe(path):
    out = run_checked([FFPROBE, "-v", "error", "-show_entries",
                                   "stream=codec_type,codec_name,profile,width,height,pix_fmt,color_space,color_primaries,color_transfer,color_range,r_frame_rate,nb_frames,sample_rate,channels:format=duration,size",
                                   "-of", "json", path])
    return json.loads(out)


def reference_details():
    import reference_pet as pet
    elements = [{"name": "tail", "path": pet._TAIL[0], "color": pet._TAIL[1]}]
    for i, foot in enumerate(pet._FEET):
        elements.extend({"name": f"foot_{i}_{j}", "path": path, "color": color}
                        for j, (path, color) in enumerate(foot))
    elements.extend({"name": f"body_{i}", "path": path, "color": color}
                    for i, (path, color) in enumerate(pet._BODY))
    elements += [
        {"name": "mouth", "path": pet._IDLE_MOUTH, "color": "#965c48"},
        {"name": "cheeks", "path": pet._CHEEKS[0], "color": pet._CHEEKS[1]},
    ]
    if len(elements) != 14:
        raise RuntimeError("Expected the reference pet's 14 SVG path elements")
    return {
        "reference_edition": "task0001 v3.2",
        "reference_file": REFERENCE_JS,
        "reference_sha256": REFERENCE_SHA256,
        "implementation": "engine/reference_pet.py",
        "implementation_sha256": sha(os.path.join(HERE, "reference_pet.py")),
        "svg_path_elements": elements,
        "svg_path_element_count": len(elements),
        "moving_mouth_alternative": pet._MOVING_MOUTH,
        "path_count_note": "14 SVG elements; the mouth has two authored animation states.",
        "source_svg_viewbox": [0, 0, 24, 22],
        "output_svg_unit_pixels": pet.SVG_UNIT,
        "scale_relative_to_task0001_css_pet": pet.REFERENCE_SCALE,
        "reference_files_sha256": {
            relative(path): sha(path)
            for path in sorted(Path(ROOT, "reference", "task0001-v3.2").glob("*")) if path.is_file()
        },
        "orientation_policy": "Fixed right-facing reference pet; no mirroring or turning.",
        "entrance_exit_policy": "Entrance and exit follow the task0001 v3.2 reference animation and timing relationship.",
        "scope": "Original pet paths, colors and unmirrored pose equations translated to Skia, plus the reference whole opening and ending presentation. Finance retains its 93-cue narration and financial facts.",
        "bookends": {
            "source": "reference/task0001-v3.2/index.html",
            "source_sha256": "d229957a3c3b48d3369d817d33427d2845a47e4011e07dff9d103d0bf83a93d7",
            "implementation": "engine/reference_bookends.py",
            "opening": "84 seeded floating glyphs and original role icons converge; original logo back-easing and staggered title reveal.",
            "ending": "Original spotlight, logo, rule and sequential copy reveal; the compositor keeps result and ending foregrounds mutually exclusive.",
            "timing": "Original 5000/5200 ms presentation clocks fit the existing finance opening/ending durations; narration, captions and audio are unchanged.",
            "copy": "Existing finance role values, task ID, English/Chinese title and ending text retained; particle words use finance evidence.",
        },
    }


def portable_font_record(source_path):
    """Retain the renderer's selections without publishing workstation paths."""
    record = read_json(source_path)
    for face in record["fonts"].values():
        source = face["source"]
        path = Path(source)
        if path.is_file():
            face["font_file_sha256"] = sha(path)
            try:
                face["source"] = relative(path)
                face["source_base"] = "editable source root"
            except ValueError:
                face["source"] = f"system-fonts/{path.name}"
                face["source_base"] = "Operating-system font directory; font not redistributed"
        else:
            if path.is_absolute():
                raise FileNotFoundError(f"The font recorded by the render is no longer available: {source}")
            face["source"] = source.replace("\\", "/")
    return record


def runtime_versions():
    packages = {}
    for name in ("skia-python", "numpy", "pybind11", "fonttools", "Brotli", "Pillow"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    return {
        "python": platform.python_version(),
        "platform": platform.system(),
        "packages": packages,
        "ffmpeg": run_checked([FFMPEG, "-version"]).decode("utf-8", errors="replace").splitlines()[0],
        "ffprobe": run_checked([FFPROBE, "-version"]).decode("utf-8", errors="replace").splitlines()[0],
        "phase": "packaging runtime",
    }


def main(run):
    if run not in NAMES:
        raise ValueError("This portable delivery contains only the fin run")
    ctx = compose.Ctx(run)
    tl = ctx.tl
    name, doc = NAMES[run]
    build = os.path.join(ROOT, "build", run)
    source_mp4 = os.path.join(build, f"{run}.mp4")
    source_fonts = os.path.join(build, f"{run}.font-selection.json")
    source_receipt = os.path.join(build, f"{run}.render-receipt.json")
    for required in (source_mp4, source_fonts, source_receipt):
        if not os.path.isfile(required):
            raise FileNotFoundError(f"Full render artifact is missing: {required}")
    render_receipt = read_json(source_receipt)
    if render_receipt["output_sha256"] != sha(source_mp4):
        raise RuntimeError("Full video does not match its render receipt")
    packaging_only_changes = {}
    for path, expected in render_receipt["inputs"]["source_sha256"].items():
        actual_path = Path(ROOT, path).resolve()
        actual_path.relative_to(Path(ROOT).resolve())
        actual = sha(actual_path)
        if actual != expected:
            if path != "engine/package.py":
                raise RuntimeError(f"Rendered input changed before packaging: {path}")
            # This CLI runs after rendering and is not imported by the renderer.
            # Keep the immutable receipt and disclose its packaging-only change.
            packaging_only_changes[path] = {
                "render_time_sha256": expected,
                "packaging_time_sha256": actual,
                "reason": "Correct font-loop variable shadowing of the delivery media name; no frame or audio code changed.",
            }
    rendered_fonts = render_receipt["inputs"]["font_sha256"]
    selected_fonts = read_json(source_fonts)["fonts"]
    if set(rendered_fonts) != set(selected_fonts):
        raise RuntimeError("Font selections do not match the render receipt")
    for font_name, expected in rendered_fonts.items():
        if sha(selected_fonts[font_name]["source"]) != expected:
            raise RuntimeError(f"Rendered font changed before packaging: {font_name}")
    from render import verify_video
    verify_video(source_mp4, tl.nframes)
    for lang in ("en", "zh", "bilingual"):
        generated = Path(build, f"captions.{lang}.srt").read_bytes()
        original = Path(ROOT, "docs", f"captions.{lang}.srt").read_bytes()
        if generated != original:
            raise RuntimeError(f"The rendered {lang} captions differ from the supplied finance edition")
    src_files = sorted(Path(ROOT, "engine").glob("*.py"))
    src_files += [Path(ROOT, "story", "fin.py"), Path(ROOT, "README-guide-aligned.md"),
                  Path(ROOT, "requirements-render.txt")]
    source_hashes = {relative(f): sha(f) for f in src_files}
    # Re-audit the current geometry at packaging so a stale preview report is not
    # presented as evidence for an edited guide. No raster render or model call.
    from check_guide import audit
    qa = audit()
    qa["source_snapshot_sha256"] = source_hashes
    qa["source_snapshot_phase"] = "packaging"
    qa_path = os.path.join(build, "guide-geometry-qa.json")
    write_json(qa_path, qa)
    if not qa["passed"]:
        raise RuntimeError(f"Guide geometry/source preservation audit failed; inspect {relative(qa_path)}")
    out_v = os.path.join(ROOT, "deliver", "assets", "video")
    out_d = os.path.join(ROOT, "deliver", "docs", "video", doc)
    os.makedirs(out_v, exist_ok=True)
    os.makedirs(out_d, exist_ok=True)
    mp4 = os.path.join(out_v, f"{name}.mp4")
    shutil.copyfile(source_mp4, mp4)
    sid, c = POSTER[run]
    sh = next(s for s in tl.shots if s.id == sid)
    png = os.path.join(build, "poster.png")
    compose.render_still(ctx, sh.start + sh.cue(c), png)
    poster = os.path.join(out_v, f"{name}-poster.jpg")
    run_checked([FFMPEG, "-v", "error", "-y", "-i", png, "-q:v", "2", poster])
    for lang in ("en", "zh", "bilingual"):
        shutil.copyfile(os.path.join(build, f"captions.{lang}.srt"), os.path.join(out_d, f"captions.{lang}.srt"))
    shutil.copyfile(qa_path, os.path.join(out_d, "guide-geometry-qa.json"))
    shutil.copyfile(source_receipt, os.path.join(out_d, "render-receipt.json"))
    fonts_path = os.path.join(out_d, "font-selection.json")
    write_json(fonts_path, portable_font_record(source_fonts))
    shutil.copyfile(os.path.join(ROOT, "README-guide-aligned.md"), os.path.join(out_d, "README.md"))
    run_data = rundata.load(run)
    data_path, log_glob = rundata.SOURCES[run]
    import glob
    logs = glob.glob(log_glob)
    if len(logs) != 1:
        raise RuntimeError(f"Expected one request metadata file, found {len(logs)}")
    log = logs[0]
    p = probe(mp4)
    chapters = []
    for i, (a, b) in enumerate(tl.chapters):
        chapters.append({"name": CHAPTERS[i], "start_seconds": round(a, 3), "end_seconds": round(b, 3)})
    shots = [{"id": s.id, "chapter": CHAPTERS[s.ch], "kind": s.kind, "start_seconds": round(s.start, 3),
              "end_seconds": round(s.end, 3), "narration_en": s.en, "caption_zh": s.zh,
              "trace_seconds": s.d.get("trace")} for s in tl.shots]
    prov = {
        "version": VERSION,
        "task_id": ctx.conf["task_id"],
        "run": run,
        "status": "awaiting user review",
        "model": "qwen3.7-max", "harness": "Claude Code 2.1.114", "runner": "Harbor 0.20.0",
        "judge_model": ctx.conf["chips"][3][1],
        "recorded_agent_seconds": run_data.duration,
        "model_requests": len(run_data.requests), "tool_calls": len(run_data.tool_steps),
        "reward": run_data.result["reward"],
        "duration_seconds": round(float(p["format"]["duration"]), 3),
        "frames": tl.nframes, "fps": f"{FPS}/1", "resolution": [1920, 1080],
        "streams": p["streams"],
        "voice": "en-US-AriaNeural (same voice as the approved PR #27 replay), rate +12% to match its 1.12 pacing",
        "audio_is_synthetic": True,
        "audio_processing": "per-shot neural TTS clips placed on the shot timeline, loudnorm I=-16.5 LUFS, AAC 48 kHz mono",
        "burned_captions": ["en", "zh"],
        "renderer": "offline Skia (skia-python) frame renderer; no browser, no CDP; H.264 High via libx264",
        "runtime": runtime_versions(),
        "guide_alignment": reference_details(),
        "source_relationship": {
            "upstream_edition": "sufe-claude-relay-v2",
            "upstream_source_directory": "research/sufe-video-claude-relay-20261018/",
            "supplied_archive_sha256": UPSTREAM_ARCHIVE_SHA256,
            "upstream_finance_video_sha256": UPSTREAM_VIDEO_SHA256,
            "upstream_manifest": {"path": "MANIFEST.json", "sha256": sha(os.path.join(ROOT, "MANIFEST.json"))},
            "preserved": "Original story, financial evidence, request metadata, voice caches, captions and original-source snapshot.",
            "changed": "Reference-matched entrance/exit, fixed right-facing guide without turns, pointer/focus alignment, and bounded resumable Windows rendering.",
            "source_snapshot_phase": "packaging",
            "source_paths_base": "portable editable source root; source files use forward slashes",
        },
        "validation": {
            "geometry_report": f"docs/video/{doc}/guide-geometry-qa.json",
            "font_selection": f"docs/video/{doc}/font-selection.json",
            "render_receipt": f"docs/video/{doc}/render-receipt.json",
            "render_input_fingerprint": render_receipt["input_fingerprint"],
            "post_render_packaging_changes": packaging_only_changes,
            "geometry_passed": qa["passed"],
            "frames_checked": qa["frames_checked"],
            "cue_boundaries_checked": qa["cues_checked"],
            "video_checks": "Full render frame count, frame rate and dimensions verified with ffprobe before packaging.",
            "review_scope": "Automated geometry and asset checks; these records do not claim full human viewing or listening.",
        },
        "chapters": chapters,
        "shots": shots,
        "files": {
            f"assets/video/{name}.mp4": {"bytes": os.path.getsize(mp4), "sha256": sha(mp4)},
            f"assets/video/{name}-poster.jpg": {"bytes": os.path.getsize(poster), "sha256": sha(poster)},
            **{f"docs/video/{doc}/captions.{l}.srt": {"bytes": os.path.getsize(os.path.join(out_d, f"captions.{l}.srt")),
                                                      "sha256": sha(os.path.join(out_d, f"captions.{l}.srt"))}
               for l in ("en", "zh", "bilingual")},
            **{f"docs/video/{doc}/{filename}": {
                "bytes": os.path.getsize(os.path.join(out_d, filename)),
                "sha256": sha(os.path.join(out_d, filename))}
               for filename in ("guide-geometry-qa.json", "font-selection.json", "render-receipt.json", "README.md")},
        },
        "sources": {
            "run_export": {"path": relative(data_path), "sha256": sha(data_path)},
            "request_metadata": {"path": relative(log), "sha256": sha(log), "note": "Derived metadata only; original transcript is excluded."},
            "facts_audit": {"path": "docs/finance-audit.md", "sha256": sha(os.path.join(ROOT, "docs", "finance-audit.md"))},
            "voice_cache_index": {"path": f"build/{run}/voice.json", "sha256": sha(os.path.join(build, "voice.json"))},
        },
        "editable_source": {
            "directory": ".",
            "files_sha256": source_hashes,
            "requirements": "requirements-render.txt",
            "instructions": "README-guide-aligned.md",
            "rebuild": [f"python -X utf8 engine/render.py {run} --workers 2",
                        f"python -X utf8 engine/package.py {run}"],
            "offline": "Uses the 34 supplied narration MP3 clips and voice.json; do not run voice.py for this rebuild.",
        },
        "boundaries": [
            "Editorial replay of an existing recorded pilot run; no new agent run, no re-scoring.",
            "Request numbers are the 28 assistant message ids of the Claude Code session log; tool steps are run-export indexes.",
            "Claude Code and Bash run inside the task's Docker container; the model is reached through an API.",
            "The rubric and tests are absent during the agent run; Harbor copies tests into the same container afterwards.",
            "Judge sessions are separate per criterion; scores never feed back into the recorded agent run.",
        ],
    }
    if source_hashes != {relative(f): sha(f) for f in src_files}:
        raise RuntimeError("Editable source changed during packaging; run packaging again after edits finish")
    write_json(os.path.join(out_d, "provenance.json"), prov)
    print(json.dumps({"mp4": mp4, "duration": prov["duration_seconds"], "sha256": prov["files"][f"assets/video/{name}.mp4"]["sha256"],
                      "poster": poster}, indent=1))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python engine/package.py fin")
    main(sys.argv[1])
