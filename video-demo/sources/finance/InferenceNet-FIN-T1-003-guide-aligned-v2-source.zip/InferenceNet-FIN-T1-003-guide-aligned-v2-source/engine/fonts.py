"""Font setup for the offline Skia renderer.

Inter (OFL) remains the supplied typeface. System fonts are read in place:
SF Mono / PingFang SC on macOS, Consolas / Microsoft YaHei on Windows.
Every registered face must load and cover its role's probe characters.
"""
from __future__ import annotations

import os
import sys
from functools import lru_cache

import skia

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.normpath(os.path.join(HERE, "..", "fonts"))
INTER_SRC = os.path.join(FONT_DIR, "inter-latin.woff2")
SF_MONO = "/System/Library/Fonts/SFNSMono.ttf"
INTER_WEIGHTS = (400, 500, 600, 700, 800)
MONO_WEIGHTS = (400, 500, 600, 700)
FONT_SELECTION = {}
ASCII_PROBE = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
WINDOWS_FONTS = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")


def _inter_path(w: int) -> str:
    return os.path.join(FONT_DIR, f"Inter-{w}.ttf")


def build_static_inter() -> None:
    missing = [w for w in INTER_WEIGHTS if not os.path.exists(_inter_path(w))]
    if not missing:
        return
    from fontTools.ttLib import TTFont
    from fontTools.varLib import instancer

    for w in missing:
        f = TTFont(INTER_SRC)
        f.flavor = None
        inst = instancer.instantiateVariableFont(f, {"wght": w})
        inst.save(_inter_path(w))


def _mono_typeface(weight: int) -> skia.Typeface:
    if sys.platform == "win32":
        return skia.Typeface.MakeFromFile(os.path.join(
            WINDOWS_FONTS, "consolab.ttf" if weight >= 600 else "consola.ttf"))
    base = skia.Typeface.MakeFromFile(SF_MONO)
    if base is None:
        return skia.FontMgr().matchFamilyStyle("Menlo", skia.FontStyle.Normal())
    try:
        tag = (ord("w") << 24) | (ord("g") << 16) | (ord("h") << 8) | ord("t")
        coord = skia.FontArguments.VariationPosition.Coordinate(tag, float(weight))
        coords = skia.FontArguments.VariationPosition.Coordinates([coord])
        pos = skia.FontArguments.VariationPosition(coords)
        args = skia.FontArguments()
        args.setVariationDesignPosition(pos)
        clone = base.makeClone(args)
        return clone or base
    except Exception:
        return base


CJK_WEIGHTS = (400, 500, 600)


def _register(prov, alias, tf, source, probe):
    if tf is None:
        raise RuntimeError(f"Font {alias} could not be loaded from {source}")
    glyphs = tf.unicharsToGlyphs([ord(c) for c in probe])
    missing = [c for c, glyph in zip(probe, glyphs) if glyph == 0]
    if missing:
        raise RuntimeError(f"Font {alias} ({source}) lacks required glyphs: {missing!r}")
    prov.registerTypeface(tf, alias)
    FONT_SELECTION[alias] = {
        "family": tf.getFamilyName(),
        "source": source,
        "probe": probe,
        "probe_glyphs_present": True,
    }


def font_manifest():
    """Return the actual loaded faces so exports can record font substitutions."""
    provider()
    return {"platform": sys.platform, "fonts": dict(FONT_SELECTION)}


@lru_cache(maxsize=1)
def provider() -> skia.textlayout.TypefaceFontProvider:
    build_static_inter()
    prov = skia.textlayout.TypefaceFontProvider()
    for w in INTER_WEIGHTS:
        path = _inter_path(w)
        _register(prov, f"Inter{w}", skia.Typeface.MakeFromFile(path), path, ASCII_PROBE)
    for w in MONO_WEIGHTS:
        path = (os.path.join(WINDOWS_FONTS, "consolab.ttf" if w >= 600 else "consola.ttf")
                if sys.platform == "win32" else SF_MONO + " / Menlo")
        _register(prov, f"Mono{w}", _mono_typeface(w), path, ASCII_PROBE)
    system = skia.FontMgr()
    for w in CJK_WEIGHTS:
        style = skia.FontStyle(w, skia.FontStyle.kNormal_Width, skia.FontStyle.kUpright_Slant)
        if sys.platform == "win32":
            source = os.path.join(WINDOWS_FONTS, "msyhbd.ttc" if w >= 600 else "msyh.ttc")
            tf = skia.Typeface.MakeFromFile(source)
        else:
            source = "system family: PingFang SC"
            tf = system.matchFamilyStyle("PingFang SC", style)
        _register(prov, f"CJK{w}", tf, source, "中文财务月末结账模型执行检验报告底稿")
    # Symbols that neither Inter nor PingFang carry (arrows, check marks).
    if sys.platform == "win32":
        sym_source = os.path.join(WINDOWS_FONTS, "seguisym.ttf")
        serif_source = os.path.join(WINDOWS_FONTS, "georgia.ttf")
        sym = skia.Typeface.MakeFromFile(sym_source)
        serif = skia.Typeface.MakeFromFile(serif_source)
    else:
        sym_source, serif_source = "system family: Apple Symbols", "system family: Georgia"
        sym = system.matchFamilyStyle("Apple Symbols", skia.FontStyle.Normal())
        serif = system.matchFamilyStyle("Georgia", skia.FontStyle.Normal())
    _register(prov, "Sym", sym, sym_source, "→←↑↓✓×−")
    _register(prov, "Serif", serif, serif_source, "N")
    if sys.platform == "win32":
        # The recorded binary Word read intentionally contains replacement characters.
        misc_source = os.path.join(WINDOWS_FONTS, "segoeui.ttf")
        _register(prov, "Misc", skia.Typeface.MakeFromFile(misc_source), misc_source, "\ufffd")
    return prov


@lru_cache(maxsize=1)
def collection() -> skia.textlayout.FontCollection:
    fc = skia.textlayout.FontCollection()
    fc.setDefaultFontManager(provider())
    return fc


def families(kind: str, weight: int) -> list[str]:
    cjk = min(CJK_WEIGHTS, key=lambda x: abs(x - weight))
    fallback = ["Misc"] if sys.platform == "win32" else []
    if kind == "serif":
        return ["Serif", f"CJK{cjk}"] + fallback
    if kind == "mono":
        w = min(MONO_WEIGHTS, key=lambda x: abs(x - weight))
        return [f"Mono{w}", f"CJK{cjk}", "Sym"] + fallback
    w = min(INTER_WEIGHTS, key=lambda x: abs(x - weight))
    return [f"Inter{w}", f"CJK{cjk}", "Sym"] + fallback
