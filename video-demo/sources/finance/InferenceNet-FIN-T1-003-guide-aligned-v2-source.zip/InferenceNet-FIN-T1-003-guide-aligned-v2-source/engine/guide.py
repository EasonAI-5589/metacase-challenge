"""Narration-cued task0001 guide for the existing finance storyboard.

Routes are compiled once in absolute video time. A cue never resets a local
animation clock or jumps to the previous cue's intended (unreached) endpoint.
The pet stays right-facing, as in task0001 v3.2. Its fixed SVG, opening
fade/move, idle baton, and closing move use that reference's clock rules.
"""
from __future__ import annotations

from bisect import bisect_right
import math

import skia

import gfx as G
from guide_targets import describe
from reference_pet import draw_pet, draw_pointer


def smooth(v):
    v = G.clamp(v)
    return v * v * v * (v * (v * 6 - 15) + 10)


def point(a, b, u):
    return tuple(G.lerp(x, y, u) for x, y in zip(a, b))


def random(n):
    v = math.sin(n * 78.233 + 11.17) * 43758.5453
    return v - math.floor(v)


def same_focus(a, b):
    return a.get("box") == b.get("box") and a.get("color") == b.get("color")


def park(d):
    x, y = d["dock"]
    # Reference idle tip: (dock.x + 100, dock.y + 5), enlarged by 1.5.
    return (x + 150, y + 7.5)


class Guide:
    def __init__(self, ctx):
        events = []
        for sh in ctx.tl.shots:
            cues = sh.d.get("pet", [])
            for cue, target in cues:
                d = dict(describe(sh, target))
                d.pop("facing", None)
                if sh.kind == "open":
                    d = dict(dock=(288.0, 798.0), tip=None, box=None,
                             color=G.MODEL, id=f"{sh.id}:reference-entry")
                elif sh.kind == "outro":
                    d = dict(dock=(1596.0, 796.5), tip=None, box=None,
                             color=G.MODEL, id=f"{sh.id}:reference-outro")
                events.append(dict(time=sh.start + sh.cue(cue), end=sh.end,
                                   shot=sh.id, target=target, descriptor=d,
                                   outro=sh.kind == "outro"))
        events.sort(key=lambda e: e["time"])
        # Equal-time cues resolve deterministically to the last authored target.
        unique = {}
        for event in events:
            unique[event["time"]] = event
        self.events = list(unique.values())
        self.times = [e["time"] for e in self.events]
        # Keep the authored cue list while replacing its first pose with the
        # exact reference opening: (160,532) -> (192,532) over 0.65 seconds.
        self.events[0]["descriptor"] = dict(
            dock=(288.0, 798.0), tip=None, box=None,
            color=G.MODEL, id="reference-entry")
        prior = dict(dock=(240.0, 798.0), tip=None, box=None,
                     color=G.MODEL, id="entrance")
        for i, event in enumerate(self.events):
            d = event["descriptor"]
            a = prior.get("tip") or park(prior)
            b = d.get("tip") or park(d)
            dist = math.dist(prior["dock"], d["dock"])
            tipdist = math.dist(a, b)
            movement = max(dist, tipdist)
            # Source route has a y=478 return lane. Tall finance cards may
            # require a lower lane; all remain above the 900px caption band.
            boxes = [item["box"] for item in (prior, d) if item.get("box")]
            lane = max(717.0, min(885.0, max(
                (box[1] + box[3] + 9 for box in boxes), default=717.0)))
            lane = max(lane, prior.get("route_y", 717.0), d.get("route_y", 717.0))
            direct_edge = (
                bool(boxes) and prior.get("tip") is not None and d.get("tip") is not None
                and (
                    (abs(a[1] - b[1]) < 0.01
                     and all(a[1] >= box[1] + box[3] + 4 for box in boxes))
                    or (abs(a[0] - b[0]) < 0.01
                        and (all(a[0] <= box[0] - 4 for box in boxes)
                             or all(a[0] >= box[0] + box[2] + 4 for box in boxes)))
                )
            )
            corner = (not direct_edge and abs(a[0] - b[0]) > 0.01
                      and (a[1] < lane or b[1] < lane))
            pathdist = (abs(a[0] - b[0]) + abs(a[1] - lane) + abs(b[1] - lane)
                        if corner else tipdist)
            duration = min(3.2, max(0.65, dist / 360, pathdist / 360))
            if movement < 0.01:
                duration = 0.0
            if i + 1 < len(self.events):
                duration = min(duration, max(0.0, (self.events[i + 1]["time"] - event["time"]) * 0.88))
            if i == 0:
                duration = 0.65
            elif event["outro"] and not self.events[i - 1]["outro"]:
                duration = 3.2
            event.update(prior=prior, duration=duration, distance=dist,
                         old_tip=a, new_tip=b, lane=lane, direct_edge=direct_edge)
            prior = d
        self.last = None

    def state(self, T):
        if not self.events:
            return None
        idx = max(0, bisect_right(self.times, T) - 1)
        e = self.events[idx]
        d, prev = e["descriptor"], e["prior"]
        elapsed = T - e["time"]
        u = G.clamp(elapsed / e["duration"]) if e["duration"] else 1.0
        base = smooth(u)
        h = base
        a, b, lane = e["old_tip"], e["new_tip"], e["lane"]
        tx, ty = point(a, b, base)
        # This is the reference's continuous safe-lane route, scaled to 1920.
        # Horizontal pet motion shares the tip's horizontal progress so the
        # right-hand baton never has to turn through the pet's torso.
        if not e["direct_edge"] and abs(a[0] - b[0]) > 0.01 and (a[1] < lane or b[1] < lane):
            if a[1] < lane <= b[1]:
                length = abs(b[0] - a[0]) + abs(lane - a[1]) + abs(b[1] - lane)
                part = G.clamp((lane - a[1]) / length, 0.08, 0.8)
                h = smooth((u - part) / (1 - part))
                tx = G.lerp(a[0], b[0], h)
                ty = G.lerp(a[1], lane, smooth(u / part)) if u < part else G.lerp(lane, b[1], h)
            elif a[1] >= lane > b[1]:
                length = abs(b[0] - a[0]) + abs(a[1] - lane) + lane - b[1]
                part = G.clamp((abs(b[0] - a[0]) + abs(a[1] - lane)) / length, 0.2, 0.92)
                h = smooth(u / part)
                tx = G.lerp(a[0], b[0], h)
                ty = G.lerp(a[1], lane, h) if u < part else G.lerp(lane, b[1], smooth((u - part) / (1 - part)))
            else:
                h = smooth((u - 0.25) / 0.5)
                tx = G.lerp(a[0], b[0], h)
                ty = (G.lerp(a[1], lane, smooth(u / 0.25)) if u < 0.25
                      else G.lerp(lane, b[1], smooth((u - 0.75) / 0.25)) if u > 0.75 else lane)
        tip = (tx, ty)
        # In the finance layout a leftward move can begin while the old tip
        # lowers: the right hand moves away from that tip, never through it.
        # The pet must also stay ahead when the tip completes its crossing,
        # so the larger of the full and horizontal progress remains safe.
        if d["dock"][0] < prev["dock"][0] and not e["outro"]:
            h = max(base, h)
        dock = (G.lerp(prev["dock"][0], d["dock"][0], h),
                G.lerp(prev["dock"][1], d["dock"][1], base))
        if not e["duration"]:
            tip = e["new_tip"]
        weight = min(1.0, e["distance"] / 105) * math.sin(math.pi * h) ** 2
        next_e = self.events[idx + 1] if idx + 1 < len(self.events) else None
        until = min(e["end"], next_e["time"] if next_e else e["end"])
        unchanged = same_focus(prev, d) and e["distance"] < 0.01
        glow = (1.0 if unchanged else G.ease((elapsed - e["duration"]) / 0.25))
        if not next_e or not same_focus(d, next_e["descriptor"]) or next_e["shot"] != e["shot"]:
            glow *= G.ease((until - T) / 0.25)
        if not d.get("box") or T >= e["end"] or elapsed < 0:
            glow = 0.0
        alpha = G.ease((T - 0.45) / 0.45)
        pointer_alpha = alpha * (1.0 - weight * 0.35)
        x, y = dock
        y = y - weight * 12 + math.sin(T * 2.1) * 1.05
        pose = dict(flight=weight, travel_u=u, dx=d["dock"][0] - prev["dock"][0],
                    tip=tip, focus=glow, opacity=alpha)
        geometry = draw_pet(None, x, y, T, **pose)
        # Reference safety limit: 595 logical pixels, enlarged by 1.5.
        y -= max(0.0, geometry["bottom"] - 892.5)
        geometry = draw_pet(None, x, y, T, **pose)
        return dict(event=e, index=idx, u=u, h=h, x=x, y=y, tip=tip,
                    pose=pose, geometry=geometry, glow=glow,
                    opacity=alpha, pointer_opacity=pointer_alpha,
                    moving=weight > 0.001, weight=weight, descriptor=d)

    def draw(self, cv, T):
        st = self.state(T)
        if st is None:
            return
        d, e = st["descriptor"], st["event"]
        box, col = d.get("box"), d["color"]
        cv.save()
        cv.clipRect(skia.Rect.MakeXYWH(0, 87, 1920, 809))
        if box and st["glow"] > 0.003:
            x, y, w, h = box
            rr = skia.RRect.MakeRectXY(skia.Rect.MakeXYWH(x, y, w, h), 10.5, 10.5)
            cv.drawRRect(rr, G.paint(col, st["glow"] * 0.22, stroke=7.5, blur=4.5))
            cv.drawRRect(rr, G.paint(col, st["glow"] * 0.025))
            cv.drawRRect(rr, G.paint(col, st["glow"], stroke=1.95))
        # Reference dust follows actual earlier route positions, never a shot-local reset.
        for j in range(6):
            t = math.floor(T / 0.14) * 0.14 - j * 0.14
            age = T - t
            if t < 0 or not 0 <= age <= 0.6:
                continue
            past = self.state(t)
            if not past["moving"]:
                continue
            seed = math.floor(t * 100)
            r = random(seed)
            direction = 1 if past["pose"]["dx"] >= 0 else -1
            px = past["x"] + 38 - direction * age * (30 + r * 25)
            py = min(888, past["y"] + 84) - age * 21
            G.rrect(cv, px, py, 3 + math.floor(r * 2), 3, r=0,
                    fill=(231, 173, 132), a=(1 - age / 0.6) * 0.42)
        burst_age = T - e["time"] - e["duration"] - 0.3
        if box and not same_focus(e["prior"], d) and 0 < burst_age < 0.7:
            for j in range(7):
                angle = j / 7 * math.tau
                radius = 6 + burst_age * (24 + random(j + st["index"]) * 24)
                px = st["tip"][0] + math.cos(angle) * radius
                py = st["tip"][1] + math.sin(angle) * radius
                G.rrect(cv, px, py, 3, 3, r=0, fill=col,
                        a=math.sin(burst_age / 0.7 * math.pi) * 0.65 * st["glow"])
        cv.restore()
        G.glow(cv, st["x"] + 6, min(885, d["dock"][1] + 84),
               91.5 * (1 - st["weight"] * 0.25), 7.5, 3.75,
               (0, 0, 0), a=st["opacity"] * 0.6 * (4 / 15), sigma=3)
        draw_pet(cv, st["x"], st["y"], T, **st["pose"])
        draw_pointer(cv, st["geometry"]["hand"], st["tip"], T, color=col,
                     glow=st["glow"], flight=st["weight"], opacity=st["opacity"])
        self.last = st
