"""Left and right columns: task card, the agent's TodoWrite plan, run ledger, findings, /app/output."""
from __future__ import annotations

import gfx as G
import ui as U

TOOL_COL = {"bash": G.SANDBOX, "todo": G.HARNESS, "write": G.WARN, "edit": G.WARN, "read": G.BRAND}


def task_card(cv, conf, a=1.0, hi=0.0):
    x, y, w, h = U.LX, U.TOP, U.LW, 322
    U.panel(cv, x, y, w, h, a=a, accent=G.BRAND, accent_a=hi)
    G.kicker(cv, f"TASK  {conf['task_id']}", x + 24, y + 22, a=a, size=14.5)
    U.pill(cv, conf["domain"], x + w - 22, y + 18, G.BRAND, a=a, size=13.5, align="right")
    _, th = G.text(cv, conf["title"], x + 24, y + 56, size=27, c=G.FG, weight=600, a=a, width=w - 48, lh=1.18)
    yy = y + 56 + th + 8
    # v3 (English only): the Chinese subtitle repeated the title; it is no longer drawn.
    yy += 6
    _, h3 = G.text(cv, conf["role"], x + 24, yy, size=13.5, c=G.DIM, kind="mono", a=a, width=w - 48, lh=1.35)
    yy += h3 + 10
    G.text(cv, conf["meta"], x + 24, yy, size=13.5, c=(150, 160, 176), kind="mono", a=a, width=w - 48)


def _short(conf, txt):
    for pre, lab in conf["plan_labels"]:
        if txt.startswith(pre):
            return lab
    return txt[:34]


def plan_card(cv, conf, todos, a=1.0, hi=0.0, reveal=1.0, flash=None, self_tag=0.0, n_slots=9, footer_a=1.0):
    """flash: dict index->0..1 pulse; self_tag: show 'self-reported' tags on completed rows."""
    x, y, w, h = U.LX, 454, U.LW, U.BOT - 454
    U.panel(cv, x, y, w, h, a=a, accent=G.HARNESS, accent_a=hi)
    G.icon_role(cv, "harness", x + 32, y + 30, G.HARNESS, a=a, s=8)
    G.kicker(cv, "AGENT'S PLAN · TodoWrite", x + 50, y + 21, c=G.HARNESS, a=a, size=14)
    rows = todos or []
    done = sum(1 for t in rows if t["status"] == "completed")
    if rows:
        G.text(cv, f"{done} / {len(rows)}", x + w - 22, y + 21, size=15, c=G.FG, kind="mono", a=a, align="right")
    y0 = y + 58
    rh = 38 if max(len(rows), n_slots) <= 9 else 34
    if not rows:
        mid = n_slots // 2
        for j in range(n_slots):
            if j == mid:
                continue
            G.rrect(cv, x + 22, y0 + j * rh + 6, 22, 22, 6, stroke=(40, 48, 62), sw=1.4, a=a * 0.7)
            G.rrect(cv, x + 56, y0 + j * rh + 14, 150 + (j * 37) % 110, 6, 3, fill=(32, 40, 54), a=a * 0.7)
        G.text(cv, "no plan written yet", x + w / 2, y0 + mid * rh + 6, size=15, c=G.DIM, kind="mono", a=a, align="center")
    for j, t in enumerate(rows):
        ra = a * G.ease(G.clamp(reveal * len(rows) - j))
        if ra <= 0.01:
            continue
        yy = y0 + j * rh
        st = t["status"]
        f = (flash or {}).get(j, 0.0)
        if f > 0.01:
            G.rrect(cv, x + 12, yy, w - 24, rh - 4, 7, fill=G.HARNESS, a=ra * 0.13 * f)
        if st == "completed":
            G.rrect(cv, x + 22, yy + 6, 22, 22, 6, fill=G.mix(G.PANEL, G.PASS, 0.18), stroke=G.PASS, sw=1.5, a=ra)
            G.icon_check(cv, x + 33, yy + 17, G.PASS, a=ra, s=6.5, sw=2.2)
            lc = G.FG
        elif st == "in_progress":
            G.rrect(cv, x + 22, yy + 6, 22, 22, 6, stroke=G.BRAND, sw=1.6, a=ra)
            G.circle(cv, x + 33, yy + 17, 4, fill=G.BRAND, a=ra)
            lc = G.BRAND
        else:
            G.rrect(cv, x + 22, yy + 6, 22, 22, 6, stroke=G.FAINT, sw=1.5, a=ra)
            lc = G.DIM
        G.text(cv, _short(conf, t["text"]), x + 56, yy + 7, size=16, c=lc, weight=500, a=ra, maxlines=1, width=w - 150)
        if st == "completed" and self_tag > 0.01:
            G.text(cv, "self-reported", x + w - 22, yy + 10, size=12, c=G.HARNESS, kind="mono", a=ra * self_tag, align="right")
    G.text(cv, "the agent's own checklist · not a grade", x + w / 2, y + h - 30, size=12.5, c=G.DIM, kind="mono", a=a * 0.85 * footer_a, align="center")


def ledger_card(cv, conf, run, T, a=1.0, hi=None):
    x, y, w, h = U.RX, U.TOP, U.RW, 346
    U.panel(cv, x, y, w, h, a=a)
    G.icon_role(cv, "harness", x + 32, y + 30, G.HARNESS, a=a, s=8)
    G.kicker(cv, "RUN LEDGER", x + 50, y + 21, c=G.HARNESS, a=a, size=14)
    nreq = run.requests_done(T) if T is not None else 0
    tools = run.tools_done(T) if T is not None else []
    NR, NT = conf["total_requests"], conf["total_tools"]
    hi = hi or {}
    # model requests
    G.text(cv, "model requests", x + 24, y + 60, size=16, c=G.DIM, a=a)
    G.text(cv, f"{nreq} / {NR}", x + w - 24, y + 60, size=16, c=G.FG, kind="mono", a=a, align="right")
    sw_ = (w - 48 - (NR - 1) * 2) / NR
    for k in range(NR):
        on = k < nreq
        col = G.MODEL if on else (34, 43, 57)
        if on and k == nreq - 1 and hi.get("req", 0) > 0:
            G.glow(cv, x + 24 + k * (sw_ + 2) - 2, y + 88 - 2, sw_ + 4, 16, 3, G.MODEL, a=0.6 * hi["req"] * a, sigma=6)
        G.rrect(cv, x + 24 + k * (sw_ + 2), y + 88, sw_, 12, 2.5, fill=col, a=a)
    # tool calls
    G.text(cv, "tool calls", x + 24, y + 118, size=16, c=G.DIM, a=a)
    G.text(cv, f"{len(tools)} / {NT}", x + w - 24, y + 118, size=16, c=G.FG, kind="mono", a=a, align="right")
    per_row = (NT + 1) // 2
    tw_ = (w - 48 - (per_row - 1) * 2) / per_row
    for k in range(NT):
        r, cidx = divmod(k, per_row)
        on = k < len(tools)
        col = TOOL_COL.get(G_kind(tools[k]["tool"]), G.SANDBOX) if on else (34, 43, 57)
        if on and tools[k].get("is_error"):
            col = G.FAIL
        G.rrect(cv, x + 24 + cidx * (tw_ + 2), y + 146 + r * 12, tw_, 9, 2, fill=col, a=a)
    # legend
    lx = x + 24
    for lab, col in (("Bash", G.SANDBOX), ("TodoWrite", G.HARNESS), ("Read/Edit/Write", G.WARN)):
        G.rrect(cv, lx, y + 182, 10, 10, 2, fill=col, a=a * 0.9)
        tw, _ = G.text(cv, lab, lx + 16, y + 179, size=12.5, c=G.DIM, kind="mono", a=a)
        lx += tw + 34
    # tokens + time
    G.text(cv, "output tokens", x + 24, y + 214, size=15, c=G.DIM, a=a)
    G.text(cv, G.fmt_int(run.out_tokens(T) if T is not None else 0), x + 24, y + 236, size=40, c=G.FG, weight=600, a=a)
    G.text(cv, "agent time", x + w - 24, y + 214, size=15, c=G.DIM, a=a, align="right")
    tv = f"+{T:05.1f} s" if T is not None else "+000.0 s"
    G.text(cv, tv, x + w - 24, y + 246, size=21, c=G.FG, kind="mono", weight=600, a=a, align="right")
    G.text(cv, f"of {run.duration:.1f} s", x + w - 24, y + 274, size=13, c=G.DIM, kind="mono", a=a, align="right")
    ctx = run.ctx_tokens(T) if T is not None else 0
    G.line(cv, [(x + 24, y + 300), (x + w - 24, y + 300)], (32, 40, 54), sw=1, a=a)
    G.text(cv, "latest prompt", x + 24, y + 312, size=13.5, c=G.DIM, kind="mono", a=a)
    G.text(cv, f"{G.fmt_int(ctx)} tok" if ctx else "—", x + w - 24, y + 311, size=15, c=G.BRAND, kind="mono", a=a, align="right")


def G_kind(tool):
    return {"Bash": "bash", "TodoWrite": "todo", "Write": "write", "Edit": "edit", "Read": "read"}.get(tool, "bash")


def found_card(cv, conf, run, T, a=1.0, extra=None, hi_label=None, hi=0.0):
    x, y, w, h = U.RX, 478, U.RW, 206
    U.panel(cv, x, y, w, h, a=a)
    G.kicker(cv, "AGENT FOUND", x + 24, y + 20, a=a, size=14)
    items = []
    if T is not None:
        n = len(run.files_opened(T))
        if n:
            items.append((conf["files_opened_label"], f"{n} / {conf['inputs']}", "fg"))
        for (tt, lab, val, col) in conf["found"]:
            if T >= tt:
                prev = [i for i, it in enumerate(items) if it[0] == lab]
                if prev:
                    items[prev[0]] = (lab, val, col)
                else:
                    items.append((lab, val, col))
    if extra:
        items.extend(extra)
    items = items[-4:]
    if not items:
        G.text(cv, "nothing yet", x + w / 2, y + 112, size=15, c=G.DIM, kind="mono", a=a * 0.8, align="center")
    for j, (lab, val, col) in enumerate(items):
        cx_ = x + 24 + (j % 2) * 182
        cy_ = y + 54 + (j // 2) * 74
        k = hi if (hi_label and lab == hi_label) else 0.0
        if k > 0.01:
            G.rrect(cv, cx_ - 8, cy_ - 6, 176, 66, 8, fill=G.ROLE.get(col, G.FG), a=0.12 * k * a)
        G.text(cv, lab, cx_, cy_, size=13, c=G.DIM, kind="mono", a=a, maxlines=1, width=172)
        G.text(cv, val, cx_, cy_ + 20, size=23, c=G.ROLE.get(col, G.FG), weight=600, a=a, maxlines=1, width=176)


def output_card(cv, conf, files, a=1.0, hi=0.0, hi_kind=None, flash_rows=0.0):
    x, y, w, h = U.RX, 708, U.RW, U.BOT - 708
    U.panel(cv, x, y, w, h, a=a, accent=G.SANDBOX, accent_a=hi)
    G.icon_folder(cv, x + 22, y + 18, w=22, h=17, c=G.SANDBOX, a=a)
    G.kicker(cv, "/app/output", x + 54, y + 19, c=G.SANDBOX, a=a, size=14)
    G.text(cv, f"{len(files)} / 2 files", x + w - 24, y + 19, size=14, c=G.DIM, kind="mono", a=a, align="right")
    if not files:
        for j, kind in enumerate(("docx", "xlsx")):
            yy = y + 56 + j * 58
            G.rrect(cv, x + 20, yy, w - 40, 48, 8, stroke=(52, 62, 80), sw=1.3, a=a * 0.9, dash=(6, 5))
            G.text(cv, f"{kind.upper()} · not written yet", x + w / 2, yy + 14, size=14, c=G.DIM, kind="mono", a=a, align="center")
        return
    order = {"docx": 0, "xlsx": 1}
    have = {f["kind"] for f in files}
    for kind, j in order.items():
        if kind in have:
            continue
        yy = y + 54 + j * 60
        G.rrect(cv, x + 16, yy - 4, w - 32, 56, 8, stroke=(52, 62, 80), sw=1.3, a=a * 0.9, dash=(6, 5))
        G.text(cv, f"{kind.upper()} · not written yet", x + w / 2, yy + 14, size=14, c=G.DIM, kind="mono", a=a, align="center")
    for f in sorted(files, key=lambda f: order[f["kind"]]):
        j = order[f["kind"]]
        yy = y + 54 + j * 60
        st = f.get("state", "ok")
        col = G.WARN if st == "warn" else G.SANDBOX
        k = hi if hi_kind == f["kind"] else 0.0
        G.rrect(cv, x + 16, yy - 4, w - 32, 56, 8, fill=G.mix(G.PANEL, col, 0.06 + 0.10 * k), stroke=G.mix(G.EDGE, col, 0.3 + 0.7 * k), sw=1.3, a=a)
        G.icon_file(cv, x + 26, yy + 2, f["kind"], a=a, w=30, h=38)
        G.text(cv, f["name"], x + 66, yy + 2, size=14.5, c=G.FG, weight=600, a=a, maxlines=1, width=w - 96)
        G.text(cv, f["meta"] + (f"  ·  {f['size']}" if f.get("size") else ""), x + 66, yy + 24, size=12.5,
               c=G.WARN if st == "warn" else G.DIM, kind="mono", a=a, maxlines=1, width=w - 96)
