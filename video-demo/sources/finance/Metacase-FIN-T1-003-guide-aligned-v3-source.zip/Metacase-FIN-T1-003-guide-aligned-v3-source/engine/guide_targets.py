"""Narration targets for the fixed-right task0001 guide, in 1920 × 1080 pixels.

The box keeps the original semantic focus. Docks place the original right hand
on the clear side of that box; no cue mirrors or turns the reference character.
"""
from __future__ import annotations

BRAND = (143, 173, 214)
MODEL = (240, 146, 95)
HARNESS = (185, 164, 247)
SANDBOX = (115, 213, 156)
FAIL = (242, 119, 122)
WARN = (236, 190, 104)
ROLE = {"brand": BRAND, "scorer": BRAND, "model": MODEL, "harness": HARNESS,
        "sandbox": SANDBOX, "pass": SANDBOX, "fail": FAIL, "warn": WARN}
FULL = {"open", "chapter", "reward", "outro"}


def _target(name, box, tip, color=BRAND, dock=None, route_y=None):
    if dock is None:
        clearance = 126 if tip is not None and tip[1] >= 700 else 114
        dock = (tip[0] - clearance, 798) if tip is not None else (1250, 798)
    result = dict(id=name, box=box, tip=tip, color=color, dock=dock, facing=1)
    if route_y is not None:
        result["route_y"] = route_y
    return result


# Tuple keys are the unchanged storyboard cue targets, not new timing cues.
TUPLES = {
    'f00': {
        (720, 530): _target('brand-title', (640, 384, 640, 150), (720, 538), BRAND, dock=(570, 790)),
        (560, 622): _target('run-participants', (360, 570, 1200, 52), (560, 628), BRAND, dock=(410, 790)),
        (640, 690): _target('finance-task-title', (510, 650, 900, 80), (640, 736), BRAND, dock=(490, 790)),
    },
    'f01': {
        (700, 360): _target('books-lock', (502, 314, 430, 46), (938, 366), BRAND, dock=(824, 798)),
        (648, 776): _target('six-unposted-entries', (502, 384, 916, 390), (648, 780), BRAND, dock=(522, 798)),
        (960, 776): _target('accept-replace-reject', (502, 384, 916, 390), (960, 780), BRAND, dock=(834, 798)),
    },
    'f02': {
        (640, 640): _target('review-brief', (502, 326, 916, 316), (1424, 648), BRAND, dock=(1310, 798)),
        (562, 832): _target('one-independent-reviewer', (524, 736, 100, 90), None, WARN, dock=(1270, 798)),
        (900, 832): _target('review-hours', (652, 732, 730, 88), (1388, 824), WARN, dock=(1262, 798)),
    },
    'f03': {
        (700, 380): _target('readonly-input-folder', (526, 358, 630, 30), (1188, 388), BRAND, dock=(1074, 798)),
        (760, 836): _target('55-source-files', (526, 398, 630, 300), (1188, 704), BRAND, dock=(1062, 798)),
        (900, 836): _target('two-deliverables', (526, 728, 642, 90), (1174, 824), SANDBOX, dock=(1048, 798)),
    },
    'f04': {
        (900, 836): _target('agent-container', (502, 314, 680, 520), (1188, 840), SANDBOX, dock=(1062, 798)),
        (1310, 692): _target('sealed-tests', (1204, 360, 214, 330), (1424, 696), BRAND, dock=(1310, 798)),
    },
    'f05': {
        (803, 470): _target('observation-return', (596, 428, 727, 36), (803, 470), BRAND, dock=(689, 798)),
    },
    'f08': {
        (803, 470): _target('observation-return', (596, 428, 727, 36), (803, 470), BRAND, dock=(689, 798)),
    },
    'f09': {
        (597, 432): _target('one-model-response', (502, 330, 190, 96), (698, 432), MODEL, dock=(584, 798), route_y=790),
        (1060, 630): _target('four-parallel-bash-calls', (752, 314, 666, 338), (1424, 658), HARNESS, dock=(1310, 798)),
        (1060, 702): _target('four-results-together', (868, 650, 526, 40), (1120, 696), BRAND, dock=(1006, 798)),
    },
    'f11': {
        (760, 610): _target('opened-source-files', (502, 322, 916, 272), (1424, 600), SANDBOX, dock=(1310, 798)),
        (1300, 790): _target('27-of-55-opened', (1194, 622, 214, 116), (1300, 744), SANDBOX, dock=(1174, 798)),
    },
    'f14': {
        (787, 520): _target('june-30-valuation', (729, 366, 122, 166), (857, 538), MODEL, dock=(743, 798), route_y=790),
        (1063, 780): _target('july-31-valuation', (1090, 366, 136, 404), (1188, 776), MODEL, dock=(1062, 798)),
        (1200, 650): _target('july-value-change', (1268, 594, 150, 72), (1424, 672), MODEL, dock=(1310, 798)),
    },
    'f17': {
        (1100, 466): _target('nameerror-before-save', (1064.8, 344, 165.6, 120), (1236, 470), FAIL, dock=(1122, 798)),
        (1325, 540): _target('save-not-reached', (1252.4, 344, 165.6, 194), (1424, 544), FAIL, dock=(1310, 798)),
        (720, 730): _target('unchanged-sheet-rows', (582, 684, 580, 44), (1168, 734), WARN, dock=(1042, 798)),
    },
    'f18': {
        (682, 650): _target('sheets-three-and-four', (502, 330, 360, 198), (868, 534), SANDBOX, dock=(754, 798)),
        (1100, 736): _target('word-report', (892, 330, 526, 404), (1424, 740), SANDBOX, dock=(1298, 798)),
        (1250, 736): _target('six-report-sections', (908, 430, 492, 292), (1424, 728), SANDBOX, dock=(1298, 798)),
    },
    'f20': {
        (960, 640): _target('agent-names-the-unsaved-error', (502, 480, 916, 228), (1424, 714), MODEL, dock=(672, 798)),
    },
    'f23': {
        (960, 640): _target('whole-run-trace', (502, 314, 916, 352), (1424, 672), HARNESS, dock=(1310, 798)),
        (594, 762): _target('bash-and-todowrite-counts', (502, 690, 354, 70), (862, 766), SANDBOX, dock=(736, 798)),
        (1050, 762): _target('unused-read-edit-write', (870, 690, 538, 70), (1100, 766), BRAND, dock=(974, 798)),
    },
    'f24': {
        (1484, 425): _target('latest-prompt-counter', (1500, 409, 362, 37), (1480, 427), MODEL, dock=(1366, 798)),
    },
    'f25': {
        (712, 520): _target('agent-session-ended', (526, 370, 380, 150), (912, 526), HARNESS, dock=(798, 798)),
        (1240, 640): _target('tests-copied-into-container', (1088, 370, 300, 278), (1424, 654), BRAND, dock=(798, 798)),
        (1150, 806): _target('judge-scoring-starts', (932, 694, 462, 110), (1400, 810), BRAND, dock=(1274, 798)),
    },
    'f26': {
        (960, 594): _target('independent-check-chapter', (560, 432, 800, 150), (960, 594), BRAND, dock=(810, 790)),
    },
    'f27': {
        (900, 600): _target('27-independent-judge-sessions', (948, 330, 462, 224), (1424, 560), BRAND, dock=(1310, 798)),
        (800, 716): _target('judge-model', (748, 640, 400, 74), (948, 720), BRAND, dock=(822, 798)),
        (700, 796): _target('no-feedback-to-agent', (502, 750, 916, 44), (1424, 800), BRAND, dock=(1298, 798)),
    },
    'f28': {
        (725, 504): _target('submitted-dv01-cell', (502, 352, 443, 150), (951, 508), SANDBOX, dock=(837, 798)),
        (1190, 604): _target('dv01-recomputation-and-verdict', (975, 352, 443, 250), (1424, 608), SANDBOX, dock=(1310, 798)),
        (960, 732): _target('dv01-source-evidence', (502, 630, 916, 100), (960, 736), MODEL, dock=(834, 798)),
    },
    'f29': {
        (960, 504): _target('d02-register-and-report', (502, 352, 916, 150), (1424, 508), BRAND, dock=(1310, 798)),
        (900, 612): _target('g2-red-line-clear', (502, 540, 916, 70), (1424, 616), SANDBOX, dock=(1310, 798)),
        (1000, 700): _target('r51-half-credit', (502, 628, 916, 70), (1000, 704), WARN, dock=(874, 798)),
    },
    'f30': {
        (1240, 660): _target('zero-formulas-in-five-sheets', (1092, 352, 326, 298), (1424, 656), FAIL, dock=(1310, 798)),
        (900, 776): _target('untraceable-calculation-chain', (502, 704, 916, 70), (900, 780), FAIL, dock=(774, 798)),
    },
    'f31': {
        (700, 470): _target('20-positive-criteria', (502, 326, 916, 118), (1424, 450), WARN, dock=(1310, 798)),
        (700, 600): _target('five-penalties-clear', (502, 478, 916, 70), (1424, 554), SANDBOX, dock=(1310, 798)),
        (700, 700): _target('two-red-lines-clear', (502, 582, 916, 70), (1424, 658), SANDBOX, dock=(1310, 798)),
    },
    'f32': {
        (560, 600): _target('recorded-rubric-reward', (550, 254, 820, 414), (1376, 674), WARN, dock=(1226, 790)),
        (690, 712): _target('pilot-score-scope', (550, 692, 820, 66), (1376, 764), WARN, dock=(1226, 790)),
    },
    'f33': {
        (560, 600): _target('professional-tasks-outro', (500, 486, 920, 54), (560, 546), BRAND, dock=(410, 790)),
        (690, 594): _target('challenge-site', (640, 566, 640, 46), (640, 618), BRAND, dock=(490, 790)),
    },
}


def describe(sh, target):
    """Resolve a cue without changing its timing, highlight meaning, or facts."""
    sid = sh.id
    if isinstance(target, (tuple, list)):
        result = TUPLES.get(sid, {}).get(tuple(target))
        if result is None:
            raise ValueError(f"Unmapped guide target in {sid}: {target!r}")
        return dict(result, id=f"{sid}:{result['id']}")

    if target.startswith("card"):
        i = int(target[4:])
        box = (502 + 313 * i, 480, 290, 228)
        color = BRAND
        for phase in sh.d.get("phases", []):
            cards = phase.get("cards", [])
            if i < len(cards) and cards[i]:
                card = cards[i]
                color = ROLE.get(card.get("role", "brand"), BRAND)
                span = card.get("span", 1)
                box = (card.get("x", box[0]), 480,
                       card.get("w", 290 * span + 23 * (span - 1)), 228)
                break
        if sid == "f07" and i == 2:
            box, color = (825, 646, 583, 56), FAIL
        tip = (box[0] + box[2] + 6, box[1] + box[3] + 6)
        dock = None
        # These short follow-ups use one low dock. The baton changes aim while
        # the right-facing character keeps its place and its original shape.
        if sid in ("f15", "f20") or (sid == "f19" and i == 2):
            dock = (672, 798)
        elif sid == "f06" and i == 2:
            dock = (985, 798)
        return _target(f"{sid}:{target}", box, tip, color, dock)

    persistent = {
        # At y760 the pet fits to the right of the final plan rows. Its feet
        # stay above the y862 note, and its right hand reaches the outer edge.
        "task": _target("task", (42,108,394,322), (438,300), BRAND, (324,760)),
        "plan": _target("plan", (42,454,394,438), (438,640), HARNESS, (324,760)),
        "ledger": _target("ledger", (1484,108,394,346), (1480,300), HARNESS),
        "found": _target("found", (1484,478,394,206), (1480,580), BRAND),
        "output": _target("output", (1484,708,394,184), (1480,800), SANDBOX),
        "route": _target("route", (596,428,727,36), (803,470), BRAND),
        "rest": _target("rest", None, None, BRAND, (1250,790 if sh.kind in FULL else 798)),
    }
    if target in persistent:
        return dict(persistent[target], id=f"{sid}:{target}")
    if target.startswith("stage"):
        i = int(target[5:])
        box = (502+236*i,332,206,76)
        return _target(f"{sid}:{target}",box,(box[0]+103,414),(MODEL,HARNESS,SANDBOX,BRAND)[i])
    raise ValueError(f"Unmapped guide target in {sid}: {target!r}")
