"""econ-0157 storyboard (one narration cue per shot).

One recorded pilot run: gpt-6-astra in Terminus-2 2.0.0, Harbor 0.24.0, 2026-11-14,
job pilot-20261114-or__A32__terminus-2__openai-gpt-6-astra. The reference is Table 2,
column 1 of Lai and Li, "China's Anticorruption Campaign and Civil Servant Fever",
The Journal of Law and Economics (2024).

The wording follows the page copy (metacase-economics.html; section 6 of the copy file).
What makes the task hard, in the order the video tells it:
  1. the result cannot simply be run: the task takes only the data from the authors'
     replication package, names a Stata command and the authors' script, supplies
     neither, and the container has no Stata; so the agent has to read Stata source
     written by others and rebuild the same algorithm in Python within a 1% tolerance;
  2. the specification is incomplete: the authors' script estimates the effect with and
     without covariates (-66.33 and -69.35) and the task does not say which column;
     the agent could not verify it and said so.
The column-2 figures (-69.35, standard error 22.68) are not from the run: after the run,
column 2's five covariates were put into the agent's delivered program (page copy 6.5).

Every figure on screen is read from the run record (data/econ.json, built by
tools/build_econ_data.py; terminal output quoted from the trial's terminus_2.pane) or
from the grader's receipt (verifier/reward-details.json). Trace times are the run's own
seconds. Only this run is shown; no other model or run appears.

say : narration sent to the voice; {key} marks the start of the next word and becomes a
      visual cue time. en : caption (defaults to say without markers).
trace: agent-run seconds swept by the header clock during the shot.
"""
from story.econ_scenes import SCENES  # noqa: F401  (centre-panel scenes of this story)

RUN = "econ"

SHOTS = [
    # ------------------------------------------------------------------ 01 TASK
    dict(id="e00", ch=0, kind="open",
         say="One model, one harness, one replication. {a}Follow how the agent works inside Terminus two, {b}and how its number is checked.",
         en="One model, one harness, one replication. Follow how the agent works inside Terminus-2, and how its number is checked.",
         st=("brand", "econ-0157 · economics · recorded pilot run")),
    dict(id="e01", ch=0, kind="question",
         say="From twenty thirteen, central inspection teams entered China's government departments {five}in five waves. {q}Did competition for their civil-service posts change? {panel}A published paper answers with data on seven hundred seventeen departments.",
         en="From 2013, central inspection teams entered China's government departments in five waves. Did competition for their civil-service posts change? A published paper answers with data on 717 departments.",
         st=("brand", "Lai and Li · The Journal of Law and Economics · 2024")),
    dict(id="e02", ch=0, kind="task",
         say="The task: reproduce one of its results as three numbers, {three}how large the effect is, how uncertain that estimate is, and whether it is significant, {script}with a script that reproduces them.",
         st=("brand", "task econ-0157 · three numbers · two files to hand in")),
    dict(id="e03", ch=0, kind="reflect",
         say="The first difficulty: the result cannot simply be run. The task names a Stata command {none}and the authors' script, but supplies neither, {stata}and the container has no Stata.",
         hold=1.0,
         st=("brand", "difficulty 1 · the result cannot simply be run")),
    dict(id="e04", ch=0, kind="task",
         say="Behind that command stand three Stata programs, one more than four thousand lines long. The agent has to rebuild the same algorithm in Python: {conv}cohort weights, the parts of the variance, dropped observations, degrees of freedom. {tol}Any departure may fall outside the one percent tolerance.",
         en="Behind that command stand three Stata programs, one more than four thousand lines long. The agent has to rebuild the same algorithm in Python: cohort weights, the parts of the variance, dropped observations, degrees of freedom. Any departure may fall outside the 1% tolerance.",
         hold=0.8,
         st=("brand", "difficulty 1 · rebuild the algorithm in Python, within 1%")),
    dict(id="e05", ch=0, kind="specs",
         say="The second difficulty: the specification is incomplete. The authors' script estimates the effect twice: {c1}minus sixty-six point three three without covariates, {c2}minus sixty-nine point three five with five. {q}The task does not say which, and the wrong one scores zero.",
         en="The second difficulty: the specification is incomplete. The authors' script estimates the effect twice: −66.33 without covariates, −69.35 with five. The task does not say which, and the wrong one scores zero.",
         hold=1.0,
         st=("brand", "difficulty 2 · the specification is incomplete")),
    dict(id="e07", ch=0, kind="sealed",
         say="The agent gets one data file. {lock}The reference values are not in the container.",
         st=("scorer", "tests/ and solution/ absent during the agent run")),

    # ------------------------------------------------------------------ 02 AGENT
    dict(id="e08", ch=1, kind="loop_intro",
         say="Terminus two runs the loop: {m}the model writes keystrokes, {h}Terminus two types them into a terminal, {s}the commands run in the container, {o}and the screen returns to the model.",
         en="Terminus-2 runs the loop: the model writes keystrokes, Terminus-2 types them into a terminal, the commands run in the container, and the screen returns to the model.",
         st=("harness", "harness · Terminus-2 2.0.0 · a tmux terminal in /workspace"), trace=(0.0, 8.5)),
    dict(id="e10", ch=1, kind="fetch",
         say="{net}The container has network access. {gh}At twenty-four seconds the agent takes the estimator's source from its author's GitHub repository, {mata}and later the regression program it depends on: {gen}general-purpose programs, with nothing specific to this study.",
         en="The container has network access. At 24 seconds the agent takes the estimator's source from its author's GitHub repository, and later the regression program it depends on: general-purpose programs, with nothing specific to this study.",
         hold=1.2,
         st=("model", "commands 5 and 13 · eventstudyinteract.ado · reghdfe.mata"), trace=(8.5, 33.6)),
    dict(id="e12", ch=1, kind="algo",
         say="{src}The source gives the algorithm: {int}estimate each cohort's effect, {avg}weight the effects by cohort shares, {var}and add a variance term for the shares.",
         hold=0.8,
         st=("sandbox", "command 6 · comment lines of eventstudyinteract.ado, as printed"), trace=(33.6, 47.0)),
    dict(id="e14", ch=1, kind="sample",
         say="{sing}Seventy-six departments are observed only once. {before}The shares are computed before they are dropped; {n}the regression then uses three thousand one hundred seventy observations.",
         en="76 departments are observed only once. The shares are computed before they are dropped; the regression then uses 3,170 observations.",
         hold=0.4,
         st=("sandbox", "command 11 · recorded assistant text · +74.0 s"), trace=(59.0, 74.0)),
    dict(id="e15", ch=1, kind="dof",
         say="{mata}For the standard error it reads the regression program's source, {line}past line four thousand, {dof}to confirm the correction for clustered errors.",
         en="For the standard error it reads the regression program's source, past line 4,000, to confirm the correction for clustered errors.",
         hold=1.4,
         st=("sandbox", "commands 13–14 · reghdfe.mata · 641 clusters → 640 degrees of freedom"), trace=(74.0, 80.1)),
    dict(id="e11", ch=1, kind="search",
         say="{srch}Meanwhile it searches for the authors' script: {where}GitHub, Google, Bing, Harvard Dataverse. {nf}It does not find it.",
         hold=1.2,
         st=("model", "commands 7–16 · 3a_analysis_ncse.do · not found"), trace=(80.1, 104.3)),
    dict(id="e16", ch=1, kind="estimate",
         say="{run}Then it runs its own estimator in Python: {b}minus sixty-six point three three, {se}with a standard error of twenty-five point zero five.",
         en="Then it runs its own estimator in Python: −66.33, with a standard error of 25.05.",
         hold=1.2,
         st=("sandbox", "command 17 · +123.5 s · /output/estimate.py"), trace=(123.5, 124.5)),
    dict(id="e13", ch=1, kind="cohorts",
         say="{w}That number is a weighted sum. {n}The five cohorts hold fourteen, eight, sixty-five, seventy-nine and fourteen treated observations; {eff}their shares weight {sum}the five cohort effects.",
         en="That number is a weighted sum. The five cohorts hold 14, 8, 65, 79 and 14 treated observations; their shares weight the five cohort effects.",
         hold=0.6,
         st=("sandbox", "commands 11 and 17 · 180 treated observations in five cohorts"), trace=(124.5, 124.5)),
    dict(id="e17", ch=1, kind="altsets",
         say="{alt}It tries four other sets of covariates too. {mv}The estimates differ. {keep}It does not pick a set without support, and keeps the baseline.",
         hold=1.6,
         st=("model", "command 17 · five covariate sets · recorded assistant text · +140.9 s"), trace=(124.5, 140.9)),
    dict(id="e18", ch=1, kind="validate",
         say="{val}It checks the result another way: {dum}a regression with explicit department and year dummies {same}gives the same five cohort effects.",
         hold=1.0,
         st=("pass", "command 22 · +178.5 s · validation passed"), trace=(178.5, 185.0)),
    dict(id="e19", ch=1, kind="stall",
         say="{more}It goes on searching, finds two replication packages, {none}and declines to use them. {stall}Then one lookup holds the terminal, and the commands queued behind it never run. {cc}The agent interrupts it, then writes and runs its files.",
         hold=0.6,
         st=("fail", "“I will not use unrelated replication code.” · interrupt at +376.0 s"), trace=(245.4, 393.7)),
    dict(id="e20", ch=1, kind="finish",
         say="{doc}Its script states what it could not verify: {q}which covariates each column uses. {fin}Then it marks the task complete: {tot}forty requests, fifty-two tool calls, about eight minutes.",
         en="Its script states what it could not verify: which covariates each column uses. Then it marks the task complete: 40 requests, 52 tool calls, about eight minutes.",
         hold=0.4,
         st=("model", "agent trace 500.5 s · 16,649 output tokens"), trace=(478.7, 500.5)),

    # ------------------------------------------------------------------ 03 HARNESS
    dict(id="e21", ch=2, kind="trace",
         say="Here is the whole run: {calls}fifty-two tool calls. {turn}The estimate was confirmed by one hundred eighty-five seconds; nearly five more minutes went on searching.",
         en="Here is the whole run: 52 tool calls. The estimate was confirmed by 185 seconds; nearly five more minutes went on searching.",
         hold=0.8,
         st=("harness", "52 tool calls · 40 requests · 500.5 s"), trace=(500.5, 500.5)),
    dict(id="e23", ch=2, kind="handoff",
         say="{stop}When the agent stops, {tests}Harbor copies the grader and the reference values into the same container. {score}Only then does scoring begin.",
         st=("scorer", "same container · tests/ copied in · the grader runs as root"), trace=(500.5, 500.5)),

    # ------------------------------------------------------------------ 04 CHECK
    dict(id="e24", ch=3, kind="chapter",
         say="An independent check now takes over.",
         title="Independent check", sub="The result file is compared with the reference, number by number.", hold=1.0,
         st=("scorer", "evaluate.py · a deterministic grader")),
    dict(id="e25", ch=3, kind="compare",
         say="{g}The grader calls no model. {c}The coefficient matches the reference. {s}So does the standard error. {p}The p-value is off by two ten-thousandths, within tolerance.",
         hold=0.6,
         st=("scorer", "evaluate.py · reference.json · graded in 0.2 s")),
    dict(id="e26", ch=3, kind="pbasis",
         say="{why}The gap has a cause: {t}the agent used the t distribution; {n}the reference agrees with the normal.",
         hold=1.6,
         st=("scorer", "one t statistic · two reference distributions")),
    dict(id="e27", ch=3, kind="specs",
         say="{rule}All three must pass, or the score is zero. {alt}After the run, column two's five covariates were put into the agent's own program: {off}minus sixty-nine point three five, four point six percent off. {zero}That scores zero.",
         en="All three must pass, or the score is zero. After the run, column 2's five covariates were put into the agent's own program: −69.35, 4.6% off. That scores zero.",
         hold=1.2,
         st=("fail", "recomputed after the run · not part of the agent's run")),

    # ------------------------------------------------------------------ 05 RESULT
    dict(id="e28", ch=4, kind="reward",
         say="{rw}The grader's verdict is one: {w}all three comparisons pass. {pilot}It is one pilot run, not accuracy and not a ranking.",
         st=("scorer", "reward 1.0 · one pilot run")),
    dict(id="e29", ch=4, kind="reflect",
         say="{net}The agent had network access, and obtained the estimator's public source, not the authors' script. {rep}It rebuilt a published method; it did not derive one. {why}And its baseline was never checked against that script.",
         hold=1.3,
         st=("brand", "what this record shows · and what it does not")),
    dict(id="e30", ch=4, kind="outro",
         say="A published estimate, an agent run, and an independent check. {site}Explore more on the Global Metacase Challenge site.",
         st=("brand", "easonai-5589.github.io/metacase-challenge")),
]

# ---------------------------------------------------------------------------- persistent panels
CONF = dict(
    task_id="econ-0157", domain="Economics", version="",
    title="Replicating a staggered difference-in-differences estimate",
    title_zh="",
    role="Replication · Lai and Li, The Journal of Law and Economics (2024)",
    meta="1 data file · JSON + Python · 30-minute limit",
    chips=[("MODEL", "gpt-6-astra"), ("HARNESS", "Terminus-2 2.0.0"),
           ("SANDBOX", "Docker · tmux"), ("GRADER", "evaluate.py")],
    total_tools=52, total_requests=40, inputs=1, plan_slots=8,
    plan_labels=[],
    # (trace s, label, value, colour) — values as the run printed them, rounded for display
    found=[
        (9.6, "panel rows", "3,246", "fg"),
        (24.7, "estimator source", "fetched", "model"),
        (60.1, "cohorts", "5", "fg"),
        (74.0, "singletons", "76", "warn"),
        (124.5, "coefficient", "−66.33", "model"),
        (124.5, "standard error", "25.053", "fg"),
        (140.9, "other covariate sets", "4 run", "warn"),
        (179.6, "dummy check", "passed", "pass"),
    ],
    files_opened_label="data file opened",
    # decorative labels in the opening particle cloud: codes and totals of this run
    particle_words=("%", "Δ", "se", "p", "FE", "DiD", "2013", "2017", "717", "40", "{ }"),
    # wording that differs from the Finance and HR stories
    track_label="ECONOMETRICS",
    loop_title="Terminus-2 · tool loop",
    plan_kicker="SETTINGS TO MATCH",
    plan_empty="nothing settled yet",
    plan_footer="ticked when the run record shows it settled",
    ledger_legend=(("command", (115, 213, 156)), ("wait", (92, 104, 124)), ("complete", (185, 164, 247)),
                   ("exit ≠ 0", (242, 119, 122))),
    out_dir="/output", out_kinds=("json", "py"),
    container_label="Docker container · Harbor 0.24.0",
    container_tools="python3 · pandas · pyfixest · pyhdfe",
    input_label="/data/0157/data · 1 file · read-only",
    input_note="data_for_analysis.dta · 3,246 rows · 30 labelled variables",
    deliverables=[("json", "Result file"), ("py", "Script")],
    tests_lines=["reference.json", "evaluate.py"],
    handoff=dict(session="Terminus-2 · agent session", model="model: gpt-6-astra",
                 out="/output · submitted files",
                 scorer=("evaluate.py · a deterministic grader",
                         "it reads 157_result.json and the reference",
                         "no model call, no channel back")),
    open_scorer="independent grader",
    outro_q="A published estimate, reproduced and checked",
    outro_credit="Paper: Lai and Li, The Journal of Law and Economics (2024)",
    robot_sprites="sprites-terminus",   # the homepage robot holding the arena's Terminus-2 blaster (blaster-m.glb)
    robot_max_aim=80,                   # this blaster's muzzle enters the body box at steeper aims
)

# The left panel: the settings this estimate depends on, ticked at the trace second the
# run record first shows each one settled. This is a reading of the record, not a plan
# the agent wrote. "Column" is never ticked: the agent could not verify it and said so.
_SETTINGS = [
    ("Control cohort", "never inspected", None, 9.6),
    ("Estimator", "Sun–Abraham", 24.7, 47.0),
    ("Cohort weights", "5 cohorts", None, 60.1),
    ("Sample", "singletons out", None, 74.0),
    ("Variance", "two terms", None, 124.5),
    ("Degrees of freedom", "641 − 1", 74.0, 124.5),
    ("Column", "unverified", 140.9, None),
    ("Result file", "written", None, 393.7),
]
_PENDING_NOTE = {"Estimator": "source fetched", "Degrees of freedom": "reading source", "Column": "unverified"}


def plan(T):
    if T is None:
        return None
    rows = []
    for text, note, started, done in _SETTINGS:
        if done is not None and T >= done:
            rows.append(dict(text=text, status="completed", note=note))
        elif started is not None and T >= started:
            rows.append(dict(text=text, status="in_progress", note=_PENDING_NOTE[text]))
        else:
            rows.append(dict(text=text, status="pending"))
    return rows


def outputs(T):
    """State of /output at trace time T (from the recorded commands; sizes from the collected artifacts)."""
    out = []
    if T >= 393.7:
        out.append(dict(kind="py", name="main.py", meta="written by the agent",
                        size="3,910 B" if T >= 479.8 else "", state="ok"))
        out.append(dict(kind="json", name="157_result.json", meta="3 numbers",
                        size="106 B" if T >= 479.8 else "", state="ok"))
    return out


# ---------------------------------------------------------------------------- shot payloads (visuals)
_LAB = ["MODEL", "TOOL CALL", "DOCKER · TMUX", "OBSERVATION"]

PAY = {
    "e00": dict(pet=[(0.0, (720, 530)), ("a", (560, 622)), ("b", (640, 690))]),
    "e01": dict(title="The question", sub="Did a central inspection change competition for civil-service posts?",
                paper="China's Anticorruption Campaign and Civil Servant Fever",
                cite="Lai and Li · The Journal of Law and Economics · 2024",
                years=[2012, 2013, 2014, 2015, 2016, 2017], cohorts=[2013, 2014, 2015, 2016, 2017],
                cohort_note="five inspection cohorts · 2013–2017",
                outcome="outcome: comp · labelled AHR in the data",
                stats=[("717", "departments"), ("2012–2017", "six years"), ("3,246", "department-years")],
                foot="one Stata data file · 30 labelled variables",
                pet=[(0.0, (960, 370)), ("five", (960, 500)), ("panel", (960, 652))]),
    "e02": dict(title="The task", sub="Reproduce one published result as three numbers",
                deadline="agent time limit · 30 minutes", badge_r="outcome: applicant-to-hire ratio",
                items=[dict(id="coefficient", obj="1", title="How large the effect of inspection is",
                            amount="", tag=""),
                       dict(id="standard error", obj="2", title="How uncertain that estimate is", amount="", tag=""),
                       dict(id="p-value", obj="3", title="Whether it is significant", amount="", tag="")],
                items_at="three",
                pet=[(0.0, (700, 360)), ("three", (960, 477)), ("script", "output")]),
    "e03": dict(title="The first difficulty", sub="The result cannot simply be run",
                items=[("NAMED IN THE TASK", "eventstudyinteract · the Stata command the paper used",
                        "not supplied", "warn", 0.0),
                       ("NAMED IN THE TASK", "3a_analysis_ncse.do · the authors' script",
                        "not supplied · the task takes only the data from the authors' package", "warn", "none"),
                       ("THE CONTAINER", "Python, and no Stata",
                        "one data file · network access", "sandbox", "stata")],
                pet=[(0.0, (960, 376)), ("none", (960, 506)), ("stata", (960, 636))]),
    "e04": dict(title="The first difficulty", sub="Read the Stata source, rebuild the same algorithm in Python",
                deadline="three Stata programs · one over 4,000 lines", badge_r="tolerance: 1%", pill_w=520, cols=4,
                items=[dict(id="cohort weights", obj="", title="Each cohort's share of treated observations", amount="", tag=""),
                       dict(id="variance parts", obj="", title="The regression's, plus one for the shares",
                            amount="", tag=""),
                       dict(id="dropped units", obj="", title="Departments observed only once", amount="", tag=""),
                       dict(id="d.f. correction", obj="", title="Degrees of freedom, for clustered errors", amount="", tag="")],
                items_at="conv",
                pet=[(0.0, (700, 360)), ("conv", (960, 477))]),
    "e05": dict(title="The second difficulty", sub="The specification is incomplete",
                top=("task text: “row-specific covariates per table column”", 0.0),
                cols=[dict(kick="THE AUTHORS' SCRIPT · COLUMN 1", title="No covariates", c="model", at="c1", hi=[("c1", 2.0)],
                           rows=[("coefficient", "−66.33", "c1", "fg")]),
                      dict(kick="THE AUTHORS' SCRIPT · COLUMN 2", title="Five covariates", c="harness", at="c2", hi=[("c2", 2.0)],
                           rows=[("coefficient", "−69.35", "c2", "fg")])],
                col_h=170,
                bottom=("4.6% apart. The task does not say which column; the wrong one scores 0.", "q", "warn"),
                pet=[(0.0, (960, 339)), ("c1", (725, 469)), ("c2", (1195, 469)), ("q", (960, 606))]),
    "e07": dict(title="The environment", sub="One data file in, two files out; the reference stays outside",
                pet=[(0.0, (900, 836)), ("lock", (1310, 692))]),
    "e08": dict(as_="loop", accent="harness", container=0.0, phases=[dict(
        at=0.0, rq="", sub="Model → Terminus-2 → terminal → back to the model",
        stages=["gpt-6-astra", "Terminus-2", "tmux · bash", "terminal screen"],
        labels=["MODEL", "HARNESS", "DOCKER · TMUX", "OBSERVATION"],
        beats=[("m", 0), ("h", 1), ("s", 2), ("o", 3)], route="o",
        cards=[dict(kick="MODEL · REMOTE API", title="Chooses the next action", role="model", at="m", hi=[("m", "h")],
                    lines=["Reads the task and the terminal so far", "Replies with analysis, plan, keystrokes", "Served through OpenRouter"]),
               dict(kick="HARNESS", title="Terminus-2 runs the loop", role="harness", at="h", hi=[("h", "s")],
                    lines=["Types the keystrokes into a terminal", "Tools: bash_command, mark_task_complete", "Returns the new terminal output"]),
               dict(kick="SANDBOX · DOCKER", title="Work happens in /workspace", role="sandbox", at="s", hi=[("s", "o")],
                    lines=["python3 with pandas and pyhdfe", "Reads /data (read-only)", "Writes /output"])],)],
        pet=[("m", "card0"), ("h", "card1"), ("s", "card2"), ("o", (803, 470))]),
    "e10": dict(as_="loop", accent="model", tk=[("net", 23.7), ("gh", 24.7), ("mata", 33.6)], phases=[dict(
        at=0.0, rq="COMMANDS 5 AND 13 / 52", sub="Back to the source: the estimation command's public code",
        stages=["gpt-6-astra", "bash_command", "curl", "source files"],
        beats=[("net", 0), (("net", 0.6), 1), ("gh", 2), (("gh", 1.0), 3), ("mata", 2)], route=("mata", 1.0),
        cards=[dict(kick="COMMAND 5 · +23.7 s", role="model", mono=True, size=12.5, at="gh", hi=[("gh", "mata")], maxl=1,
                    lines=["curl … raw.githubusercontent", "  .com/lsun20/", "  EventStudyInteract/main/",
                           "  eventstudyinteract.ado", "wc -c: 6497 bytes"]),
               dict(kick="COMMAND 13 · +73.0 s", role="model", mono=True, size=12.5, at="mata", hi=[("mata", 2.5)], maxl=1,
                    lines=["curl … raw.githubusercontent", "  .com/sergiocorreia/", "  reghdfe/master/src/", "  reghdfe.mata"]),
               dict(kick="NETWORK USE", title="General-purpose programs", role="warn", at="gen",
                    hi=[("gen", 3.0)],
                    lines=["Nothing specific to this study", "Not the authors' script"])],)],
        pet=[("net", "stage0"), ("gh", "card0"), ("mata", "card1"), ("gen", "card2")]),
    "e11": dict(as_="loop", accent="model", tk=[("srch", 80.1), ("nf", 104.3)], phases=[dict(
        at=0.0, rq="COMMANDS 7–16 / 52", sub="Search for the authors' script by name",
        stages=["gpt-6-astra", "bash_command", "python · curl", "search results"],
        beats=[("srch", 0), (("srch", 0.6), 2), ("where", 2), ("nf", 3)],
        cards=[dict(kick="SEARCHED", role="model", mono=True, size=13.5, at="where", hi=[("where", "nf")],
                    lines=["GitHub code search", "Google · Bing · DuckDuckGo", "Harvard Dataverse",
                           "later: DataCite · Crossref"]),
               dict(kick="OBSERVATION · command 14", role="brand", mono=True, size=12.5, at=("where", 1.2), maxl=2,
                    lines=['3a_analysis_ncse.do "HTTP', '  Error 403: Forbidden"', 'ncse "HTTP Error 403:', '  Forbidden"']),
               dict(kick="RESULT", title="Script not found", role="warn", at="nf", hi=[("nf", 3.0)],
                    lines=["Requests refused, or", "unrelated results"])],)],
        pet=[("srch", "stage0"), ("where", "card0"), ("nf", "card2")]),
    "e12": dict(as_="loop", tk=[("src", 33.6), ("var", 47.0)], phases=[dict(
        at=0.0, rq="COMMAND 6 / 52", sub="Read the estimator's source: it cannot be run here",
        stages=["gpt-6-astra", "bash_command", "cat", "Stata source"],
        beats=[("src", 0), (("src", 0.5), 2), ("int", 3)],
        cards=[dict(kick="OBSERVATION · eventstudyinteract.ado", role="brand", mono=True, size=12.5, at="src", span=2, maxl=1,
                    cols=[None, "harness", "sandbox", "model", "warn", "warn"],
                    lines=["program define eventstudyinteract, eclass sortpreserve",
                           "* Loop over cohort and get cohort shares for relative times",
                           "* Estimate the interacted regression",
                           "* Take weighted average for IW estimators",
                           "* Ptwise variance from cohort share estimation and interacted",
                           "  regression"]),
               None,
               dict(kick="6,497 BYTES OF STATA", title="Read, not run", role="warn", at=("src", 0.8), hi=[(("src", 0.8), 2.5)],
                    lines=["There is no Stata", "to execute it"])],)],
        pet=[("src", "card0"), ("var", "card0")]),
    "e13": dict(sub="Cohort weights, cohort effects, and their weighted sum", rq="COMMANDS 11 AND 17 / 52",
                                cohorts=[(2013, 14, "0.078", "−38.2"), (2014, 8, "0.044", "+27.6"), (2015, 65, "0.361", "−49.2"),
                         (2016, 79, "0.439", "−104.9"), (2017, 14, "0.078", "−9.7")],
                sum_label="sum of weight × effect · no covariates", sum_value="−66.33",
                foot="counts at +59.0 s · effects at +123.5 s",
                pet=[("w", (960, 440)), ("eff", (960, 590)), ("sum", (960, 672))]),
    "e14": dict(as_="loop", tk=[("sing", 60.1), ("before", 74.0)], phases=[dict(
        at=0.0, rq="COMMAND 11 / 52", sub="Shares before the singletons are dropped, regression after",
        stages=["gpt-6-astra", "bash_command", "python", "terminal screen"],
        beats=[("sing", 3), ("before", 0), ("n", 0)],
        cards=[dict(kick="OBSERVATION · command 11", role="brand", mono=True, size=13, at="sing", hi=[("sing", "before")],
                    cols=[None, "warn", None],
                    lines=["Panel size distribution:", "{1: 76, 2: 52, 3: 53,", " 4: 98, 5: 113, 6: 325}"]),
               dict(kick="THE AGENT'S ANALYSIS · +74.0 s", role="model", size=14.5, at="before", hi=[("before", "n")],
                    lines=["“cohort shares must be calculated before dropping these singletons, because eventstudyinteract computes weights before invoking reghdfe”"],
                    maxl=7),
               dict(kick="THE REGRESSION SAMPLE", title="3,170 observations", role="sandbox", at="n", hi=[("n", 3.5)],
                    lines=["on 641 departments", "76 singletons dropped"])],)],
        pet=[("sing", "card0"), ("before", "card1"), ("n", "card2")]),
    "e15": dict(as_="loop", tk=[("mata", 74.0), ("line", 80.1)], phases=[dict(
        at=0.0, rq="COMMANDS 13–14 / 52", sub="The standard error follows reghdfe's own corrections",
        stages=["gpt-6-astra", "bash_command", "grep · sed", "Mata source"],
        beats=[("mata", 0), (("mata", 0.5), 2), ("line", 3)],
        cards=[dict(kick="COMMAND 13 · +73.0 s", role="model", mono=True, size=12.5, at="mata", maxl=1,
                    lines=["grep -n -E 'dof_adj|", "  nested_adj|dofminus|", "  N_clust.*N_clust|sol.df_r'", "  /output/reghdfe.mata"]),
               dict(kick="OBSERVATION · reghdfe.mata", role="brand", mono=True, size=12.5, at="line", span=2, maxl=1,
                    hi=[("dof", 3.5)], cols=["harness", "harness", "sandbox", "sandbox"],
                    lines=["4043: dof_adj = (sol.N - 1) / (sol.N - nested_adj - sol.df_m",
                           "        -S.df_a) * N_clust / (N_clust - 1)",
                           "4057: if (sol.df_r > df_r) {",
                           "4058:     sol.df_r = df_r"]),
               None],)],
        pet=[("mata", "card0"), ("line", "card1")]),
    "e16": dict(as_="loop", tk=[("run", 123.5), ("b", 124.5)], phases=[dict(
        at=0.0, rq="COMMAND 17 / 52", sub="The estimator, rebuilt in Python and run",
        stages=["gpt-6-astra", "bash_command", "python", "result"],
        beats=[("run", 0), (("run", 0.5), 1), (("run", 1.0), 2), ("b", 3)], route=("se", 1.0),
        cards=[dict(kick="COMMAND 17 · +123.5 s", role="model", mono=True, size=12.5, at="run", maxl=1,
                    lines=["cat > /output/estimate.py", "import numpy as np", "import pandas as pd", "import pyhdfe",
                           "from scipy.stats import t, norm", "def estimate(data,", "    covariates=()):"]),
               dict(kick="OBSERVATION · COVARIATES []", role="brand", mono=True, size=12.5, at="b", span=2, maxl=1,
                    hi=[("se", 3.5)], cols=["model", None, None, "harness", "harness", "sandbox"],
                    lines=["'coefficient': -66.32690130805284,", "'standard_error': 25.05311592215568,",
                           "'p_value': 0.008309820567288007", "'variance_regression': 619.5263433893384,",
                           "'variance_shares': 8.132274019632053,", "'n': 3170, 'clusters': 641"]),
               None],)],
        pet=[("run", "card0"), ("b", "card1")]),
    "e18": dict(as_="loop", tk=[("val", 178.5), ("same", 185.0)], phases=[dict(
        at=0.0, rq="COMMAND 22 / 52", sub="A second route to the same five cohort effects",
        stages=["gpt-6-astra", "bash_command", "python", "validation"],
        beats=[("val", 0), (("val", 0.5), 2), ("same", 3)],
        cards=[dict(kick="COMMAND 22 · +178.5 s", role="model", mono=True, size=12.5, at="val", maxl=1,
                    lines=["from estimate import estimate", "f=pd.get_dummies(x[['agcyid',", "  'year']].astype(str), …)",
                           "b,_,rank,_=lstsq(X,y)"]),
               dict(kick="OBSERVATION", role="pass", mono=True, size=12.5, at="dum", span=2, maxl=1, hi=[("same", 3.0)],
                    cols=["pass", None, None, None],
                    lines=["Explicit dummy-regression validation passed. Rank: 651",
                           "Cohort effects: [ -38.24707597   27.63881736",
                           "  -49.19392808 -104.94964402   -9.70475054]"]),
               None],)],
        pet=[("val", "card0"), ("dum", "card1")]),
    "e19": dict(as_="loop", tk=[("more", 246.5), ("stall", 367.2), ("cc", 376.0), (("cc", 2.0), 393.7)], phases=[dict(
        at=0.0, rq="COMMANDS 28–42 / 52", sub="Two packages declined, a stalled lookup, an interrupt",
        stages=["gpt-6-astra", "bash_command", "curl · python", "terminal screen"],
        beats=[("more", 0), (("more", 0.6), 2), ("none", 3), ("stall", 2), ("cc", 0), (("cc", 0.8), 3)],
        cards=[dict(kick="TWO PACKAGES · FILE LISTS", role="model", mono=True, size=12.5, at="more", hi=[("none", "stall")], maxl=1,
                    lines=["doi:10.7910/DVN/DJ989N", "  Figures.do · Tables.do", "doi:10.7910/DVN/SFYMSY", "  DO main.do · Codebook.tab",
                           "→ other studies"]),
               dict(kick="COMMAND 39 · +376.0 s", title="C-c", role="warn", mono=True, size=13.5, at="stall", hi=[("stall", "cc")],
                    lines=["the stalled lookup", "is interrupted"]),
               dict(kick="COMMAND 42 · +392.2 s", role="sandbox", mono=True, size=12.5, at=("cc", 0.8), hi=[(("cc", 0.8), 3.0)], maxl=1,
                    lines=["ls -l /output/main.py …", "", " 106 /output/157_result.json", "3910 /output/main.py"])],)],
        pet=[("more", "card0"), ("stall", "card1"), ("cc", "card2")]),
    "e20": dict(as_="loop", tk=[("doc", 479.8), ("fin", 486.4), ("tot", 500.5)], phases=[dict(
        at=0.0, rq="COMMANDS 50–52 / 52", sub="What the agent left on record, and the end of the run",
        stages=["gpt-6-astra", "task complete", "—", "done"], dim=[2],
        beats=[("doc", 0), ("fin", 1), ("tot", 0)],
        cards=[dict(kick="DELIVERABLE · /output/main.py · docstring", role="warn", mono=True, size=12.5, at="doc", span=2, maxl=1,
                    hi=[("q", "fin")], cols=[None, "warn", "warn", "warn"],
                    lines=["No extra covariates are included in this baseline. The named",
                           "source file 3a_analysis_ncse.do is not among the supplied files;",
                           "its table-column covariate mapping has not been verified."]),
               None,
               dict(kick="RUN TOTALS", title="40 requests · 52 tool calls", role="harness", at="tot", hi=[("tot", 3.0)],
                    lines=["39 commands · 10 waits", "1 interrupt · 2 completion marks", "agent trace 500.5 s"])],)],
        pet=[("doc", "card0"), ("tot", "card2")]),
}

for _s in SHOTS:
    _p = PAY.get(_s["id"])
    if _p:
        _p = dict(_p)
        if "as_" in _p:
            _p["as"] = _p.pop("as_")
        _s.update(_p)
    if _s.get("as") == "loop":
        _s.setdefault("labels", _LAB)
        _s.setdefault("container", 0.0)   # Terminus-2 drives the container's terminal; it is not drawn inside it

PAY2 = {
    "e17": dict(sub="Choice of specification: the estimates differ", rq="COMMAND 17 / 52",
                rows=[("none (the baseline)", "−66.33", "25.05", "kept", "model", "alt"),
                      ("lngdpp", "−66.97", "25.15", "", "fg", "alt"),
                      ("five covariates", "−68.97", "22.74", "", "fg", "alt"),
                      ("six covariates", "−69.49", "22.81", "", "fg", "alt"),
                      ("seven covariates", "−70.07", "22.88", "", "fg", "alt")],
                quote=("“Alternative covariate sets produce different estimates, so I will not substitute one without source support.”",
                       "recorded assistant text · +140.9 s", "keep"),
                pet=[("alt", (960, 365)), ("mv", (960, 515)), ("keep", (960, 654))]),
    "e21": dict(title="The whole run", sub="40 requests · 52 tool calls · 500.5 s",
                phases_=[(0, 24, "data"), (24, 124, "source · search"), (124, 186, "estimate"),
                         (186, 392, "search the archives"), (392, 500.5, "write · document")],
                marks=[(23.7, "source fetched", "model", "calls"), (185.0, "confirmed", "sandbox", "turn"),
                       (376.0, "interrupt", "warn", "turn")],
                counts=[("commands", 39, "sandbox"), ("waits", 10, "dim"), ("interrupt", 1, "warn"),
                        ("completion marks", 2, "harness")],
                count_at=0.6, foot="red dots: non-zero exits (2) · bars: output tokens of each response",
                pet=[(0.0, (960, 640)), ("calls", (594, 762)), ("turn", (1050, 560))]),
    "e23": dict(sub="Harbor ends the agent phase and starts scoring",
                pet=[("stop", (712, 520)), ("tests", (1240, 640)), ("score", (1150, 806))]),
    "e24": dict(pet=[(0.0, (960, 594))]),
    "e25": dict(sub="Three numbers against the reference",
                grader="evaluate.py · deterministic · no model call", grader_r="graded in 0.2 s",
                rows=[("Coefficient", "−66.326901", "−66.326901", "0.00%", "within 1%", "c"),
                      ("Standard error", "25.053116", "25.053116", "0.00%", "within 1%", "s"),
                      ("p-value", "0.008110", "0.008310", "0.0002", "within 0.01", "p")],
                note="All three must pass. There is no partial credit.", note_at="p",
                pet=[("g", (960, 337)), ("c", (960, 440)), ("s", (960, 524)), ("p", (960, 608))]),
    "e26": dict(sub="Why the p-value differs from the reference",
                stat_label="T STATISTIC", stat="−2.647", stat_note="coefficient ÷ standard error",
                rows=[("t distribution · 640 d.f.", "the value in the result file", "0.00831", "reported", "model", "t"),
                      ("normal distribution", "agrees with the reference", "0.00811", "= reference", "pass", "n")],
                diff_label="Difference between the two", diff_note="tolerance for the p-value: 0.01", diff="0.0002",
                diff_at=("n", 0.7), had_at=("n", 0.3),
                log_kick="THE AGENT'S OWN DIAGNOSTICS · COMMAND 17 · +123.5 s",
                log=["'p_value': 0.008309820567288007", "'p_normal': 0.00811010689144556"], log_hot=1, log_dx=440,
                pet=[("why", (660, 390)), ("t", (1120, 350)), ("n", (1120, 430)), (("n", 1.4), (960, 636))]),
    "e27": dict(check=True, title="Independent check", sub="The weight of a specification: recomputed after the run",
                cols=[dict(kick="COLUMN 1 · REPORTED BY THE AGENT", title="No covariates", c="pass", at=0.0,
                           rows=[("coefficient", "−66.33", 0.0, "fg"), ("standard error", "25.05", 0.0, "fg"),
                                 ("off the reference", "0.0% · 0.0%", 0.0, "pass")],
                           badge=("all three within tolerance → 1", "pass", "rule")),
                      dict(kick="COLUMN 2 · RECOMPUTED AFTERWARDS", title="Five covariates", c="fail", at="alt", hi=[("off", 3.0)],
                           rows=[("coefficient", "−69.35", "alt", "fg"), ("standard error", "22.68", "alt", "fg"),
                                 ("off the reference", "4.6% · 9.5%", "off", "fail")],
                           badge=("outside the 1% tolerance → 0", "fail", "zero"))],
                col_h=292, row_h=44,
                bottom=("Same data, same program: only the covariates differ.", ("off", 1.0), "warn"),
                pet=[("rule", (725, 460)), ("alt", (1195, 460)), ("zero", (960, 658))]),
    "e28": dict(kicker="GRADER VERDICT", value="1.000", formula="coefficient · standard error · p-value: all within tolerance",
                line1="gpt-6-astra  +  Terminus-2 2.0.0  ·  econ-0157",
                line2="40 model requests · 52 tool calls · 500.5 s agent run",
                line3="deterministic grader, no model call · the container had network access",
                note="One pilot run — not accuracy, not a ranking.", note2="",
                pet=[("rw", (560, 600)), ("pilot", (690, 712))]),
    "e29": dict(title="Limits of this record", sub="What this run does and does not establish",
                items=[("NETWORK ACCESS", "The estimator's public source, not the authors' script",
                        "with network access, that script is not out of reach", "warn", "net"),
                       ("WHAT THE RECORD SHOWS", "A published method, rebuilt from its source",
                        "not an independent derivation of the method", "brand", "rep"),
                       ("NOT CHECKED", "The reported baseline, against the authors' script",
                        "the agent's script: “covariate mapping has not been verified”", "model", "why")],
                pet=[("net", (960, 376)), ("rep", (960, 506)), ("why", (960, 636))]),
    "e30": dict(pet=[(0.0, (560, 600)), ("site", (690, 594))]),
}

for _s in SHOTS:
    if _s["id"] in PAY2:
        _s.update(PAY2[_s["id"]])
    _s.setdefault("zh", "")


# ---------------------------------------------------------------------------- guide targets
# (name, highlighted box, laser tip, colour role[, dock]). The robot stands left of its tip,
# in the bottom-right corner unless a dock is given, and never over printed text.
def _row(name, box, role="brand", dock=(1310, 798)):
    return (name, box, (1424, box[1] + box[3] / 2), role, dock)


_OPEN = {(720, 530): ("brand-title", (640, 384, 640, 150), (720, 538), "brand", (570, 790)),
         (560, 622): ("run-participants", (360, 570, 1200, 52), (560, 628), "brand", (410, 790)),
         (640, 690): ("econ-task-title", (510, 650, 900, 80), (640, 736), "brand", (490, 790))}
_CARDS3 = {(960, 376): _row("first-card", (502, 318, 916, 116), "warn"),
           (960, 506): _row("second-card", (502, 448, 916, 116), "warn"),
           (960, 636): _row("third-card", (502, 578, 916, 116), "brand")}

GUIDE = {
    "e00": _OPEN,
    "e01": {(960, 370): _row("published-paper", (502, 314, 916, 112)),
            (960, 500): _row("five-inspection-cohorts", (502, 456, 916, 122), "model"),
            (960, 652): _row("panel-size", (502, 606, 916, 92))},
    "e02": {(700, 360): ("time-limit", (502, 314, 430, 46), (938, 366), "brand", (700, 798)),
            (960, 477): _row("three-numbers-to-reproduce", (502, 384, 916, 186), "model")},
    "e03": _CARDS3,
    "e04": {(700, 360): ("three-stata-programs", (502, 314, 520, 46), (1028, 366), "brand", (800, 798)),
            (960, 477): _row("four-conventions", (502, 384, 916, 186), "model")},
    "e05": {(960, 339): _row("task-text", (502, 314, 916, 50)),
            (725, 469): ("without-covariates", (502, 384, 446, 170), (954, 469), "model", (760, 798)),
            (1195, 469): _row("with-covariates", (972, 384, 446, 170), "harness"),
            (960, 606): _row("column-not-named", (502, 574, 916, 64), "warn")},
    "e07": {(900, 836): ("agent-container", (502, 314, 680, 520), (1188, 840), "sandbox", (1062, 798)),
            (1310, 692): ("sealed-reference", (1204, 360, 214, 330), (1424, 696), "brand", (1310, 798))},
    "e08": {(803, 470): ("observation-return", (596, 428, 727, 36), (803, 470), "brand", (689, 798))},
    "e13": {(960, 440): _row("treated-observations-by-cohort", (640, 330, 778, 190), "sandbox"),
            (960, 590): _row("weights-and-effects", (502, 552, 916, 76), "model"),
            (960, 672): _row("weighted-sum", (502, 640, 916, 64), "model")},
    "e17": {(960, 365): _row("baseline-row", (502, 344, 916, 42), "model"),
            (960, 515): _row("other-covariate-sets", (502, 394, 916, 192), "warn"),
            (960, 654): _row("agent-keeps-the-baseline", (502, 608, 916, 92), "model")},
    "e21": {(960, 640): ("whole-run-trace", (502, 314, 916, 352), (1424, 672), "harness", (1310, 798)),
            (594, 762): ("tool-call-counts", (502, 690, 722, 70), (1424, 726), "sandbox", (1310, 798)),
            (1050, 560): ("after-the-estimate-was-confirmed", (974, 314, 444, 352), (1424, 672), "warn", (1310, 798))},
    "e23": {(712, 520): ("agent-session-ended", (526, 370, 380, 150), (912, 526), "harness", (798, 798)),
            (1240, 640): ("tests-copied-into-container", (1088, 362, 300, 264), (1424, 654), "brand", (798, 798)),
            (1150, 806): ("grader-starts", (932, 694, 462, 110), (926, 750), "brand", (800, 798))},
    "e24": {(960, 594): ("independent-check-chapter", (560, 432, 800, 150), (960, 594), "brand", (810, 790))},
    "e25": {(960, 337): ("grader-no-model", (502, 314, 503, 46), (1011, 340), "brand", (781, 798)),
            (960, 440): _row("coefficient-matches", (502, 404, 916, 72), "pass"),
            (960, 524): _row("standard-error-matches", (502, 488, 916, 72), "pass"),
            (960, 608): _row("p-value-inside-tolerance", (502, 572, 916, 72), "pass")},
    "e26": {(660, 390): ("t-statistic", (502, 314, 300, 150), (808, 390), "brand", (600, 798)),
            (1120, 350): _row("t-distribution-reported", (826, 314, 592, 70), "model"),
            (1120, 430): _row("normal-is-the-reference", (826, 394, 592, 70), "pass"),
            (960, 636): _row("agent-diagnostics-show-it", (502, 580, 916, 112), "model")},
    "e27": {(725, 460): ("baseline-reported", (502, 314, 446, 292), (954, 460), "pass", (760, 798)),
            (1195, 460): _row("variant-would-fail", (972, 314, 446, 292), "fail"),
            (960, 658): _row("same-sign-different-specification", (502, 626, 916, 64), "warn")},
    "e28": {(560, 600): ("grader-verdict", (550, 254, 820, 414), (1376, 674), "warn", (1226, 790)),
            (690, 712): ("pilot-run-scope", (550, 690, 820, 48), (1376, 746), "warn", (1226, 790))},
    "e29": _CARDS3,
    "e30": {(560, 600): ("outro-line", (500, 486, 920, 54), (560, 546), "brand", (410, 790)),
            (690, 594): ("challenge-site", (640, 566, 640, 46), (640, 618), "brand", (490, 790))},
}


# ---------------------------------------------------------------------------- per-shot state
def _out(name, kind="json"):
    def f(ctx, sh, t, st):
        import gfx as G
        st["out_hi"] = G.ease(G.seg(t, sh.cue(name), sh.cue(name) + 0.5))
        st["out_kind"] = kind
    return f


def _found(name, label):
    def f(ctx, sh, t, st):
        import gfx as G
        st["found_hi"] = G.fade_io(t, sh.cue(name), sh.dur, 0.4)
        st["found_label"] = label
    return f


def _plan_hi(name):
    def f(ctx, sh, t, st):
        import gfx as G
        st["plan_hi"] = G.fade_io(t, sh.cue(name), sh.dur, 0.4)
    return f


def _e20(ctx, sh, t, st):
    import gfx as G
    st["ledger_hi"] = {"req": G.fade_io(t, sh.cue("tot"), sh.dur, 0.3)}
    st["plan_hi"] = G.fade_io(t, sh.cue("q"), sh.cue("fin"), 0.4)


def _e17(ctx, sh, t, st):
    _found("alt", "other covariate sets")(ctx, sh, t, st)
    _plan_hi("keep")(ctx, sh, t, st)


STATE = {"e02": _out("script", "py"), "e10": _found("gh", "estimator source"), "e13": _found("sum", "coefficient"),
         "e14": _found("sing", "singletons"), "e16": _found("se", "standard error"), "e17": _e17,
         "e18": _found("same", "dummy check"), "e19": _out(("cc", 0.8)), "e20": _e20}
