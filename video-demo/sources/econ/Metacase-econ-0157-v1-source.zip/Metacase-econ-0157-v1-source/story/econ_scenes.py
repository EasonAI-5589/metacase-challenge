"""Centre-panel scenes used only by the econ-0157 story.

They follow engine/scenes_x.py: one function per shot kind, all timing keyed to narration
cues, every figure passed in through the shot payload (story/econ.py) so the numbers live
in one place. Inner content area of the centre panel: x 502..1418, y 314..836.

Layout rule: content stops at y 705. The guide robot stands in the bottom-right corner
(dock 1310, 798) and aims at the right edge of the box in focus, so nothing printed on a
card is covered. Footers sit bottom-left and end before x 1250.
"""
from __future__ import annotations

import gfx as G
from scenes import cue, after
from scenes_x import frame, check_frame, IX0, IX1

CARD = (13, 18, 26)
FULL_W = IX1 - IX0


def _box(cv, x, y, w, h, a, stroke=None, fill=CARD, sw=1.4, r=12):
    G.rrect(cv, x, y, w, h, r, fill=fill, fa=0.96, stroke=stroke or G.EDGE, sw=sw, a=a)


def _foot(cv, d, a, y=724):
    if d.get("foot"):
        G.text(cv, d["foot"], IX0, y, size=14.5, c=G.DIM, kind="mono", a=a, maxlines=2, width=740)


# ============================================================================ TASK
def draw_question(cv, sh, t, a, ctx):
    """The paper, the five inspection cohorts on a 2012-2017 axis, and the panel's size."""
    d = sh.d
    frame(cv, a, d.get("title", "The question"), d.get("sub", ""), title_c=G.BRAND)
    k0 = after(sh, t, 0.0, 0.5)
    _box(cv, IX0, 314, FULL_W, 112, a * k0, stroke=G.mix(G.EDGE, G.BRAND, 0.6))
    G.kicker(cv, "PUBLISHED PAPER", IX0 + 20, 328, c=G.BRAND, a=a * k0, size=13)
    G.text(cv, d["paper"], IX0 + 20, 352, size=22, c=G.FG, weight=600, a=a * k0, maxlines=1, width=880)
    G.text(cv, d["cite"], IX0 + 20, 390, size=14.5, c=G.DIM, kind="mono", a=a * k0)
    # 2012..2017 axis with the five inspection cohorts
    years = d["years"]
    x0, x1, ya = IX0 + 70, IX1 - 70, 540
    kx = after(sh, t, 0.0, 0.6, 0.3)
    G.line(cv, [(x0 - 40, ya), (x1 + 40, ya)], (60, 72, 92), sw=2, a=a * kx)
    for j, yr in enumerate(years):
        x = x0 + (x1 - x0) * j / (len(years) - 1)
        G.line(cv, [(x, ya - 7), (x, ya + 7)], (90, 102, 122), sw=2, a=a * kx)
        G.text(cv, str(yr), x, ya + 16, size=16, c=G.DIM, kind="mono", a=a * kx, align="center")
        if yr in d["cohorts"]:
            i = d["cohorts"].index(yr)
            kw = a * G.ease(G.seg(t, cue(sh, "five") + i * 0.16, cue(sh, "five") + i * 0.16 + 0.45))
            if kw > 0.01:
                G.glow(cv, x - 16, ya - 72, 32, 32, 16, G.MODEL, a=0.35 * kw, sigma=10)
                G.circle(cv, x, ya - 56, 15 * (0.6 + 0.4 * kw), fill=G.mix(G.PANEL, G.MODEL, 0.35), stroke=G.MODEL, sw=1.8, a=kw)
                G.text(cv, str(i + 1), x, ya - 66, size=15, c=G.FG, weight=700, kind="mono", a=kw, align="center")
                G.line(cv, [(x, ya - 40), (x, ya - 9)], G.MODEL, sw=1.6, a=kw, dash=(4, 4))
    kf = after(sh, t, "five", 0.5, 0.6)
    G.text(cv, d["cohort_note"], IX0, 446, size=15, c=G.MODEL, kind="mono", a=a * kf)
    kq = after(sh, t, "q", 0.5)
    G.text(cv, d["outcome"], IX1, 446, size=15, c=G.FG, kind="mono", a=a * kq, align="right")
    # the panel
    kp = after(sh, t, "panel", 0.5)
    w = (FULL_W - 2 * 20) / 3
    for j, (val, lab) in enumerate(d["stats"]):
        x = IX0 + j * (w + 20)
        kj = a * G.ease(G.seg(t, cue(sh, "panel") + j * 0.18, cue(sh, "panel") + j * 0.18 + 0.45))
        _box(cv, x, 606, w, 92, kj)
        G.text(cv, val, x + 20, 618, size=34, c=G.FG, weight=600, a=kj)
        G.text(cv, lab, x + 20, 666, size=14, c=G.DIM, kind="mono", a=kj)
    _foot(cv, d, a * kp)


def draw_specs(cv, sh, t, a, ctx):
    """Two specifications side by side. Payload: top (text, cue); cols [dict(kick, title, c, at,
    code, rows [(label, value, cue, colour)], badge (text, colour, cue), hi)];
    bottom (text, cue, colour); col_h, row_h; check=True for the scorer's frame."""
    d = sh.d
    if d.get("check"):
        check_frame(cv, a, d.get("title", "Independent check"), d.get("sub", ""))
    else:
        frame(cv, a, d.get("title", "Two specifications"), d.get("sub", ""), title_c=G.BRAND)
    top = d.get("top")
    y = 314
    if top:
        kt = after(sh, t, top[1], 0.5)
        G.rrect(cv, IX0, y, FULL_W, 50, 25, fill=G.BRAND_TINT, stroke=G.BRAND, sw=1.4, a=a * kt)
        G.text(cv, top[0], IX0 + 26, y + 14, size=16.5, c=G.FG, kind="mono", a=a * kt, maxlines=1, width=870)
        y += 70
    cols = d["cols"]
    w = (FULL_W - 24) / 2
    h = d.get("col_h", 236)
    rh = d.get("row_h", 48)
    for j, c in enumerate(cols):
        x = IX0 + j * (w + 24)
        col = G.ROLE.get(c.get("c", "brand"), G.BRAND)
        k = a * after(sh, t, c.get("at", 0.0), 0.5)
        if k <= 0.01:
            continue
        hi = max((G.fade_io(t, cue(sh, hc[0]), cue(sh, hc[0]) + hc[1], 0.3) for hc in c.get("hi", [])), default=0.0)
        if hi > 0.01:
            G.glow(cv, x, y, w, h, 12, col, a=0.20 * hi * k, sigma=16)
        _box(cv, x, y, w, h, k, stroke=G.mix(G.EDGE, col, 0.45 + 0.55 * hi), sw=1.4 + hi)
        G.kicker(cv, c["kick"], x + 20, y + 18, c=col, a=k, size=13.5)
        G.text(cv, c["title"], x + 20, y + 42, size=24, c=G.FG, weight=600, a=k, maxlines=1, width=w - 40)
        ry = y + 92
        for (lab, val, at, vc) in c.get("rows", []):
            kr = k * after(sh, t, at, 0.45)
            G.text(cv, lab, x + 20, ry + 6, size=14.5, c=G.DIM, kind="mono", a=kr)
            G.text(cv, val, x + w - 20, ry, size=23, c=G.ROLE.get(vc, G.FG), weight=600, kind="mono", a=kr, align="right")
            G.line(cv, [(x + 20, ry + rh - 10), (x + w - 20, ry + rh - 10)], (30, 38, 50), sw=1, a=kr)
            ry += rh
        b = c.get("badge")
        if b:
            kb = k * after(sh, t, b[2], 0.45)
            bc = G.ROLE.get(b[1], G.FG)
            G.rrect(cv, x + 20, y + h - 54, w - 40, 38, 9, fill=G.mix(G.PANEL, bc, 0.14), stroke=bc, sw=1.4, a=kb)
            G.text(cv, b[0], x + w / 2, y + h - 45, size=15.5, c=bc, weight=600, kind="mono", a=kb, align="center")
    bot = d.get("bottom")
    if bot:
        kb = after(sh, t, bot[1], 0.5)
        bc = G.ROLE.get(bot[2], G.FG) if len(bot) > 2 else G.FG
        yb = y + h + 20
        _box(cv, IX0, yb, FULL_W, 64, a * kb, stroke=G.mix(G.EDGE, bc, 0.8))
        G.text(cv, bot[0], IX0 + 22, yb + 20, size=17, c=G.FG, a=a * kb, maxlines=1, width=872)
    _foot(cv, d, a)


# ============================================================================ AGENT
def draw_cohorts(cv, sh, t, a, ctx):
    """Five cohorts: treated observations as bars, weight and effect below, then the weighted sum."""
    d = sh.d
    frame(cv, a, d.get("title", ctx.conf.get("loop_title", "Tool loop")), d.get("sub", ""), d.get("rq", ""),
          accent=G.SANDBOX, accent_a=0.35)
    rows = d["cohorts"]                    # (year, treated obs, weight, effect)
    n = len(rows)
    xl = IX0 + 150
    cw = (IX1 - xl) / n
    base, hmax = 510, 140
    vmax = max(r[1] for r in rows)
    G.text(cv, "treated", IX0, 384, size=14, c=G.SANDBOX, kind="mono", a=a)
    G.text(cv, "observations", IX0, 404, size=14, c=G.SANDBOX, kind="mono", a=a)
    G.text(cv, "cohort", IX0, base + 14, size=14, c=G.DIM, kind="mono", a=a)
    G.text(cv, "weight", IX0, base + 54, size=14, c=G.HARNESS, kind="mono", a=a)
    G.text(cv, "effect", IX0, base + 98, size=14, c=G.MODEL, kind="mono", a=a)
    G.line(cv, [(xl - 6, base), (IX1, base)], (52, 62, 80), sw=1.2, a=a)
    for j, (yr, obs, wgt, eff) in enumerate(rows):
        cx = xl + cw * (j + 0.5)
        kb = G.ease(G.seg(t, cue(sh, "n") + j * 0.42 - 0.1, cue(sh, "n") + j * 0.42 + 0.4))
        hh = hmax * obs / vmax * kb
        if kb > 0.01:
            G.rrect(cv, cx - 34, base - hh, 68, max(hh, 1.0), 5, fill=G.mix(G.PANEL, G.SANDBOX, 0.55), stroke=G.SANDBOX,
                    sw=1.3, a=a * min(1.0, kb * 3))
        G.text(cv, str(obs), cx, base - hh - 30, size=22, c=G.FG, weight=600, kind="mono", a=a * kb, align="center")
        G.text(cv, str(yr), cx, base + 12, size=16, c=G.DIM, kind="mono", a=a, align="center")
        kw = G.ease(G.seg(t, cue(sh, "n") + j * 0.42 + 0.2, cue(sh, "n") + j * 0.42 + 0.6))
        G.text(cv, wgt, cx, base + 50, size=19, c=G.HARNESS, weight=600, kind="mono", a=a * kw, align="center")
        ke = G.ease(G.seg(t, cue(sh, "eff") + j * 0.14, cue(sh, "eff") + j * 0.14 + 0.4))
        G.text(cv, eff, cx, base + 94, size=19, c=G.MODEL, weight=600, kind="mono", a=a * ke, align="center")
    ks = after(sh, t, "sum", 0.5)
    ys = 640
    G.glow(cv, IX0, ys, FULL_W, 64, 12, G.MODEL, a=0.14 * ks * a, sigma=14)
    _box(cv, IX0, ys, FULL_W, 64, a * ks, stroke=G.MODEL, sw=1.6)
    G.text(cv, d["sum_label"], IX0 + 22, ys + 21, size=16.5, c=G.FG, kind="mono", a=a * ks)
    G.text(cv, d["sum_value"], IX1 - 22, ys + 11, size=32, c=G.MODEL, weight=700, kind="mono", a=a * ks, align="right")
    _foot(cv, d, a)


# ============================================================================ CHECK
def draw_compare(cv, sh, t, a, ctx):
    """The grader's three comparisons. rows: (name, reference, this run, error, tolerance, cue)."""
    d = sh.d
    check_frame(cv, a, d.get("title", "Independent check"), d.get("sub", ""))
    kg = after(sh, t, "g", 0.5)
    gw = G.measure(d["grader"], 16, 500, "mono")[0] + 78
    G.rrect(cv, IX0, 314, gw, 46, 23, fill=G.BRAND_TINT, stroke=G.SCORER, sw=1.4, a=a * kg)
    G.icon_role(cv, "scorer", IX0 + 28, 337, G.SCORER, a=a * kg, s=9)
    G.text(cv, d["grader"], IX0 + 50, 325, size=16, c=G.FG, kind="mono", a=a * kg)
    G.text(cv, d.get("grader_r", ""), IX1, 327, size=14.5, c=G.DIM, kind="mono", a=a * kg, align="right")
    xs = [IX0 + 20, IX0 + 216, IX0 + 376, IX0 + 540, IX0 + 656]
    heads = ["compared", "reference", "this run", "error", "tolerance"]
    yh = 378
    for x, hd in zip(xs, heads):
        G.text(cv, hd, x, yh, size=13, c=G.DIM, kind="mono", a=a * kg, ls=1.0)
    G.text(cv, "verdict", IX1 - 20, yh, size=13, c=G.DIM, kind="mono", a=a * kg, align="right", ls=1.0)
    for j, (name, ref, val, err, tol, at) in enumerate(d["rows"]):
        k = after(sh, t, at, 0.5)
        y = 404 + j * 84
        _box(cv, IX0, y, FULL_W, 72, a * kg, stroke=G.mix((30, 38, 50), G.PASS, 0.8 * k), sw=1.5)
        if k > 0.01:
            G.glow(cv, IX0, y, FULL_W, 72, 12, G.PASS, a=0.10 * k * a, sigma=12)
        G.text(cv, name, xs[0], y + 23, size=18, c=G.mix(G.DIM, G.FG, k), weight=600, a=a * kg)
        G.text(cv, ref, xs[1], y + 23, size=19, c=G.FG, kind="mono", a=a * k)
        G.text(cv, val, xs[2], y + 23, size=19, c=G.SANDBOX, weight=600, kind="mono", a=a * k)
        G.text(cv, err, xs[3], y + 25, size=15.5, c=G.FG, kind="mono", a=a * k)
        G.text(cv, tol, xs[4], y + 25, size=15.5, c=G.DIM, kind="mono", a=a * k)
        G.icon_check(cv, IX1 - 82, y + 36, G.PASS, a=a * k, s=9, sw=2.6, prog=G.ease(G.seg(t, cue(sh, at) + 0.2, cue(sh, at) + 0.6)))
        G.text(cv, "pass", IX1 - 20, y + 25, size=16, c=G.PASS, weight=600, kind="mono", a=a * k, align="right")
    kn = after(sh, t, d.get("note_at", "p"), 0.5, 0.6)
    G.text(cv, d.get("note", ""), IX0, 666, size=16.5, c=G.FG, a=a * kn, maxlines=1, width=916)
    _foot(cv, d, a)


def draw_pbasis(cv, sh, t, a, ctx):
    """One t statistic, two reference distributions. rows: (label, note, value, tag, colour, cue)."""
    d = sh.d
    check_frame(cv, a, d.get("title", "Independent check"), d.get("sub", ""))
    k0 = after(sh, t, "why", 0.5)
    _box(cv, IX0, 314, 300, 150, a * k0, stroke=G.mix(G.EDGE, G.BRAND, 0.6))
    G.kicker(cv, d["stat_label"], IX0 + 20, 330, c=G.BRAND, a=a * k0, size=13)
    G.text(cv, d["stat"], IX0 + 20, 362, size=52, c=G.FG, weight=700, kind="mono", a=a * k0, ls=-1)
    G.text(cv, d["stat_note"], IX0 + 20, 432, size=13.5, c=G.DIM, kind="mono", a=a * k0)
    x = IX0 + 324
    for j, (lab, note, val, tag, col, at) in enumerate(d["rows"]):
        k = after(sh, t, at, 0.5)
        y = 314 + j * 80
        c = G.ROLE.get(col, G.FG)
        _box(cv, x, y, IX1 - x, 70, a * k, stroke=G.mix(G.EDGE, c, 0.75))
        G.text(cv, lab, x + 20, y + 13, size=17, c=G.FG, weight=600, a=a * k, maxlines=1, width=330)
        G.text(cv, note, x + 20, y + 40, size=13.5, c=G.DIM, kind="mono", a=a * k, maxlines=1, width=360)
        G.text(cv, val, IX1 - 20, y + 9, size=26, c=c, weight=700, kind="mono", a=a * k, align="right")
        G.text(cv, tag, IX1 - 20, y + 44, size=13, c=c, kind="mono", a=a * k, align="right")
    kd = after(sh, t, d.get("diff_at", "n"), 0.5, 0.5)
    y = 484
    _box(cv, IX0, y, FULL_W, 76, a * kd, stroke=G.mix(G.EDGE, G.PASS, 0.8))
    G.text(cv, d["diff_label"], IX0 + 22, y + 14, size=17, c=G.FG, weight=600, a=a * kd)
    G.text(cv, d["diff_note"], IX0 + 22, y + 43, size=13.5, c=G.DIM, kind="mono", a=a * kd)
    G.text(cv, d["diff"], IX1 - 22, y + 18, size=30, c=G.PASS, weight=700, kind="mono", a=a * kd, align="right")
    kh = after(sh, t, d.get("had_at", "had"), 0.5)
    y = 580
    _box(cv, IX0, y, FULL_W, 112, a * kh, stroke=G.mix(G.EDGE, G.MODEL, 0.7))
    G.kicker(cv, d["log_kick"], IX0 + 22, y + 16, c=G.MODEL, a=a * kh, size=13)
    for j, ln in enumerate(d["log"]):
        hot = j == d.get("log_hot", -1)
        G.text(cv, ln, IX0 + 22 + j * d.get("log_dx", 300), y + 56, size=16, c=G.MODEL if hot else (196, 204, 216), weight=600 if hot else 500,
               kind="mono", a=a * kh)
    G.text(cv, d.get("log_note", ""), IX0 + 22, y + 80, size=13, c=G.DIM, kind="mono", a=a * kh)
    _foot(cv, d, a)


# ============================================================================ RESULT
def draw_reflect(cv, sh, t, a, ctx):
    """Three limits of the record, one card each: (kicker, headline, line, colour, cue)."""
    d = sh.d
    frame(cv, a, d.get("title", "Limits of this record"), d.get("sub", ""), title_c=G.BRAND)
    for j, (kick, head, line, col, at) in enumerate(d["items"]):
        k = after(sh, t, at, 0.5)
        y = 318 + j * 130
        c = G.ROLE.get(col, G.FG)
        yy = y + (1 - k) * 14
        _box(cv, IX0, yy, FULL_W, 116, a * k, stroke=G.mix(G.EDGE, c, 0.75), sw=1.5)
        G.rrect(cv, IX0, yy, 6, 116, 3, fill=c, a=a * k)
        G.kicker(cv, kick, IX0 + 28, yy + 15, c=c, a=a * k, size=13)
        G.text(cv, head, IX0 + 28, yy + 39, size=23, c=G.FG, weight=600, a=a * k, maxlines=1, width=860)
        G.text(cv, line, IX0 + 28, yy + 79, size=15.5, c=G.DIM, kind="mono", a=a * k, maxlines=1, width=860)
    _foot(cv, d, a)


def draw_altsets(cv, sh, t, a, ctx):
    """Covariate sets the agent ran. rows: (label, coefficient, standard error, tag, colour, cue);
    quote: (text, source, cue)."""
    d = sh.d
    frame(cv, a, d.get("title", ctx.conf.get("loop_title", "Tool loop")), d.get("sub", ""), d.get("rq", ""),
          accent=G.MODEL, accent_a=0.35)
    xs = [IX0 + 20, IX0 + 430, IX0 + 620]
    yh = 318
    for x, hd in zip(xs, ["covariates in the model", "coefficient", "standard error"]):
        G.text(cv, hd, x, yh, size=13, c=G.DIM, kind="mono", a=a, ls=1.0)
    for j, (lab, coef, se, tag, col, at) in enumerate(d["rows"]):
        k = after(sh, t, at, 0.45, j * 0.12 if j else 0.0)
        y = 344 + j * 50
        c = G.ROLE.get(col, G.FG)
        _box(cv, IX0, y, FULL_W, 42, a * k, stroke=G.mix(G.EDGE, c, 0.7 if tag else 0.25), r=9)
        G.text(cv, lab, xs[0], y + 11, size=15.5, c=G.FG, kind="mono", a=a * k, maxlines=1, width=400)
        G.text(cv, coef, xs[1], y + 9, size=19, c=c if tag else G.FG, weight=600, kind="mono", a=a * k)
        G.text(cv, se, xs[2], y + 9, size=19, c=G.FG, kind="mono", a=a * k)
        if tag:
            G.text(cv, tag, IX1 - 20, y + 12, size=14, c=c, weight=600, kind="mono", a=a * k, align="right")
    q = d.get("quote")
    if q:
        kq = after(sh, t, q[2], 0.5)
        y = 344 + len(d["rows"]) * 50 + 14
        _box(cv, IX0, y, FULL_W, 92, a * kq, stroke=G.mix(G.EDGE, G.MODEL, 0.7))
        G.rrect(cv, IX0, y, 6, 92, 3, fill=G.MODEL, a=a * kq)
        G.text(cv, q[0], IX0 + 28, y + 12, size=17, c=G.FG, weight=500, a=a * kq, maxlines=2, width=860, lh=1.3)
        G.text(cv, q[1], IX0 + 28, y + 66, size=13, c=G.DIM, kind="mono", a=a * kq)
    _foot(cv, d, a)


SCENES = {
    "question": draw_question, "specs": draw_specs, "cohorts": draw_cohorts,
    "compare": draw_compare, "pbasis": draw_pbasis, "reflect": draw_reflect, "altsets": draw_altsets,
}
