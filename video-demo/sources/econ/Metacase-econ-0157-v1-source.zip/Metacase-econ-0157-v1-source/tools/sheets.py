"""Contact sheets of the review stills: python tools/sheets.py <run> [per sheet=4] [suffix filter]

Tiles build/<run>/review/*.jpg two across into build/<run>/review/sheets/sheet-NN.jpg."""
import glob
import os
import sys

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
run = sys.argv[1]
per = int(sys.argv[2]) if len(sys.argv) > 2 else 4
flt = sys.argv[3] if len(sys.argv) > 3 else ""
src = sorted(p for p in glob.glob(os.path.join(ROOT, "build", run, "review", "*.jpg")) if flt in os.path.basename(p))
out = os.path.join(ROOT, "build", run, "review", "sheets")
os.makedirs(out, exist_ok=True)
for old in glob.glob(os.path.join(out, "*.jpg")):
    os.remove(old)
for k in range(0, len(src), per):
    ims = [Image.open(p) for p in src[k:k + per]]
    w, h = ims[0].size
    rows = (len(ims) + 1) // 2
    sheet = Image.new("RGB", (w * 2, h * rows), (0, 0, 0))
    for j, im in enumerate(ims):
        sheet.paste(im, ((j % 2) * w, (j // 2) * h))
    path = os.path.join(out, "sheet-%02d.jpg" % (k // per + 1))
    sheet.save(path, quality=88)
    print(path, [os.path.basename(p) for p in src[k:k + per]])
