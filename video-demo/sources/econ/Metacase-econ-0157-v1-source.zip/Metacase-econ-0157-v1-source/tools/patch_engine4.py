"""Fourth one-off patch (already applied): an aim limit for the guide robot.

The Terminus-2 blaster sits higher on the robot than the Claude Code one, so at aims
steeper than about 83 degrees its muzzle falls inside the body box that check_guide.py
tests the sight line against. A story can set CONF["robot_max_aim"] (degrees); every
dock is then moved left just far enough that the aim to its target stays within the
limit. Without the key nothing changes (Finance and HR stories)."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def patch(rel, pairs):
    path = os.path.join(ROOT, rel)
    s = open(path, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (rel, s.count(a), a[:80])
        s = s.replace(a, b)
    open(path, "w", encoding="utf-8", newline="\n").write(s)
    print("patched", rel, len(pairs))


patch("engine/guide_targets.py", [
    ('''def describe(sh, target):
    """Resolve a cue without changing its timing, highlight meaning, or facts."""
    sid = sh.id
''',
     '''MAX_AIM = None   # degrees; set from CONF["robot_max_aim"] by compose.Ctx
# Aim pivot relative to the dock: the feet are at dock + (48, 86); the pivot is the
# middle of grip and muzzle at level aim, (33.9, -18.8) stage pixels from the feet.
_PIVOT = (81.9, 67.2)


def describe(sh, target):
    """Resolve a cue; with MAX_AIM set, move the dock left until the aim is within it."""
    import math
    d = _describe(sh, target)
    tip, dock = d.get("tip"), d.get("dock")
    if MAX_AIM is None or tip is None or dock is None:
        return d
    dy = dock[1] + _PIVOT[1] - tip[1]
    if dy <= 0:
        return d
    need = dy * math.tan(math.radians(90.0 - MAX_AIM))
    if tip[0] - (dock[0] + _PIVOT[0]) < need:
        d = dict(d, dock=(round(tip[0] - _PIVOT[0] - need, 1), dock[1]))
    return d


def _describe(sh, target):
    """Resolve a cue without changing its timing, highlight meaning, or facts."""
    sid = sh.id
'''),
])
patch("engine/compose.py", [
    ('''        reference_robot.set_sprites(self.conf.get("robot_sprites", "sprites"))
''',
     '''        reference_robot.set_sprites(self.conf.get("robot_sprites", "sprites"))
        import guide_targets
        guide_targets.MAX_AIM = self.conf.get("robot_max_aim")
'''),
])

P = os.path.join(ROOT, "story", "econ.py")
s = open(P, encoding="utf-8").read()


def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80])
    s = s.replace(a, b)


rep('''    robot_sprites="sprites-terminus",   # the homepage robot holding the arena's Terminus-2 blaster (blaster-m.glb)
''',
    '''    robot_sprites="sprites-terminus",   # the homepage robot holding the arena's Terminus-2 blaster (blaster-m.glb)
    robot_max_aim=80,                   # this blaster's muzzle enters the body box at steeper aims
''')
# loop-scene footers sit where the robot stands when it points at the first cards
for foot in ('''
        foot="Harbor 0.24.0 · Terminus-2 2.0.0")],''', '''
        foot="both from GitHub")],''', '''
        foot="query: 3a_analysis_ncse.do")],''', '''
        foot="recorded assistant text, quoted")],''', '''
        foot="641 clusters → 640 degrees of freedom")],''', '''
        foot="the same effects as the residualised regression")],''', '''
        foot="“I will not use unrelated replication code.” · +299.9 s")],''', '''
        foot="/output/estimate.py")],''', '''
        foot="comment lines of the source, as printed")],''', '''
        foot="+500.5 s · the agent session ends here")],'''):
    rep(foot, ")],")
# what the dropped footers said goes to the status line or onto a card
rep('''st=("sandbox", "commands 13–14 · reghdfe.mata"), trace=(74.0, 80.1)),''',
    '''st=("sandbox", "commands 13–14 · reghdfe.mata · 641 clusters → 640 degrees of freedom"), trace=(74.0, 80.1)),''')
rep('''st=("fail", "commands 28–42 · interrupt at +376.0 s · files written at +391.2 s"), trace=(245.4, 393.7)),''',
    '''st=("fail", "“I will not use unrelated replication code.” · interrupt at +376.0 s"), trace=(245.4, 393.7)),''')
rep('''st=("sandbox", "command 6 · eventstudyinteract.ado · 6,497 bytes of Stata"), trace=(33.6, 47.0)),''',
    '''st=("sandbox", "command 6 · comment lines of eventstudyinteract.ado, as printed"), trace=(33.6, 47.0)),''')
# e02: the three numbers appear when they are named, after the robot has left the time limit
rep('''                items_at=1.0,
                pet=[(0.0, (700, 360)), ("three", (960, 477)), ("script", "output")]),''',
    '''                items_at="three",
                pet=[(0.0, (700, 360)), ("three", (960, 477)), ("script", "output")]),''')
open(P, "w", encoding="utf-8", newline="\n").write(s)
print("story updated")
