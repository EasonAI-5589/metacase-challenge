"""One-off: let the guide robot hold another harness's weapon (run once).

robot/sprite.html takes ?weapon=<glb file> (default blaster-e.glb, Claude Code) and reads the
site from /site/; robot/render_sprites.mjs takes --weapon and --page; engine/reference_robot.py
reads the sprite folder named by the story's CONF["robot_sprites"] (default "sprites").
"""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def patch(rel, pairs):
    p = os.path.join(ROOT, rel)
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        n = s.count(a)
        assert n == 1, (rel, n, a[:80])
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8", newline="\n").write(s)
    print("patched", rel, len(pairs))


patch("robot/sprite.html", [
    ("const SITE = '/inferencenet-challenge-website/';", "const SITE = new URLSearchParams(location.search).get('site') || '/site/';"),
    ("const claude = ARENA_WEAPONS.findIndex(w => w.file === 'blaster-e.glb');\nconst gun = weapons[claude];",
     "// ?weapon=blaster-d.glb is the arena's Codex CLI carbine; the default is Claude Code's blaster.\n"
     "const WEAPON = params.get('weapon') || 'blaster-e.glb';\n"
     "const claude = ARENA_WEAPONS.findIndex(w => w.file === WEAPON);\n"
     "if (claude < 0) throw new Error('unknown weapon ' + WEAPON);\n"
     "const gun = weapons[claude];"),
])
patch("robot/render_sprites.mjs", [
    ("await page.goto(`${base}/video-work/fin-v3/source/robot/sprite.html?size=${size}`);",
     "const pagePath = args.page || '/work/robot/sprite.html';\n"
     "const weapon = args.weapon ? `&weapon=${args.weapon}` : '';\n"
     "await page.goto(`${base}${pagePath}?size=${size}${weapon}`);"),
])
patch("engine/reference_robot.py", [
    ('''SPRITES = os.path.normpath(os.path.join(HERE, "..", "robot", "sprites"))''',
     '''SPRITES = os.path.normpath(os.path.join(HERE, "..", "robot", "sprites"))


def set_sprites(name="sprites"):
    """Choose the sprite set (robot/<name>): one folder per harness weapon."""
    global SPRITES
    path = os.path.normpath(os.path.join(HERE, "..", "robot", name))
    if path != SPRITES:
        SPRITES = path
        _meta.cache_clear()
        _image.cache_clear()'''),
])
patch("engine/compose.py", [
    ('''        U.TRACK_LABEL = self.conf.get("track_label", "BUSINESS ANALYSIS")
''', '''        U.TRACK_LABEL = self.conf.get("track_label", "BUSINESS ANALYSIS")
        import reference_robot
        reference_robot.set_sprites(self.conf.get("robot_sprites", "sprites"))
'''),
])
print("done")
