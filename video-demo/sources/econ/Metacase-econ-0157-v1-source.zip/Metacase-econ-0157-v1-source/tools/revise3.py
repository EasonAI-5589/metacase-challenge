"""One-off (already applied): bring the story under five minutes.

Drops the input/output shot (e06) and the context-growth shot (e22) and shortens the
narration of the remaining shots; no fact is added."""
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, "story", "econ.py")
s = open(P, encoding="utf-8").read()


def shot(sid):
    """Span of the dict(...) literal of one shot in SHOTS."""
    a = s.index('    dict(id="%s"' % sid)
    b = s.index("\n    dict(id=", a + 10) if '\n    dict(id=' in s[a + 10:a + 4000] else None
    c = s.index("\n\n    # ----", a) if "\n\n    # ----" in s[a:a + 4000] else None
    d = s.index("\n]\n", a)
    end = min(x for x in (b, c, d) if x is not None)
    return a, end


def drop_shot(sid):
    global s
    a, e = shot(sid)
    s = s[:a] + s[e + 1:]   # s[e] is the newline that ended the shot


def set_say(sid, say, en=None, hold="keep"):
    global s
    a, e = shot(sid)
    blk = s[a:e]
    m = re.search(r'\n         say="[^\n]*",\n', blk)
    assert m, sid
    new = '\n         say="%s",\n' % say
    blk = blk[:m.start()] + new + blk[m.end():]
    blk = re.sub(r'         en="[^\n]*",\n', '', blk)
    if en:
        blk = blk.replace(new, new + '         en="%s",\n' % en)
    if hold != "keep":
        blk = re.sub(r'         hold=[0-9.]+,\n', '', blk)
        blk = re.sub(r', hold=[0-9.]+', '', blk)
        if hold is not None:
            blk = blk.replace('         st=(', '         hold=%s,\n         st=(' % hold, 1)
    s = s[:a] + blk + s[e:]


drop_shot("e06")
drop_shot("e22")

set_say("e01",
        "From twenty thirteen, central inspection teams entered China's government departments {five}in five waves. {q}Did competition for their civil-service posts change? {panel}A published paper answers with data on seven hundred seventeen departments.",
        "From 2013, central inspection teams entered China's government departments in five waves. Did competition for their civil-service posts change? A published paper answers with data on 717 departments.")
set_say("e03",
        "The first difficulty: the result cannot simply be run. The task names a Stata command {none}and the authors' script, but supplies neither, {stata}and the container has no Stata.",
        hold=1.0)
set_say("e04",
        "Behind that command stand three Stata programs, one more than four thousand lines long. The agent has to rebuild the same algorithm in Python: {conv}cohort weights, the parts of the variance, dropped observations, degrees of freedom. {tol}Any departure may fall outside the one percent tolerance.",
        "Behind that command stand three Stata programs, one more than four thousand lines long. The agent has to rebuild the same algorithm in Python: cohort weights, the parts of the variance, dropped observations, degrees of freedom. Any departure may fall outside the 1% tolerance.",
        hold=0.8)
set_say("e05",
        "The second difficulty: the specification is incomplete. The authors' script estimates the effect twice: {c1}minus sixty-six point three three without covariates, {c2}minus sixty-nine point three five with five. {q}The task does not say which, and the wrong one scores zero.",
        "The second difficulty: the specification is incomplete. The authors' script estimates the effect twice: −66.33 without covariates, −69.35 with five. The task does not say which, and the wrong one scores zero.",
        hold=1.0)
set_say("e07",
        "The agent gets one data file. {lock}The reference values are not in the container.")
set_say("e08",
        "Terminus two runs the loop: {m}the model writes keystrokes, {h}Terminus two types them into a terminal, {s}the commands run in the container, {o}and the screen returns to the model.",
        "Terminus-2 runs the loop: the model writes keystrokes, Terminus-2 types them into a terminal, the commands run in the container, and the screen returns to the model.")
set_say("e10",
        "{net}The container has network access. {gh}At twenty-four seconds the agent takes the estimator's source from its author's GitHub repository, {mata}and later the regression program it depends on: {gen}general-purpose programs, with nothing specific to this study.",
        "The container has network access. At 24 seconds the agent takes the estimator's source from its author's GitHub repository, and later the regression program it depends on: general-purpose programs, with nothing specific to this study.",
        hold=1.2)
set_say("e11",
        "{srch}It also searches for the authors' script: {where}GitHub, Google, Bing, Harvard Dataverse. {nf}It does not find it.",
        hold=1.2)
set_say("e12",
        "{src}The source gives the algorithm: {int}estimate each cohort's effect, {avg}weight the effects by cohort shares, {var}and add a variance term for the shares.",
        hold=0.8)
set_say("e13",
        "{w}The five cohorts hold {n}fourteen, eight, sixty-five, seventy-nine and fourteen treated observations. {eff}Their shares weight the cohort effects: {sum}minus sixty-six point three three.",
        "The five cohorts hold 14, 8, 65, 79 and 14 treated observations. Their shares weight the cohort effects: −66.33.",
        hold=0.6)
set_say("e14",
        "{sing}Seventy-six departments are observed only once. {before}The shares are computed before they are dropped; {n}the regression then uses three thousand one hundred seventy observations on six hundred forty-one departments.",
        "76 departments are observed only once. The shares are computed before they are dropped; the regression then uses 3,170 observations on 641 departments.",
        hold=0.4)
set_say("e15",
        "{mata}For the standard error it reads the regression program's source, {line}past line four thousand, {dof}to confirm the correction for clustered errors.",
        "For the standard error it reads the regression program's source, past line 4,000, to confirm the correction for clustered errors.",
        hold=1.4)
set_say("e16",
        "{run}Then it runs its own estimator in Python: {b}minus sixty-six point three three, {se}with a standard error of twenty-five point zero five.",
        "Then it runs its own estimator in Python: −66.33, with a standard error of 25.05.",
        hold=1.2)
set_say("e19",
        "{more}It goes on searching, finds two replication packages, {none}and declines to use them. {stall}Then one lookup holds the terminal, and the commands queued behind it never run. {cc}The agent interrupts it, then writes and runs its files.",
        hold=0.6)
set_say("e20",
        "{doc}Its script states what it could not verify: {q}which covariates each column uses. {fin}Then it marks the task complete: {tot}forty requests, fifty-two tool calls, about eight minutes.",
        "Its script states what it could not verify: which covariates each column uses. Then it marks the task complete: 40 requests, 52 tool calls, about eight minutes.",
        hold=0.4)
set_say("e21",
        "Here is the whole run: {calls}fifty-two tool calls. {turn}The estimate was confirmed by one hundred eighty-five seconds; nearly five more minutes went on searching.",
        "Here is the whole run: 52 tool calls. The estimate was confirmed by 185 seconds; nearly five more minutes went on searching.",
        hold=0.8)
set_say("e25",
        "{g}The grader calls no model. {c}The coefficient matches the reference. {s}So does the standard error. {p}The p-value is off by two ten-thousandths, within tolerance.",
        hold=0.6)
set_say("e26",
        "{why}The gap has a cause: {t}the agent used the t distribution; {n}the reference agrees with the normal.",
        hold=1.6)
set_say("e27",
        "{rule}All three must pass, or the score is zero. {alt}After the run, column two's five covariates were put into the agent's own program: {off}minus sixty-nine point three five, four point six percent off. {zero}That scores zero.",
        "All three must pass, or the score is zero. After the run, column 2's five covariates were put into the agent's own program: −69.35, 4.6% off. That scores zero.",
        hold=1.2)
set_say("e29",
        "Read it with its limits. {net}The agent had network access, and obtained the estimator's public source, not the authors' script. {rep}It rebuilt a published method; it did not derive one. {why}And its baseline was never checked against that script.",
        hold=1.3)

pairs = [
    # e17: shorter hold
    ('''say="{alt}It tries four other sets of covariates too. {mv}The estimates differ. {keep}It does not pick a set without support, and keeps the baseline.",
         hold=2.2,''',
     '''say="{alt}It tries four other sets of covariates too. {mv}The estimates differ. {keep}It does not pick a set without support, and keeps the baseline.",
         hold=1.6,'''),
    # e26: the diagnostics box follows the normal-distribution row
    ('''pet=[("why", (660, 390)), ("t", (1120, 350)), ("n", (1120, 430)), ("had", (960, 636))]),''',
     '''pet=[("why", (660, 390)), ("t", (1120, 350)), ("n", (1120, 430)), (("n", 1.4), (960, 636))]),'''),
    # e07: one line for input and output, since the input/output shot is gone
    ('''"e07": dict(title="The environment", sub="What the agent can and cannot see",''',
     '''"e07": dict(title="The environment", sub="One data file in, two files out; the reference stays outside",'''),
    # e21: the count line no longer waits for the narration to list the four kinds
    ('''count_at="calls", foot="red dots: non-zero exits (2) · bars: output tokens of each response",''',
     '''count_at=0.6, foot="red dots: non-zero exits (2) · bars: output tokens of each response",'''),
]
for a, b in pairs:
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)

# payloads and guide targets of the two dropped shots
for key in ('    "e06": dict(title="The environment"', '    "e22": dict(title="What the model sees"',
            '    "e06": {(700, 380)', '    "e22": {(1484, 425)'):
    a = s.index(key)
    e = s.index('\n    "e', a + 5)
    s = s[:a] + s[e + 1:]

open(P, "w", encoding="utf-8", newline="\n").write(s)
print("done")
