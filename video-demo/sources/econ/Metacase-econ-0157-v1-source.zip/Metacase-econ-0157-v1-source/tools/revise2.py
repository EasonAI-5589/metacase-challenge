"""One-off (already applied): align story/econ.py with the final page copy for the
gpt-6-astra x Terminus-2 run, and switch the wordmark to "Global Metacase Challenge"."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def patch(rel, pairs):
    path = os.path.join(ROOT, rel)
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (rel, s.count(a), a[:80])
        s = s.replace(a, b)
    open(path, 'w', encoding='utf-8', newline='\n').write(s)
    print('patched', rel, len(pairs))


patch('engine/brand.py', [
    ('''def wordmark(cv, x, y, size, a=1.0, align="left", weight=650):''',
     '''# The site's wordmark has read "Global Metacase Challenge" since 2026-11-10 (site PR 75).
NAME_HEAD = "Global Metacase"


def wordmark(cv, x, y, size, a=1.0, align="left", weight=650):'''),
    ('''    w1 = G.measure("Metacase", size, weight, ls=ls)[0] + size * 0.26''', '''    w1 = G.measure(NAME_HEAD, size, weight, ls=ls)[0] + size * 0.26'''),
    ('''    G.text(cv, "Metacase", x0, y, size=size, c=G.WHITE, weight=weight, ls=ls)''', '''    G.text(cv, NAME_HEAD, x0, y, size=size, c=G.WHITE, weight=weight, ls=ls)'''),
])

patch('story/econ.py', [
 # docstring
 ('''What makes the task hard, in the order the video tells it:
  1. the task names a Stata command and the authors' script, supplies neither, and the
     container has no Stata;
  2. so the agent has to read Stata source written by others and rebuild the same
     algorithm in Python, convention by convention, for a grader that allows 1%;
  3. the script behind the paper estimates the effect with and without covariates, and
     the task does not say which; the agent could not verify it and said so.
''',
  '''The wording follows the page copy (metacase-economics.html; section 6 of the copy file).
What makes the task hard, in the order the video tells it:
  1. the result cannot simply be run: the task takes only the data from the authors'
     replication package, names a Stata command and the authors' script, supplies
     neither, and the container has no Stata; so the agent has to read Stata source
     written by others and rebuild the same algorithm in Python within a 1% tolerance;
  2. the specification is incomplete: the authors' script estimates the effect with and
     without covariates (-66.33 and -69.35) and the task does not say which column;
     the agent could not verify it and said so.
The column-2 figures (-69.35, standard error 22.68) are not from the run: after the run,
column 2's five covariates were put into the agent's delivered program (page copy 6.5).
'''),
 # e01
 ('''{q}Did an inspection change how many candidates competed for each civil-service post? {panel}A published paper answers with a panel of seven hundred seventeen departments.",
         en="From 2013, central inspection teams entered China's government departments in five waves. Did an inspection change how many candidates competed for each civil-service post? A published paper answers with a panel of 717 departments.",''',
  '''{q}After an inspection, did competition for a department's civil-service posts change? {panel}A published paper answers with data on seven hundred seventeen recruiting departments.",
         en="From 2013, central inspection teams entered China's government departments in five waves. After an inspection, did competition for a department's civil-service posts change? A published paper answers with data on 717 recruiting departments.",'''),
 # e02
 ('''say="The task is to reproduce one estimate from that paper: {three}a coefficient, its standard error and its p-value, {script}plus a script that reproduces them.",''',
  '''say="The task is to reproduce one of its results as three numbers: {three}how large the effect is, how uncertain that estimate is, and whether it is significant, {script}with a Python script that reproduces them.",'''),
 # e03
 ('''say="The task names a Stata command and the authors' script. {none}Neither is supplied, {stata}and the container has no Stata.",
         hold=1.6,
         st=("brand", "difficulty 1 · named in the task, absent from the container")),''',
  '''say="The first difficulty: the result cannot simply be run. The task names the Stata command the paper used, {none}and the authors' script, but supplies neither, {stata}and the container has no Stata.",
         hold=1.4,
         st=("brand", "difficulty 1 · the result cannot simply be run")),'''),
 # e04
 ('''say="So the agent must read Stata source written by others, and rebuild the same algorithm in Python. {conv}Cohort weights, a two-part variance, dropped singletons, degrees of freedom: {tol}each convention has to match, because the grader allows one percent.",
         en="So the agent must read Stata source written by others, and rebuild the same algorithm in Python. Cohort weights, a two-part variance, dropped singletons, degrees of freedom: each convention has to match, because the grader allows 1%.",
         hold=1.4,
         st=("brand", "difficulty 2 · rebuild the estimator, convention by convention")),''',
  '''say="Behind that command stand three Stata programs written by others, one more than four thousand lines long. The agent has to read the source and rebuild the same algorithm in Python: {conv}cohort weights, the parts of the variance, which observations are dropped, the degrees-of-freedom correction. {tol}If any of them departs from the original, the result may fall outside the one percent tolerance.",
         en="Behind that command stand three Stata programs written by others, one more than four thousand lines long. The agent has to read the source and rebuild the same algorithm in Python: cohort weights, the parts of the variance, which observations are dropped, the degrees-of-freedom correction. If any of them departs from the original, the result may fall outside the 1% tolerance.",
         hold=1.0,
         st=("brand", "difficulty 1 · rebuild the algorithm in Python, within 1%")),'''),
 # e05
 ('''say="The script behind the paper also estimates the effect twice: {c1}without covariates, {c2}and with them. {q}The task does not say which.",
         hold=1.6,
         st=("brand", "difficulty 3 · two versions of the estimate, one reference value")),''',
  '''say="The second difficulty: the specification is incomplete. The authors' script estimates the effect twice: {c1}minus sixty-six point three three without covariates, {c2}and minus sixty-nine point three five with five. {q}The task does not say which column, and reporting the wrong one scores zero.",
         en="The second difficulty: the specification is incomplete. The authors' script estimates the effect twice: −66.33 without covariates, and −69.35 with five. The task does not say which column, and reporting the wrong one scores zero.",
         hold=1.2,
         st=("brand", "difficulty 2 · the specification is incomplete")),'''),
 # e10
 ('''say="{net}The container is online. {gh}From GitHub, the agent fetches the public source of the estimator, {mata}and of the regression routine beneath it.",''',
  '''say="{net}The container has network access. {gh}At twenty-four seconds, the agent takes the estimator's source from its author's GitHub repository, {mata}and later the source of the regression program it depends on. {gen}Both are general-purpose programs, with nothing specific to this study.",
         en="The container has network access. At 24 seconds, the agent takes the estimator's source from its author's GitHub repository, and later the source of the regression program it depends on. Both are general-purpose programs, with nothing specific to this study.",'''),
 # e11
 ('''say="{srch}It also searches for the authors' script: {where}GitHub code search, Google, Bing, Dataverse. {nf}It does not find it.",''',
  '''say="{srch}It also searches public sources for the authors' script: {where}GitHub, Google, Bing, Harvard Dataverse. {nf}Most requests are refused or return unrelated results. It does not find the script.",'''),
 # e14
 ('''{n}three thousand one hundred seventy observations, six hundred forty-one clusters.",
         en="76 departments appear only once. The source computes the weights before dropping them, and runs the regression after: 3,170 observations, 641 clusters.",''',
  '''{n}three thousand one hundred seventy observations on six hundred forty-one departments.",
         en="76 departments are observed only once. The source computes the shares before dropping them, and runs the regression after: 3,170 observations on 641 departments.",'''),
 ('''say="{sing}Seventy-six departments appear only once. {before}The source computes the weights before dropping them,''',
  '''say="{sing}Seventy-six departments are observed only once. {before}The source computes the shares before dropping them,'''),
 # e15
 ('''say="{mata}For the standard error it reads the regression routine's source, {line}past line four thousand, {dof}to copy its small-sample correction and its degrees of freedom.",
         en="For the standard error it reads the regression routine's source, past line 4,000, to copy its small-sample correction and its degrees of freedom.",''',
  '''say="{mata}For the standard error it reads the regression program's source, {line}past line four thousand, {dof}to confirm the small-sample correction for clustered standard errors, and the degrees of freedom.",
         en="For the standard error it reads the regression program's source, past line 4,000, to confirm the small-sample correction for clustered standard errors, and the degrees of freedom.",'''),
 # e17
 ('''say="{alt}It runs four other covariate sets too. {mv}Each one moves the estimate. {keep}With nothing in the task to choose between them, it keeps the baseline.",''',
  '''say="{alt}It tries four other sets of covariates too. {mv}The estimates differ. {keep}It does not pick a set without support, and keeps the baseline.",'''),
 # e18
 ('''say="{val}It checks the result a second way: {dum}a regression with explicit department and year dummies {same}returns the same five cohort effects.",''',
  '''say="{val}It checks the result another way: {dum}a regression with explicit department and year dummies {same}gives the same five cohort effects.",'''),
 # e19
 ('''say="{more}It goes on looking for the script in public archives. {none}The candidates turn out to be other studies. {stall}Then one lookup stalls, and the commands queued behind it never run. {cc}The agent interrupts it, and writes its files.",''',
  '''say="{more}It goes on searching. It finds two replication packages, checks their file lists, {none}and declines to use them: they belong to other studies. {stall}Then one lookup does not return and holds the terminal, so the commands queued behind it never run. {cc}The agent interrupts it, then writes and runs its files.",'''),
 # e20
 ('''say="{doc}In its script it writes down what it could not verify: {q}the table's covariates, without the authors' file. {fin}Then it marks the task complete:''',
  '''say="{doc}The header of its script states what it could not verify: {q}which covariates each column uses. {fin}Then it marks the task complete:'''),
 ('''en="In its script it writes down what it could not verify: the table's covariates, without the authors' file. Then it marks the task complete: 40 requests, 52 tool calls, about eight minutes.",''',
  '''en="The header of its script states what it could not verify: which covariates each column uses. Then it marks the task complete: 40 requests, 52 tool calls, about eight minutes.",'''),
 # e21
 ('''{turn}The estimate was ready after two minutes; most of the rest went to looking for a script that was never found.",
         en="Here is the whole run. 52 tool calls: 39 commands, ten waits, one interrupt and two completion marks. The estimate was ready after two minutes; most of the rest went to looking for a script that was never found.",''',
  '''{turn}The estimate was confirmed by one hundred eighty-five seconds; nearly five more minutes went on searching for a script that was never found.",
         en="Here is the whole run. 52 tool calls: 39 commands, ten waits, one interrupt and two completion marks. The estimate was confirmed by 185 seconds; nearly five more minutes went on searching for a script that was never found.",'''),
 # e25 status
 ('''st=("scorer", "evaluate.py · reference.json · no model call")),''', '''st=("scorer", "evaluate.py · reference.json · graded in 0.2 s")),'''),
 # e27
 ('''say="{rule}The rule is all or nothing. {alt}Had the agent reported its five-covariate variant instead, {off}the coefficient would be four percent off, {zero}and the score would be zero.",
         en="The rule is all or nothing. Had the agent reported its five-covariate variant instead, the coefficient would be 4% off, and the score would be zero.",
         hold=1.2,
         st=("fail", "a variant the agent computed · not what it reported")),''',
  '''say="{rule}Passing all three scores one; anything else scores zero. {alt}After the run, column two's five covariates were put into the agent's own program: {off}minus sixty-nine point three five, four point six percent off the reference. {zero}Under the same rule, that scores zero.",
         en="Passing all three scores one; anything else scores zero. After the run, column 2's five covariates were put into the agent's own program: −69.35, 4.6% off the reference. Under the same rule, that scores zero.",
         hold=1.2,
         st=("fail", "recomputed after the run · not part of the agent's run")),'''),
 # e29
 ('''say="Read it with its limits. {net}The agent was online: it fetched the estimator's public source, not the authors' code. {rep}It rebuilt a published method in Python; it did not derive one. {why}And which column to reproduce stayed unverified, as its own script says.",''',
  '''say="Read it with its limits. {net}The container had network access: the agent obtained the estimator's public source, and not the authors' script. {rep}It rebuilt a published method from that source; it did not derive one. {why}And the baseline it reported was never checked against the authors' script, as its own program states.",'''),
 # payloads: e02 items
 ('''items=[dict(id="coefficient", obj="1", title="Effect of an inspection on competition for posts",
                            amount="", tag=""),
                       dict(id="standard error", obj="2", title="Clustered by department", amount="", tag=""),
                       dict(id="p-value", obj="3", title="Two-sided, for the same estimate", amount="", tag="")],''',
  '''items=[dict(id="coefficient", obj="1", title="How large the effect of inspection is",
                            amount="", tag=""),
                       dict(id="standard error", obj="2", title="How uncertain that estimate is", amount="", tag=""),
                       dict(id="p-value", obj="3", title="Whether it is significant", amount="", tag="")],'''),
 ('''"e02": dict(title="The task", sub="Reproduce one published estimate, and hand in the code",
                deadline="agent time limit · 30 minutes", badge_r="one published estimate",''',
  '''"e02": dict(title="The task", sub="Reproduce one published result as three numbers",
                deadline="agent time limit · 30 minutes", badge_r="outcome: applicant-to-hire ratio",'''),
 # e03 payload
 ('''"e03": dict(title="What the task names", sub="A command and a script: neither is in the container",
                items=[("NAMED IN THE TASK", "eventstudyinteract · a Stata command",
                        "not installed: the container has no Stata", "warn", 0.0),
                       ("NAMED IN THE TASK", "3a_analysis_ncse.do · the authors' script",
                        "not among the supplied files", "warn", "none"),
                       ("WHAT THE CONTAINER HAS", "Python with pandas, pyfixest and pyhdfe",
                        "one data file · network access", "sandbox", "stata")],''',
  '''"e03": dict(title="The first difficulty", sub="The result cannot simply be run",
                items=[("NAMED IN THE TASK", "eventstudyinteract · the Stata command the paper used",
                        "not supplied", "warn", 0.0),
                       ("NAMED IN THE TASK", "3a_analysis_ncse.do · the authors' script",
                        "not supplied · the task takes only the data from the authors' package", "warn", "none"),
                       ("THE CONTAINER", "Python, and no Stata",
                        "one data file · network access", "sandbox", "stata")],'''),
 # e04 payload
 ('''"e04": dict(title="What that demands", sub="Read the Stata source, rebuild the algorithm in Python",
                deadline="grader tolerance · 1% on coefficient and standard error", badge_r="p-value: within 0.01",
                items=[dict(id="cohort weights", obj="1", title="Each cohort's share of treated observations", amount="", tag=""),
                       dict(id="two-part variance", obj="2", title="Regression variance, plus the variance of the shares",
                            amount="", tag=""),
                       dict(id="singletons", obj="3", title="Departments observed once are dropped", amount="", tag=""),
                       dict(id="degrees of freedom", obj="4", title="Clusters minus one, for the p-value", amount="", tag="")],''',
  '''"e04": dict(title="The first difficulty", sub="Read the Stata source, rebuild the same algorithm in Python",
                deadline="three Stata programs · one over 4,000 lines", badge_r="tolerance: 1%",
                items=[dict(id="cohort weights", obj="1", title="Each cohort's share of treated observations", amount="", tag=""),
                       dict(id="parts of the variance", obj="2", title="The regression's, plus one for the shares",
                            amount="", tag=""),
                       dict(id="dropped observations", obj="3", title="Departments observed only once", amount="", tag=""),
                       dict(id="degrees of freedom", obj="4", title="The correction for clustered errors", amount="", tag="")],'''),
 # e05 payload
 ('''"e05": dict(title="Two versions, one reference", sub="The authors' script estimates the effect with and without covariates",
                top=("task text: “row-specific covariates per table column”", 0.0),
                cols=[dict(kick="TABLE 2 · COLUMN 1", title="No covariates", c="model", at="c1", hi=[("c1", 2.0)],
                           rows=[("estimate", "?", "c1", "dim")]),
                      dict(kick="TABLE 2 · COLUMN 2", title="Five covariates", c="harness", at="c2", hi=[("c2", 2.0)],
                           rows=[("estimate", "?", "c2", "dim")])],
                col_h=170,
                bottom=("The task does not name the column to reproduce.", "q", "warn"),''',
  '''"e05": dict(title="The second difficulty", sub="The specification is incomplete",
                top=("task text: “row-specific covariates per table column”", 0.0),
                cols=[dict(kick="THE AUTHORS' SCRIPT · COLUMN 1", title="No covariates", c="model", at="c1", hi=[("c1", 2.0)],
                           rows=[("coefficient", "−66.33", "c1", "fg")]),
                      dict(kick="THE AUTHORS' SCRIPT · COLUMN 2", title="Five covariates", c="harness", at="c2", hi=[("c2", 2.0)],
                           rows=[("coefficient", "−69.35", "c2", "fg")])],
                col_h=170,
                bottom=("4.6% apart. The task does not say which column; the wrong one scores 0.", "q", "warn"),'''),
 # e10 payload
 ('''at=0.0, rq="COMMANDS 5 AND 13 / 52", sub="The container is online: fetch the public source of the method",''',
  '''at=0.0, rq="COMMANDS 5 AND 13 / 52", sub="Back to the source: the estimation command's public code",'''),
 ('''dict(kick="WHAT THE NETWORK WAS USED FOR", title="Public source of the method", role="warn", at=("mata", 0.8),
                    hi=[(("mata", 0.8), 3.0)],
                    lines=["Not the authors' analysis code"])],
        foot="the estimator, and the regression routine it calls")],
        pet=[("net", "stage0"), ("gh", "card0"), ("mata", "card1"), (("mata", 1.0), "card2")]),''',
  '''dict(kick="WHAT THE NETWORK WAS USED FOR", title="General-purpose programs", role="warn", at="gen",
                    hi=[("gen", 3.0)],
                    lines=["Nothing specific to this study", "Not the authors' script"])],
        foot="the estimation command, and the regression program it depends on")],
        pet=[("net", "stage0"), ("gh", "card0"), ("mata", "card1"), ("gen", "card2")]),'''),
 # e11 payload
 ('''dict(kick="RESULT", title="Script not found", role="warn", at="nf", hi=[("nf", 3.0)],
                    lines=["It searches again later,", "with the same outcome"])],''',
  '''dict(kick="RESULT", title="Script not found", role="warn", at="nf", hi=[("nf", 3.0)],
                    lines=["Requests refused, or", "unrelated results"])],'''),
 ('''lines=["api.github.com/search/code", "google.com · bing.com", "grep.app · duckduckgo.com",
                           "dataverse.harvard.edu"]),''',
  '''lines=["GitHub code search", "Google · Bing · DuckDuckGo", "Harvard Dataverse",
                           "later: DataCite · Crossref"]),'''),
 # e14 payload
 ('''lines=["641 department clusters", "76 singletons dropped"])],''', '''lines=["on 641 departments", "76 singletons dropped"])],'''),
 ('''sub="Weights before the singletons are dropped, regression after",''', '''sub="Shares before the singletons are dropped, regression after",'''),
 # e17 payload
 ('''"e17": dict(sub="Five covariate sets, one estimate each", rq="COMMAND 17 / 52",''', '''"e17": dict(sub="Choice of specification: the estimates differ", rq="COMMAND 17 / 52",'''),
 # e19 payload
 ('''at=0.0, rq="COMMANDS 28–42 / 52", sub="More searching, a stalled lookup, an interrupt",''', '''at=0.0, rq="COMMANDS 28–42 / 52", sub="Two packages declined, a stalled lookup, an interrupt",'''),
 ('''dict(kick="ARCHIVES CHECKED", role="model", mono=True, size=12.5, at="more", hi=[("none", "stall")], maxl=1,''',
  '''dict(kick="TWO PACKAGES · FILE LISTS", role="model", mono=True, size=12.5, at="more", hi=[("none", "stall")], maxl=1,'''),
 ('''foot="the first attempt to write main.py was queued and never ran")],''', '''foot="“I will not use unrelated replication code.” · +299.9 s")],'''),
 # e21 marks
 ('''marks=[(23.7, "source fetched", "model", "calls"), (123.5, "−66.33", "sandbox", "turn"),
                       (376.0, "interrupt", "warn", "turn")],''',
  '''marks=[(23.7, "source fetched", "model", "calls"), (185.0, "confirmed", "sandbox", "turn"),
                       (376.0, "interrupt", "warn", "turn")],'''),
 # e25
 ('''grader="evaluate.py · deterministic · no model call", grader_r="reference: Table 2, column 1",''', '''grader="evaluate.py · deterministic · no model call", grader_r="graded in 0.2 s",'''),
 # e27 payload
 ('''"e27": dict(check=True, title="Independent check", sub="The same rule, applied to a variant the agent also ran",''',
  '''"e27": dict(check=True, title="Independent check", sub="The weight of a specification: recomputed after the run",'''),
 ('''dict(kick="FIVE COVARIATES · RUN, NOT REPORTED", title="A variant", c="fail", at="alt", hi=[("off", 3.0)],
                           rows=[("coefficient", "−68.97", "alt", "fg"), ("standard error", "22.74", "alt", "fg"),
                                 ("off the reference", "4.0% · 9.3%", "off", "fail")],''',
  '''dict(kick="COLUMN 2 · RECOMPUTED AFTERWARDS", title="Five covariates", c="fail", at="alt", hi=[("off", 3.0)],
                           rows=[("coefficient", "−69.35", "alt", "fg"), ("standard error", "22.68", "alt", "fg"),
                                 ("off the reference", "4.6% · 9.5%", "off", "fail")],'''),
 ('''dict(kick="BASELINE · REPORTED", title="No covariates", c="pass", at=0.0,''', '''dict(kick="COLUMN 1 · REPORTED BY THE AGENT", title="No covariates", c="pass", at=0.0,'''),
 ('''bottom=("Same sign and same significance level; a different specification.", ("off", 1.0), "warn"),''',
  '''bottom=("Same data, same program: only the covariates differ.", ("off", 1.0), "warn"),'''),
 # e28
 ('''line3="deterministic grader · the agent was online and used the estimator's public source",''',
  '''line3="deterministic grader, no model call · the container had network access",'''),
 # e29 payload
 ('''items=[("NETWORK ACCESS", "Used for the estimator's public source",
                        "eventstudyinteract.ado and reghdfe.mata from GitHub · not the authors' code", "warn", "net"),
                       ("WHAT THE RECORD SHOWS", "A published method, rebuilt in Python",
                        "not an independent derivation of the method", "brand", "rep"),
                       ("LEFT UNVERIFIED", "Which column of the table to reproduce",
                        "the agent's script: “covariate mapping has not been verified”", "model", "why")],''',
  '''items=[("NETWORK ACCESS", "The estimator's public source, not the authors' script",
                        "with network access, that script is not out of reach", "warn", "net"),
                       ("WHAT THE RECORD SHOWS", "A published method, rebuilt from its source",
                        "not an independent derivation of the method", "brand", "rep"),
                       ("NOT CHECKED", "The reported baseline, against the authors' script",
                        "the agent's script: “covariate mapping has not been verified”", "model", "why")],'''),
])
print("done")
