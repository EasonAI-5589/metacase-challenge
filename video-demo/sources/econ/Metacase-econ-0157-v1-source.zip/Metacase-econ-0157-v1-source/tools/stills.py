"""Review stills: python tools/stills.py <run> [shot ids...] [--at end|mid|both] [--scale 0.5]

Writes build/<run>/review/<shot>_<tag>.jpg (downscaled) for a quick look at every shot.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "engine"))
sys.path.insert(0, ROOT)

import skia  # noqa: E402
import compose  # noqa: E402
import gfx as G  # noqa: E402

args = sys.argv[1:]
run = args[0]
at = "end"
scale = 0.5
ids = []
i = 1
while i < len(args):
    if args[i] == "--at":
        at = args[i + 1]; i += 2
    elif args[i] == "--scale":
        scale = float(args[i + 1]); i += 2
    else:
        ids.append(args[i]); i += 1

ctx = compose.Ctx(run)
out = os.path.join(ROOT, "build", run, "review")
os.makedirs(out, exist_ok=True)
for sh in ctx.tl.shots:
    if ids and sh.id not in ids:
        continue
    times = []
    if at in ("end", "both"):
        times.append(("end", sh.dur - 0.25))
    if at in ("mid", "both"):
        times.append(("mid", sh.dur * 0.55))
    if at not in ("end", "mid", "both"):
        for tok in at.split(","):
            times.append((tok.replace(".", "p"), float(tok)))
    for tag, tt in times:
        surf = skia.Surface(G.W, G.H)
        compose.frame(surf.getCanvas(), ctx, sh.start + tt)
        img = surf.makeImageSnapshot()
        w, h = int(G.W * scale), int(G.H * scale)
        small = skia.Surface(w, h)
        c = small.getCanvas()
        c.scale(scale, scale)
        c.drawImage(img, 0, 0, skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear))
        p = os.path.join(out, f"{sh.id}_{tag}.jpg")
        small.makeImageSnapshot().save(p, skia.kJPEG, 88)
        print(p)
