"""Build data/econ.json and data/econ.requests.jsonl from the recorded run.

Source: the replay record written by metacase-harbor's scripts/replay_record.py for
pilot-20261114-or__A32__terminus-2__openai-gpt-6-astra (econ-0157, gpt-6-astra x Terminus-2 2.0.0).
Kept: step times, tool names, exit status, the first line of each command, the request
metadata (time, token usage, tool names). Dropped: full terminal output and message text
that the video does not show. Nothing is estimated; fields the run did not record stay absent.

Each tool step also gets `act`, read from the recorded call itself:
  command   : bash_command with keystrokes
  wait      : bash_command with empty keystrokes (the agent waits for the terminal)
  interrupt : bash_command sending C-c
  complete  : mark_task_complete

usage: python tools/build_econ_data.py <replay dir>
"""
import collections
import json
import os
import sys

src = sys.argv[1]
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
run = json.load(open(os.path.join(src, "run.json"), encoding="utf-8"))


def act(s):
    det = s.get("detail") or ""
    if s["tool"] == "mark_task_complete":
        return "complete"
    if det.startswith('{"keystrokes": ""'):
        return "wait"
    if det.strip() == "C-c":
        return "interrupt"
    return "command"


steps = []
for s in run["agent"]["steps"]:
    d = {"i": s["i"], "t_s": s["t_s"], "kind": s["kind"]}
    if s["kind"] == "tool":
        d.update(tool=s["tool"], act=act(s), end_s=s.get("end_s"), is_error=bool(s.get("is_error")),
                 exit_code=s.get("exit_code"), cmd=(s.get("detail") or "").split("\n")[0][:160])
    steps.append(d)

a = run["agent"]
out = {
    "schema": run["schema"],
    "partial": ["judging.judge (deterministic grader: no judge model)"],
    "task": {"key": "ECON", "id": "econ-0157", "domain_en": "Economics", "fictional": False,
             "title_en": "Replicating a staggered difference-in-differences estimate",
             "paper": "Lai and Li, China's Anticorruption Campaign and Civil Servant Fever, "
                      "The Journal of Law and Economics, 2024",
             "target": "Table 2, column 1"},
    "materials": [{"name": "data_for_analysis.dta", "kind": "dta", "label": "data", "opened_step": 3}],
    "agent": {"harness": a["harness"], "runner": a["runner"], "provider": a["provider"],
              "requested_model": a["requested_model"].split("/")[-1],
              "session": {"model_responses": a["session"]["model_responses"],
                          "duration_s": a["session"]["duration_s"]},
              "tool_calls": a["tool_calls"],
              "usage": {k: a["usage"][k] for k in ("requests", "input_tokens", "cache_read_input_tokens",
                                                   "output_tokens")},
              "steps": steps},
    "deliverables": {"files": [{"name": "157_result.json", "bytes": 106}, {"name": "main.py", "bytes": 3910}]},
    "judging": {"judge": {"harness": "evaluate.py (deterministic)", "model": None, "api_requests": 0},
                "criteria": [],
                "result": run["judging"]["result"]},
    "provenance": {"job_name": run["provenance"]["job_name"], "trial_name": run["provenance"]["trial_name"],
                   "generated_from": "replay/run.json and replay/requests.jsonl of the trial",
                   "deliverable_sizes": "bytes of the two collected artifacts (trial/artifacts/output)"},
}
os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
with open(os.path.join(ROOT, "data", "econ.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

n = 0
with open(os.path.join(src, "requests.jsonl"), encoding="utf-8") as f, \
        open(os.path.join(ROOT, "data", "econ.requests.jsonl"), "w", encoding="utf-8") as g:
    for line in f:
        if not line.strip():
            continue
        r = json.loads(line)
        if r.get("type") == "assistant":
            m = r["message"]
            r = {"type": "assistant", "timestamp": r["timestamp"],
                 "message": {"id": m["id"], "usage": m.get("usage") or {},
                             "content": [{"type": "tool_use", "name": c.get("name")}
                                         for c in m.get("content", []) if c.get("type") == "tool_use"]}}
            n += 1
        g.write(json.dumps(r, ensure_ascii=False) + "\n")
tools = [s for s in steps if s["kind"] == "tool"]
print("steps", len(steps), "tool steps", len(tools), "errors", sum(s["is_error"] for s in tools), "request rows", n)
print("acts", dict(collections.Counter(s["act"] for s in tools)))
rows = [json.loads(l) for l in open(os.path.join(ROOT, "data", "econ.requests.jsonl"), encoding="utf-8")]
aa = [r for r in rows if r["type"] == "assistant"]
ctx = [(r["message"]["usage"].get("input_tokens") or 0) + (r["message"]["usage"].get("cache_read_input_tokens") or 0)
       for r in aa]
print("ctx first/last/max", ctx[0], ctx[-1], max(ctx),
      "out total", sum(r["message"]["usage"].get("output_tokens") or 0 for r in aa),
      "tool_use", sum(len(r["message"]["content"]) for r in aa))
