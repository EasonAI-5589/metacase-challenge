"""Second one-off patch: guide targets and file tiles may come from the story (run once)."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
E = os.path.join(ROOT, "engine")


def patch(name, pairs):
    p = os.path.join(E, name)
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        n = s.count(a)
        assert n == 1, (name, n, a[:70])
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8", newline="\n").write(s)
    print("patched", name, len(pairs))


patch("guide_targets.py", [
    ('''def describe(sh, target):
    """Resolve a cue without changing its timing, highlight meaning, or facts."""
    sid = sh.id
    if isinstance(target, (tuple, list)):
        result = TUPLES.get(sid, {}).get(tuple(target))
''', '''def _story_targets(sid):
    """A story may carry its own tuple targets: GUIDE = {shot id: {(x, y): (name, box, tip, role[, dock])}}."""
    import sys
    for name, mod in list(sys.modules.items()):
        guide = getattr(mod, "GUIDE", None) if name.startswith("story.") else None
        if guide and sid in guide:
            return {k: _target(v[0], v[1], v[2], ROLE.get(v[3], BRAND), *(v[4:5]))
                    for k, v in guide[sid].items()}
    return {}


def describe(sh, target):
    """Resolve a cue without changing its timing, highlight meaning, or facts."""
    sid = sh.id
    if isinstance(target, (tuple, list)):
        result = TUPLES.get(sid, {}).get(tuple(target)) or _story_targets(sid).get(tuple(target))
'''),
])

patch("scenes_x.py", [
    ('''            G.text(cv, num or kind[:3].upper(), fx + tw / 2, fy + 6, size=13, c=G.FG if on else G.DIM, kind="mono", a=alpha, align="center")''',
     '''            G.text(cv, num or m.get("label") or kind[:3].upper(), fx + tw / 2, fy + 6, size=13, c=G.FG if on else G.DIM, kind="mono", a=alpha, align="center")'''),
    ('''    file_grid(cv, ctx, IX0 + 24, 398, cols, tw, 48, 8, a, appear=appear)
''', '''    file_grid(cv, ctx, IX0 + 24, 398, cols, tw, 48, 8, a, appear=appear)
    if conf.get("input_note"):   # one line beside a short grid: what the input holds
        nx = IX0 + 24 + min(cols, len(ctx.run.materials)) * (tw + 8) + 12
        G.text(cv, conf["input_note"], nx, 414, size=14.5, c=G.FG, kind="mono", a=a * appear)
'''),
])
print("done")
