"""Audit every string that reaches the screen: python tools/screen_text.py <run> [step]

Draws every `step`-th frame (default 3), records each string drawn with opacity >= 0.6 and
how long it stays up in each shot, and reports:
  - strings with CJK characters (the video is English only);
  - strings containing words this video must not show (other models, "film", Claude Code);
  - strings up for less than 0.3 s + words / 4 (the reading-time rule).
Writes build/<run>/screen-text-qa.json.
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "engine"))
sys.path.insert(0, ROOT)

import skia  # noqa: E402
import gfx as G  # noqa: E402
import compose  # noqa: E402
from timeline import FPS  # noqa: E402

run = sys.argv[1]
step = int(sys.argv[2]) if len(sys.argv) > 2 else 3
ctx = compose.Ctx(run)
CJK = re.compile(r"[　-〿一-鿿＀-￯]")
BANNED = re.compile(r"\bfilm\b|claude|qwen|kimi|deepseek|opus|fable|sonnet|argon|gemini|codex|opencode|deepagents",
                    re.I)
cur = [None, 0.0]
seen = {}       # (shot, string) -> [frames visible, first t, last t]
orig = G.text


def text(cv, s, x, y, *a, **k):
    alpha = k.get("a", 1.0)
    if s and alpha >= 0.6:
        e = seen.setdefault((cur[0], s), [0, cur[1], cur[1]])
        if e[2] != cur[1] or e[0] == 0:
            e[0] += 1
        e[2] = cur[1]
    return orig(cv, s, x, y, *a, **k)


G.text = text
surf = skia.Surface(G.W, G.H)
cv = surf.getCanvas()
for f in range(0, ctx.tl.nframes, step):
    T = f / FPS
    sh, t, _ = ctx.tl.locate(T)
    cur[0], cur[1] = sh.id, T
    compose.frame(cv, ctx, T)

dur = {s.id: s.dur for s in ctx.tl.shots}
cjk, banned, short = [], [], []
rows = []
for (sid, s), (n, t0, t1) in sorted(seen.items(), key=lambda kv: (kv[0][0], kv[1][1])):
    up = n * step / FPS
    words = len(re.findall(r"[A-Za-z0-9][A-Za-z0-9'’.,:%+\-−/()]*", s))
    need = 0.3 + words / 4
    rows.append(dict(shot=sid, text=s, seconds=round(up, 2), words=words, need=round(need, 2)))
    if CJK.search(s):
        cjk.append((sid, s))
    if BANNED.search(s):
        banned.append((sid, s))
    # the outgoing scene is cross-faded for XFADE at the next shot's start; ignore sub-0.6 s remnants
    if up + 0.11 < need and up > 0.6:
        short.append((sid, round(up, 2), round(need, 2), s))
out = os.path.join(ROOT, "build", run, "screen-text-qa.json")
json.dump(dict(run=run, frame_step=step, strings=len(rows), cjk=cjk, banned=banned,
               below_reading_time=short, rows=rows), open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("strings", len(rows), "| CJK", len(cjk), "| banned", len(banned), "| below reading time", len(short))
for x in cjk + banned:
    print("  !", x)
for x in short:
    print("  short", x)
print(out)
