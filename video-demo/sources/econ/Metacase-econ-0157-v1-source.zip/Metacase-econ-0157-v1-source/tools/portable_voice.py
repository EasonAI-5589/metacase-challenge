"""Make the narration cache portable: python tools/portable_voice.py <run>

engine/voice.py writes absolute clip paths into build/<run>/voice.json and keeps the clips
of every earlier wording. This rewrites the paths relative to the project root (the engine
resolves them against it) and deletes the clips the current narration does not use.
Run it after voice.py and before the full render.
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
run = sys.argv[1]
index = os.path.join(ROOT, "build", run, "voice.json")
clips = json.load(open(index, encoding="utf-8"))
keep = set()
for c in clips:
    path = c["mp3"] if os.path.isabs(c["mp3"]) else os.path.join(ROOT, c["mp3"])
    assert os.path.isfile(path), path
    c["mp3"] = os.path.relpath(path, ROOT).replace(os.sep, "/")
    keep.add(os.path.basename(path)[:-4])
json.dump(clips, open(index, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
folder = os.path.join(ROOT, "build", run, "voice")
removed = 0
for name in sorted(os.listdir(folder)):
    if os.path.splitext(name)[0] not in keep:
        os.remove(os.path.join(folder, name))
        removed += 1
print("clips kept", len(keep), "| stale files removed", removed, "| files left", len(os.listdir(folder)))
