"""Build the editable-source archive: python tools/make_source_zip.py <output zip> <HR v3 source dir>

Contents: engine, story, data, fonts, brand, reference, tools, the robot page with the
Terminus-2 sprite set, the narration cache with its index, the QA records and the delivered
docs. Left out: the virtual environment, rendered segments and the MP4, review stills,
node_modules, the two sprite sets this video does not use, and the workstation-specific
font sidecar (its portable form is docs/font-selection.json).
"""
import os
import subprocess
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out, base = sys.argv[1], sys.argv[2]
TOP = "Metacase-econ-0157-v1-source"

# engine and robot-page changes against the HR v3 source
patch = os.path.join(ROOT, "ENGINE-CHANGES.patch")
chunks = []
for sub in ("engine", "robot/sprite.html", "robot/render_sprites.mjs"):
    r = subprocess.run(["diff", "-ruN", "-x", "__pycache__", os.path.join(base, sub), os.path.join(ROOT, sub)],
                       capture_output=True, text=True)
    assert r.returncode in (0, 1), r.stderr
    chunks.append(r.stdout.replace(base.rstrip("/") + "/", "a/").replace(ROOT + "/", "b/"))
open(patch, "w", encoding="utf-8").write("".join(chunks))

files = ["README-econ-v1.md", "ENGINE-CHANGES.patch", "requirements-render.txt",
         "robot/sprite.html", "robot/render_sprites.mjs", "robot/sheet.py",
         "build/econ/voice.json", "build/econ/captions.en.srt", "build/econ/guide-geometry-qa.json",
         "build/econ/screen-text-qa.json", "build/econ/laser-text-qa.json", "build/econ/econ.render-receipt.json"]
for folder in ("engine", "story", "data", "fonts", "brand", "reference", "tools", "robot/sprites-terminus",
               "build/econ/voice"):
    for d, dirs, names in os.walk(os.path.join(ROOT, folder)):
        dirs[:] = sorted(x for x in dirs if x != "__pycache__")
        for n in sorted(names):
            if not n.endswith(".pyc") and n != ".DS_Store":
                files.append(os.path.relpath(os.path.join(d, n), ROOT))
docs = os.path.join(ROOT, "deliver", "docs", "video", "econ")
os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
if os.path.exists(out):
    os.remove(out)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for rel in files:
        z.write(os.path.join(ROOT, rel), f"{TOP}/{rel}")
    for n in sorted(os.listdir(docs)):
        z.write(os.path.join(docs, n), f"{TOP}/docs/{n}")
with zipfile.ZipFile(out) as z:
    names = z.namelist()
    bad = [n for n in names if "node_modules" in n or ".venv" in n or n.endswith(".mp4") or "segments" in n]
    assert not bad, bad
    assert z.testzip() is None
print(out, len(names), "files", os.path.getsize(out), "bytes")
