"""Revision 1 after the first review stills (run once): text fit, text timing, total length."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def patch(rel, pairs):
    p = os.path.join(ROOT, rel)
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        n = s.count(a)
        assert n == 1, (rel, n, a[:80])
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8", newline="\n").write(s)
    print("patched", rel, len(pairs))


patch("story/econ.py", [
    # left panel heading must clear the "k / 8" counter
    ('plan_kicker="WHAT THE NUMBER DEPENDS ON"', 'plan_kicker="SETTINGS TO MATCH"'),
    # e02: fewer words per card, shown from the start of the sentence
    ('''                items=[dict(id="coefficient", obj="to match", title="Effect of an inspection on competition for posts",
                            amount="reference sealed", tag="to reproduce"),
                       dict(id="standard error", obj="to match", title="Clustered by department",
                            amount="reference sealed", tag="to reproduce"),
                       dict(id="p-value", obj="to match", title="Two-sided, for the same estimate",
                            amount="reference sealed", tag="to reproduce")],
                items_at="three",''',
     '''                items=[dict(id="coefficient", obj="1", title="Effect of an inspection on competition for posts",
                            amount="", tag=""),
                       dict(id="standard error", obj="2", title="Clustered by department", amount="", tag=""),
                       dict(id="p-value", obj="3", title="Two-sided, for the same estimate", amount="", tag="")],
                items_at=1.0,'''),
    # e03: the closing line appears with "twice", so it stays up long enough
    ('''bottom=("The task names the authors' script, but not the column to reproduce.", ("c2", 1.4), "warn"),''',
     '''bottom=("The task names the authors' script, but not the column to reproduce.", "two", "warn"),'''),
    ('''         en="Because inspections came in waves, the paper uses the Sun–Abraham estimator, with never-inspected departments as controls. The authors' script estimates the effect twice: without covariates, and with five.",
         hold=1.6,''',
     '''         en="Because inspections came in waves, the paper uses the Sun–Abraham estimator, with never-inspected departments as controls. The authors' script estimates the effect twice: without covariates, and with five.",
         hold=0.6,'''),
    # e07: three labels, not five lines of them
    ('''               dict(kick="OBSERVATION · variable labels", role="brand", mono=True, size=12.5, at="lab", maxl=1,
                    hi=[("sa", 3.0)], cols=[None, None, None, "harness", "harness", "harness", "harness", "harness"],
                    lines=["comp: AHR", "inspectmain: = 1 if a leading", "  dept & having been inspected",
                           "first_inspect: (for Sun &", "  Abraham estimator) …", "never_inspect: (for Sun &",
                           "  Abraham estimator) = 1 if", "  never inspected"])],''',
     '''               dict(kick="OBSERVATION · LABELS", role="brand", mono=True, size=12.5, at="lab", maxl=1,
                    hi=[("sa", 3.0)], cols=[None, "harness", "harness", "harness", "harness", "harness"],
                    lines=["comp: AHR", "first_inspect: (for Sun &", "  Abraham estimator) …", "never_inspect: (for Sun &",
                           "  Abraham estimator) = 1 if", "  never inspected"])],'''),
    # e08: the address fits its card
    ('''                    lines=["curl -s -o /tmp/replication.zip", "  https://laiwz.github.io/assets/", "  zips/Lai_and_Li-JLE_2024.zip",
                           "  && unzip -l", "  /tmp/replication.zip"]),''',
     '''                    lines=["curl -s -o /tmp/replication.zip", "  https://laiwz.github.io/", "  assets/zips/",
                           "  Lai_and_Li-JLE_2024.zip", "  && unzip -l …"]),'''),
    ('''         en="The container has network access. At 103 seconds, the agent downloads the authors' public replication package and reads the script the task names.",
         hold=1.2,''',
     '''         en="The container has network access. At 103 seconds, the agent downloads the authors' public replication package and reads the script the task names.",
         hold=0.8,'''),
    ('''         say="{c1}In that script, column one calls the estimator with no covariates. {c2}Column two adds five. {q}The task itself says only: covariates per table column.",
         hold=1.2,''',
     '''         say="{c1}In that script, column one calls the estimator with no covariates. {c2}Column two adds five. {q}The task itself says only: covariates per table column.",
         hold=0.4,'''),
    # e10: no red stage (nothing failed in the output), one quoted comment
    ('''        beats=[("no", 0), (("no", 0.5), 2), ("src", 0), (("src", 0.6), 2), ("read", 3)], fail="no",''',
     '''        beats=[("no", 0), (("no", 0.5), 2), ("src", 0), (("src", 0.6), 2), ("read", 3)],'''),
    ('''               dict(kick="OBSERVATION · eventstudyinteract.ado", role="brand", mono=True, size=12.5, at="read", hi=[("read", 3.0)],
                    lines=["* Loop over cohort and get cohort shares for relative times",
                           "* Get VCV estimate for the cohort shares using avar"])],''',
     '''               dict(kick="eventstudyinteract.ado", role="brand", mono=True, size=12.5, at="read", hi=[("read", 3.0)],
                    lines=["* Loop over cohort and get cohort shares for relative times"])],'''),
    ('''         en="It computes the cohort weights from the treated observations: 14, 8, 65, 79 and 14. Each cohort's effect, weighted by its share, adds up to −66.33.",
         hold=0.8,''',
     '''         en="It computes the cohort weights from the treated observations: 14, 8, 65, 79 and 14. Each cohort's effect, weighted by its share, adds up to −66.33.",
         hold=0.4,'''),
    # e12: drop the web-search sentence; the open question takes its place
    ('''         say="{both}Then it computes both columns: {a}minus sixty-six point three three without covariates, {b}minus sixty-nine point three five with them. {srch}It also searches the web for the task's wording.",
         en="Then it computes both columns: −66.33 without covariates, −69.35 with them. It also searches the web for the task's wording.",
         hold=1.0,''',
     '''         say="{both}Then it computes both columns: {a}minus sixty-six point three three without covariates, {b}minus sixty-nine point three five with them.",
         en="Then it computes both columns: −66.33 without covariates, −69.35 with them.",
         hold=1.4,'''),
    ('''"e12": dict(as_="loop", accent="model", tk=[("both", 232.9), ("srch", 271.3)], phases=[dict(''',
     '''"e12": dict(as_="loop", accent="model", tk=[("both", 232.9), (("b", 2.5), 233.5)], phases=[dict('''),
    ('''               dict(kick="NEXT · +271.3 s", title="A web search", role="warn", at="srch", hi=[("srch", 2.5)],
                    lines=["for the task's phrase:", "“row-specific covariates", "per table column”"])],
        foot="column 1: no covariates · column 2: five")],
        pet=[("both", "card0"), ("a", "card1"), ("srch", "card2")]),''',
     '''               dict(kick="NOT YET DECIDED", title="Which column?", role="warn", at=("b", 0.6), hi=[(("b", 0.6), 3.0)],
                    lines=["The task does not name it"])],
        foot="column 1: no covariates · column 2: five")],
        pet=[("both", "card0"), ("a", "card1"), (("b", 0.8), "card2")]),'''),
    ('''         st=("model", "command 28 · +232.9 s · both columns on the table"), trace=(232.9, 271.3)),''',
     '''         st=("model", "command 28 · +232.9 s · both columns on the table"), trace=(232.9, 233.5)),'''),
    # e13: no red stage
    ('''("drop", 0), (("drop", 0.8), 3)], fail="lib",''', '''("drop", 0), (("drop", 0.8), 3)],'''),
    ('''         en="Then one library returns 3,170 rows, not 3,246. 76 departments appear only once. Stata drops such singletons by default, so the agent does the same.",
         hold=0.8,''',
     '''         en="Then one library returns 3,170 rows, not 3,246. 76 departments appear only once. Stata drops such singletons by default, so the agent does the same.",
         hold=0.3,'''),
    ('''         en="The variance has two parts: one for the cohort effects, one for estimating the weights. Together they give a standard error of 25.05.",
         hold=0.8,''',
     '''         en="The variance has two parts: one for the cohort effects, one for estimating the weights. Together they give a standard error of 25.05.",
         hold=0.3,'''),
    ('''         en="For the p-value it computes three versions, and keeps the t distribution with 640 degrees of freedom: 0.0083.",
         hold=1.0,''',
     '''         en="For the p-value it computes three versions, and keeps the t distribution with 640 degrees of freedom: 0.0083.",
         hold=0.4,'''),
    ('''         say="{wr}It writes the script, {run}runs it, {json}and the result file appears, with three numbers.",
         hold=1.2,''',
     '''         say="{wr}It writes the script, {run}runs it, {json}and the result file appears, with three numbers.",
         hold=0.9,'''),
    # e17: no red stage (the shot ends on a pass)
    ('''("fix", 0), (("fix", 0.7), 3)], fail="chk",''', '''("fix", 0), (("fix", 0.7), 3)],'''),
    ('''         en="A self-check then stops with a NameError: the check called a library it had not imported. The agent corrects the check, and it passes.",
         hold=0.8,''',
     '''         en="A self-check then stops with a NameError: the check called a library it had not imported. The agent corrects the check, and it passes.",
         hold=0.3,'''),
    ('''         en="A command to delete temporary files is rejected by the harness. The agent lists the two files and stops: 103 requests, 102 commands, about 13 minutes.",
         hold=0.6,''',
     '''         en="A command to delete temporary files is rejected by the harness. The agent lists the two files and stops: 103 requests, 102 commands, about 13 minutes.",
         hold=0.2,'''),
    # e19: band labels that fit their bands; the highlighted stretch is 272-700 s
    ('''                phases_=[(0, 89, "inspect"), (89, 200, "find the source"), (200, 272, "both columns"),
                         (272, 466, "read Stata source"), (466, 700, "sample · variance · p"), (700, 794.7, "write")],''',
     '''                phases_=[(0, 89, "data"), (89, 200, "find source"), (200, 272, "weights"),
                         (272, 466, "read Stata source"), (466, 700, "sample · variance · p"), (700, 794.7, "write")],'''),
    ('''            (1050, 560): ("stata-conventions-stretch", (840, 314, 526, 300), (1424, 600), "warn", (1310, 798))},''',
     '''            (1050, 560): ("stata-conventions-stretch", (906, 314, 420, 300), (1424, 600), "warn", (1310, 798))},'''),
    ('''         en="Here is the whole run. 102 shell commands; 15 ended with a non-zero exit, ten of them searches that found nothing. About half of the run went to matching Stata's conventions.",
         hold=1.0,''',
     '''         en="Here is the whole run. 102 shell commands; 15 ended with a non-zero exit, ten of them searches that found nothing. About half of the run went to matching Stata's conventions.",
         hold=0.5,'''),
    # e21: the grader line fits its box
    ('''"it reads /output/157_result.json and the reference",''', '''"it reads 157_result.json and the reference",'''),
    # e22: the chapter card needs time for its sentence
    ('''         title="Independent check", sub="The result file is compared with the reference, number by number.",''',
     '''         title="Independent check", sub="The result file is compared with the reference, number by number.", hold=1.0,'''),
    ('''         say="{g}The grader calls no model. It compares three numbers with the reference. {c}The coefficient matches. {s}So does the standard error. {p}The p-value is off by two ten-thousandths, inside the tolerance.",
         hold=1.4,''',
     '''         say="{g}The grader calls no model. It compares three numbers with the reference. {c}The coefficient matches. {s}So does the standard error. {p}The p-value is off by two ten-thousandths, inside the tolerance.",
         hold=0.6,'''),
    # e24: the agent's own output appears with "normal distribution"; one line of text less
    ('''diff_at=("n", 0.7), had_at="had",''', '''diff_at=("n", 0.7), had_at=("n", 0.3),'''),
    ('''                log_note="all three were computed; the first went into the result file",
''', ''''''),
    ('''         say="{why}That gap has a cause. {t}The agent reported a p-value from the t distribution; {n}the reference agrees with the normal distribution, {had}a value the agent had also computed.",
         hold=1.6,''',
     '''         say="{why}That gap has a cause. {t}The agent reported a p-value from the t distribution; {n}the reference agrees with the normal distribution, {had}a value the agent had also computed.",
         hold=1.0,'''),
    # e25: the closing line comes with "off"
    ('''bottom=("Same sign and same significance level; a different column of the table.", ("zero", 0.7), "warn"),''',
     '''bottom=("Same sign and same significance level; a different column of the table.", ("off", 1.0), "warn"),'''),
    ('''         en="The rule is all or nothing. Had the agent reported column two, its coefficient would be 4.6% off, and the score would be zero.",
         hold=2.0,''',
     '''         en="The rule is all or nothing. Had the agent reported column two, its coefficient would be 4.6% off, and the score would be zero.",
         hold=1.2,'''),
    # e26: the network line sits in the box, up from "all three comparisons pass"
    ('''                line3="deterministic grader · no judge model",
                note="One pilot run — not accuracy, not a ranking.",
                note2="the agent was online and used the authors' public replication package",''',
     '''                line3="deterministic grader · the agent was online and used the authors' public code",
                note="One pilot run — not accuracy, not a ranking.",
                note2="",'''),
    ('''            (690, 712): ("pilot-run-scope", (550, 692, 820, 66), (1376, 764), "warn", (1226, 790))},''',
     '''            (690, 712): ("pilot-run-scope", (550, 690, 820, 48), (1376, 746), "warn", (1226, 790))},'''),
    ('''         say="Read it with its limits. {net}The agent was online and used the authors' public code: {rep}this is a replication from published materials, not an independent derivation. {why}And its reason for choosing column one was never recorded.",
         hold=1.8,''',
     '''         say="Read it with its limits. {net}The agent was online and used the authors' public code: {rep}this is a replication from published materials, not an independent derivation. {why}And its reason for choosing column one was never recorded.",
         hold=1.3,'''),
])

patch("story/econ_scenes.py", [
    ('''    G.rrect(cv, IX0, 314, 430, 46, 23, fill=G.BRAND_TINT, stroke=G.SCORER, sw=1.4, a=a * kg)
    G.icon_role(cv, "scorer", IX0 + 28, 337, G.SCORER, a=a * kg, s=9)
    G.text(cv, d["grader"], IX0 + 50, 325, size=16, c=G.FG, kind="mono", a=a * kg)''',
     '''    gw = G.measure(d["grader"], 16, 500, "mono")[0] + 78
    G.rrect(cv, IX0, 314, gw, 46, 23, fill=G.BRAND_TINT, stroke=G.SCORER, sw=1.4, a=a * kg)
    G.icon_role(cv, "scorer", IX0 + 28, 337, G.SCORER, a=a * kg, s=9)
    G.text(cv, d["grader"], IX0 + 50, 325, size=16, c=G.FG, kind="mono", a=a * kg)'''),
    ('''    xs = [IX0 + 20, IX0 + 226, IX0 + 404, IX0 + 582, IX0 + 716]''',
     '''    xs = [IX0 + 20, IX0 + 216, IX0 + 376, IX0 + 540, IX0 + 656]'''),
    ('''    for j, ln in enumerate(d["log"]):
        hot = j == d.get("log_hot", -1)
        G.text(cv, ln, IX0 + 22 + j * 300, y + 48, size=16,''',
     '''    for j, ln in enumerate(d["log"]):
        hot = j == d.get("log_hot", -1)
        G.text(cv, ln, IX0 + 22 + j * 300, y + 56, size=16,'''),
])

patch("tools/build_econ_data.py", [
    ('''    "materials": [{"name": "data_for_analysis.dta", "kind": "dta", "opened_step": 7}],''',
     '''    "materials": [{"name": "data_for_analysis.dta", "kind": "dta", "label": "data", "opened_step": 7}],'''),
])
print("done")
