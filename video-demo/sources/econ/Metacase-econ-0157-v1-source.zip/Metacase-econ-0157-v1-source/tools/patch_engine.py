"""One-off: make the HR v3 engine take harness/task wording from the story's CONF.

Every default stays what the Finance and HR stories use, so `render.py hr` is unchanged.
Run once from the project root:  python tools/patch_engine.py
"""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
E = os.path.join(ROOT, "engine")


def patch(name, pairs):
    p = os.path.join(E, name)
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        n = s.count(a)
        assert n == 1, (name, n, a[:70])
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8", newline="\n").write(s)
    print("patched", name, len(pairs))


patch("rundata.py", [
    ('''    "hr": (os.path.join(BASE, "data", "hr.json"),
           os.path.join(BASE, "data", "hr.requests.jsonl")),
}''', '''    "hr": (os.path.join(BASE, "data", "hr.json"),
           os.path.join(BASE, "data", "hr.requests.jsonl")),
    # econ-0157: gemini-3.8-flash x Codex 0.169.0, built by tools/build_econ_data.py
    "econ": (os.path.join(BASE, "data", "econ.json"),
             os.path.join(BASE, "data", "econ.requests.jsonl")),
}'''),
])

patch("gfx.py", [
    ('''               "py": (240, 200, 90)}''',
     '''               "py": (240, 200, 90), "dta": (143, 173, 214), "json": (115, 213, 156)}'''),
])

patch("ui.py", [
    ('''CHAPTERS = ["TASK", "AGENT", "HARNESS", "CHECK", "RESULT"]''',
     '''CHAPTERS = ["TASK", "AGENT", "HARNESS", "CHECK", "RESULT"]
TRACK_LABEL = "BUSINESS ANALYSIS"   # set from CONF["track_label"] by compose.Ctx'''),
    ('''    G.text(cv, "BUSINESS ANALYSIS", 92 + w + 16, 37, size=12, c=G.DIM, kind="brandmono", ls=1.6)''',
     '''    G.text(cv, TRACK_LABEL, 92 + w + 16, 37, size=12, c=G.DIM, kind="brandmono", ls=1.6)'''),
])

patch("compose.py", [
    ('''        self.conf = self.story.CONF
''', '''        self.conf = self.story.CONF
        U.TRACK_LABEL = self.conf.get("track_label", "BUSINESS ANALYSIS")
'''),
    ('''        vals[3] = ("JUDGE", "sealed")''', '''        vals[3] = (vals[3][0], "sealed")'''),
    ('''    todos = ctx.run.plan(T) if T is not None else None
''', '''    todos = ctx.run.plan(T) if T is not None else None
    if hasattr(ctx.story, "plan"):   # a story may supply the left panel's rows itself
        todos = ctx.story.plan(T)
'''),
])

patch("panels.py", [
    ('''    G.kicker(cv, "AGENT'S PLAN · TodoWrite", x + 50, y + 21, c=G.HARNESS, a=a, size=14)''',
     '''    G.kicker(cv, conf.get("plan_kicker", "AGENT'S PLAN · TodoWrite"), x + 50, y + 21, c=G.HARNESS, a=a, size=14)'''),
    ('''        G.text(cv, "no plan written yet", x + w / 2, y0 + mid * rh + 6, size=15, c=G.DIM, kind="mono", a=a, align="center")''',
     '''        G.text(cv, conf.get("plan_empty", "no plan written yet"), x + w / 2, y0 + mid * rh + 6, size=15, c=G.DIM, kind="mono", a=a, align="center")'''),
    ('''        G.text(cv, _short(conf, t["text"]), x + 56, yy + 7, size=16, c=lc, weight=500, a=ra, maxlines=1, width=w - 150)''',
     '''        G.text(cv, _short(conf, t["text"]), x + 56, yy + 7, size=16, c=lc, weight=500, a=ra, maxlines=1,
               width=w - (150 if not t.get("note") else 190))
        if t.get("note"):
            G.text(cv, t["note"], x + w - 22, yy + 10, size=12.5, c=G.DIM if st != "completed" else G.FG, kind="mono",
                   a=ra, align="right")'''),
    ('''    G.text(cv, "the agent's own checklist · not a grade", x + w / 2, y + h - 30, size=12.5, c=G.DIM, kind="mono", a=a * 0.85 * footer_a, align="center")''',
     '''    G.text(cv, conf.get("plan_footer", "the agent's own checklist · not a grade"), x + w / 2, y + h - 30, size=12.5, c=G.DIM, kind="mono", a=a * 0.85 * footer_a, align="center")'''),
    ('''    for lab, col in (("Bash", G.SANDBOX), ("TodoWrite", G.HARNESS), ("Read/Edit/Write", G.WARN)):''',
     '''    for lab, col in conf.get("ledger_legend", (("Bash", G.SANDBOX), ("TodoWrite", G.HARNESS), ("Read/Edit/Write", G.WARN))):'''),
    ('''    G.kicker(cv, "/app/output", x + 54, y + 19, c=G.SANDBOX, a=a, size=14)''',
     '''    G.kicker(cv, conf.get("out_dir", "/app/output"), x + 54, y + 19, c=G.SANDBOX, a=a, size=14)'''),
    ('''    if not files:
        for j, kind in enumerate(("docx", "xlsx")):''',
     '''    kinds = tuple(conf.get("out_kinds", ("docx", "xlsx")))
    if not files:
        for j, kind in enumerate(kinds):'''),
    ('''    order = {"docx": 0, "xlsx": 1}''', '''    order = {k: j for j, k in enumerate(kinds)}'''),
])

patch("scenes.py", [
    ('''    title = sh.d.get("title", "Claude Code · tool loop")''',
     '''    title = sh.d.get("title", ctx.conf.get("loop_title", "Claude Code · tool loop"))'''),
])

patch("scenes_x.py", [
    # the environment
    ('''    container(cv, a, IX0, 314, cw, 520)
    G.text(cv, "claude 2.1.114 · python3 · LibreOffice", IX0 + cw - 20, 326, size=12.5, c=G.DIM, kind="mono", a=a, align="right")
    lab = f"/app/input_files · {conf['inputs']} files · read-only"''',
     '''    container(cv, a, IX0, 314, cw, 520, label=conf.get("container_label", "Docker container · Harbor 0.20.0"))
    G.text(cv, conf.get("container_tools", "claude 2.1.114 · python3 · LibreOffice"), IX0 + cw - 20, 326, size=12.5, c=G.DIM, kind="mono", a=a, align="right")
    lab = conf.get("input_label") or f"/app/input_files · {conf['inputs']} files · read-only"'''),
    ('''        G.text(cv, "/app/output", IX0 + 58, oy, size=15, c=G.FG, kind="mono", a=a * ko)''',
     '''        G.text(cv, conf.get("out_dir", "/app/output"), IX0 + 58, oy, size=15, c=G.FG, kind="mono", a=a * ko)'''),
    # the whole run
    ('''        col = {"Bash": G.SANDBOX, "TodoWrite": G.HARNESS}.get(s["tool"], G.WARN)''',
     '''        col = {"Bash": G.SANDBOX, "TodoWrite": G.HARNESS, "exec_command": G.SANDBOX}.get(s["tool"], G.WARN)'''),
    ('''        G.text(cv, d["foot"], IX0, 778 if sh.id in ("f23", "h16") else 790, size=15, c=G.DIM, kind="mono", a=a,
               maxlines=None if sh.id in ("f23", "h16") else 1, width=210 if sh.id in ("f23", "h16") else 916)''',
     '''        wrap = sh.id in ("f23", "h16") or d.get("foot_wrap")
        G.text(cv, d["foot"], IX0, 778 if wrap else 790, size=15, c=G.DIM, kind="mono", a=a,
               maxlines=None if wrap else 1, width=d.get("foot_width", 210) if wrap else 916)'''),
    # what the model sees
    ('''    vmax = 110000
    Y = lambda v: y_bot - (y_bot - y_top) * v / vmax
    for v in (25000, 50000, 75000, 100000):''',
     '''    vmax = d.get("vmax", 110000)
    Y = lambda v: y_bot - (y_bot - y_top) * v / vmax
    for v in d.get("vticks", (25000, 50000, 75000, 100000)):'''),
    ('''        G.text(cv, d["foot"], IX0, 790, size=15, c=G.DIM, kind="mono", a=a,
               maxlines=None if sh.id in ("f24", "h17") else 1, width=450 if sh.id in ("f24", "h17") else 916)''',
     '''        wrap = sh.id in ("f24", "h17") or d.get("foot_wrap")
        G.text(cv, d["foot"], IX0, 790, size=15, c=G.DIM, kind="mono", a=a,
               maxlines=None if wrap else 1, width=450 if wrap else 916)'''),
    # same container, new phase
    ('''    G.text(cv, "Claude Code · agent session", cx + 70, cy + 72, size=16, c=G.mix(G.FG, G.DIM, ks), weight=600, a=a)
    G.text(cv, "model: qwen3.7-max", cx + 44, cy + 110, size=14, c=G.DIM, kind="mono", a=a)''',
     '''    hc = ctx.conf.get("handoff", {})
    G.text(cv, hc.get("session", "Claude Code · agent session"), cx + 70, cy + 72, size=16, c=G.mix(G.FG, G.DIM, ks), weight=600, a=a)
    G.text(cv, hc.get("model", "model: qwen3.7-max"), cx + 44, cy + 110, size=14, c=G.DIM, kind="mono", a=a)'''),
    ('''    G.text(cv, "/app/output · submitted files", cx + 58, cy + 236, size=15, c=G.FG, kind="mono", a=a)
    for j, kind in enumerate(("docx", "xlsx")):''',
     '''    G.text(cv, hc.get("out", "/app/output · submitted files"), cx + 58, cy + 236, size=15, c=G.FG, kind="mono", a=a)
    for j, kind in enumerate(ctx.conf.get("out_kinds", ("docx", "xlsx"))):'''),
    ('''        G.text(cv, "RewardKit · judge sessions run as root", cx + 484, cy + 400, size=17, c=G.FG, weight=600, a=a * kj)
        G.text(cv, "they read /app/output; inputs only to check facts", cx + 462, cy + 429, size=14, c=G.DIM, kind="mono", a=a * kj)
        G.text(cv, "no channel back to the finished agent run", cx + 462, cy + 453, size=14, c=G.SCORER, kind="mono", a=a * kj)''',
     '''        sc = hc.get("scorer", ("RewardKit · judge sessions run as root",
                               "they read /app/output; inputs only to check facts",
                               "no channel back to the finished agent run"))
        G.text(cv, sc[0], cx + 484, cy + 400, size=17, c=G.FG, weight=600, a=a * kj)
        G.text(cv, sc[1], cx + 462, cy + 429, size=14, c=G.DIM, kind="mono", a=a * kj)
        G.text(cv, sc[2], cx + 462, cy + 453, size=14, c=G.SCORER, kind="mono", a=a * kj)'''),
])

patch("reference_bookends.py", [
    ('''    names[3] = ("scorer", "independent judge")''',
     '''    names[3] = ("scorer", ctx.conf.get("open_scorer", "independent judge"))'''),
    ('''    _text(cv, "Scenarios contributed by Shanghai University of Finance and Economics",
          482, 13, G.DIM, alpha(1400), kind="brandmono", weight=400)''',
     '''    _text(cv, ctx.conf.get("outro_credit", "Scenarios contributed by Shanghai University of Finance and Economics"),
          482, 13, G.DIM, alpha(1400), kind="brandmono", weight=400)'''),
])
print("done")
