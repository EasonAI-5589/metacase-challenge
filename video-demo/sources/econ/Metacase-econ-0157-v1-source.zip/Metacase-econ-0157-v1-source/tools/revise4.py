"""One-off (already applied): fixes after the first look at the stills of the Terminus-2 story.

- header: wordmark and track label sized so that "Global Metacase Challenge" plus the
  label clear the chapter tabs (same sizes as the social-science video);
- task scene: number of columns and badge width can be set per shot;
- agent chapter reordered so that the header clock never runs backwards;
- text that did not fit its box."""
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def patch(rel, pairs):
    path = os.path.join(ROOT, rel)
    s = open(path, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (rel, s.count(a), a[:80])
        s = s.replace(a, b)
    open(path, "w", encoding="utf-8", newline="\n").write(s)
    print("patched", rel, len(pairs))


patch("engine/ui.py", [
    ('''    w = B.wordmark(cv, 92, 23, 30)
    G.text(cv, TRACK_LABEL, 92 + w + 16, 37, size=12, c=G.DIM, kind="brandmono", ls=1.6)''',
     '''    w = B.wordmark(cv, 92, 26, 25)
    G.text(cv, TRACK_LABEL, 92 + w + 14, 37, size=11.5, c=G.DIM, kind="brandmono", ls=1.4)'''),
])
patch("engine/scenes_x.py", [
    ('''    G.rrect(cv, IX0, 314, 430, 46, 23, fill=G.BRAND_TINT, stroke=G.BRAND, sw=1.4, a=a * kb)''',
     '''    G.rrect(cv, IX0, 314, d.get("pill_w", 430), 46, 23, fill=G.BRAND_TINT, stroke=G.BRAND, sw=1.4, a=a * kb)'''),
    ('''    items = d["items"]
    cols = 3
    cw = (IX1 - IX0 - 2 * 20) / cols''',
     '''    items = d["items"]
    cols = d.get("cols", 3)
    cw = (IX1 - IX0 - (cols - 1) * 20) / cols'''),
])

P = os.path.join(ROOT, "story", "econ.py")
s = open(P, encoding="utf-8").read()


def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80])
    s = s.replace(a, b)


# ---- reorder the agent chapter: e08, e10, e12, e14, e15, e11, e16, e13, e17, e18, e19, e20
head = s.index("SHOTS = [")
tail = s.index("\n]\n", head)
body = s[head:tail]
blocks = {}
for m in re.finditer(r'    dict\(id="(e\d\d)"', body):
    blocks[m.group(1)] = m.start()
ids = list(blocks)
spans = {}
for i, sid in enumerate(ids):
    a = blocks[sid]
    e = blocks[ids[i + 1]] if i + 1 < len(ids) else len(body)
    spans[sid] = body[a:e]
# chapter comments ride at the end of the preceding block; detach them
comment = {}
for sid in ids:
    m = re.search(r"\n    # -+ \d\d [A-Z]+\n$", spans[sid])
    if m:
        comment[sid] = spans[sid][m.start() + 1:]
        spans[sid] = spans[sid][:m.start() + 1].rstrip("\n") + "\n"
order = ["e00", "e01", "e02", "e03", "e04", "e05", "e07", "e08", "e10", "e12", "e14", "e15", "e11", "e16", "e13",
         "e17", "e18", "e19", "e20", "e21", "e23", "e24", "e25", "e26", "e27", "e28", "e29", "e30"]
assert sorted(order) == sorted(ids), (sorted(set(ids) ^ set(order)))
after_comment = {"e07": comment.get("e07"), "e20": comment.get("e20"), "e23": comment.get("e23"), "e27": comment.get("e27")}
out = body[:blocks[ids[0]]]
for sid in order:
    blk = spans[sid]
    if not blk.endswith("\n"):
        blk += "\n"
    out += blk
    if after_comment.get(sid):
        out += "\n" + after_comment[sid]
s = s[:head] + out.rstrip("\n") + s[tail:]

# ---- narration that depends on the new order
rep('''say="{srch}It also searches for the authors' script: {where}GitHub, Google, Bing, Harvard Dataverse. {nf}It does not find it.",''',
    '''say="{srch}Meanwhile it searches for the authors' script: {where}GitHub, Google, Bing, Harvard Dataverse. {nf}It does not find it.",''')
rep('''say="{w}The five cohorts hold {n}fourteen, eight, sixty-five, seventy-nine and fourteen treated observations. {eff}Their shares weight the cohort effects: {sum}minus sixty-six point three three.",
         en="The five cohorts hold 14, 8, 65, 79 and 14 treated observations. Their shares weight the cohort effects: −66.33.",''',
    '''say="{w}That number is a weighted sum. {n}The five cohorts hold fourteen, eight, sixty-five, seventy-nine and fourteen treated observations; {eff}their shares weight {sum}the five cohort effects.",
         en="That number is a weighted sum. The five cohorts hold 14, 8, 65, 79 and 14 treated observations; their shares weight the five cohort effects.",''')

# ---- traces: the header clock is non-decreasing through the chapter
rep('''st=("model", "commands 5 and 13 · eventstudyinteract.ado · reghdfe.mata"), trace=(23.7, 74.0)),''',
    '''st=("model", "commands 5 and 13 · eventstudyinteract.ado · reghdfe.mata"), trace=(8.5, 33.6)),''')
rep('''st=("model", "commands 7–16 · 3a_analysis_ncse.do · not found"), trace=(33.7, 104.3)),''',
    '''st=("model", "commands 7–16 · 3a_analysis_ncse.do · not found"), trace=(80.1, 104.3)),''')
rep('''st=("sandbox", "commands 11 and 17 · 180 treated observations in five cohorts"), trace=(60.1, 124.5)),''',
    '''st=("sandbox", "commands 11 and 17 · 180 treated observations in five cohorts"), trace=(124.5, 124.5)),''')
rep('''st=("sandbox", "command 11 · recorded assistant text · +74.0 s"), trace=(60.1, 74.0)),''',
    '''st=("sandbox", "command 11 · recorded assistant text · +74.0 s"), trace=(59.0, 74.0)),''')
rep('''st=("sandbox", "commands 13–14 and 19 · reghdfe.mata"), trace=(74.0, 150.5)),''',
    '''st=("sandbox", "commands 13–14 · reghdfe.mata"), trace=(74.0, 80.1)),''')
rep('''"e10": dict(as_="loop", accent="model", tk=[("net", 23.7), ("gh", 24.7), ("mata", 74.0)], phases=[dict(''',
    '''"e10": dict(as_="loop", accent="model", tk=[("net", 23.7), ("gh", 24.7), ("mata", 33.6)], phases=[dict(''')
rep('''"e11": dict(as_="loop", accent="model", tk=[("srch", 34.7), ("where", 60.1), ("nf", 104.3)], phases=[dict(''',
    '''"e11": dict(as_="loop", accent="model", tk=[("srch", 80.1), ("nf", 104.3)], phases=[dict(''')
rep('''tk=[("w", 60.1), ("eff", 124.5), ("sum", 124.5)],
''', '')
rep('''"e14": dict(as_="loop", tk=[("sing", 60.1), ("n", 74.0)], phases=[dict(''',
    '''"e14": dict(as_="loop", tk=[("sing", 60.1), ("before", 74.0)], phases=[dict(''')
rep('''"e15": dict(as_="loop", tk=[("mata", 74.0), ("line", 80.1), ("dof", 150.5)], phases=[dict(
        at=0.0, rq="COMMANDS 13, 14 AND 19 / 52",''',
    '''"e15": dict(as_="loop", tk=[("mata", 74.0), ("line", 80.1)], phases=[dict(
        at=0.0, rq="COMMANDS 13–14 / 52",''')
rep('''_SETTINGS = [
    ("Control cohort", "never inspected", None, 24.7),
    ("Estimator", "Sun–Abraham", 24.7, 47.0),
    ("Cohort weights", "5 cohorts", None, 60.1),
    ("Sample", "singletons out", None, 74.0),
    ("Variance", "two terms", None, 124.5),
    ("Degrees of freedom", "641 − 1", 74.0, 150.5),
    ("Column", "unverified", 124.5, None),
    ("Result file", "written", None, 393.7),
]''',
    '''_SETTINGS = [
    ("Control cohort", "never inspected", None, 9.6),
    ("Estimator", "Sun–Abraham", 24.7, 47.0),
    ("Cohort weights", "5 cohorts", None, 60.1),
    ("Sample", "singletons out", None, 74.0),
    ("Variance", "two terms", None, 124.5),
    ("Degrees of freedom", "641 − 1", 74.0, 124.5),
    ("Column", "unverified", 140.9, None),
    ("Result file", "written", None, 393.7),
]''')

# ---- text that did not fit
rep('''tests_lines=["reference.json · 3 numbers", "evaluate.py · the grader"],''',
    '''tests_lines=["reference.json", "evaluate.py"],''')
rep('''"e04": dict(title="The first difficulty", sub="Read the Stata source, rebuild the same algorithm in Python",
                deadline="three Stata programs · one over 4,000 lines", badge_r="tolerance: 1%",
                items=[dict(id="cohort weights", obj="1", title="Each cohort's share of treated observations", amount="", tag=""),
                       dict(id="parts of the variance", obj="2", title="The regression's, plus one for the shares",
                            amount="", tag=""),
                       dict(id="dropped observations", obj="3", title="Departments observed only once", amount="", tag=""),
                       dict(id="degrees of freedom", obj="4", title="The correction for clustered errors", amount="", tag="")],
                items_at="conv",
                pet=[(0.0, (700, 360)), ("conv", (960, 477)), ("tol", (700, 360))]),''',
    '''"e04": dict(title="The first difficulty", sub="Read the Stata source, rebuild the same algorithm in Python",
                deadline="three Stata programs · one over 4,000 lines", badge_r="tolerance: 1%", pill_w=520, cols=4,
                items=[dict(id="cohort weights", obj="1", title="Each cohort's share of treated observations", amount="", tag=""),
                       dict(id="variance parts", obj="2", title="The regression's, plus one for the shares",
                            amount="", tag=""),
                       dict(id="dropped units", obj="3", title="Departments observed only once", amount="", tag=""),
                       dict(id="d.f. correction", obj="4", title="Degrees of freedom, for clustered errors", amount="", tag="")],
                items_at="conv",
                pet=[(0.0, (700, 360)), ("conv", (960, 477))]),''')
rep('''"e04": {(700, 360): ("grader-tolerance", (502, 314, 556, 46), (1064, 366), "brand", (840, 798)),
            (960, 477): _row("four-conventions", (502, 384, 916, 250), "model")},''',
    '''"e04": {(700, 360): ("three-stata-programs", (502, 314, 520, 46), (1028, 366), "brand", (800, 798)),
            (960, 477): _row("four-conventions", (502, 384, 916, 186), "model")},''')
rep('''lines=["curl … raw.githubusercontent.com/", "  lsun20/EventStudyInteract/", "  main/eventstudyinteract.ado",
                           "", "6497 /output/eventstudyinteract.ado"]),''',
    '''lines=["curl … raw.githubusercontent", "  .com/lsun20/", "  EventStudyInteract/main/",
                           "  eventstudyinteract.ado", "wc -c: 6497 bytes"]),''')
rep('''lines=["curl … raw.githubusercontent.com/", "  sergiocorreia/reghdfe/", "  master/src/reghdfe.mata"]),''',
    '''lines=["curl … raw.githubusercontent", "  .com/sergiocorreia/", "  reghdfe/master/src/", "  reghdfe.mata"]),''')
rep('''dict(kick="WHAT THE NETWORK WAS USED FOR", title="General-purpose programs",''',
    '''dict(kick="NETWORK USE", title="General-purpose programs",''')
rep('''foot="the estimation command, and the regression program it depends on")],''', '''foot="both from GitHub")],''')
rep('''stages=["gpt-6-astra", "mark_task_complete", "—", "done"], dim=[2],''',
    '''stages=["gpt-6-astra", "task complete", "—", "done"], dim=[2],''')
rep('''(1050, 560): ("searching-stretch", (934, 314, 312, 300), (1424, 600), "warn", (1310, 798))},''',
    '''(1050, 560): ("after-the-estimate-was-confirmed", (940, 314, 478, 250), (1424, 439), "warn", (1310, 798))},''')

open(P, "w", encoding="utf-8", newline="\n").write(s)
print("story updated")
