"""Which cues make the sight line cross the robot's body? python tools/collisions.py <run> [sprite set]"""
import collections
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "engine"))
sys.path.insert(0, ROOT)

import compose  # noqa: E402
import check_guide as C  # noqa: E402
from timeline import FPS  # noqa: E402

run = sys.argv[1]
ctx = compose.Ctx(run)
if len(sys.argv) > 2:
    import reference_robot
    reference_robot.set_sprites(sys.argv[2])
    ctx.guide = compose.Guide(ctx)
n = collections.Counter()
worst = {}
for f in range(ctx.tl.nframes):
    t = f / FPS
    st = ctx.guide.state(t)
    if st is None or st.get("pointer_opacity", 0) < C.VISIBLE_POINTER_OPACITY:
        continue
    g = st["geometry"]
    ov = C.interior_interval(g["hand"], st["tip"], g["body_polygon"])
    if ov is not None:
        key = (st["event"]["shot"], str(st["event"]["target"]))
        n[key] += 1
        worst[key] = max(worst.get(key, 0), ov[1] - ov[0])
print("collision frames", sum(n.values()))
for k, v in sorted(n.items()):
    print(k, v, "max interior fraction %.4f" % worst[k])
