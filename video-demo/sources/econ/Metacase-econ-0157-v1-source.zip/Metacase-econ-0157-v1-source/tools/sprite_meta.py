"""Compare the muzzle positions and body boxes of the robot sprite sets: python tools/sprite_meta.py"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for name in ("sprites", "sprites-codex", "sprites-terminus"):
    p = os.path.join(ROOT, "robot", name, "sprites.json")
    if not os.path.exists(p):
        continue
    m = json.load(open(p))
    print(name, "size", m["size"], "body", m["body"], "keys", sorted(m["sprites"][0].keys()))
    for a in (-85, -75, -60, -45, -30, -15, 0, 30):
        s = [x for x in m["sprites"] if round(x["aim"]) == a and not x["eyesClosed"]]
        if s:
            print("  ", a, "muzzle", [round(v, 1) for v in s[0]["muzzle"]], "grip", [round(v, 1) for v in s[0]["grip"]])
