"""Does the robot's sight line, or the robot itself, cover printed text?

python tools/laser_text.py <run> [frame step=3] [shot ids...]

Draws every `step`-th frame, records the stage box of every string drawn with opacity
>= 0.35, and tests it against (a) the segment from the robot's muzzle to its target while
the pointer is visible and (b) the robot's body box. Captions and the status line under
them are not counted (the robot never reaches them). Writes build/<run>/laser-text-qa.json.
"""
import collections
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "engine"))
sys.path.insert(0, ROOT)

import skia  # noqa: E402
import gfx as G  # noqa: E402
import compose  # noqa: E402
import check_guide as C  # noqa: E402
from timeline import FPS  # noqa: E402

run = sys.argv[1]
step = int(sys.argv[2]) if len(sys.argv) > 2 else 3
only = set(sys.argv[3:])
ctx = compose.Ctx(run)
PAD = 2.0
boxes = []
orig = G.text


def text(cv, s, x, y, size=18, c=G.FG, weight=500, kind="sans", a=1.0, align="left",
         width=None, ls=0.0, lh=None, maxlines=None):
    w, h = orig(cv, s, x, y, size=size, c=c, weight=weight, kind=kind, a=a, align=align,
                width=width, ls=ls, lh=lh, maxlines=maxlines)
    if s and a >= 0.35 and w > 0:
        if width is None:
            x0 = x if align == "left" else (x - w / 2 if align == "center" else x - w)
            x1 = x0 + w
        else:
            ll = min(G.measure(s, size, weight, kind, ls, width)[0], width)
            x0 = x if align == "left" else (x + (width - ll) / 2 if align == "center" else x + width - ll)
            x1 = x0 + ll
        m = cv.getTotalMatrix()
        pts = m.mapPoints([skia.Point(x0, y), skia.Point(x1, y + h)])
        bx0, bx1 = sorted((pts[0].x(), pts[1].x()))
        by0, by1 = sorted((pts[0].y(), pts[1].y()))
        boxes.append((str(s), bx0 - PAD, by0 - PAD, bx1 + PAD, by1 + PAD))
    return w, h


G.text = text


def seg_hits(p, q, box):
    """Liang-Barsky: does segment p-q enter the rectangle?"""
    _, x0, y0, x1, y1 = box
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for pp, qq in ((-dx, p[0] - x0), (dx, x1 - p[0]), (-dy, p[1] - y0), (dy, y1 - p[1])):
        if pp == 0:
            if qq < 0:
                return False
        else:
            r = qq / pp
            if pp < 0:
                t0 = max(t0, r)
            else:
                t1 = min(t1, r)
            if t0 > t1:
                return False
    return True


surf = skia.Surface(G.W, G.H)
cv = surf.getCanvas()
laser = collections.Counter()
body = collections.Counter()
for f in range(0, ctx.tl.nframes, step):
    T = f / FPS
    sh, t, _ = ctx.tl.locate(T)
    if only and sh.id not in only:
        continue
    del boxes[:]
    compose.frame(cv, ctx, T)
    st = ctx.guide.state(T)
    if st is None:
        continue
    g = st["geometry"]
    poly = g["body_polygon"]
    rx0, rx1 = min(p[0] for p in poly), max(p[0] for p in poly)
    ry0, ry1 = min(p[1] for p in poly), max(p[1] for p in poly)
    show = st.get("pointer_opacity", 0) >= C.VISIBLE_POINTER_OPACITY
    for b in boxes:
        if b[2] > 884:                       # captions and the status line
            continue
        if show and seg_hits(g["hand"], st["tip"], b):
            laser[(sh.id, str(st["event"]["target"]), b[0][:60])] += 1
        if st.get("opacity", 1.0) > 0.3 and b[1] < rx1 and b[3] > rx0 and b[2] < ry1 and b[4] > ry0:
            body[(sh.id, str(st["event"]["target"]), b[0][:60])] += 1
rows = [dict(kind="laser", shot=k[0], target=k[1], text=k[2], seconds=round(n * step / FPS, 2)) for k, n in sorted(laser.items())]
rows += [dict(kind="robot", shot=k[0], target=k[1], text=k[2], seconds=round(n * step / FPS, 2)) for k, n in sorted(body.items())]
if not only:
    out = os.path.join(ROOT, "build", run, "laser-text-qa.json")
    json.dump(dict(run=run, frame_step=step, padding_px=PAD, findings=rows), open(out, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(out)
print("laser over text:", len(laser), "| robot over text:", len(body))
for r in rows:
    print(" ", r["kind"], r["shot"], r["target"], "%.2fs" % r["seconds"], "|", r["text"])
