"""Third one-off patch: colour tool steps by what the call did (`act`), for Terminus-2 runs."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
E = os.path.join(ROOT, "engine")


def patch(name, pairs):
    p = os.path.join(E, name)
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        n = s.count(a)
        assert n == 1, (name, n, a[:70])
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8", newline="\n").write(s)
    print("patched", name, len(pairs))


patch("panels.py", [
    ('''TOOL_COL = {"bash": G.SANDBOX, "todo": G.HARNESS, "write": G.WARN, "edit": G.WARN, "read": G.BRAND}''',
     '''TOOL_COL = {"bash": G.SANDBOX, "todo": G.HARNESS, "write": G.WARN, "edit": G.WARN, "read": G.BRAND}
# Terminus-2 has one tool for everything typed into the terminal; data/<run>.json marks what each call did.
ACT_COL = {"command": G.SANDBOX, "wait": (92, 104, 124), "interrupt": G.WARN, "complete": G.HARNESS}'''),
    ('''        col = TOOL_COL.get(G_kind(tools[k]["tool"]), G.SANDBOX) if on else (34, 43, 57)''',
     '''        col = (ACT_COL.get(tools[k].get("act")) or TOOL_COL.get(G_kind(tools[k]["tool"]), G.SANDBOX)) if on else (34, 43, 57)'''),
])
patch("scenes_x.py", [
    ('''        col = {"Bash": G.SANDBOX, "TodoWrite": G.HARNESS, "exec_command": G.SANDBOX}.get(s["tool"], G.WARN)''',
     '''        col = {"Bash": G.SANDBOX, "TodoWrite": G.HARNESS, "exec_command": G.SANDBOX}.get(s["tool"], G.WARN)
        if s.get("act"):
            import panels as P
            col = P.ACT_COL.get(s["act"], col)'''),
])
print("done")
