"""One-off (already applied): header label that clears the chapter tabs; task cards may omit the number pill."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def patch(rel, pairs):
    path = os.path.join(ROOT, rel)
    s = open(path, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (rel, s.count(a), a[:80])
        s = s.replace(a, b)
    open(path, "w", encoding="utf-8", newline="\n").write(s)
    print("patched", rel, len(pairs))


patch("engine/scenes_x.py", [
    ('''        U.pill(cv, it["obj"], x + cw - 14, yy + 12, G.DIM, a=k, size=12.5, align="right")''',
     '''        if it.get("obj"):
            U.pill(cv, it["obj"], x + cw - 14, yy + 12, G.DIM, a=k, size=12.5, align="right")'''),
])
patch("story/econ.py", [
    ('''track_label="ECONOMETRIC REPLICATION",''', '''track_label="ECONOMETRICS",'''),
    ('''items=[dict(id="cohort weights", obj="1", title="Each cohort's share of treated observations", amount="", tag=""),
                       dict(id="variance parts", obj="2", title="The regression's, plus one for the shares",
                            amount="", tag=""),
                       dict(id="dropped units", obj="3", title="Departments observed only once", amount="", tag=""),
                       dict(id="d.f. correction", obj="4", title="Degrees of freedom, for clustered errors", amount="", tag="")],''',
     '''items=[dict(id="cohort weights", obj="", title="Each cohort's share of treated observations", amount="", tag=""),
                       dict(id="variance parts", obj="", title="The regression's, plus one for the shares",
                            amount="", tag=""),
                       dict(id="dropped units", obj="", title="Departments observed only once", amount="", tag=""),
                       dict(id="d.f. correction", obj="", title="Degrees of freedom, for clustered errors", amount="", tag="")],'''),
])
