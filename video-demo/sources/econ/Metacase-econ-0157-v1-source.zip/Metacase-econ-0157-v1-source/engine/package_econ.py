"""Package the econ-0157 replay video (gpt-6-astra x Terminus-2 2.0.0) with its validation records.

usage: python engine/package_econ.py
Requires the full build/econ/econ.mp4, its render receipt and font-selection sidecar, and
the two text audits (tools/screen_text.py econ, tools/laser_text.py econ).

Writes deliver/assets/video/econ-0157-replay.mp4, its poster, and deliver/docs/video/econ/.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import compose  # noqa: E402
import rundata  # noqa: E402
from package import (CHAPTERS, FFMPEG, probe, read_json, reference_details,  # noqa: E402
                     relative, run_checked, runtime_versions, sha, write_json)
from timeline import FPS  # noqa: E402

RUN = "econ"
VERSION = "econ-0157-metacase-v1"
NAME, DOC = "econ-0157-replay", "econ"
README = "README-econ-v1.md"
POSTER_SHOT, POSTER_CUE, POSTER_AFTER = "e13", "sum", 1.2   # the cohort weights with their weighted sum


def _portable_fonts(source_path):
    """Font selections without workstation paths; macOS records some faces as a family description, not a file."""
    record = read_json(source_path)
    for face in record["fonts"].values():
        source = face["source"]
        if os.path.isfile(source):
            face["font_file_sha256"] = sha(source)
            try:
                face["source"] = relative(source)
                face["source_base"] = "editable source root"
            except ValueError:
                face["source"] = f"system-fonts/{os.path.basename(source)}"
                face["source_base"] = "operating-system font directory; font not redistributed"
        else:
            face["source"] = " / ".join(os.path.basename(part.strip()) for part in source.split(" / "))
            face["source_base"] = "operating-system font, selected by family name; not redistributed"
    return record


def main():
    ctx = compose.Ctx(RUN)
    tl = ctx.tl
    build = os.path.join(ROOT, "build", RUN)
    source_mp4 = os.path.join(build, f"{RUN}.mp4")
    source_fonts = os.path.join(build, f"{RUN}.font-selection.json")
    source_receipt = os.path.join(build, f"{RUN}.render-receipt.json")
    text_audit = os.path.join(build, "screen-text-qa.json")
    cover_audit = os.path.join(build, "laser-text-qa.json")
    for required in (source_mp4, source_fonts, source_receipt, text_audit, cover_audit):
        if not os.path.isfile(required):
            raise FileNotFoundError(f"Missing: {required}")
    receipt = read_json(source_receipt)
    if receipt["output_sha256"] != sha(source_mp4):
        raise RuntimeError("Full video does not match its render receipt")
    for path, expected in receipt["inputs"]["source_sha256"].items():
        if sha(Path(ROOT, path)) != expected:
            raise RuntimeError(f"Rendered input changed before packaging: {path}")
    fonts = read_json(source_fonts)["fonts"]
    if not set(receipt["inputs"]["font_sha256"]) <= set(n for n, f in fonts.items() if os.path.isfile(f["source"])):
        raise RuntimeError("Font selections do not match the render receipt")
    from render import verify_video
    verify_video(source_mp4, tl.nframes)

    src_files = sorted(Path(ROOT, "engine").glob("*.py")) + sorted(Path(ROOT, "tools").glob("*.py"))
    src_files += [Path(ROOT, "story", "econ.py"), Path(ROOT, "story", "econ_scenes.py"), Path(ROOT, "story", "fin_en.py"),
                  Path(ROOT, "data", "econ.json"), Path(ROOT, "data", "econ.requests.jsonl"),
                  Path(ROOT, README), Path(ROOT, "requirements-render.txt"),
                  Path(ROOT, "robot", "sprites-terminus", "sprites.json"), Path(ROOT, "robot", "sprite.html"),
                  Path(ROOT, "robot", "render_sprites.mjs"), Path(ROOT, "fonts", "SpaceMono-400.ttf")]
    src_files += sorted(Path(ROOT, "brand").glob("*"))
    source_hashes = {relative(f): sha(f) for f in src_files}

    from check_guide import audit
    qa = audit(RUN)
    qa["source_snapshot_sha256"] = source_hashes
    qa["source_snapshot_phase"] = "packaging"
    qa_path = os.path.join(build, "guide-geometry-qa.json")
    write_json(qa_path, qa)
    if not qa["passed"]:
        raise RuntimeError(f"Guide geometry audit failed; inspect {relative(qa_path)}")

    texts = read_json(text_audit)
    cover = read_json(cover_audit)
    if texts["cjk"] or texts["banned"]:
        raise RuntimeError("On-screen text audit found Chinese text or a name this video must not show")

    out_v = os.path.join(ROOT, "deliver", "assets", "video")
    out_d = os.path.join(ROOT, "deliver", "docs", "video", DOC)
    for d in (out_v, out_d):
        shutil.rmtree(d, ignore_errors=True)
        os.makedirs(d)
    mp4 = os.path.join(out_v, f"{NAME}.mp4")
    shutil.copyfile(source_mp4, mp4)
    sh = next(s for s in tl.shots if s.id == POSTER_SHOT)
    png = os.path.join(build, "poster.png")
    compose.render_still(ctx, sh.start + min(sh.cue(POSTER_CUE) + POSTER_AFTER, sh.dur - 0.9), png)
    poster = os.path.join(out_v, f"{NAME}-poster.jpg")
    run_checked([FFMPEG, "-v", "error", "-y", "-i", png, "-q:v", "2", poster])
    shutil.copyfile(os.path.join(build, "captions.en.srt"), os.path.join(out_d, "captions.en.srt"))
    shutil.copyfile(qa_path, os.path.join(out_d, "guide-geometry-qa.json"))
    shutil.copyfile(source_receipt, os.path.join(out_d, "render-receipt.json"))
    write_json(os.path.join(out_d, "font-selection.json"), _portable_fonts(source_fonts))
    shutil.copyfile(os.path.join(ROOT, README), os.path.join(out_d, "README.md"))
    write_json(os.path.join(out_d, "cjk-onscreen.json"), texts["cjk"])
    write_json(os.path.join(out_d, "text-timing.json"), {
        "rule": "visible >= 0.3 s + words / 4", "frame_step": texts["frame_step"], "strings_checked": texts["strings"],
        "with_chinese_characters": texts["cjk"], "names_this_video_must_not_show": texts["banned"],
        "below_reading_time": [dict(shot=s, seconds=up, need=need, text=t) for s, up, need, t in texts["below_reading_time"]],
        "note": "The one string below the rule is the host line of the opening card, drawn by the shared bookend "
                "code exactly as in the Finance and social-science videos.",
    })
    shutil.copyfile(cover_audit, os.path.join(out_d, "text-cover-qa.json"))

    run_data = rundata.load(RUN)
    data_path, log_path = rundata.SOURCES[RUN]
    p = probe(mp4)
    prov = {
        "version": VERSION,
        "task_id": ctx.conf["task_id"],
        "run": RUN,
        "status": "built for the economics Metacase page; not yet watched end to end by a person",
        "model": "gpt-6-astra", "harness": "Terminus-2 2.0.0", "runner": "Harbor 0.24.0",
        "provider": "OpenRouter",
        "job": "pilot-20261114-or__A32__terminus-2__openai-gpt-6-astra",
        "grader": "evaluate.py (deterministic; calls no model)",
        "recorded_agent_seconds": run_data.duration,
        "model_requests": len(run_data.requests), "tool_calls": len(run_data.tool_steps),
        "reward": run_data.result["reward"],
        "duration_seconds": round(float(p["format"]["duration"]), 3),
        "frames": tl.nframes, "fps": f"{FPS}/1", "resolution": [1920, 1080],
        "streams": p["streams"],
        "voice": "edge-tts, en-US-AriaNeural, rate +12% (as in the Finance and HR videos)",
        "audio_is_synthetic": True,
        "audio_processing": "per-shot neural TTS clips placed on the shot timeline, loudnorm I=-16.5 LUFS, AAC 48 kHz mono",
        "burned_captions": ["en"],
        "renderer": "offline Skia (skia-python) frame renderer; no browser, no CDP; H.264 High via libx264",
        "runtime": runtime_versions(),
        "guide_alignment": reference_details(),
        "guide_character": {
            "character": "the homepage robot holding the arena's Terminus-2 blaster (Kenney blaster-m.glb, CC0)",
            "renderer": "robot/sprite.html?weapon=blaster-m.glb (three.js, homepage lights) -> 362 transparent sprites, "
                        "-90..+90 degrees aim in 1-degree steps, eyes open and mid-blink",
            "sprites_index": {"path": "robot/sprites-terminus/sprites.json",
                              "sha256": sha(os.path.join(ROOT, "robot", "sprites-terminus", "sprites.json"))},
            "aim_limit_degrees": ctx.conf.get("robot_max_aim"),
            "pointer": "a sight laser from the muzzle to the cue target; hidden in the parked pose",
            "routes_and_cues": f"{len(ctx.guide.events)} cues; targets in story/econ.py GUIDE and engine/guide_targets.py",
        },
        "what_each_figure_rests_on": {
            "run_record": "requests 40, tool calls 52 (39 commands, 10 waits, 1 interrupt, 2 completion marks), step times, "
                          "exit codes, tokens, every quoted command and terminal line, the quoted assistant sentences, "
                          "the docstring of the delivered main.py, deliverable sizes (106 and 3,910 bytes)",
            "grader_receipt": "reference and submitted values, errors, reward 1.0 (verifier/reward-details.json)",
            "page_copy": "the framing of the two difficulties; that the authors' script estimates the effect without "
                         "covariates (-66.33) and with five (-69.35); 'three Stata programs, one more than four thousand "
                         "lines long'; 'graded in 0.2 s'; the column-2 recomputation after the run "
                         "(-69.35, standard error 22.68, 4.6% and 9.5% off)",
            "not_from_this_run": "the column-2 figures: after the run, column 2's five covariates were put into the "
                                 "agent's delivered program (page copy 6.5). The video labels them 'recomputed afterwards'. "
                                 "They were not recomputed while building the video.",
            "editorial": [
                "The left panel 'SETTINGS TO MATCH' is a reading of the record, ticked at the trace second each setting "
                "is first settled; Terminus-2 keeps no plan and the agent wrote none.",
                "Tool calls are coloured by what the call did (command, wait, interrupt, completion mark), read from "
                "the recorded keystrokes (tools/build_econ_data.py).",
                "Shots in the AGENT chapter follow the run's clock; the search for the authors' script, which is "
                "interleaved with the other steps from +33.7 s to +103 s, is told in one shot placed at +80.1 to +104.3 s.",
                "'four other sets of covariates' are sets the agent chose itself; the video shows their size, not their members, "
                "except lngdpp.",
            ],
        },
        "network_access": {
            "statement_in_video": "The container has network access (shot e10); the agent obtained the estimator's public "
                                  "source and not the authors' script (shots e10, e11, e29).",
            "obtained": ["eventstudyinteract.ado from raw.githubusercontent.com/lsun20/EventStudyInteract (6,497 bytes, +23.7 s)",
                         "reghdfe.mata from raw.githubusercontent.com/sergiocorreia/reghdfe (+73.0 s)"],
            "requested_but_not_obtained": "avar.ado (+149.5 s): the saved file is 14 bytes, the size of a 'not found' "
                                          "response. The video therefore shows two source files, not three.",
            "searched_without_finding": "the authors' script 3a_analysis_ncse.do: GitHub code search, Google, Bing, DuckDuckGo, "
                                        "grep.app, Harvard Dataverse, DataCite, Crossref",
            "inspected_and_declined": ["doi:10.7910/DVN/DJ989N (file list only)", "doi:10.7910/DVN/SFYMSY (file list only)"],
        },
        "english_only": {
            "captions": "English only",
            "check": "tools/screen_text.py drew every 3rd frame: no string with Chinese characters reaches the screen",
        },
        "brand": {
            "mark_and_wordmark": "Metacase mark and the 'Global Metacase Challenge' wordmark, as on the live site",
            "institutions": "NTU, HKU, SUFE and Tsinghua crests and the host line of the homepage hero, unchanged from "
                            "the Finance and social-science videos",
            "site": "easonai-5589.github.io/metacase-challenge",
            "attribution": "brand/ATTRIBUTION.txt",
        },
        "validation": {
            "geometry_report": f"docs/video/{DOC}/guide-geometry-qa.json",
            "text_timing": f"docs/video/{DOC}/text-timing.json",
            "text_cover": f"docs/video/{DOC}/text-cover-qa.json",
            "font_selection": f"docs/video/{DOC}/font-selection.json",
            "render_receipt": f"docs/video/{DOC}/render-receipt.json",
            "render_input_fingerprint": receipt["input_fingerprint"],
            "geometry_passed": qa["passed"],
            "frames_checked": qa["frames_checked"],
            "cue_boundaries_checked": qa["cues_checked"],
            "text_cover_findings": len(cover["findings"]),
            "video_checks": "Full render frame count, frame rate and dimensions verified with ffprobe before packaging.",
            "review_scope": "Automated geometry and text checks plus stills of every shot; these records do not claim "
                            "full human viewing or listening.",
        },
        "chapters": [{"name": CHAPTERS[i], "start_seconds": round(a_, 3), "end_seconds": round(b_, 3)}
                     for i, (a_, b_) in enumerate(tl.chapters)],
        "shots": [{"id": s.id, "chapter": CHAPTERS[s.ch], "kind": s.kind, "start_seconds": round(s.start, 3),
                   "end_seconds": round(s.end, 3), "narration_en": s.en, "trace_seconds": s.d.get("trace")}
                  for s in tl.shots],
        "files": {
            f"assets/video/{NAME}.mp4": {"bytes": os.path.getsize(mp4), "sha256": sha(mp4)},
            f"assets/video/{NAME}-poster.jpg": {"bytes": os.path.getsize(poster), "sha256": sha(poster)},
            **{f"docs/video/{DOC}/{fn}": {"bytes": os.path.getsize(os.path.join(out_d, fn)), "sha256": sha(os.path.join(out_d, fn))}
               for fn in sorted(os.listdir(out_d)) if fn != "provenance.json"},
        },
        "sources": {
            "run_export": {"path": relative(data_path), "sha256": sha(data_path),
                           "note": "built from the trial's replay record by tools/build_econ_data.py; step times, tool names, "
                                   "exit status and the first line of each command"},
            "request_metadata": {"path": relative(log_path), "sha256": sha(log_path), "note": "time, token usage and tool names only"},
            "voice_cache_index": {"path": f"build/{RUN}/voice.json", "sha256": sha(os.path.join(build, "voice.json"))},
        },
        "editable_source": {
            "directory": ".",
            "files_sha256": source_hashes,
            "requirements": "requirements-render.txt",
            "instructions": README,
            "rebuild": [f"python -X utf8 engine/render.py {RUN} --workers 2",
                        f"python -X utf8 tools/screen_text.py {RUN}", f"python -X utf8 tools/laser_text.py {RUN}",
                        "python -X utf8 engine/package_econ.py"],
            "offline": f"Uses the {len(tl.shots)} cached narration clips and build/{RUN}/voice.json; "
                       "run voice.py only after changing the narration.",
        },
        "boundaries": [
            "Editorial replay of one recorded pilot run; no new agent run, no re-scoring.",
            "Only this run is shown; no other model or run is named.",
            "The score is one pilot run's grader verdict, not accuracy and not a ranking.",
            "The grader and the reference are absent during the agent run; Harbor copies tests into the same container afterwards.",
            "The agent rebuilt a published estimator from its public source; the video does not claim an independent derivation.",
        ],
    }
    if source_hashes != {relative(f): sha(f) for f in src_files}:
        raise RuntimeError("Editable source changed during packaging; run packaging again after edits finish")
    write_json(os.path.join(out_d, "provenance.json"), prov)
    print(json.dumps({"mp4": mp4, "duration": prov["duration_seconds"], "frames": tl.nframes, "shots": len(tl.shots),
                      "sha256": prov["files"][f"assets/video/{NAME}.mp4"]["sha256"], "poster": poster}, indent=1))


if __name__ == "__main__":
    main()
